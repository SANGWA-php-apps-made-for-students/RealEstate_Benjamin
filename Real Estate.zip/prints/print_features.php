<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';
class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database=new dbconnection();
        $db = $database->openconnection();        $sql = "select * from features  ";
   // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Cell(120, 7,'ESERCOS REAL ESTATE', 0, 0, 'L');
        $this->Cell(60, 7, 'DISTRICT: NYARUGENGE DISTRICT', 0, 0, 'L');
        $this->Ln();
        $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
        $this->Cell(60, 7, 'TELEPHONE: 07866775208 ', 0, 0, 'L');

        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(170, 7, 'features REPORT ', 0, 0, 'C');

        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", '', 14);
// </editor-fold>

$this->Cell(30, 7, 'features_id', 1, 0, 'L');$this->Cell(30, 7, 'name', 1, 0, 'L');$this->Cell(30, 7, 'property_type', 1, 0, 'L');$this->Cell(30, 7, 'category', 1, 0, 'L');
 $this->Ln();
        foreach ($db->query($sql) as $row) {
$this->cell(30, 7, $row['features_id'], 1, 0, 'L');
$this->cell(30, 7, $row['name'], 1, 0, 'L');
$this->cell(30, 7, $row['property_type'], 1, 0, 'L');
$this->cell(30, 7, $row['category'], 1, 0, 'L');


 $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->SetFont('Arial', '', 13);
$pdf->AddPage();
$pdf->LoadData();
$pdf->Output(); 
