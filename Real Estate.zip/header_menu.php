<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                real_estate
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_profile.php">profile</a>
<a href="new_property.php">property</a>
<a href="new_property_category.php">property_category</a>
<a href="new_property_subcategory.php">property_subcategory</a>
<a href="new_features.php">features</a>
<a href="new_listing.php">listing</a>
<a href="new_listing_type.php">listing_type</a>
<a href="new_image.php">image</a>
<a href="new_location.php">location</a>
<a href="new_price.php">price</a>
<a href="new_property_visitor.php">property_visitor</a>
<a href="new_basic_info.php">basic_info</a>
<a href="new_property_type.php">property_type</a>
<a href="new_province.php">province</a>
<a href="new_sector.php">sector</a>
<a href="new_cell.php">cell</a>
<a href="new_district.php">district</a>
<a href="new_listing_basic_info.php">listing_basic_info</a>
<a href="new_listing_features.php">listing_features</a>
<a href="new_basic_apartment.php">basic_apartment</a>
<a href="new_basic_commercial.php">basic_commercial</a>
<a href="new_basic_house.php">basic_house</a>
<a href="new_basic_land.php">basic_land</a>
<a href="new_basic_develop.php">basic_develop</a>
<a href="new_currency_conversion.php">currency_conversion</a>
<a href="new_property_request.php">property_request</a>
<a href="new_features_cat.php">features_cat</a>
<a href="new_sector.php">sector</a>
<a href="new_cell.php">cell</a>
<a href="new_district.php">district</a>
<a href="new_sector.php">sector</a>
<a href="new_cell.php">cell</a>
<a href="new_utilities.php">utilities</a>
<a href="new_price_utilities.php">price_utilities</a>
<a href="new_comment_replies.php">comment_replies</a>
<a href="new_agency.php">agency</a>
<a href="new_message.php">message</a>
<a href="new_msg_type.php">msg_type</a>
<a href="new_agent.php">agent</a>
<a href="new_featured.php">featured</a>
<a href="new_featured_cat.php">featured_cat</a>
<a href="new_listing_comment.php">listing_comment</a>
<a href="new_web_visits.php">web_visits</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
