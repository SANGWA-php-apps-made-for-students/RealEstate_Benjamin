
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`account_category`     VARCHAR(60) 
,`online`     VARCHAR(60) 
,`deleted`     VARCHAR(60) 
,`date_created`     Date 
, `profile`     int(11)   

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`home_phone`     VARCHAR(60) 
,`office_phone`     VARCHAR(60) 
,`mobile_phone`     VARCHAR(60) 
,`address`     VARCHAR(60) 
,`city`     VARCHAR(60) 
,`country`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property`
--

CREATE TABLE IF NOT EXISTS `property` (
`property_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`property_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_category`
--

CREATE TABLE IF NOT EXISTS `property_category` (
`property_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property_type`     int(11)   

,PRIMARY KEY (`property_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_subcategory`
--

CREATE TABLE IF NOT EXISTS `property_subcategory` (
`property_subcategory_id`     int(11) NOT NULL AUTO_INCREMENT 
, `property_subcategory`     int(11)   

,PRIMARY KEY (`property_subcategory_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `features`
--

CREATE TABLE IF NOT EXISTS `features` (
`features_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property_type`     int(11)   
, `category`     int(11)   

,PRIMARY KEY (`features_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing`
--

CREATE TABLE IF NOT EXISTS `listing` (
`listing_id`     int(11) NOT NULL AUTO_INCREMENT 
,`listing_date`     Date 
, `account`     int(11)   
, `listing_type`     int(11)   
, `property`     int(11)   
,`title`     VARCHAR(60) 
,`purpose`     VARCHAR(60) 
, `property_category`     int(11)   
, `location`     int(11)   
,`active`     VARCHAR(60) 

,PRIMARY KEY (`listing_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_type`
--

CREATE TABLE IF NOT EXISTS `listing_type` (
`listing_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`listing_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 
,`deleted`     VARCHAR(60) 
,`appear`     VARCHAR(60) 
, `listing`     int(11)   

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
`location_id`     int(11) NOT NULL AUTO_INCREMENT 
,`appear`     VARCHAR(60) 
, `property`     int(11)   
,`lat`     VARCHAR(60) 
,`longtd`     VARCHAR(60) 
,`area`     VARCHAR(60) 
,`address`     VARCHAR(60) 
, `cell`     int(11)   

,PRIMARY KEY (`location_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `price`
--

CREATE TABLE IF NOT EXISTS `price` (
`price_id`     int(11) NOT NULL AUTO_INCREMENT 
, `amount`     int(11)   
,`currency`     VARCHAR(60) 
,`condition`     VARCHAR(60) 
, `property`     int(11)   
,`Minimum_advance`     VARCHAR(60) 
,`deposit_required`     VARCHAR(60) 
,`commission`     VARCHAR(60) 
,`utilities_extra`     VARCHAR(60) 
, `listing`     int(11)   
, `amount_per_day`     int(11)   
,`condition_per_day`     VARCHAR(60) 
,`minimum_advance_per_day`     VARCHAR(60) 
,`deposit_required_per_day`     VARCHAR(60) 
,`commission_per_day`     VARCHAR(60) 
,`utilities_extra_per_day`     VARCHAR(60) 

,PRIMARY KEY (`price_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_visitor`
--

CREATE TABLE IF NOT EXISTS `property_visitor` (
`property_visitor_id`     int(11) NOT NULL AUTO_INCREMENT 
, `property`     int(11)   

,PRIMARY KEY (`property_visitor_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_info`
--

CREATE TABLE IF NOT EXISTS `basic_info` (
`basic_info_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property_type`     int(11)   

,PRIMARY KEY (`basic_info_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_type`
--

CREATE TABLE IF NOT EXISTS `property_type` (
`property_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property`     int(11)   

,PRIMARY KEY (`property_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
`province_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`province_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`sector_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `district`     int(11)   

,PRIMARY KEY (`sector_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `sector`     int(11)   

,PRIMARY KEY (`cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`district_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `province`     int(11)   

,PRIMARY KEY (`district_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_basic_info`
--

CREATE TABLE IF NOT EXISTS `listing_basic_info` (
`listing_basic_info_id`     int(11) NOT NULL AUTO_INCREMENT 
, `listing`     int(11)   
, `basic_info`     int(11)   
,`value`     VARCHAR(60) 

,PRIMARY KEY (`listing_basic_info_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_features`
--

CREATE TABLE IF NOT EXISTS `listing_features` (
`listing_features_id`     int(11) NOT NULL AUTO_INCREMENT 
, `listing`     int(11)   
, `features`     int(11)   

,PRIMARY KEY (`listing_features_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_apartment`
--

CREATE TABLE IF NOT EXISTS `basic_apartment` (
`basic_apartment_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_apartmentdeleted`     VARCHAR(60) 
, `listing`     int(11)   
,`bedrooms`     VARCHAR(60) 
, `bathrooms`     int(11)   
,`floor_number`     VARCHAR(60) 
, `total_number_floors`     int(11)   
,`furnished`     VARCHAR(60) 

,PRIMARY KEY (`basic_apartment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_commercial`
--

CREATE TABLE IF NOT EXISTS `basic_commercial` (
`basic_commercial_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_commercialdeleted`     VARCHAR(60) 
, `listing`     int(11)   
, `bedroom`     int(11)   
, `bathroom`     int(11)   
, `compound_size`     int(11)   
, `living_floors`     int(11)   
, `total_number_floors`     int(11)   
,`furnished`     VARCHAR(60) 

,PRIMARY KEY (`basic_commercial_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_house`
--

CREATE TABLE IF NOT EXISTS `basic_house` (
`basic_house_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_housedeleted`     VARCHAR(60) 
, `listing`     int(11)   
,`furnished`     VARCHAR(60) 
,`available_from`     Date 
, `bedroom`     int(11)   
, `bathroom`     int(11)   
, `compound_size`     int(11)   
, `living_floors`     int(11)   
, `total_number_floors`     int(11)   

,PRIMARY KEY (`basic_house_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_land`
--

CREATE TABLE IF NOT EXISTS `basic_land` (
`basic_land_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_landdeleted`     VARCHAR(60) 
, `listing`     int(11)   
,`administrative_location`     VARCHAR(60) 
,`plot_number`     VARCHAR(60) 
,`plot_size`     VARCHAR(60) 
,`lot_use`     VARCHAR(60) 
,`available_from`     Date 

,PRIMARY KEY (`basic_land_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_develop`
--

CREATE TABLE IF NOT EXISTS `basic_develop` (
`basic_develop_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_developdeleted`     VARCHAR(60) 
, `listing`     int(11)   
, `bedrooms`     int(11)   
, `bathrooms`     int(11)   
, `compound_size`     int(11)   
, `living_floors`     int(11)   
, `total_number_floors`     int(11)   

,PRIMARY KEY (`basic_develop_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `currency_conversion`
--

CREATE TABLE IF NOT EXISTS `currency_conversion` (
`currency_conversion_id`     int(11) NOT NULL AUTO_INCREMENT 
,`currency_conversiondeleted`     VARCHAR(60) 
,`from`     VARCHAR(60) 
,`to`     VARCHAR(60) 
, `rate`     int(11)   

,PRIMARY KEY (`currency_conversion_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_request`
--

CREATE TABLE IF NOT EXISTS `property_request` (
`property_request_id`     int(11) NOT NULL AUTO_INCREMENT 
,`property_requestdeleted`     VARCHAR(60) 
,`names`     Date 
,`telephone`     VARCHAR(60) 
,`email`     VARCHAR(60) 
, `listing`     int(11)   
,`received`     VARCHAR(60) 
, `account`     int(11)   

,PRIMARY KEY (`property_request_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `features_cat`
--

CREATE TABLE IF NOT EXISTS `features_cat` (
`features_cat_id`     int(11) NOT NULL AUTO_INCREMENT 
,`features_catdeleted`     VARCHAR(60) 
,`cat_name`     VARCHAR(60) 

,PRIMARY KEY (`features_cat_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `price_utilities`
--

CREATE TABLE IF NOT EXISTS `price_utilities` (
`price_utilities_id`     int(11) NOT NULL AUTO_INCREMENT 
,`price_utilitiesdeleted`     VARCHAR(60) 
, `price`     int(11)   
, `utilities`     int(11)   

,PRIMARY KEY (`price_utilities_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `utilities`
--

CREATE TABLE IF NOT EXISTS `utilities` (
`utilities_id`     int(11) NOT NULL AUTO_INCREMENT 
,`utilitiesdeleted`     VARCHAR(60) 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`utilities_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `comment_replies`
--

CREATE TABLE IF NOT EXISTS `comment_replies` (
`comment_replies_id`     int(11) NOT NULL AUTO_INCREMENT 
,`comment_repliesdeleted`     VARCHAR(60) 
,`date`     Date 
, `comment`     int(11)   
, `message`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`comment_replies_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `agency`
--

CREATE TABLE IF NOT EXISTS `agency` (
`agency_id`     int(11) NOT NULL AUTO_INCREMENT 
,`website`     VARCHAR(60) 
,`office_address`     VARCHAR(60) 
,`agency_desc`     VARCHAR(60) 
,`logo`     VARCHAR(60) 
,`agency_name`     VARCHAR(60) 

,PRIMARY KEY (`agency_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
`message_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`date`     Date 
, `type`     int(11)   
,`message`     VARCHAR(60) 

,PRIMARY KEY (`message_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `msg_type`
--

CREATE TABLE IF NOT EXISTS `msg_type` (
`msg_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`msg_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `agent`
--

CREATE TABLE IF NOT EXISTS `agent` (
`agent_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
, `agency`     int(11)   

,PRIMARY KEY (`agent_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `featured`
--

CREATE TABLE IF NOT EXISTS `featured` (
`featured_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `listing`     int(11)   
,`description`     VARCHAR(60) 
, `featured_cat`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`featured_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `featured_cat`
--

CREATE TABLE IF NOT EXISTS `featured_cat` (
`featured_cat_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`featured_cat_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_comment`
--

CREATE TABLE IF NOT EXISTS `listing_comment` (
`listing_comment_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `listing`     int(11)   
, `message`     int(11)   

,PRIMARY KEY (`listing_comment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `web_visits`
--

CREATE TABLE IF NOT EXISTS `web_visits` (
`web_visits_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `visit_count`     int(11)   
, `listing`     int(11)   

,PRIMARY KEY (`web_visits_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`account_category`     VARCHAR(60) 
,`online`     VARCHAR(60) 
,`deleted`     VARCHAR(60) 
,`date_created`     Date 
, `profile`     int(11)   

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`home_phone`     VARCHAR(60) 
,`office_phone`     VARCHAR(60) 
,`mobile_phone`     VARCHAR(60) 
,`address`     VARCHAR(60) 
,`city`     VARCHAR(60) 
,`country`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property`
--

CREATE TABLE IF NOT EXISTS `property` (
`property_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`property_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_category`
--

CREATE TABLE IF NOT EXISTS `property_category` (
`property_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property_type`     int(11)   

,PRIMARY KEY (`property_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_subcategory`
--

CREATE TABLE IF NOT EXISTS `property_subcategory` (
`property_subcategory_id`     int(11) NOT NULL AUTO_INCREMENT 
, `property_subcategory`     int(11)   

,PRIMARY KEY (`property_subcategory_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `features`
--

CREATE TABLE IF NOT EXISTS `features` (
`features_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property_type`     int(11)   
, `category`     int(11)   

,PRIMARY KEY (`features_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing`
--

CREATE TABLE IF NOT EXISTS `listing` (
`listing_id`     int(11) NOT NULL AUTO_INCREMENT 
,`listing_date`     Date 
, `account`     int(11)   
, `listing_type`     int(11)   
, `property`     int(11)   
,`title`     VARCHAR(60) 
,`purpose`     VARCHAR(60) 
, `property_category`     int(11)   
, `location`     int(11)   
,`active`     VARCHAR(60) 

,PRIMARY KEY (`listing_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_type`
--

CREATE TABLE IF NOT EXISTS `listing_type` (
`listing_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`listing_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 
,`deleted`     VARCHAR(60) 
,`appear`     VARCHAR(60) 
, `listing`     int(11)   

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
`location_id`     int(11) NOT NULL AUTO_INCREMENT 
,`appear`     VARCHAR(60) 
, `property`     int(11)   
,`lat`     VARCHAR(60) 
,`longtd`     VARCHAR(60) 
,`area`     VARCHAR(60) 
,`address`     VARCHAR(60) 
, `cell`     int(11)   

,PRIMARY KEY (`location_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `price`
--

CREATE TABLE IF NOT EXISTS `price` (
`price_id`     int(11) NOT NULL AUTO_INCREMENT 
, `amount`     int(11)   
,`currency`     VARCHAR(60) 
,`condition`     VARCHAR(60) 
, `property`     int(11)   
,`Minimum_advance`     VARCHAR(60) 
,`deposit_required`     VARCHAR(60) 
,`commission`     VARCHAR(60) 
,`utilities_extra`     VARCHAR(60) 
, `listing`     int(11)   
, `amount_per_day`     int(11)   
,`condition_per_day`     VARCHAR(60) 
,`minimum_advance_per_day`     VARCHAR(60) 
,`deposit_required_per_day`     VARCHAR(60) 
,`commission_per_day`     VARCHAR(60) 
,`utilities_extra_per_day`     VARCHAR(60) 

,PRIMARY KEY (`price_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_visitor`
--

CREATE TABLE IF NOT EXISTS `property_visitor` (
`property_visitor_id`     int(11) NOT NULL AUTO_INCREMENT 
, `property`     int(11)   

,PRIMARY KEY (`property_visitor_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_info`
--

CREATE TABLE IF NOT EXISTS `basic_info` (
`basic_info_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property_type`     int(11)   

,PRIMARY KEY (`basic_info_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_type`
--

CREATE TABLE IF NOT EXISTS `property_type` (
`property_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `property`     int(11)   

,PRIMARY KEY (`property_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
`province_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`province_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`sector_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `district`     int(11)   

,PRIMARY KEY (`sector_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `sector`     int(11)   

,PRIMARY KEY (`cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`district_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `province`     int(11)   

,PRIMARY KEY (`district_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_basic_info`
--

CREATE TABLE IF NOT EXISTS `listing_basic_info` (
`listing_basic_info_id`     int(11) NOT NULL AUTO_INCREMENT 
, `listing`     int(11)   
, `basic_info`     int(11)   
,`value`     VARCHAR(60) 

,PRIMARY KEY (`listing_basic_info_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_features`
--

CREATE TABLE IF NOT EXISTS `listing_features` (
`listing_features_id`     int(11) NOT NULL AUTO_INCREMENT 
, `listing`     int(11)   
, `features`     int(11)   

,PRIMARY KEY (`listing_features_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_apartment`
--

CREATE TABLE IF NOT EXISTS `basic_apartment` (
`basic_apartment_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_apartmentdeleted`     VARCHAR(60) 
, `listing`     int(11)   
,`bedrooms`     VARCHAR(60) 
, `bathrooms`     int(11)   
,`floor_number`     VARCHAR(60) 
, `total_number_floors`     int(11)   
,`furnished`     VARCHAR(60) 

,PRIMARY KEY (`basic_apartment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_commercial`
--

CREATE TABLE IF NOT EXISTS `basic_commercial` (
`basic_commercial_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_commercialdeleted`     VARCHAR(60) 
, `listing`     int(11)   
, `bedroom`     int(11)   
, `bathroom`     int(11)   
, `compound_size`     int(11)   
, `living_floors`     int(11)   
, `total_number_floors`     int(11)   
,`furnished`     VARCHAR(60) 

,PRIMARY KEY (`basic_commercial_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_house`
--

CREATE TABLE IF NOT EXISTS `basic_house` (
`basic_house_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_housedeleted`     VARCHAR(60) 
, `listing`     int(11)   
,`furnished`     VARCHAR(60) 
,`available_from`     Date 
, `bedroom`     int(11)   
, `bathroom`     int(11)   
, `compound_size`     int(11)   
, `living_floors`     int(11)   
, `total_number_floors`     int(11)   

,PRIMARY KEY (`basic_house_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_land`
--

CREATE TABLE IF NOT EXISTS `basic_land` (
`basic_land_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_landdeleted`     VARCHAR(60) 
, `listing`     int(11)   
,`administrative_location`     VARCHAR(60) 
,`plot_number`     VARCHAR(60) 
,`plot_size`     VARCHAR(60) 
,`lot_use`     VARCHAR(60) 
,`available_from`     Date 

,PRIMARY KEY (`basic_land_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `basic_develop`
--

CREATE TABLE IF NOT EXISTS `basic_develop` (
`basic_develop_id`     int(11) NOT NULL AUTO_INCREMENT 
,`basic_developdeleted`     VARCHAR(60) 
, `listing`     int(11)   
, `bedrooms`     int(11)   
, `bathrooms`     int(11)   
, `compound_size`     int(11)   
, `living_floors`     int(11)   
, `total_number_floors`     int(11)   

,PRIMARY KEY (`basic_develop_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `currency_conversion`
--

CREATE TABLE IF NOT EXISTS `currency_conversion` (
`currency_conversion_id`     int(11) NOT NULL AUTO_INCREMENT 
,`currency_conversiondeleted`     VARCHAR(60) 
,`from`     VARCHAR(60) 
,`to`     VARCHAR(60) 
, `rate`     int(11)   

,PRIMARY KEY (`currency_conversion_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `property_request`
--

CREATE TABLE IF NOT EXISTS `property_request` (
`property_request_id`     int(11) NOT NULL AUTO_INCREMENT 
,`property_requestdeleted`     VARCHAR(60) 
,`names`     Date 
,`telephone`     VARCHAR(60) 
,`email`     VARCHAR(60) 
, `listing`     int(11)   
,`received`     VARCHAR(60) 
, `account`     int(11)   

,PRIMARY KEY (`property_request_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `features_cat`
--

CREATE TABLE IF NOT EXISTS `features_cat` (
`features_cat_id`     int(11) NOT NULL AUTO_INCREMENT 
,`features_catdeleted`     VARCHAR(60) 
,`cat_name`     VARCHAR(60) 

,PRIMARY KEY (`features_cat_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `price_utilities`
--

CREATE TABLE IF NOT EXISTS `price_utilities` (
`price_utilities_id`     int(11) NOT NULL AUTO_INCREMENT 
,`price_utilitiesdeleted`     VARCHAR(60) 
, `price`     int(11)   
, `utilities`     int(11)   

,PRIMARY KEY (`price_utilities_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `utilities`
--

CREATE TABLE IF NOT EXISTS `utilities` (
`utilities_id`     int(11) NOT NULL AUTO_INCREMENT 
,`utilitiesdeleted`     VARCHAR(60) 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`utilities_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `comment_replies`
--

CREATE TABLE IF NOT EXISTS `comment_replies` (
`comment_replies_id`     int(11) NOT NULL AUTO_INCREMENT 
,`comment_repliesdeleted`     VARCHAR(60) 
,`date`     Date 
, `comment`     int(11)   
, `message`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`comment_replies_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `agency`
--

CREATE TABLE IF NOT EXISTS `agency` (
`agency_id`     int(11) NOT NULL AUTO_INCREMENT 
,`website`     VARCHAR(60) 
,`office_address`     VARCHAR(60) 
,`agency_desc`     VARCHAR(60) 
,`logo`     VARCHAR(60) 
,`agency_name`     VARCHAR(60) 

,PRIMARY KEY (`agency_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
`message_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`date`     Date 
, `type`     int(11)   
,`message`     VARCHAR(60) 

,PRIMARY KEY (`message_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `msg_type`
--

CREATE TABLE IF NOT EXISTS `msg_type` (
`msg_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`msg_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `agent`
--

CREATE TABLE IF NOT EXISTS `agent` (
`agent_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
, `agency`     int(11)   

,PRIMARY KEY (`agent_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `featured`
--

CREATE TABLE IF NOT EXISTS `featured` (
`featured_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `listing`     int(11)   
,`description`     VARCHAR(60) 
, `featured_cat`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`featured_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `featured_cat`
--

CREATE TABLE IF NOT EXISTS `featured_cat` (
`featured_cat_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`featured_cat_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `listing_comment`
--

CREATE TABLE IF NOT EXISTS `listing_comment` (
`listing_comment_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `listing`     int(11)   
, `message`     int(11)   

,PRIMARY KEY (`listing_comment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `web_visits`
--

CREATE TABLE IF NOT EXISTS `web_visits` (
`web_visits_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `visit_count`     int(11)   
, `listing`     int(11)   

,PRIMARY KEY (`web_visits_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

