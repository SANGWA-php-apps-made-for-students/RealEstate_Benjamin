<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td> username </td><td> password </td><td> account_category </td><td> online </td><td> deleted </td><td> date_created </td><td> profile </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="username_id_cols account " title="account" >
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['password']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['online']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['deleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_online($id) {

            $db = new dbconnection();
            $sql = "select   account.online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['online'];
            echo $field;
        }

        function get_chosen_account_deleted($id) {

            $db = new dbconnection();
            $sql = "select   account.deleted from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['deleted'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td> name </td><td> last_name </td><td> email </td><td> home_phone </td><td> office_phone </td><td> mobile_phone </td><td> address </td><td> city </td><td> country </td><td> image </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="name_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['home_phone']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['office_phone']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['mobile_phone']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['address']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['city']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['country']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_last_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['last_name'];
            echo $field;
        }

        function get_chosen_profile_email($id) {

            $db = new dbconnection();
            $sql = "select   profile.email from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_profile_home_phone($id) {

            $db = new dbconnection();
            $sql = "select   profile.home_phone from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['home_phone'];
            echo $field;
        }

        function get_chosen_profile_office_phone($id) {

            $db = new dbconnection();
            $sql = "select   profile.office_phone from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['office_phone'];
            echo $field;
        }

        function get_chosen_profile_mobile_phone($id) {

            $db = new dbconnection();
            $sql = "select   profile.mobile_phone from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['mobile_phone'];
            echo $field;
        }

        function get_chosen_profile_address($id) {

            $db = new dbconnection();
            $sql = "select   profile.address from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['address'];
            echo $field;
        }

        function get_chosen_profile_city($id) {

            $db = new dbconnection();
            $sql = "select   profile.city from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['city'];
            echo $field;
        }

        function get_chosen_profile_country($id) {

            $db = new dbconnection();
            $sql = "select   profile.country from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['country'];
            echo $field;
        }

        function get_chosen_profile_image($id) {

            $db = new dbconnection();
            $sql = "select   profile.image from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_property($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from property";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> property </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['property_id']; ?>
                    </td>
                    <td class="name_id_cols property " title="property" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="property_delete_link" style="color: #000080;" value="
                           <?php echo $row['property_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="property_update_link" style="color: #000080;" value="
                           <?php echo $row['property_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_property_name($id) {

            $db = new dbconnection();
            $sql = "select   property.name from property where property_id=:property_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_property() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  property_id   from property";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_property() {
            $con = new dbconnection();
            $sql = "select property.property_id from property
                    order by property.property_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_id'];
            return $first_rec;
        }

        function get_last_property() {
            $con = new dbconnection();
            $sql = "select property.property_id from property
                    order by property.property_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_id'];
            return $first_rec;
        }

        function list_property_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from property_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> property_category </td>
                    <td> name </td><td> property_type </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['property_category_id']; ?>
                    </td>
                    <td class="name_id_cols property_category " title="property_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property_type']); ?>
                    </td>


                    <td>
                        <a href="#" class="property_category_delete_link" style="color: #000080;" value="
                           <?php echo $row['property_category_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="property_category_update_link" style="color: #000080;" value="
                           <?php echo $row['property_category_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_property_category_name($id) {

            $db = new dbconnection();
            $sql = "select   property_category.name from property_category where property_category_id=:property_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_property_category_property_type($id) {

            $db = new dbconnection();
            $sql = "select   property_category.property_type from property_category where property_category_id=:property_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property_type'];
            echo $field;
        }

        function All_property_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  property_category_id   from property_category";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_property_category() {
            $con = new dbconnection();
            $sql = "select property_category.property_category_id from property_category
                    order by property_category.property_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_category_id'];
            return $first_rec;
        }

        function get_last_property_category() {
            $con = new dbconnection();
            $sql = "select property_category.property_category_id from property_category
                    order by property_category.property_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_category_id'];
            return $first_rec;
        }

        function list_property_subcategory($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from property_subcategory";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> property_subcategory </td>
                    <td> property_subcategory </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['property_subcategory_id']; ?>
                    </td>
                    <td class="property_subcategory_id_cols property_subcategory " title="property_subcategory" >
                        <?php echo $this->_e($row['property_subcategory']); ?>
                    </td>


                    <td>
                        <a href="#" class="property_subcategory_delete_link" style="color: #000080;" value="
                           <?php echo $row['property_subcategory_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="property_subcategory_update_link" style="color: #000080;" value="
                           <?php echo $row['property_subcategory_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_property_subcategory_property_subcategory($id) {

            $db = new dbconnection();
            $sql = "select   property_subcategory.property_subcategory from property_subcategory where property_subcategory_id=:property_subcategory_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_subcategory_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property_subcategory'];
            echo $field;
        }

        function All_property_subcategory() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  property_subcategory_id   from property_subcategory";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_property_subcategory() {
            $con = new dbconnection();
            $sql = "select property_subcategory.property_subcategory_id from property_subcategory
                    order by property_subcategory.property_subcategory_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_subcategory_id'];
            return $first_rec;
        }

        function get_last_property_subcategory() {
            $con = new dbconnection();
            $sql = "select property_subcategory.property_subcategory_id from property_subcategory
                    order by property_subcategory.property_subcategory_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_subcategory_id'];
            return $first_rec;
        }

        function list_features($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from features";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> features </td>
                    <td> name </td><td> property_type </td><td> category </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['features_id']; ?>
                    </td>
                    <td class="name_id_cols features " title="features" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property_type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['category']); ?>
                    </td>


                    <td>
                        <a href="#" class="features_delete_link" style="color: #000080;" value="
                           <?php echo $row['features_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="features_update_link" style="color: #000080;" value="
                           <?php echo $row['features_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_features_name($id) {

            $db = new dbconnection();
            $sql = "select   features.name from features where features_id=:features_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':features_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_features_property_type($id) {

            $db = new dbconnection();
            $sql = "select   features.property_type from features where features_id=:features_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':features_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property_type'];
            echo $field;
        }

        function get_chosen_features_category($id) {

            $db = new dbconnection();
            $sql = "select   features.category from features where features_id=:features_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':features_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['category'];
            echo $field;
        }

        function All_features() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  features_id   from features";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_features() {
            $con = new dbconnection();
            $sql = "select features.features_id from features
                    order by features.features_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['features_id'];
            return $first_rec;
        }

        function get_last_features() {
            $con = new dbconnection();
            $sql = "select features.features_id from features
                    order by features.features_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['features_id'];
            return $first_rec;
        }

        function list_listing($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from listing";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> listing </td>
                    <td> listing_date </td><td> account </td><td> listing_type </td><td> property </td><td> title </td><td> purpose </td><td> property_category </td><td> location </td><td> active </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['listing_id']; ?>
                    </td>
                    <td class="listing_date_id_cols listing " title="listing" >
                        <?php echo $this->_e($row['listing_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing_type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['title']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['purpose']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['location']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['active']); ?>
                    </td>


                    <td>
                        <a href="#" class="listing_delete_link" style="color: #000080;" value="
                           <?php echo $row['listing_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="listing_update_link" style="color: #000080;" value="
                           <?php echo $row['listing_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_listing_listing_date($id) {

            $db = new dbconnection();
            $sql = "select   listing.listing_date from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing_date'];
            echo $field;
        }

        function get_chosen_listing_account($id) {

            $db = new dbconnection();
            $sql = "select   listing.account from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_listing_listing_type($id) {

            $db = new dbconnection();
            $sql = "select   listing.listing_type from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing_type'];
            echo $field;
        }

        function get_chosen_listing_property($id) {

            $db = new dbconnection();
            $sql = "select   listing.property from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property'];
            echo $field;
        }

        function get_chosen_listing_title($id) {

            $db = new dbconnection();
            $sql = "select   listing.title from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['title'];
            echo $field;
        }

        function get_chosen_listing_purpose($id) {

            $db = new dbconnection();
            $sql = "select   listing.purpose from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['purpose'];
            echo $field;
        }

        function get_chosen_listing_property_category($id) {

            $db = new dbconnection();
            $sql = "select   listing.property_category from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property_category'];
            echo $field;
        }

        function get_chosen_listing_location($id) {

            $db = new dbconnection();
            $sql = "select   listing.location from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['location'];
            echo $field;
        }

        function get_chosen_listing_active($id) {

            $db = new dbconnection();
            $sql = "select   listing.active from listing where listing_id=:listing_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['active'];
            echo $field;
        }

        function All_listing() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  listing_id   from listing";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_listing() {
            $con = new dbconnection();
            $sql = "select listing.listing_id from listing
                    order by listing.listing_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_id'];
            return $first_rec;
        }

        function get_last_listing() {
            $con = new dbconnection();
            $sql = "select listing.listing_id from listing
                    order by listing.listing_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_id'];
            return $first_rec;
        }

        function list_listing_type($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from listing_type";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> listing_type </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['listing_type_id']; ?>
                    </td>
                    <td class="name_id_cols listing_type " title="listing_type" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="listing_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['listing_type_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="listing_type_update_link" style="color: #000080;" value="
                           <?php echo $row['listing_type_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_listing_type_name($id) {

            $db = new dbconnection();
            $sql = "select   listing_type.name from listing_type where listing_type_id=:listing_type_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_type_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_listing_type() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  listing_type_id   from listing_type";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_listing_type() {
            $con = new dbconnection();
            $sql = "select listing_type.listing_type_id from listing_type
                    order by listing_type.listing_type_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_type_id'];
            return $first_rec;
        }

        function get_last_listing_type() {
            $con = new dbconnection();
            $sql = "select listing_type.listing_type_id from listing_type
                    order by listing_type.listing_type_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_type_id'];
            return $first_rec;
        }

        function list_image($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from image";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> image </td>
                    <td> path </td><td> deleted </td><td> appear </td><td> listing </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class="path_id_cols image " title="image" >
                        <?php echo $this->_e($row['path']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['deleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['appear']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>


                    <td>
                        <a href="#" class="image_delete_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_image_path($id) {

            $db = new dbconnection();
            $sql = "select   image.path from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['path'];
            echo $field;
        }

        function get_chosen_image_deleted($id) {

            $db = new dbconnection();
            $sql = "select   image.deleted from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['deleted'];
            echo $field;
        }

        function get_chosen_image_appear($id) {

            $db = new dbconnection();
            $sql = "select   image.appear from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['appear'];
            echo $field;
        }

        function get_chosen_image_listing($id) {

            $db = new dbconnection();
            $sql = "select   image.listing from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function All_image() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  image_id   from image";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function get_last_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function list_location($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from location";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> location </td>
                    <td> appear </td><td> property </td><td> lat </td><td> longtd </td><td> area </td><td> address </td><td> cell </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['location_id']; ?>
                    </td>
                    <td class="appear_id_cols location " title="location" >
                        <?php echo $this->_e($row['appear']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['lat']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['longtd']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['area']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['address']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['cell']); ?>
                    </td>


                    <td>
                        <a href="#" class="location_delete_link" style="color: #000080;" value="
                           <?php echo $row['location_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="location_update_link" style="color: #000080;" value="
                           <?php echo $row['location_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_location_appear($id) {

            $db = new dbconnection();
            $sql = "select   location.appear from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['appear'];
            echo $field;
        }

        function get_chosen_location_property($id) {

            $db = new dbconnection();
            $sql = "select   location.property from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property'];
            echo $field;
        }

        function get_chosen_location_lat($id) {

            $db = new dbconnection();
            $sql = "select   location.lat from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['lat'];
            echo $field;
        }

        function get_chosen_location_longtd($id) {

            $db = new dbconnection();
            $sql = "select   location.longtd from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['longtd'];
            echo $field;
        }

        function get_chosen_location_area($id) {

            $db = new dbconnection();
            $sql = "select   location.area from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['area'];
            echo $field;
        }

        function get_chosen_location_address($id) {

            $db = new dbconnection();
            $sql = "select   location.address from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['address'];
            echo $field;
        }

        function get_chosen_location_cell($id) {

            $db = new dbconnection();
            $sql = "select   location.cell from location where location_id=:location_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':location_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['cell'];
            echo $field;
        }

        function All_location() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  location_id   from location";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_location() {
            $con = new dbconnection();
            $sql = "select location.location_id from location
                    order by location.location_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['location_id'];
            return $first_rec;
        }

        function get_last_location() {
            $con = new dbconnection();
            $sql = "select location.location_id from location
                    order by location.location_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['location_id'];
            return $first_rec;
        }

        function list_price($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from price";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> price </td>
                    <td> amount </td><td> currency </td><td> condition </td><td> property </td><td> Minimum_advance </td><td> deposit_required </td><td> commission </td><td> utilities_extra </td><td> listing </td><td> amount_per_day </td><td> condition_per_day </td><td> minimum_advance_per_day </td><td> deposit_required_per_day </td><td> commission_per_day </td><td> utilities_extra_per_day </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['price_id']; ?>
                    </td>
                    <td class="amount_id_cols price " title="price" >
                        <?php echo $this->_e($row['amount']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['currency']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['condition']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Minimum_advance']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['deposit_required']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['commission']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['utilities_extra']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['amount_per_day']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['condition_per_day']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['minimum_advance_per_day']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['deposit_required_per_day']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['commission_per_day']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['utilities_extra_per_day']); ?>
                    </td>


                    <td>
                        <a href="#" class="price_delete_link" style="color: #000080;" value="
                           <?php echo $row['price_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="price_update_link" style="color: #000080;" value="
                           <?php echo $row['price_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_price_amount($id) {

            $db = new dbconnection();
            $sql = "select   price.amount from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['amount'];
            echo $field;
        }

        function get_chosen_price_currency($id) {

            $db = new dbconnection();
            $sql = "select   price.currency from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['currency'];
            echo $field;
        }

        function get_chosen_price_condition($id) {

            $db = new dbconnection();
            $sql = "select   price.condition from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['condition'];
            echo $field;
        }

        function get_chosen_price_property($id) {

            $db = new dbconnection();
            $sql = "select   price.property from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property'];
            echo $field;
        }

        function get_chosen_price_Minimum_advance($id) {

            $db = new dbconnection();
            $sql = "select   price.Minimum_advance from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Minimum_advance'];
            echo $field;
        }

        function get_chosen_price_deposit_required($id) {

            $db = new dbconnection();
            $sql = "select   price.deposit_required from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['deposit_required'];
            echo $field;
        }

        function get_chosen_price_commission($id) {

            $db = new dbconnection();
            $sql = "select   price.commission from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['commission'];
            echo $field;
        }

        function get_chosen_price_utilities_extra($id) {

            $db = new dbconnection();
            $sql = "select   price.utilities_extra from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['utilities_extra'];
            echo $field;
        }

        function get_chosen_price_listing($id) {

            $db = new dbconnection();
            $sql = "select   price.listing from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_price_amount_per_day($id) {

            $db = new dbconnection();
            $sql = "select   price.amount_per_day from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['amount_per_day'];
            echo $field;
        }

        function get_chosen_price_condition_per_day($id) {

            $db = new dbconnection();
            $sql = "select   price.condition_per_day from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['condition_per_day'];
            echo $field;
        }

        function get_chosen_price_minimum_advance_per_day($id) {

            $db = new dbconnection();
            $sql = "select   price.minimum_advance_per_day from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['minimum_advance_per_day'];
            echo $field;
        }

        function get_chosen_price_deposit_required_per_day($id) {

            $db = new dbconnection();
            $sql = "select   price.deposit_required_per_day from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['deposit_required_per_day'];
            echo $field;
        }

        function get_chosen_price_commission_per_day($id) {

            $db = new dbconnection();
            $sql = "select   price.commission_per_day from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['commission_per_day'];
            echo $field;
        }

        function get_chosen_price_utilities_extra_per_day($id) {

            $db = new dbconnection();
            $sql = "select   price.utilities_extra_per_day from price where price_id=:price_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['utilities_extra_per_day'];
            echo $field;
        }

        function All_price() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  price_id   from price";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_price() {
            $con = new dbconnection();
            $sql = "select price.price_id from price
                    order by price.price_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['price_id'];
            return $first_rec;
        }

        function get_last_price() {
            $con = new dbconnection();
            $sql = "select price.price_id from price
                    order by price.price_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['price_id'];
            return $first_rec;
        }

        function list_property_visitor($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from property_visitor";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> property_visitor </td>
                    <td> property </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['property_visitor_id']; ?>
                    </td>
                    <td class="property_id_cols property_visitor " title="property_visitor" >
                        <?php echo $this->_e($row['property']); ?>
                    </td>


                    <td>
                        <a href="#" class="property_visitor_delete_link" style="color: #000080;" value="
                           <?php echo $row['property_visitor_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="property_visitor_update_link" style="color: #000080;" value="
                           <?php echo $row['property_visitor_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_property_visitor_property($id) {

            $db = new dbconnection();
            $sql = "select   property_visitor.property from property_visitor where property_visitor_id=:property_visitor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_visitor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property'];
            echo $field;
        }

        function All_property_visitor() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  property_visitor_id   from property_visitor";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_property_visitor() {
            $con = new dbconnection();
            $sql = "select property_visitor.property_visitor_id from property_visitor
                    order by property_visitor.property_visitor_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_visitor_id'];
            return $first_rec;
        }

        function get_last_property_visitor() {
            $con = new dbconnection();
            $sql = "select property_visitor.property_visitor_id from property_visitor
                    order by property_visitor.property_visitor_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_visitor_id'];
            return $first_rec;
        }

        function list_basic_info($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from basic_info";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> basic_info </td>
                    <td> name </td><td> property_type </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['basic_info_id']; ?>
                    </td>
                    <td class="name_id_cols basic_info " title="basic_info" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property_type']); ?>
                    </td>


                    <td>
                        <a href="#" class="basic_info_delete_link" style="color: #000080;" value="
                           <?php echo $row['basic_info_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="basic_info_update_link" style="color: #000080;" value="
                           <?php echo $row['basic_info_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_basic_info_name($id) {

            $db = new dbconnection();
            $sql = "select   basic_info.name from basic_info where basic_info_id=:basic_info_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_info_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_basic_info_property_type($id) {

            $db = new dbconnection();
            $sql = "select   basic_info.property_type from basic_info where basic_info_id=:basic_info_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_info_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property_type'];
            echo $field;
        }

        function All_basic_info() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  basic_info_id   from basic_info";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_basic_info() {
            $con = new dbconnection();
            $sql = "select basic_info.basic_info_id from basic_info
                    order by basic_info.basic_info_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_info_id'];
            return $first_rec;
        }

        function get_last_basic_info() {
            $con = new dbconnection();
            $sql = "select basic_info.basic_info_id from basic_info
                    order by basic_info.basic_info_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_info_id'];
            return $first_rec;
        }

        function list_property_type($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from property_type";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> property_type </td>
                    <td> name </td><td> property </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['property_type_id']; ?>
                    </td>
                    <td class="name_id_cols property_type " title="property_type" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['property']); ?>
                    </td>


                    <td>
                        <a href="#" class="property_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['property_type_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="property_type_update_link" style="color: #000080;" value="
                           <?php echo $row['property_type_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_property_type_name($id) {

            $db = new dbconnection();
            $sql = "select   property_type.name from property_type where property_type_id=:property_type_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_type_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_property_type_property($id) {

            $db = new dbconnection();
            $sql = "select   property_type.property from property_type where property_type_id=:property_type_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_type_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property'];
            echo $field;
        }

        function All_property_type() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  property_type_id   from property_type";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_property_type() {
            $con = new dbconnection();
            $sql = "select property_type.property_type_id from property_type
                    order by property_type.property_type_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_type_id'];
            return $first_rec;
        }

        function get_last_property_type() {
            $con = new dbconnection();
            $sql = "select property_type.property_type_id from property_type
                    order by property_type.property_type_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_type_id'];
            return $first_rec;
        }

        function list_province($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from province";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> province </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['province_id']; ?>
                    </td>
                    <td class="name_id_cols province " title="province" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="province_delete_link" style="color: #000080;" value="
                           <?php echo $row['province_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="province_update_link" style="color: #000080;" value="
                           <?php echo $row['province_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_province_name($id) {

            $db = new dbconnection();
            $sql = "select   province.name from province where province_id=:province_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':province_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_province() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  province_id   from province";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_province() {
            $con = new dbconnection();
            $sql = "select province.province_id from province
                    order by province.province_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['province_id'];
            return $first_rec;
        }

        function get_last_province() {
            $con = new dbconnection();
            $sql = "select province.province_id from province
                    order by province.province_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['province_id'];
            return $first_rec;
        }

        function list_sector($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from sector";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> sector </td>
                    <td> name </td><td> district </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['sector_id']; ?>
                    </td>
                    <td class="name_id_cols sector " title="sector" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['district']); ?>
                    </td>


                    <td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="sector_update_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_sector_name($id) {

            $db = new dbconnection();
            $sql = "select   sector.name from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_sector_district($id) {

            $db = new dbconnection();
            $sql = "select   sector.district from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['district'];
            echo $field;
        }

        function All_sector() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  sector_id   from sector";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function get_last_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function list_cell($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cell";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cell </td>
                    <td> name </td><td> sector </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['sector']); ?>
                    </td>


                    <td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cell_name($id) {

            $db = new dbconnection();
            $sql = "select   cell.name from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_cell_sector($id) {

            $db = new dbconnection();
            $sql = "select   cell.sector from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['sector'];
            echo $field;
        }

        function All_cell() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  cell_id   from cell";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function get_last_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function list_district($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from district";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> district </td>
                    <td> name </td><td> province </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['district_id']; ?>
                    </td>
                    <td class="name_id_cols district " title="district" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['province']); ?>
                    </td>


                    <td>
                        <a href="#" class="district_delete_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="district_update_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_district_name($id) {

            $db = new dbconnection();
            $sql = "select   district.name from district where district_id=:district_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':district_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_district_province($id) {

            $db = new dbconnection();
            $sql = "select   district.province from district where district_id=:district_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':district_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['province'];
            echo $field;
        }

        function All_district() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  district_id   from district";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_district() {
            $con = new dbconnection();
            $sql = "select district.district_id from district
                    order by district.district_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['district_id'];
            return $first_rec;
        }

        function get_last_district() {
            $con = new dbconnection();
            $sql = "select district.district_id from district
                    order by district.district_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['district_id'];
            return $first_rec;
        }

        function list_listing_basic_info($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from listing_basic_info";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> listing_basic_info </td>
                    <td> listing </td><td> basic_info </td><td> value </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['listing_basic_info_id']; ?>
                    </td>
                    <td class="listing_id_cols listing_basic_info " title="listing_basic_info" >
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['basic_info']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['value']); ?>
                    </td>


                    <td>
                        <a href="#" class="listing_basic_info_delete_link" style="color: #000080;" value="
                           <?php echo $row['listing_basic_info_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="listing_basic_info_update_link" style="color: #000080;" value="
                           <?php echo $row['listing_basic_info_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_listing_basic_info_listing($id) {

            $db = new dbconnection();
            $sql = "select   listing_basic_info.listing from listing_basic_info where listing_basic_info_id=:listing_basic_info_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_basic_info_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_listing_basic_info_basic_info($id) {

            $db = new dbconnection();
            $sql = "select   listing_basic_info.basic_info from listing_basic_info where listing_basic_info_id=:listing_basic_info_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_basic_info_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['basic_info'];
            echo $field;
        }

        function get_chosen_listing_basic_info_value($id) {

            $db = new dbconnection();
            $sql = "select   listing_basic_info.value from listing_basic_info where listing_basic_info_id=:listing_basic_info_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_basic_info_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['value'];
            echo $field;
        }

        function All_listing_basic_info() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  listing_basic_info_id   from listing_basic_info";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_listing_basic_info() {
            $con = new dbconnection();
            $sql = "select listing_basic_info.listing_basic_info_id from listing_basic_info
                    order by listing_basic_info.listing_basic_info_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_basic_info_id'];
            return $first_rec;
        }

        function get_last_listing_basic_info() {
            $con = new dbconnection();
            $sql = "select listing_basic_info.listing_basic_info_id from listing_basic_info
                    order by listing_basic_info.listing_basic_info_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_basic_info_id'];
            return $first_rec;
        }

        function list_listing_features($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from listing_features";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> listing_features </td>
                    <td> listing </td><td> features </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['listing_features_id']; ?>
                    </td>
                    <td class="listing_id_cols listing_features " title="listing_features" >
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['features']); ?>
                    </td>


                    <td>
                        <a href="#" class="listing_features_delete_link" style="color: #000080;" value="
                           <?php echo $row['listing_features_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="listing_features_update_link" style="color: #000080;" value="
                           <?php echo $row['listing_features_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_listing_features_listing($id) {

            $db = new dbconnection();
            $sql = "select   listing_features.listing from listing_features where listing_features_id=:listing_features_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_features_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_listing_features_features($id) {

            $db = new dbconnection();
            $sql = "select   listing_features.features from listing_features where listing_features_id=:listing_features_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_features_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['features'];
            echo $field;
        }

        function All_listing_features() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  listing_features_id   from listing_features";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_listing_features() {
            $con = new dbconnection();
            $sql = "select listing_features.listing_features_id from listing_features
                    order by listing_features.listing_features_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_features_id'];
            return $first_rec;
        }

        function get_last_listing_features() {
            $con = new dbconnection();
            $sql = "select listing_features.listing_features_id from listing_features
                    order by listing_features.listing_features_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_features_id'];
            return $first_rec;
        }

        function list_basic_apartment($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from basic_apartment";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> basic_apartment </td>
                    <td> basic_apartmentdeleted </td><td> listing </td><td> bedrooms </td><td> bathrooms </td><td> floor_number </td><td> total_number_floors </td><td> furnished </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['basic_apartment_id']; ?>
                    </td>
                    <td class="basic_apartmentdeleted_id_cols basic_apartment " title="basic_apartment" >
                        <?php echo $this->_e($row['basic_apartmentdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bedrooms']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bathrooms']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['floor_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['total_number_floors']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['furnished']); ?>
                    </td>


                    <td>
                        <a href="#" class="basic_apartment_delete_link" style="color: #000080;" value="
                           <?php echo $row['basic_apartment_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="basic_apartment_update_link" style="color: #000080;" value="
                           <?php echo $row['basic_apartment_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_basic_apartment_basic_apartmentdeleted($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.basic_apartmentdeleted from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['basic_apartmentdeleted'];
            echo $field;
        }

        function get_chosen_basic_apartment_listing($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.listing from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_basic_apartment_bedrooms($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.bedrooms from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bedrooms'];
            echo $field;
        }

        function get_chosen_basic_apartment_bathrooms($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.bathrooms from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bathrooms'];
            echo $field;
        }

        function get_chosen_basic_apartment_floor_number($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.floor_number from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['floor_number'];
            echo $field;
        }

        function get_chosen_basic_apartment_total_number_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.total_number_floors from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['total_number_floors'];
            echo $field;
        }

        function get_chosen_basic_apartment_furnished($id) {

            $db = new dbconnection();
            $sql = "select   basic_apartment.furnished from basic_apartment where basic_apartment_id=:basic_apartment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_apartment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['furnished'];
            echo $field;
        }

        function All_basic_apartment() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  basic_apartment_id   from basic_apartment";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_basic_apartment() {
            $con = new dbconnection();
            $sql = "select basic_apartment.basic_apartment_id from basic_apartment
                    order by basic_apartment.basic_apartment_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_apartment_id'];
            return $first_rec;
        }

        function get_last_basic_apartment() {
            $con = new dbconnection();
            $sql = "select basic_apartment.basic_apartment_id from basic_apartment
                    order by basic_apartment.basic_apartment_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_apartment_id'];
            return $first_rec;
        }

        function list_basic_commercial($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from basic_commercial";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> basic_commercial </td>
                    <td> basic_commercialdeleted </td><td> listing </td><td> bedroom </td><td> bathroom </td><td> compound_size </td><td> living_floors </td><td> total_number_floors </td><td> furnished </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['basic_commercial_id']; ?>
                    </td>
                    <td class="basic_commercialdeleted_id_cols basic_commercial " title="basic_commercial" >
                        <?php echo $this->_e($row['basic_commercialdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bedroom']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bathroom']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['compound_size']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['living_floors']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['total_number_floors']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['furnished']); ?>
                    </td>


                    <td>
                        <a href="#" class="basic_commercial_delete_link" style="color: #000080;" value="
                           <?php echo $row['basic_commercial_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="basic_commercial_update_link" style="color: #000080;" value="
                           <?php echo $row['basic_commercial_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_basic_commercial_basic_commercialdeleted($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.basic_commercialdeleted from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['basic_commercialdeleted'];
            echo $field;
        }

        function get_chosen_basic_commercial_listing($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.listing from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_basic_commercial_bedroom($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.bedroom from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bedroom'];
            echo $field;
        }

        function get_chosen_basic_commercial_bathroom($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.bathroom from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bathroom'];
            echo $field;
        }

        function get_chosen_basic_commercial_compound_size($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.compound_size from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['compound_size'];
            echo $field;
        }

        function get_chosen_basic_commercial_living_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.living_floors from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['living_floors'];
            echo $field;
        }

        function get_chosen_basic_commercial_total_number_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.total_number_floors from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['total_number_floors'];
            echo $field;
        }

        function get_chosen_basic_commercial_furnished($id) {

            $db = new dbconnection();
            $sql = "select   basic_commercial.furnished from basic_commercial where basic_commercial_id=:basic_commercial_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_commercial_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['furnished'];
            echo $field;
        }

        function All_basic_commercial() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  basic_commercial_id   from basic_commercial";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_basic_commercial() {
            $con = new dbconnection();
            $sql = "select basic_commercial.basic_commercial_id from basic_commercial
                    order by basic_commercial.basic_commercial_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_commercial_id'];
            return $first_rec;
        }

        function get_last_basic_commercial() {
            $con = new dbconnection();
            $sql = "select basic_commercial.basic_commercial_id from basic_commercial
                    order by basic_commercial.basic_commercial_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_commercial_id'];
            return $first_rec;
        }

        function list_basic_house($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from basic_house";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> basic_house </td>
                    <td> basic_housedeleted </td><td> listing </td><td> furnished </td><td> available_from </td><td> bedroom </td><td> bathroom </td><td> compound_size </td><td> living_floors </td><td> total_number_floors </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['basic_house_id']; ?>
                    </td>
                    <td class="basic_housedeleted_id_cols basic_house " title="basic_house" >
                        <?php echo $this->_e($row['basic_housedeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['furnished']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['available_from']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bedroom']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bathroom']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['compound_size']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['living_floors']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['total_number_floors']); ?>
                    </td>


                    <td>
                        <a href="#" class="basic_house_delete_link" style="color: #000080;" value="
                           <?php echo $row['basic_house_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="basic_house_update_link" style="color: #000080;" value="
                           <?php echo $row['basic_house_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_basic_house_basic_housedeleted($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.basic_housedeleted from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['basic_housedeleted'];
            echo $field;
        }

        function get_chosen_basic_house_listing($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.listing from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_basic_house_furnished($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.furnished from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['furnished'];
            echo $field;
        }

        function get_chosen_basic_house_available_from($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.available_from from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['available_from'];
            echo $field;
        }

        function get_chosen_basic_house_bedroom($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.bedroom from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bedroom'];
            echo $field;
        }

        function get_chosen_basic_house_bathroom($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.bathroom from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bathroom'];
            echo $field;
        }

        function get_chosen_basic_house_compound_size($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.compound_size from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['compound_size'];
            echo $field;
        }

        function get_chosen_basic_house_living_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.living_floors from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['living_floors'];
            echo $field;
        }

        function get_chosen_basic_house_total_number_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_house.total_number_floors from basic_house where basic_house_id=:basic_house_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_house_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['total_number_floors'];
            echo $field;
        }

        function All_basic_house() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  basic_house_id   from basic_house";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_basic_house() {
            $con = new dbconnection();
            $sql = "select basic_house.basic_house_id from basic_house
                    order by basic_house.basic_house_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_house_id'];
            return $first_rec;
        }

        function get_last_basic_house() {
            $con = new dbconnection();
            $sql = "select basic_house.basic_house_id from basic_house
                    order by basic_house.basic_house_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_house_id'];
            return $first_rec;
        }

        function list_basic_land($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from basic_land";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> basic_land </td>
                    <td> basic_landdeleted </td><td> listing </td><td> administrative_location </td><td> plot_number </td><td> plot_size </td><td> lot_use </td><td> available_from </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['basic_land_id']; ?>
                    </td>
                    <td class="basic_landdeleted_id_cols basic_land " title="basic_land" >
                        <?php echo $this->_e($row['basic_landdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['administrative_location']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['plot_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['plot_size']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['lot_use']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['available_from']); ?>
                    </td>


                    <td>
                        <a href="#" class="basic_land_delete_link" style="color: #000080;" value="
                           <?php echo $row['basic_land_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="basic_land_update_link" style="color: #000080;" value="
                           <?php echo $row['basic_land_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_basic_land_basic_landdeleted($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.basic_landdeleted from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['basic_landdeleted'];
            echo $field;
        }

        function get_chosen_basic_land_listing($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.listing from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_basic_land_administrative_location($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.administrative_location from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['administrative_location'];
            echo $field;
        }

        function get_chosen_basic_land_plot_number($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.plot_number from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['plot_number'];
            echo $field;
        }

        function get_chosen_basic_land_plot_size($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.plot_size from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['plot_size'];
            echo $field;
        }

        function get_chosen_basic_land_lot_use($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.lot_use from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['lot_use'];
            echo $field;
        }

        function get_chosen_basic_land_available_from($id) {

            $db = new dbconnection();
            $sql = "select   basic_land.available_from from basic_land where basic_land_id=:basic_land_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_land_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['available_from'];
            echo $field;
        }

        function All_basic_land() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  basic_land_id   from basic_land";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_basic_land() {
            $con = new dbconnection();
            $sql = "select basic_land.basic_land_id from basic_land
                    order by basic_land.basic_land_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_land_id'];
            return $first_rec;
        }

        function get_last_basic_land() {
            $con = new dbconnection();
            $sql = "select basic_land.basic_land_id from basic_land
                    order by basic_land.basic_land_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_land_id'];
            return $first_rec;
        }

        function list_basic_develop($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from basic_develop";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> basic_develop </td>
                    <td> basic_developdeleted </td><td> listing </td><td> bedrooms </td><td> bathrooms </td><td> compound_size </td><td> living_floors </td><td> total_number_floors </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['basic_develop_id']; ?>
                    </td>
                    <td class="basic_developdeleted_id_cols basic_develop " title="basic_develop" >
                        <?php echo $this->_e($row['basic_developdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bedrooms']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['bathrooms']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['compound_size']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['living_floors']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['total_number_floors']); ?>
                    </td>


                    <td>
                        <a href="#" class="basic_develop_delete_link" style="color: #000080;" value="
                           <?php echo $row['basic_develop_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="basic_develop_update_link" style="color: #000080;" value="
                           <?php echo $row['basic_develop_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_basic_develop_basic_developdeleted($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.basic_developdeleted from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['basic_developdeleted'];
            echo $field;
        }

        function get_chosen_basic_develop_listing($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.listing from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_basic_develop_bedrooms($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.bedrooms from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bedrooms'];
            echo $field;
        }

        function get_chosen_basic_develop_bathrooms($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.bathrooms from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bathrooms'];
            echo $field;
        }

        function get_chosen_basic_develop_compound_size($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.compound_size from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['compound_size'];
            echo $field;
        }

        function get_chosen_basic_develop_living_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.living_floors from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['living_floors'];
            echo $field;
        }

        function get_chosen_basic_develop_total_number_floors($id) {

            $db = new dbconnection();
            $sql = "select   basic_develop.total_number_floors from basic_develop where basic_develop_id=:basic_develop_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':basic_develop_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['total_number_floors'];
            echo $field;
        }

        function All_basic_develop() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  basic_develop_id   from basic_develop";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_basic_develop() {
            $con = new dbconnection();
            $sql = "select basic_develop.basic_develop_id from basic_develop
                    order by basic_develop.basic_develop_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_develop_id'];
            return $first_rec;
        }

        function get_last_basic_develop() {
            $con = new dbconnection();
            $sql = "select basic_develop.basic_develop_id from basic_develop
                    order by basic_develop.basic_develop_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['basic_develop_id'];
            return $first_rec;
        }

        function list_currency_conversion($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from currency_conversion";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> currency_conversion </td>
                    <td> currency_conversiondeleted </td><td> from </td><td> to </td><td> rate </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['currency_conversion_id']; ?>
                    </td>
                    <td class="currency_conversiondeleted_id_cols currency_conversion " title="currency_conversion" >
                        <?php echo $this->_e($row['currency_conversiondeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['from']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['to']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['rate']); ?>
                    </td>


                    <td>
                        <a href="#" class="currency_conversion_delete_link" style="color: #000080;" value="
                           <?php echo $row['currency_conversion_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="currency_conversion_update_link" style="color: #000080;" value="
                           <?php echo $row['currency_conversion_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_currency_conversion_currency_conversiondeleted($id) {

            $db = new dbconnection();
            $sql = "select   currency_conversion.currency_conversiondeleted from currency_conversion where currency_conversion_id=:currency_conversion_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':currency_conversion_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['currency_conversiondeleted'];
            echo $field;
        }

        function get_chosen_currency_conversion_from($id) {

            $db = new dbconnection();
            $sql = "select   currency_conversion.from from currency_conversion where currency_conversion_id=:currency_conversion_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':currency_conversion_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['from'];
            echo $field;
        }

        function get_chosen_currency_conversion_to($id) {

            $db = new dbconnection();
            $sql = "select   currency_conversion.to from currency_conversion where currency_conversion_id=:currency_conversion_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':currency_conversion_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['to'];
            echo $field;
        }

        function get_chosen_currency_conversion_rate($id) {

            $db = new dbconnection();
            $sql = "select   currency_conversion.rate from currency_conversion where currency_conversion_id=:currency_conversion_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':currency_conversion_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['rate'];
            echo $field;
        }

        function All_currency_conversion() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  currency_conversion_id   from currency_conversion";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_currency_conversion() {
            $con = new dbconnection();
            $sql = "select currency_conversion.currency_conversion_id from currency_conversion
                    order by currency_conversion.currency_conversion_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['currency_conversion_id'];
            return $first_rec;
        }

        function get_last_currency_conversion() {
            $con = new dbconnection();
            $sql = "select currency_conversion.currency_conversion_id from currency_conversion
                    order by currency_conversion.currency_conversion_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['currency_conversion_id'];
            return $first_rec;
        }

        function list_property_request($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from property_request";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> property_request </td>
                    <td> property_requestdeleted </td><td> names </td><td> telephone </td><td> email </td><td> listing </td><td> received </td><td> account </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['property_request_id']; ?>
                    </td>
                    <td class="property_requestdeleted_id_cols property_request " title="property_request" >
                        <?php echo $this->_e($row['property_requestdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['names']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['received']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="property_request_delete_link" style="color: #000080;" value="
                           <?php echo $row['property_request_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="property_request_update_link" style="color: #000080;" value="
                           <?php echo $row['property_request_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_property_request_property_requestdeleted($id) {

            $db = new dbconnection();
            $sql = "select   property_request.property_requestdeleted from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['property_requestdeleted'];
            echo $field;
        }

        function get_chosen_property_request_names($id) {

            $db = new dbconnection();
            $sql = "select   property_request.names from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['names'];
            echo $field;
        }

        function get_chosen_property_request_telephone($id) {

            $db = new dbconnection();
            $sql = "select   property_request.telephone from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['telephone'];
            echo $field;
        }

        function get_chosen_property_request_email($id) {

            $db = new dbconnection();
            $sql = "select   property_request.email from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_property_request_listing($id) {

            $db = new dbconnection();
            $sql = "select   property_request.listing from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_property_request_received($id) {

            $db = new dbconnection();
            $sql = "select   property_request.received from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['received'];
            echo $field;
        }

        function get_chosen_property_request_account($id) {

            $db = new dbconnection();
            $sql = "select   property_request.account from property_request where property_request_id=:property_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':property_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_property_request() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  property_request_id   from property_request";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_property_request() {
            $con = new dbconnection();
            $sql = "select property_request.property_request_id from property_request
                    order by property_request.property_request_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_request_id'];
            return $first_rec;
        }

        function get_last_property_request() {
            $con = new dbconnection();
            $sql = "select property_request.property_request_id from property_request
                    order by property_request.property_request_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['property_request_id'];
            return $first_rec;
        }

        function list_features_cat($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from features_cat";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> features_cat </td>
                    <td> features_catdeleted </td><td> cat_name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['features_cat_id']; ?>
                    </td>
                    <td class="features_catdeleted_id_cols features_cat " title="features_cat" >
                        <?php echo $this->_e($row['features_catdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['cat_name']); ?>
                    </td>


                    <td>
                        <a href="#" class="features_cat_delete_link" style="color: #000080;" value="
                           <?php echo $row['features_cat_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="features_cat_update_link" style="color: #000080;" value="
                           <?php echo $row['features_cat_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_features_cat_features_catdeleted($id) {

            $db = new dbconnection();
            $sql = "select   features_cat.features_catdeleted from features_cat where features_cat_id=:features_cat_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':features_cat_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['features_catdeleted'];
            echo $field;
        }

        function get_chosen_features_cat_cat_name($id) {

            $db = new dbconnection();
            $sql = "select   features_cat.cat_name from features_cat where features_cat_id=:features_cat_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':features_cat_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['cat_name'];
            echo $field;
        }

        function All_features_cat() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  features_cat_id   from features_cat";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_features_cat() {
            $con = new dbconnection();
            $sql = "select features_cat.features_cat_id from features_cat
                    order by features_cat.features_cat_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['features_cat_id'];
            return $first_rec;
        }

        function get_last_features_cat() {
            $con = new dbconnection();
            $sql = "select features_cat.features_cat_id from features_cat
                    order by features_cat.features_cat_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['features_cat_id'];
            return $first_rec;
        }

        function list_sector($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from sector";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> sector </td>
                    <td> name </td><td> district </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['sector_id']; ?>
                    </td>
                    <td class="name_id_cols sector " title="sector" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['district']); ?>
                    </td>


                    <td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="sector_update_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_sector_name($id) {

            $db = new dbconnection();
            $sql = "select   sector.name from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_sector_district($id) {

            $db = new dbconnection();
            $sql = "select   sector.district from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['district'];
            echo $field;
        }

        function All_sector() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  sector_id   from sector";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function get_last_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function list_cell($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cell";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cell </td>
                    <td> name </td><td> sector </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['sector']); ?>
                    </td>


                    <td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cell_name($id) {

            $db = new dbconnection();
            $sql = "select   cell.name from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_cell_sector($id) {

            $db = new dbconnection();
            $sql = "select   cell.sector from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['sector'];
            echo $field;
        }

        function All_cell() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  cell_id   from cell";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function get_last_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function list_district($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from district";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> district </td>
                    <td> name </td><td> province </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['district_id']; ?>
                    </td>
                    <td class="name_id_cols district " title="district" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['province']); ?>
                    </td>


                    <td>
                        <a href="#" class="district_delete_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="district_update_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_district_name($id) {

            $db = new dbconnection();
            $sql = "select   district.name from district where district_id=:district_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':district_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_district_province($id) {

            $db = new dbconnection();
            $sql = "select   district.province from district where district_id=:district_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':district_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['province'];
            echo $field;
        }

        function All_district() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  district_id   from district";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_district() {
            $con = new dbconnection();
            $sql = "select district.district_id from district
                    order by district.district_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['district_id'];
            return $first_rec;
        }

        function get_last_district() {
            $con = new dbconnection();
            $sql = "select district.district_id from district
                    order by district.district_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['district_id'];
            return $first_rec;
        }

        function list_sector($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from sector";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> sector </td>
                    <td> name </td><td> district </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['sector_id']; ?>
                    </td>
                    <td class="name_id_cols sector " title="sector" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['district']); ?>
                    </td>


                    <td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="sector_update_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_sector_name($id) {

            $db = new dbconnection();
            $sql = "select   sector.name from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_sector_district($id) {

            $db = new dbconnection();
            $sql = "select   sector.district from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['district'];
            echo $field;
        }

        function All_sector() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  sector_id   from sector";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function get_last_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function list_cell($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cell";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cell </td>
                    <td> name </td><td> sector </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['sector']); ?>
                    </td>


                    <td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cell_name($id) {

            $db = new dbconnection();
            $sql = "select   cell.name from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_cell_sector($id) {

            $db = new dbconnection();
            $sql = "select   cell.sector from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['sector'];
            echo $field;
        }

        function All_cell() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  cell_id   from cell";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function get_last_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function list_utilities($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from utilities";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> utilities </td>
                    <td> utilitiesdeleted </td><td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['utilities_id']; ?>
                    </td>
                    <td class="utilitiesdeleted_id_cols utilities " title="utilities" >
                        <?php echo $this->_e($row['utilitiesdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="utilities_delete_link" style="color: #000080;" value="
                           <?php echo $row['utilities_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="utilities_update_link" style="color: #000080;" value="
                           <?php echo $row['utilities_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_utilities_utilitiesdeleted($id) {

            $db = new dbconnection();
            $sql = "select   utilities.utilitiesdeleted from utilities where utilities_id=:utilities_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':utilities_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['utilitiesdeleted'];
            echo $field;
        }

        function get_chosen_utilities_name($id) {

            $db = new dbconnection();
            $sql = "select   utilities.name from utilities where utilities_id=:utilities_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':utilities_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_utilities() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  utilities_id   from utilities";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_utilities() {
            $con = new dbconnection();
            $sql = "select utilities.utilities_id from utilities
                    order by utilities.utilities_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['utilities_id'];
            return $first_rec;
        }

        function get_last_utilities() {
            $con = new dbconnection();
            $sql = "select utilities.utilities_id from utilities
                    order by utilities.utilities_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['utilities_id'];
            return $first_rec;
        }

        function list_price_utilities($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from price_utilities";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> price_utilities </td>
                    <td> price_utilitiesdeleted </td><td> price </td><td> utilities </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['price_utilities_id']; ?>
                    </td>
                    <td class="price_utilitiesdeleted_id_cols price_utilities " title="price_utilities" >
                        <?php echo $this->_e($row['price_utilitiesdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['price']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['utilities']); ?>
                    </td>


                    <td>
                        <a href="#" class="price_utilities_delete_link" style="color: #000080;" value="
                           <?php echo $row['price_utilities_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="price_utilities_update_link" style="color: #000080;" value="
                           <?php echo $row['price_utilities_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_price_utilities_price_utilitiesdeleted($id) {

            $db = new dbconnection();
            $sql = "select   price_utilities.price_utilitiesdeleted from price_utilities where price_utilities_id=:price_utilities_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_utilities_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['price_utilitiesdeleted'];
            echo $field;
        }

        function get_chosen_price_utilities_price($id) {

            $db = new dbconnection();
            $sql = "select   price_utilities.price from price_utilities where price_utilities_id=:price_utilities_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_utilities_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['price'];
            echo $field;
        }

        function get_chosen_price_utilities_utilities($id) {

            $db = new dbconnection();
            $sql = "select   price_utilities.utilities from price_utilities where price_utilities_id=:price_utilities_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':price_utilities_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['utilities'];
            echo $field;
        }

        function All_price_utilities() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  price_utilities_id   from price_utilities";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_price_utilities() {
            $con = new dbconnection();
            $sql = "select price_utilities.price_utilities_id from price_utilities
                    order by price_utilities.price_utilities_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['price_utilities_id'];
            return $first_rec;
        }

        function get_last_price_utilities() {
            $con = new dbconnection();
            $sql = "select price_utilities.price_utilities_id from price_utilities
                    order by price_utilities.price_utilities_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['price_utilities_id'];
            return $first_rec;
        }

        function list_comment_replies($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from comment_replies";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> comment_replies </td>
                    <td> comment_repliesdeleted </td><td> date </td><td> comment </td><td> message </td><td> account </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['comment_replies_id']; ?>
                    </td>
                    <td class="comment_repliesdeleted_id_cols comment_replies " title="comment_replies" >
                        <?php echo $this->_e($row['comment_repliesdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['comment']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="comment_replies_delete_link" style="color: #000080;" value="
                           <?php echo $row['comment_replies_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="comment_replies_update_link" style="color: #000080;" value="
                           <?php echo $row['comment_replies_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_comment_replies_comment_repliesdeleted($id) {

            $db = new dbconnection();
            $sql = "select   comment_replies.comment_repliesdeleted from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['comment_repliesdeleted'];
            echo $field;
        }

        function get_chosen_comment_replies_date($id) {

            $db = new dbconnection();
            $sql = "select   comment_replies.date from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_comment_replies_comment($id) {

            $db = new dbconnection();
            $sql = "select   comment_replies.comment from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['comment'];
            echo $field;
        }

        function get_chosen_comment_replies_message($id) {

            $db = new dbconnection();
            $sql = "select   comment_replies.message from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['message'];
            echo $field;
        }

        function get_chosen_comment_replies_account($id) {

            $db = new dbconnection();
            $sql = "select   comment_replies.account from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_comment_replies() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  comment_replies_id   from comment_replies";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_comment_replies() {
            $con = new dbconnection();
            $sql = "select comment_replies.comment_replies_id from comment_replies
                    order by comment_replies.comment_replies_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['comment_replies_id'];
            return $first_rec;
        }

        function get_last_comment_replies() {
            $con = new dbconnection();
            $sql = "select comment_replies.comment_replies_id from comment_replies
                    order by comment_replies.comment_replies_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['comment_replies_id'];
            return $first_rec;
        }

        function list_agency($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from agency";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> agency </td>
                    <td> website </td><td> office_address </td><td> agency_desc </td><td> logo </td><td> agency_name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['agency_id']; ?>
                    </td>
                    <td class="website_id_cols agency " title="agency" >
                        <?php echo $this->_e($row['website']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['office_address']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency_desc']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['logo']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency_name']); ?>
                    </td>


                    <td>
                        <a href="#" class="agency_delete_link" style="color: #000080;" value="
                           <?php echo $row['agency_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="agency_update_link" style="color: #000080;" value="
                           <?php echo $row['agency_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_agency_website($id) {

            $db = new dbconnection();
            $sql = "select   agency.website from agency where agency_id=:agency_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agency_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['website'];
            echo $field;
        }

        function get_chosen_agency_office_address($id) {

            $db = new dbconnection();
            $sql = "select   agency.office_address from agency where agency_id=:agency_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agency_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['office_address'];
            echo $field;
        }

        function get_chosen_agency_agency_desc($id) {

            $db = new dbconnection();
            $sql = "select   agency.agency_desc from agency where agency_id=:agency_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agency_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['agency_desc'];
            echo $field;
        }

        function get_chosen_agency_logo($id) {

            $db = new dbconnection();
            $sql = "select   agency.logo from agency where agency_id=:agency_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agency_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['logo'];
            echo $field;
        }

        function get_chosen_agency_agency_name($id) {

            $db = new dbconnection();
            $sql = "select   agency.agency_name from agency where agency_id=:agency_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agency_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['agency_name'];
            echo $field;
        }

        function All_agency() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  agency_id   from agency";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_agency() {
            $con = new dbconnection();
            $sql = "select agency.agency_id from agency
                    order by agency.agency_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['agency_id'];
            return $first_rec;
        }

        function get_last_agency() {
            $con = new dbconnection();
            $sql = "select agency.agency_id from agency
                    order by agency.agency_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['agency_id'];
            return $first_rec;
        }

        function list_message($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from message";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> message </td>
                    <td> account </td><td> date </td><td> type </td><td> message </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['message_id']; ?>
                    </td>
                    <td class="account_id_cols message " title="message" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>


                    <td>
                        <a href="#" class="message_delete_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="message_update_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_message_account($id) {

            $db = new dbconnection();
            $sql = "select   message.account from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_message_date($id) {

            $db = new dbconnection();
            $sql = "select   message.date from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_message_type($id) {

            $db = new dbconnection();
            $sql = "select   message.type from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['type'];
            echo $field;
        }

        function get_chosen_message_message($id) {

            $db = new dbconnection();
            $sql = "select   message.message from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['message'];
            echo $field;
        }

        function All_message() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  message_id   from message";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_message() {
            $con = new dbconnection();
            $sql = "select message.message_id from message
                    order by message.message_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['message_id'];
            return $first_rec;
        }

        function get_last_message() {
            $con = new dbconnection();
            $sql = "select message.message_id from message
                    order by message.message_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['message_id'];
            return $first_rec;
        }

        function list_msg_type($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from msg_type";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> msg_type </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['msg_type_id']; ?>
                    </td>
                    <td class="name_id_cols msg_type " title="msg_type" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="msg_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="msg_type_update_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_msg_type_name($id) {

            $db = new dbconnection();
            $sql = "select   msg_type.name from msg_type where msg_type_id=:msg_type_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':msg_type_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_msg_type() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  msg_type_id   from msg_type";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_msg_type() {
            $con = new dbconnection();
            $sql = "select msg_type.msg_type_id from msg_type
                    order by msg_type.msg_type_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['msg_type_id'];
            return $first_rec;
        }

        function get_last_msg_type() {
            $con = new dbconnection();
            $sql = "select msg_type.msg_type_id from msg_type
                    order by msg_type.msg_type_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['msg_type_id'];
            return $first_rec;
        }

        function list_agent($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from agent";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> agent </td>
                    <td> account </td><td> agency </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['agent_id']; ?>
                    </td>
                    <td class="account_id_cols agent " title="agent" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency']); ?>
                    </td>


                    <td>
                        <a href="#" class="agent_delete_link" style="color: #000080;" value="
                           <?php echo $row['agent_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="agent_update_link" style="color: #000080;" value="
                           <?php echo $row['agent_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_agent_account($id) {

            $db = new dbconnection();
            $sql = "select   agent.account from agent where agent_id=:agent_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agent_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_agent_agency($id) {

            $db = new dbconnection();
            $sql = "select   agent.agency from agent where agent_id=:agent_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':agent_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['agency'];
            echo $field;
        }

        function All_agent() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  agent_id   from agent";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_agent() {
            $con = new dbconnection();
            $sql = "select agent.agent_id from agent
                    order by agent.agent_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['agent_id'];
            return $first_rec;
        }

        function get_last_agent() {
            $con = new dbconnection();
            $sql = "select agent.agent_id from agent
                    order by agent.agent_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['agent_id'];
            return $first_rec;
        }

        function list_featured($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from featured";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> featured </td>
                    <td> date </td><td> listing </td><td> description </td><td> featured_cat </td><td> account </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['featured_id']; ?>
                    </td>
                    <td class="date_id_cols featured " title="featured" >
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['description']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['featured_cat']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="featured_delete_link" style="color: #000080;" value="
                           <?php echo $row['featured_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="featured_update_link" style="color: #000080;" value="
                           <?php echo $row['featured_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_featured_date($id) {

            $db = new dbconnection();
            $sql = "select   featured.date from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_featured_listing($id) {

            $db = new dbconnection();
            $sql = "select   featured.listing from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_featured_description($id) {

            $db = new dbconnection();
            $sql = "select   featured.description from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['description'];
            echo $field;
        }

        function get_chosen_featured_featured_cat($id) {

            $db = new dbconnection();
            $sql = "select   featured.featured_cat from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['featured_cat'];
            echo $field;
        }

        function get_chosen_featured_account($id) {

            $db = new dbconnection();
            $sql = "select   featured.account from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_featured() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  featured_id   from featured";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_featured() {
            $con = new dbconnection();
            $sql = "select featured.featured_id from featured
                    order by featured.featured_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['featured_id'];
            return $first_rec;
        }

        function get_last_featured() {
            $con = new dbconnection();
            $sql = "select featured.featured_id from featured
                    order by featured.featured_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['featured_id'];
            return $first_rec;
        }

        function list_featured_cat($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from featured_cat";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> featured_cat </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['featured_cat_id']; ?>
                    </td>
                    <td class="name_id_cols featured_cat " title="featured_cat" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="featured_cat_delete_link" style="color: #000080;" value="
                           <?php echo $row['featured_cat_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="featured_cat_update_link" style="color: #000080;" value="
                           <?php echo $row['featured_cat_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_featured_cat_name($id) {

            $db = new dbconnection();
            $sql = "select   featured_cat.name from featured_cat where featured_cat_id=:featured_cat_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_cat_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_featured_cat() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  featured_cat_id   from featured_cat";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_featured_cat() {
            $con = new dbconnection();
            $sql = "select featured_cat.featured_cat_id from featured_cat
                    order by featured_cat.featured_cat_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['featured_cat_id'];
            return $first_rec;
        }

        function get_last_featured_cat() {
            $con = new dbconnection();
            $sql = "select featured_cat.featured_cat_id from featured_cat
                    order by featured_cat.featured_cat_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['featured_cat_id'];
            return $first_rec;
        }

        function list_listing_comment($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from listing_comment";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> listing_comment </td>
                    <td> date </td><td> listing </td><td> message </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['listing_comment_id']; ?>
                    </td>
                    <td class="date_id_cols listing_comment " title="listing_comment" >
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>


                    <td>
                        <a href="#" class="listing_comment_delete_link" style="color: #000080;" value="
                           <?php echo $row['listing_comment_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="listing_comment_update_link" style="color: #000080;" value="
                           <?php echo $row['listing_comment_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_listing_comment_date($id) {

            $db = new dbconnection();
            $sql = "select   listing_comment.date from listing_comment where listing_comment_id=:listing_comment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_listing_comment_listing($id) {

            $db = new dbconnection();
            $sql = "select   listing_comment.listing from listing_comment where listing_comment_id=:listing_comment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_listing_comment_message($id) {

            $db = new dbconnection();
            $sql = "select   listing_comment.message from listing_comment where listing_comment_id=:listing_comment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':listing_comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['message'];
            echo $field;
        }

        function All_listing_comment() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  listing_comment_id   from listing_comment";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_listing_comment() {
            $con = new dbconnection();
            $sql = "select listing_comment.listing_comment_id from listing_comment
                    order by listing_comment.listing_comment_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_comment_id'];
            return $first_rec;
        }

        function get_last_listing_comment() {
            $con = new dbconnection();
            $sql = "select listing_comment.listing_comment_id from listing_comment
                    order by listing_comment.listing_comment_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['listing_comment_id'];
            return $first_rec;
        }

        function list_web_visits($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from web_visits";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> web_visits </td>
                    <td> date </td><td> visit_count </td><td> listing </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['web_visits_id']; ?>
                    </td>
                    <td class="date_id_cols web_visits " title="web_visits" >
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['visit_count']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>


                    <td>
                        <a href="#" class="web_visits_delete_link" style="color: #000080;" value="
                           <?php echo $row['web_visits_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="web_visits_update_link" style="color: #000080;" value="
                           <?php echo $row['web_visits_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_web_visits_date($id) {

            $db = new dbconnection();
            $sql = "select   web_visits.date from web_visits where web_visits_id=:web_visits_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':web_visits_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_web_visits_visit_count($id) {

            $db = new dbconnection();
            $sql = "select   web_visits.visit_count from web_visits where web_visits_id=:web_visits_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':web_visits_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['visit_count'];
            echo $field;
        }

        function get_chosen_web_visits_listing($id) {

            $db = new dbconnection();
            $sql = "select   web_visits.listing from web_visits where web_visits_id=:web_visits_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':web_visits_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function All_web_visits() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  web_visits_id   from web_visits";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_web_visits() {
            $con = new dbconnection();
            $sql = "select web_visits.web_visits_id from web_visits
                    order by web_visits.web_visits_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['web_visits_id'];
            return $first_rec;
        }

        function get_last_web_visits() {
            $con = new dbconnection();
            $sql = "select web_visits.web_visits_id from web_visits
                    order by web_visits.web_visits_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['web_visits_id'];
            return $first_rec;
        }

        function get_account_category_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account_category.account_category_id,   account_category.name from account_category";
            ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property_type.property_type_id,   property_type.name from property_type";
        ?>
        <select class="textbox cbo_property_type"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_subcategory_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property_subcategory.property_subcategory_id,   property_subcategory.name from property_subcategory";
        ?>
        <select class="textbox cbo_property_subcategory"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_subcategory_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property_type.property_type_id,   property_type.name from property_type";
        ?>
        <select class="textbox cbo_property_type"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select category.category_id,   category.name from category";
        ?>
        <select class="textbox cbo_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing_type.listing_type_id,   listing_type.name from listing_type";
        ?>
        <select class="textbox cbo_listing_type"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property.property_id,   property.name from property";
        ?>
        <select class="textbox cbo_property"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property_category.property_category_id,   property_category.name from property_category";
        ?>
        <select class="textbox cbo_property_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_location_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select location.location_id,   location.name from location";
        ?>
        <select class="textbox cbo_location"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['location_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property.property_id,   property.name from property";
        ?>
        <select class="textbox cbo_property"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_cell_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select class="textbox cbo_cell"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property.property_id,   property.name from property";
        ?>
        <select class="textbox cbo_property"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property.property_id,   property.name from property";
        ?>
        <select class="textbox cbo_property"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property_type.property_type_id,   property_type.name from property_type";
        ?>
        <select class="textbox cbo_property_type"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select property.property_id,   property.name from property";
        ?>
        <select class="textbox cbo_property"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="textbox cbo_district"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="textbox cbo_sector"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_province_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select province.province_id,   province.name from province";
        ?>
        <select class="textbox cbo_province"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_basic_info_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select basic_info.basic_info_id,   basic_info.name from basic_info";
        ?>
        <select class="textbox cbo_basic_info"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['basic_info_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_features_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select features.features_id,   features.name from features";
        ?>
        <select class="textbox cbo_features"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['features_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="textbox cbo_district"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="textbox cbo_sector"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_province_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select province.province_id,   province.name from province";
        ?>
        <select class="textbox cbo_province"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="textbox cbo_district"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="textbox cbo_sector"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_price_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select price.price_id,   price.name from price";
        ?>
        <select class="textbox cbo_price"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['price_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_utilities_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select utilities.utilities_id,   utilities.name from utilities";
        ?>
        <select class="textbox cbo_utilities"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['utilities_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_comment_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select comment.comment_id,   comment.name from comment";
        ?>
        <select class="textbox cbo_comment"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['comment_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_message_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select message.message_id,   message.name from message";
        ?>
        <select class="textbox cbo_message"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['message_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select type.type_id,   type.name from type";
        ?>
        <select class="textbox cbo_type"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_agency_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select agency.agency_id,   agency.name from agency";
        ?>
        <select class="textbox cbo_agency"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['agency_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_featured_cat_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select featured_cat.featured_cat_id,   featured_cat.name from featured_cat";
        ?>
        <select class="textbox cbo_featured_cat"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['featured_cat_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_message_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select message.message_id,   message.name from message";
        ?>
        <select class="textbox cbo_message"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['message_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_listing_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select listing.listing_id,   listing.name from listing";
        ?>
        <select class="textbox cbo_listing"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['listing_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
