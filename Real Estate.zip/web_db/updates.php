<?php

require_once 'connection.php';

class updates {

    function update_account($username, $password, $account_category, $online, $deleted, $date_created, $profile, $account_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account set username= ?, password= ?, account_category= ?, online= ?, deleted= ?, date_created= ?, profile= ? WHERE account_id=?");
        $stmt->execute(array($username, $password, $account_category, $online, $deleted, $date_created, $profile, $account_id));
    }

    function update_account_category($name, $account_category_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account_category set name= ? WHERE account_category_id=?");
        $stmt->execute(array($name, $account_category_id));
    }

    function update_profile($name, $last_name, $email, $home_phone, $office_phone, $mobile_phone, $address, $city, $country, $image, $profile_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE profile set name= ?, last_name= ?, email= ?, home_phone= ?, office_phone= ?, mobile_phone= ?, address= ?, city= ?, country= ?, image= ? WHERE profile_id=?");
        $stmt->execute(array($name, $last_name, $email, $home_phone, $office_phone, $mobile_phone, $address, $city, $country, $image, $profile_id));
    }

    function update_property($name, $property_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE property set 
name= ? WHERE property_id=?");
        $stmt->execute(array($name, $property_id));
    }

    function update_property_category($name, $property_type, $property_category_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE property_category set 
name= ?, property_type= ? WHERE property_category_id=?");
        $stmt->execute(array($name, $property_type, $property_category_id));
    }

    function update_property_subcategory($property_subcategory, $property_subcategory_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE property_subcategory set 
property_subcategory= ? WHERE property_subcategory_id=?");
        $stmt->execute(array($property_subcategory, $property_subcategory_id));
    }

    function update_features($name, $property_type, $category, $features_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE features set 
name= ?, property_type= ?, category= ? WHERE features_id=?");
        $stmt->execute(array($name, $property_type, $category, $features_id));
    }

    function update_listing($listing_date, $account, $listing_type, $property, $title, $purpose, $property_category, $location, $active, $listing_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE listing set 
listing_date= ?, account= ?, listing_type= ?, property= ?, title= ?, purpose= ?, property_category= ?, location= ?, active= ? WHERE listing_id=?");
        $stmt->execute(array($listing_date, $account, $listing_type, $property, $title, $purpose, $property_category, $location, $active, $listing_id));
    }

    function update_listing_type($name, $listing_type_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE listing_type set 
name= ? WHERE listing_type_id=?");
        $stmt->execute(array($name, $listing_type_id));
    }

    function update_image($path, $deleted, $appear, $listing, $image_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE image set 
path= ?, deleted= ?, appear= ?, listing= ? WHERE image_id=?");
        $stmt->execute(array($path, $deleted, $appear, $listing, $image_id));
    }

    function update_location($appear, $property, $lat, $longtd, $area, $address, $cell, $location_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE location set 
appear= ?, property= ?, lat= ?, longtd= ?, area= ?, address= ?, cell= ? WHERE location_id=?");
        $stmt->execute(array($appear, $property, $lat, $longtd, $area, $address, $cell, $location_id));
    }

    function update_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $price_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE price set 
amount= ?, currency= ?, condition= ?, property= ?, Minimum_advance= ?, deposit_required= ?, commission= ?, utilities_extra= ?, listing= ?, amount_per_day= ?, condition_per_day= ?, minimum_advance_per_day= ?, deposit_required_per_day= ?, commission_per_day= ?, utilities_extra_per_day= ? WHERE price_id=?");
        $stmt->execute(array($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $price_id));
    }

    function update_property_visitor($property, $property_visitor_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE property_visitor set 
property= ? WHERE property_visitor_id=?");
        $stmt->execute(array($property, $property_visitor_id));
    }

    function update_basic_info($name, $property_type, $basic_info_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE basic_info set 
name= ?, property_type= ? WHERE basic_info_id=?");
        $stmt->execute(array($name, $property_type, $basic_info_id));
    }

    function update_property_type($name, $property, $property_type_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE property_type set 
name= ?, property= ? WHERE property_type_id=?");
        $stmt->execute(array($name, $property, $property_type_id));
    }

    function update_province($name, $province_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE province set 
name= ? WHERE province_id=?");
        $stmt->execute(array($name, $province_id));
    }

    function update_sector($name, $district, $sector_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE sector set 
name= ?, district= ? WHERE sector_id=?");
        $stmt->execute(array($name, $district, $sector_id));
    }

    function update_cell($name, $sector, $cell_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
        $stmt->execute(array($name, $sector, $cell_id));
    }

    function update_district($name, $province, $district_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE district set 
name= ?, province= ? WHERE district_id=?");
        $stmt->execute(array($name, $province, $district_id));
    }

    function update_listing_basic_info($listing, $basic_info, $value, $listing_basic_info_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE listing_basic_info set 
listing= ?, basic_info= ?, value= ? WHERE listing_basic_info_id=?");
        $stmt->execute(array($listing, $basic_info, $value, $listing_basic_info_id));
    }

    function update_listing_features($listing, $features, $listing_features_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE listing_features set 
listing= ?, features= ? WHERE listing_features_id=?");
        $stmt->execute(array($listing, $features, $listing_features_id));
    }

    function update_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished, $basic_apartment_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE basic_apartment set 
basic_apartmentdeleted= ?, listing= ?, bedrooms= ?, bathrooms= ?, floor_number= ?, total_number_floors= ?, furnished= ? WHERE basic_apartment_id=?");
        $stmt->execute(array($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished, $basic_apartment_id));
    }

    function update_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished, $basic_commercial_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE basic_commercial set 
basic_commercialdeleted= ?, listing= ?, bedroom= ?, bathroom= ?, compound_size= ?, living_floors= ?, total_number_floors= ?, furnished= ? WHERE basic_commercial_id=?");
        $stmt->execute(array($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished, $basic_commercial_id));
    }

    function update_basic_house($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $basic_house_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE basic_house set 
basic_housedeleted= ?, listing= ?, furnished= ?, available_from= ?, bedroom= ?, bathroom= ?, compound_size= ?, living_floors= ?, total_number_floors= ? WHERE basic_house_id=?");
        $stmt->execute(array($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $basic_house_id));
    }

    function update_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from, $basic_land_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE basic_land set 
basic_landdeleted= ?, listing= ?, administrative_location= ?, plot_number= ?, plot_size= ?, lot_use= ?, available_from= ? WHERE basic_land_id=?");
        $stmt->execute(array($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from, $basic_land_id));
    }

    function update_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $basic_develop_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE basic_develop set 
basic_developdeleted= ?, listing= ?, bedrooms= ?, bathrooms= ?, compound_size= ?, living_floors= ?, total_number_floors= ? WHERE basic_develop_id=?");
        $stmt->execute(array($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $basic_develop_id));
    }

    function update_currency_conversion($currency_conversiondeleted, $from, $to, $rate, $currency_conversion_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE currency_conversion set 
currency_conversiondeleted= ?, from= ?, to= ?, rate= ? WHERE currency_conversion_id=?");
        $stmt->execute(array($currency_conversiondeleted, $from, $to, $rate, $currency_conversion_id));
    }

    function update_property_request($property_requestdeleted, $names, $telephone, $email, $listing, $received, $account, $property_request_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE property_request set 
property_requestdeleted= ?, names= ?, telephone= ?, email= ?, listing= ?, received= ?, account= ? WHERE property_request_id=?");
        $stmt->execute(array($property_requestdeleted, $names, $telephone, $email, $listing, $received, $account, $property_request_id));
    }

    function update_features_cat($features_catdeleted, $cat_name, $features_cat_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE features_cat set 
features_catdeleted= ?, cat_name= ? WHERE features_cat_id=?");
        $stmt->execute(array($features_catdeleted, $cat_name, $features_cat_id));
    }

    function update_sector($name, $district, $sector_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE sector set 
name= ?, district= ? WHERE sector_id=?");
        $stmt->execute(array($name, $district, $sector_id));
    }

    function update_cell($name, $sector, $cell_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
        $stmt->execute(array($name, $sector, $cell_id));
    }

    function update_district($name, $province, $district_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE district set 
name= ?, province= ? WHERE district_id=?");
        $stmt->execute(array($name, $province, $district_id));
    }

    function update_sector($name, $district, $sector_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE sector set 
name= ?, district= ? WHERE sector_id=?");
        $stmt->execute(array($name, $district, $sector_id));
    }

    function update_cell($name, $sector, $cell_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
        $stmt->execute(array($name, $sector, $cell_id));
    }

    function update_utilities($utilitiesdeleted, $name, $utilities_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE utilities set 
utilitiesdeleted= ?, name= ? WHERE utilities_id=?");
        $stmt->execute(array($utilitiesdeleted, $name, $utilities_id));
    }

    function update_price_utilities($price_utilitiesdeleted, $price, $utilities, $price_utilities_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE price_utilities set 
price_utilitiesdeleted= ?, price= ?, utilities= ? WHERE price_utilities_id=?");
        $stmt->execute(array($price_utilitiesdeleted, $price, $utilities, $price_utilities_id));
    }

    function update_comment_replies($comment_repliesdeleted, $date, $comment, $message, $account, $comment_replies_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE comment_replies set 
comment_repliesdeleted= ?, date= ?, comment= ?, message= ?, account= ? WHERE comment_replies_id=?");
        $stmt->execute(array($comment_repliesdeleted, $date, $comment, $message, $account, $comment_replies_id));
    }

    function update_agency($website, $office_address, $agency_desc, $logo, $agency_name, $agency_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE agency set 
website= ?, office_address= ?, agency_desc= ?, logo= ?, agency_name= ? WHERE agency_id=?");
        $stmt->execute(array($website, $office_address, $agency_desc, $logo, $agency_name, $agency_id));
    }

    function update_message($account, $date, $type, $message, $message_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE message set 
account= ?, date= ?, type= ?, message= ? WHERE message_id=?");
        $stmt->execute(array($account, $date, $type, $message, $message_id));
    }

    function update_msg_type($name, $msg_type_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE msg_type set 
name= ? WHERE msg_type_id=?");
        $stmt->execute(array($name, $msg_type_id));
    }

    function update_agent($account, $agency, $agent_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE agent set 
account= ?, agency= ? WHERE agent_id=?");
        $stmt->execute(array($account, $agency, $agent_id));
    }

    function update_featured($date, $listing, $description, $featured_cat, $account, $featured_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE featured set 
date= ?, listing= ?, description= ?, featured_cat= ?, account= ? WHERE featured_id=?");
        $stmt->execute(array($date, $listing, $description, $featured_cat, $account, $featured_id));
    }

    function update_featured_cat($name, $featured_cat_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE featured_cat set 
name= ? WHERE featured_cat_id=?");
        $stmt->execute(array($name, $featured_cat_id));
    }

    function update_listing_comment($date, $listing, $message, $listing_comment_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE listing_comment set 
date= ?, listing= ?, message= ? WHERE listing_comment_id=?");
        $stmt->execute(array($date, $listing, $message, $listing_comment_id));
    }

    function update_web_visits($date, $visit_count, $listing, $web_visits_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE web_visits set 
date= ?, visit_count= ?, listing= ? WHERE web_visits_id=?");
        $stmt->execute(array($date, $visit_count, $listing, $web_visits_id));
    }

}
