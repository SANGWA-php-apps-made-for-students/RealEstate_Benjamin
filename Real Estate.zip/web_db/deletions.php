<?php

require_once 'connection.php';

class deletions {

    function deleteFrom_account($account_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM account where account_id =:account_id");
        $smt->bindValue(':account_id', $account_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_account_category($account_category_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
        $smt->bindValue(':account_category_id', $account_category_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_profile($profile_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM profile where profile_id =:profile_id");
        $smt->bindValue(':profile_id', $profile_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property($property_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM property where property_id =:property_id");
        $smt->bindValue(':property_id', $property_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property_category($property_category_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM property_category where property_category_id =:property_category_id");
        $smt->bindValue(':property_category_id', $property_category_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property_subcategory($property_subcategory_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM property_subcategory where property_subcategory_id =:property_subcategory_id");
        $smt->bindValue(':property_subcategory_id', $property_subcategory_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_features($features_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM features where features_id =:features_id");
        $smt->bindValue(':features_id', $features_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_listing($listing_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM listing where listing_id =:listing_id");
        $smt->bindValue(':listing_id', $listing_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_listing_type($listing_type_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM listing_type where listing_type_id =:listing_type_id");
        $smt->bindValue(':listing_type_id', $listing_type_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_image($image_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM image where image_id =:image_id");
        $smt->bindValue(':image_id', $image_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_location($location_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM location where location_id =:location_id");
        $smt->bindValue(':location_id', $location_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_price($price_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM price where price_id =:price_id");
        $smt->bindValue(':price_id', $price_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property_visitor($property_visitor_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM property_visitor where property_visitor_id =:property_visitor_id");
        $smt->bindValue(':property_visitor_id', $property_visitor_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_info($basic_info_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM basic_info where basic_info_id =:basic_info_id");
        $smt->bindValue(':basic_info_id', $basic_info_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property_type($property_type_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM property_type where property_type_id =:property_type_id");
        $smt->bindValue(':property_type_id', $property_type_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_province($province_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM province where province_id =:province_id");
        $smt->bindValue(':province_id', $province_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_sector($sector_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM sector where sector_id =:sector_id");
        $smt->bindValue(':sector_id', $sector_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cell($cell_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cell where cell_id =:cell_id");
        $smt->bindValue(':cell_id', $cell_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_district($district_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM district where district_id =:district_id");
        $smt->bindValue(':district_id', $district_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_listing_basic_info($listing_basic_info_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM listing_basic_info where listing_basic_info_id =:listing_basic_info_id");
        $smt->bindValue(':listing_basic_info_id', $listing_basic_info_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_listing_features($listing_features_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM listing_features where listing_features_id =:listing_features_id");
        $smt->bindValue(':listing_features_id', $listing_features_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_apartment($basic_apartment_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM basic_apartment where basic_apartment_id =:basic_apartment_id");
        $smt->bindValue(':basic_apartment_id', $basic_apartment_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_commercial($basic_commercial_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM basic_commercial where basic_commercial_id =:basic_commercial_id");
        $smt->bindValue(':basic_commercial_id', $basic_commercial_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_house($basic_house_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM basic_house where basic_house_id =:basic_house_id");
        $smt->bindValue(':basic_house_id', $basic_house_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_land($basic_land_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM basic_land where basic_land_id =:basic_land_id");
        $smt->bindValue(':basic_land_id', $basic_land_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_develop($basic_develop_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM basic_develop where basic_develop_id =:basic_develop_id");
        $smt->bindValue(':basic_develop_id', $basic_develop_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_currency_conversion($currency_conversion_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM currency_conversion where currency_conversion_id =:currency_conversion_id");
        $smt->bindValue(':currency_conversion_id', $currency_conversion_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property_request($property_request_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM property_request where property_request_id =:property_request_id");
        $smt->bindValue(':property_request_id', $property_request_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_features_cat($features_cat_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM features_cat where features_cat_id =:features_cat_id");
        $smt->bindValue(':features_cat_id', $features_cat_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_sector($sector_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM sector where sector_id =:sector_id");
        $smt->bindValue(':sector_id', $sector_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cell($cell_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cell where cell_id =:cell_id");
        $smt->bindValue(':cell_id', $cell_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_district($district_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM district where district_id =:district_id");
        $smt->bindValue(':district_id', $district_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_sector($sector_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM sector where sector_id =:sector_id");
        $smt->bindValue(':sector_id', $sector_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cell($cell_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cell where cell_id =:cell_id");
        $smt->bindValue(':cell_id', $cell_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_utilities($utilities_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM utilities where utilities_id =:utilities_id");
        $smt->bindValue(':utilities_id', $utilities_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_price_utilities($price_utilities_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM price_utilities where price_utilities_id =:price_utilities_id");
        $smt->bindValue(':price_utilities_id', $price_utilities_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_comment_replies($comment_replies_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM comment_replies where comment_replies_id =:comment_replies_id");
        $smt->bindValue(':comment_replies_id', $comment_replies_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_agency($agency_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM agency where agency_id =:agency_id");
        $smt->bindValue(':agency_id', $agency_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_message($message_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM message where message_id =:message_id");
        $smt->bindValue(':message_id', $message_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_msg_type($msg_type_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM msg_type where msg_type_id =:msg_type_id");
        $smt->bindValue(':msg_type_id', $msg_type_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_agent($agent_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM agent where agent_id =:agent_id");
        $smt->bindValue(':agent_id', $agent_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_featured($featured_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM featured where featured_id =:featured_id");
        $smt->bindValue(':featured_id', $featured_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_featured_cat($featured_cat_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM featured_cat where featured_cat_id =:featured_cat_id");
        $smt->bindValue(':featured_cat_id', $featured_cat_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_listing_comment($listing_comment_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM listing_comment where listing_comment_id =:listing_comment_id");
        $smt->bindValue(':listing_comment_id', $listing_comment_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_web_visits($web_visits_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM web_visits where web_visits_id =:web_visits_id");
        $smt->bindValue(':web_visits_id', $web_visits_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

}
