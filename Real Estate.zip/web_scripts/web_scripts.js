$(document).ready(function () {
get_new_data_hide_show();
show_form_toUpdate();
web_visits_del_udpate();
get_pages_moving();
dlog_btn_No_Yes();
hide_select_pane();

        get_account_category_id_combo();        get_profile_id_combo();        get_image_id_combo();        get_property_type_id_combo();        get_property_subcategory_id_combo();        get_property_type_id_combo();        get_category_id_combo();        get_account_id_combo();        get_listing_type_id_combo();        get_property_id_combo();        get_property_category_id_combo();        get_location_id_combo();        get_listing_id_combo();        get_property_id_combo();        get_cell_id_combo();        get_property_id_combo();        get_listing_id_combo();        get_property_id_combo();        get_property_type_id_combo();        get_property_id_combo();        get_district_id_combo();        get_sector_id_combo();        get_province_id_combo();        get_listing_id_combo();        get_basic_info_id_combo();        get_listing_id_combo();        get_features_id_combo();        get_listing_id_combo();        get_listing_id_combo();        get_listing_id_combo();        get_listing_id_combo();        get_listing_id_combo();        get_listing_id_combo();        get_district_id_combo();        get_sector_id_combo();        get_province_id_combo();        get_district_id_combo();        get_sector_id_combo();        get_price_id_combo();        get_utilities_id_combo();        get_comment_id_combo();        get_message_id_combo();        get_account_id_combo();        get_account_id_combo();        get_type_id_combo();        get_account_id_combo();        get_agency_id_combo();        get_listing_id_combo();        get_featured_cat_id_combo();        get_account_id_combo();        get_listing_id_combo();        get_message_id_combo();        get_listing_id_combo();


});

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
                $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
                $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_type_id_combo() {
    try {
        $('.cbo_property_type').change(function () {
            var cbo_property_type = $('.cbo_property_type option:selected').val();
                $('#txt_property_type_id').val(cbo_property_type);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_subcategory_id_combo() {
    try {
        $('.cbo_property_subcategory').change(function () {
            var cbo_property_subcategory = $('.cbo_property_subcategory option:selected').val();
                $('#txt_property_subcategory_id').val(cbo_property_subcategory);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_type_id_combo() {
    try {
        $('.cbo_property_type').change(function () {
            var cbo_property_type = $('.cbo_property_type option:selected').val();
                $('#txt_property_type_id').val(cbo_property_type);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_category_id_combo() {
    try {
        $('.cbo_category').change(function () {
            var cbo_category = $('.cbo_category option:selected').val();
                $('#txt_category_id').val(cbo_category);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_type_id_combo() {
    try {
        $('.cbo_listing_type').change(function () {
            var cbo_listing_type = $('.cbo_listing_type option:selected').val();
                $('#txt_listing_type_id').val(cbo_listing_type);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_id_combo() {
    try {
        $('.cbo_property').change(function () {
            var cbo_property = $('.cbo_property option:selected').val();
                $('#txt_property_id').val(cbo_property);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_category_id_combo() {
    try {
        $('.cbo_property_category').change(function () {
            var cbo_property_category = $('.cbo_property_category option:selected').val();
                $('#txt_property_category_id').val(cbo_property_category);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_location_id_combo() {
    try {
        $('.cbo_location').change(function () {
            var cbo_location = $('.cbo_location option:selected').val();
                $('#txt_location_id').val(cbo_location);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_id_combo() {
    try {
        $('.cbo_property').change(function () {
            var cbo_property = $('.cbo_property option:selected').val();
                $('#txt_property_id').val(cbo_property);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
                $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_id_combo() {
    try {
        $('.cbo_property').change(function () {
            var cbo_property = $('.cbo_property option:selected').val();
                $('#txt_property_id').val(cbo_property);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_id_combo() {
    try {
        $('.cbo_property').change(function () {
            var cbo_property = $('.cbo_property option:selected').val();
                $('#txt_property_id').val(cbo_property);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_type_id_combo() {
    try {
        $('.cbo_property_type').change(function () {
            var cbo_property_type = $('.cbo_property_type option:selected').val();
                $('#txt_property_type_id').val(cbo_property_type);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_property_id_combo() {
    try {
        $('.cbo_property').change(function () {
            var cbo_property = $('.cbo_property option:selected').val();
                $('#txt_property_id').val(cbo_property);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_district_id_combo() {
    try {
        $('.cbo_district').change(function () {
            var cbo_district = $('.cbo_district option:selected').val();
                $('#txt_district_id').val(cbo_district);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_province_id_combo() {
    try {
        $('.cbo_province').change(function () {
            var cbo_province = $('.cbo_province option:selected').val();
                $('#txt_province_id').val(cbo_province);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_basic_info_id_combo() {
    try {
        $('.cbo_basic_info').change(function () {
            var cbo_basic_info = $('.cbo_basic_info option:selected').val();
                $('#txt_basic_info_id').val(cbo_basic_info);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_features_id_combo() {
    try {
        $('.cbo_features').change(function () {
            var cbo_features = $('.cbo_features option:selected').val();
                $('#txt_features_id').val(cbo_features);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_district_id_combo() {
    try {
        $('.cbo_district').change(function () {
            var cbo_district = $('.cbo_district option:selected').val();
                $('#txt_district_id').val(cbo_district);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_province_id_combo() {
    try {
        $('.cbo_province').change(function () {
            var cbo_province = $('.cbo_province option:selected').val();
                $('#txt_province_id').val(cbo_province);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_district_id_combo() {
    try {
        $('.cbo_district').change(function () {
            var cbo_district = $('.cbo_district option:selected').val();
                $('#txt_district_id').val(cbo_district);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_price_id_combo() {
    try {
        $('.cbo_price').change(function () {
            var cbo_price = $('.cbo_price option:selected').val();
                $('#txt_price_id').val(cbo_price);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_utilities_id_combo() {
    try {
        $('.cbo_utilities').change(function () {
            var cbo_utilities = $('.cbo_utilities option:selected').val();
                $('#txt_utilities_id').val(cbo_utilities);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_comment_id_combo() {
    try {
        $('.cbo_comment').change(function () {
            var cbo_comment = $('.cbo_comment option:selected').val();
                $('#txt_comment_id').val(cbo_comment);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_message_id_combo() {
    try {
        $('.cbo_message').change(function () {
            var cbo_message = $('.cbo_message option:selected').val();
                $('#txt_message_id').val(cbo_message);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_type_id_combo() {
    try {
        $('.cbo_type').change(function () {
            var cbo_type = $('.cbo_type option:selected').val();
                $('#txt_type_id').val(cbo_type);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_agency_id_combo() {
    try {
        $('.cbo_agency').change(function () {
            var cbo_agency = $('.cbo_agency option:selected').val();
                $('#txt_agency_id').val(cbo_agency);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_featured_cat_id_combo() {
    try {
        $('.cbo_featured_cat').change(function () {
            var cbo_featured_cat = $('.cbo_featured_cat option:selected').val();
                $('#txt_featured_cat_id').val(cbo_featured_cat);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_message_id_combo() {
    try {
        $('.cbo_message').change(function () {
            var cbo_message = $('.cbo_message option:selected').val();
                $('#txt_message_id').val(cbo_message);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_listing_id_combo() {
    try {
        $('.cbo_listing').change(function () {
            var cbo_listing = $('.cbo_listing option:selected').val();
                $('#txt_listing_id').val(cbo_listing);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_new_data_hide_show(){
     $('.new_data_hider').click(function (){
         $('.new_data_box').slideToggle();
     });
    
}
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
            //here its fine!.
        } else {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer','pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname=$('#txt_shall_expand_toUpdate').val();
    if (updname!='') {
          $('.new_data_box').delay(200).slideDown();
    }
        
}
function postDisplayData(call_dialog,div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
         alert('Declined!');
    });
}function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}

//update from account ...
 
function account_del_udpate(){
$('.account_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
 $('.account_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from account_category ...
 
function account_category_del_udpate(){
$('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
 $('.account_category_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account_category').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from profile ...
 
function profile_del_udpate(){
$('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
 $('.profile_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.profile').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from property ...
 
function property_del_udpate(){
$('.property_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.property').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromproperty.. 
 $('.property_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.property').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from property_category ...
 
function property_category_del_udpate(){
$('.property_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.property_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromproperty_category.. 
 $('.property_category_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.property_category').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from property_subcategory ...
 
function property_subcategory_del_udpate(){
$('.property_subcategory_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.property_subcategory').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromproperty_subcategory.. 
 $('.property_subcategory_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.property_subcategory').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from features ...
 
function features_del_udpate(){
$('.features_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.features').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfeatures.. 
 $('.features_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.features').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from listing ...
 
function listing_del_udpate(){
$('.listing_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.listing').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlisting.. 
 $('.listing_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.listing').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from listing_type ...
 
function listing_type_del_udpate(){
$('.listing_type_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.listing_type').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlisting_type.. 
 $('.listing_type_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.listing_type').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from image ...
 
function image_del_udpate(){
$('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
 $('.image_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.image').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from location ...
 
function location_del_udpate(){
$('.location_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.location').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlocation.. 
 $('.location_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.location').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from price ...
 
function price_del_udpate(){
$('.price_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.price').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprice.. 
 $('.price_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.price').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from property_visitor ...
 
function property_visitor_del_udpate(){
$('.property_visitor_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.property_visitor').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromproperty_visitor.. 
 $('.property_visitor_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.property_visitor').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from basic_info ...
 
function basic_info_del_udpate(){
$('.basic_info_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.basic_info').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombasic_info.. 
 $('.basic_info_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.basic_info').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from property_type ...
 
function property_type_del_udpate(){
$('.property_type_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.property_type').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromproperty_type.. 
 $('.property_type_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.property_type').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from province ...
 
function province_del_udpate(){
$('.province_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.province').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprovince.. 
 $('.province_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.province').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from sector ...
 
function sector_del_udpate(){
$('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
 $('.sector_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.sector').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from district ...
 
function district_del_udpate(){
$('.district_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.district').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistrict.. 
 $('.district_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.district').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from listing_basic_info ...
 
function listing_basic_info_del_udpate(){
$('.listing_basic_info_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.listing_basic_info').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlisting_basic_info.. 
 $('.listing_basic_info_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.listing_basic_info').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from listing_features ...
 
function listing_features_del_udpate(){
$('.listing_features_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.listing_features').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlisting_features.. 
 $('.listing_features_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.listing_features').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from basic_apartment ...
 
function basic_apartment_del_udpate(){
$('.basic_apartment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.basic_apartment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombasic_apartment.. 
 $('.basic_apartment_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.basic_apartment').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from basic_commercial ...
 
function basic_commercial_del_udpate(){
$('.basic_commercial_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.basic_commercial').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombasic_commercial.. 
 $('.basic_commercial_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.basic_commercial').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from basic_house ...
 
function basic_house_del_udpate(){
$('.basic_house_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.basic_house').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombasic_house.. 
 $('.basic_house_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.basic_house').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from basic_land ...
 
function basic_land_del_udpate(){
$('.basic_land_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.basic_land').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombasic_land.. 
 $('.basic_land_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.basic_land').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from basic_develop ...
 
function basic_develop_del_udpate(){
$('.basic_develop_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.basic_develop').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frombasic_develop.. 
 $('.basic_develop_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.basic_develop').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from currency_conversion ...
 
function currency_conversion_del_udpate(){
$('.currency_conversion_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.currency_conversion').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcurrency_conversion.. 
 $('.currency_conversion_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.currency_conversion').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from property_request ...
 
function property_request_del_udpate(){
$('.property_request_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.property_request').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromproperty_request.. 
 $('.property_request_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.property_request').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from features_cat ...
 
function features_cat_del_udpate(){
$('.features_cat_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.features_cat').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfeatures_cat.. 
 $('.features_cat_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.features_cat').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from sector ...
 
function sector_del_udpate(){
$('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
 $('.sector_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.sector').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from district ...
 
function district_del_udpate(){
$('.district_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.district').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistrict.. 
 $('.district_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.district').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from sector ...
 
function sector_del_udpate(){
$('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
 $('.sector_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.sector').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from utilities ...
 
function utilities_del_udpate(){
$('.utilities_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.utilities').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromutilities.. 
 $('.utilities_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.utilities').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from price_utilities ...
 
function price_utilities_del_udpate(){
$('.price_utilities_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.price_utilities').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprice_utilities.. 
 $('.price_utilities_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.price_utilities').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from comment_replies ...
 
function comment_replies_del_udpate(){
$('.comment_replies_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.comment_replies').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcomment_replies.. 
 $('.comment_replies_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.comment_replies').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from agency ...
 
function agency_del_udpate(){
$('.agency_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.agency').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromagency.. 
 $('.agency_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.agency').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from message ...
 
function message_del_udpate(){
$('.message_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.message').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frommessage.. 
 $('.message_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.message').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from msg_type ...
 
function msg_type_del_udpate(){
$('.msg_type_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.msg_type').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frommsg_type.. 
 $('.msg_type_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.msg_type').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from agent ...
 
function agent_del_udpate(){
$('.agent_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.agent').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromagent.. 
 $('.agent_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.agent').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from featured ...
 
function featured_del_udpate(){
$('.featured_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.featured').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfeatured.. 
 $('.featured_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.featured').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from featured_cat ...
 
function featured_cat_del_udpate(){
$('.featured_cat_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.featured_cat').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfeatured_cat.. 
 $('.featured_cat_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.featured_cat').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from listing_comment ...
 
function listing_comment_del_udpate(){
$('.listing_comment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.listing_comment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlisting_comment.. 
 $('.listing_comment_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.listing_comment').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}//update from web_visits ...
 
function web_visits_del_udpate(){
$('.web_visits_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.web_visits').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromweb_visits.. 
 $('.web_visits_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.web_visits').attr('title');
        var id_delete = $(this).attr('value').trim();
        
        $(this).closest('tr').slideUp(400);        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {
           
        });

    });
}
