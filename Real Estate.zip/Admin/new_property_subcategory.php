<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_property_subcategory'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'property_subcategory'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $property_subcategory_id=$_SESSION['id_upd'];
                      
$property_subcategory =trim( $_POST['txt_property_subcategory_id']);


$upd_obj->update_property_subcategory($property_subcategory,$property_subcategory_id);
unset($_SESSION['table_to_update']);
}}else{$property_subcategory =trim( $_POST['txt_property_subcategory_id']);

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_property_subcategory($property_subcategory);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
property_subcategory</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_property_subcategory.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_property_subcategory_id"   name="txt_property_subcategory_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 property_subcategory saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  property_subcategory</div>
 <table class="new_data_table">


 <tr><td>property_subcategory :</td><td> <?php get_property_subcategory_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_property_subcategory" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">property_subcategory List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_property_subcategory();
                    $obj->list_property_subcategory($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_property_subcategory_combo() {
    $obj = new multi_values();
    $obj->get_property_subcategory_in_combo();
}
function chosen_property_subcategory_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'property_subcategory') {               $id = $_SESSION['id_upd'];
               $property_subcategory = new multi_values();
               return $property_subcategory->get_chosen_property_subcategory_property_subcategory($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
