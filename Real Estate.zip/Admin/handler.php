<?php
 session_start();

if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_image'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
    return $id;
}
if (isset($_POST['cbo_property_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_type_id_by_property_type_name($_POST['cbo_property_type']);
    return $id;
}
if (isset($_POST['cbo_property_subcategory'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_subcategory_id_by_property_subcategory_name($_POST['cbo_property_subcategory']);
    return $id;
}
if (isset($_POST['cbo_property_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_type_id_by_property_type_name($_POST['cbo_property_type']);
    return $id;
}
if (isset($_POST['cbo_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_category_id_by_category_name($_POST['cbo_category']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_listing_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_type_id_by_listing_type_name($_POST['cbo_listing_type']);
    return $id;
}
if (isset($_POST['cbo_property'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_id_by_property_name($_POST['cbo_property']);
    return $id;
}
if (isset($_POST['cbo_property_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_category_id_by_property_category_name($_POST['cbo_property_category']);
    return $id;
}
if (isset($_POST['cbo_location'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_location_id_by_location_name($_POST['cbo_location']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_property'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_id_by_property_name($_POST['cbo_property']);
    return $id;
}
if (isset($_POST['cbo_cell'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
    return $id;
}
if (isset($_POST['cbo_property'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_id_by_property_name($_POST['cbo_property']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_property'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_id_by_property_name($_POST['cbo_property']);
    return $id;
}
if (isset($_POST['cbo_property_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_type_id_by_property_type_name($_POST['cbo_property_type']);
    return $id;
}
if (isset($_POST['cbo_property'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_property_id_by_property_name($_POST['cbo_property']);
    return $id;
}
if (isset($_POST['cbo_district'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_district_id_by_district_name($_POST['cbo_district']);
    return $id;
}
if (isset($_POST['cbo_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
    return $id;
}
if (isset($_POST['cbo_province'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_province_id_by_province_name($_POST['cbo_province']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_basic_info'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_basic_info_id_by_basic_info_name($_POST['cbo_basic_info']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_features'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_features_id_by_features_name($_POST['cbo_features']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_district'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_district_id_by_district_name($_POST['cbo_district']);
    return $id;
}
if (isset($_POST['cbo_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
    return $id;
}
if (isset($_POST['cbo_province'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_province_id_by_province_name($_POST['cbo_province']);
    return $id;
}
if (isset($_POST['cbo_district'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_district_id_by_district_name($_POST['cbo_district']);
    return $id;
}
if (isset($_POST['cbo_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
    return $id;
}
if (isset($_POST['cbo_price'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_price_id_by_price_name($_POST['cbo_price']);
    return $id;
}
if (isset($_POST['cbo_utilities'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_utilities_id_by_utilities_name($_POST['cbo_utilities']);
    return $id;
}
if (isset($_POST['cbo_comment'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_comment_id_by_comment_name($_POST['cbo_comment']);
    return $id;
}
if (isset($_POST['cbo_message'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_message_id_by_message_name($_POST['cbo_message']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_type_id_by_type_name($_POST['cbo_type']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_agency'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_agency_id_by_agency_name($_POST['cbo_agency']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_featured_cat'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_featured_cat_id_by_featured_cat_name($_POST['cbo_featured_cat']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}
if (isset($_POST['cbo_message'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_message_id_by_message_name($_POST['cbo_message']);
    return $id;
}
if (isset($_POST['cbo_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_listing_id_by_listing_name($_POST['cbo_listing']);
    return $id;
}

if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from account
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);}
//The Delete from account_category
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account_category($id);}
//The Delete from profile
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);}
//The Delete from property
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'property') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_property($id);}
//The Delete from property_category
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'property_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_property_category($id);}
//The Delete from property_subcategory
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'property_subcategory') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_property_subcategory($id);}
//The Delete from features
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'features') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_features($id);}
//The Delete from listing
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'listing') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_listing($id);}
//The Delete from listing_type
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'listing_type') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_listing_type($id);}
//The Delete from image
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_image($id);}
//The Delete from location
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'location') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_location($id);}
//The Delete from price
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'price') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_price($id);}
//The Delete from property_visitor
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'property_visitor') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_property_visitor($id);}
//The Delete from basic_info
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'basic_info') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_basic_info($id);}
//The Delete from property_type
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'property_type') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_property_type($id);}
//The Delete from province
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'province') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_province($id);}
//The Delete from sector
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from district
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'district') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_district($id);}
//The Delete from listing_basic_info
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'listing_basic_info') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_listing_basic_info($id);}
//The Delete from listing_features
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'listing_features') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_listing_features($id);}
//The Delete from basic_apartment
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'basic_apartment') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_basic_apartment($id);}
//The Delete from basic_commercial
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'basic_commercial') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_basic_commercial($id);}
//The Delete from basic_house
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'basic_house') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_basic_house($id);}
//The Delete from basic_land
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'basic_land') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_basic_land($id);}
//The Delete from basic_develop
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'basic_develop') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_basic_develop($id);}
//The Delete from currency_conversion
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'currency_conversion') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_currency_conversion($id);}
//The Delete from property_request
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'property_request') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_property_request($id);}
//The Delete from features_cat
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'features_cat') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_features_cat($id);}
//The Delete from sector
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from district
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'district') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_district($id);}
//The Delete from sector
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from utilities
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'utilities') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_utilities($id);}
//The Delete from price_utilities
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'price_utilities') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_price_utilities($id);}
//The Delete from comment_replies
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'comment_replies') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_comment_replies($id);}
//The Delete from agency
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'agency') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_agency($id);}
//The Delete from message
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'message') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_message($id);}
//The Delete from msg_type
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'msg_type') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_msg_type($id);}
//The Delete from agent
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'agent') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_agent($id);}
//The Delete from featured
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'featured') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_featured($id);}
//The Delete from featured_cat
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'featured_cat') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_featured_cat($id);}
//The Delete from listing_comment
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'listing_comment') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_listing_comment($id);}
//The Delete from web_visits
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'web_visits') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_web_visits($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
