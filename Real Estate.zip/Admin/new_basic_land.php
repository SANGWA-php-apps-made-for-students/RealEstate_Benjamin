<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_basic_land'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'basic_land'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $basic_land_id=$_SESSION['id_upd'];
                      
$basic_landdeleted = $_POST['txt_basic_landdeleted'];
$listing = $_POST['txt_listing_id'];

$administrative_location = $_POST['txt_administrative_location'];
$plot_number = $_POST['txt_plot_number'];
$plot_size = $_POST['txt_plot_size'];
$lot_use = $_POST['txt_lot_use'];
$available_from = $_POST['txt_available_from'];


$upd_obj->update_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from,$basic_land_id);
unset($_SESSION['table_to_update']);
}}else{$basic_landdeleted = $_POST['txt_basic_landdeleted'];
$listing =trim( $_POST['txt_listing_id']);
$administrative_location = $_POST['txt_administrative_location'];
$plot_number = $_POST['txt_plot_number'];
$plot_size = $_POST['txt_plot_size'];
$lot_use = $_POST['txt_lot_use'];
$available_from = $_POST['txt_available_from'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
basic_land</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_basic_land.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_listing_id"   name="txt_listing_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 basic_land saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  basic_land</div>
 <table class="new_data_table">


<tr><td>basic_landdeleted :</td><td> <input type="text"     name="txt_basic_landdeleted" required class="textbox" value="<?php echo trim(chosen_basic_landdeleted_upd());?>"   />  </td></tr>
 <tr><td>listing :</td><td> <?php get_listing_combo(); ?>  </td></tr><tr><td>administrative_location :</td><td> <input type="text"     name="txt_administrative_location" required class="textbox" value="<?php echo trim(chosen_administrative_location_upd());?>"   />  </td></tr>
<tr><td>plot_number :</td><td> <input type="text"     name="txt_plot_number" required class="textbox" value="<?php echo trim(chosen_plot_number_upd());?>"   />  </td></tr>
<tr><td>plot_size :</td><td> <input type="text"     name="txt_plot_size" required class="textbox" value="<?php echo trim(chosen_plot_size_upd());?>"   />  </td></tr>
<tr><td>lot_use :</td><td> <input type="text"     name="txt_lot_use" required class="textbox" value="<?php echo trim(chosen_lot_use_upd());?>"   />  </td></tr>
<tr><td>available_from :</td><td> <input type="text"     name="txt_available_from" required class="textbox" value="<?php echo trim(chosen_available_from_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_basic_land" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">basic_land List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_basic_land();
                    $obj->list_basic_land($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_listing_combo() {
    $obj = new multi_values();
    $obj->get_listing_in_combo();
}
function chosen_basic_landdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $basic_landdeleted = new multi_values();
               return $basic_landdeleted->get_chosen_basic_land_basic_landdeleted($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_listing_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $listing = new multi_values();
               return $listing->get_chosen_basic_land_listing($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_administrative_location_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $administrative_location = new multi_values();
               return $administrative_location->get_chosen_basic_land_administrative_location($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_plot_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $plot_number = new multi_values();
               return $plot_number->get_chosen_basic_land_plot_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_plot_size_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $plot_size = new multi_values();
               return $plot_size->get_chosen_basic_land_plot_size($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_lot_use_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $lot_use = new multi_values();
               return $lot_use->get_chosen_basic_land_lot_use($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_available_from_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_land') {               $id = $_SESSION['id_upd'];
               $available_from = new multi_values();
               return $available_from->get_chosen_basic_land_available_from($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
