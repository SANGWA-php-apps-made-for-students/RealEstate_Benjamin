<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_featured'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'featured'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $featured_id=$_SESSION['id_upd'];
                      
$date = $_POST['txt_date'];
$listing = $_POST['txt_listing_id'];

$description = $_POST['txt_description'];
$featured_cat = $_POST['txt_featured_cat_id'];

$account = $_POST['txt_account_id'];



$upd_obj->update_featured($date, $listing, $description, $featured_cat, $account,$featured_id);
unset($_SESSION['table_to_update']);
}}else{$date = $_POST['txt_date'];
$listing =trim( $_POST['txt_listing_id']);
$description = $_POST['txt_description'];
$featured_cat =trim( $_POST['txt_featured_cat_id']);
$account =trim( $_POST['txt_account_id']);

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_featured($date, $listing, $description, $featured_cat, $account);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
featured</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_featured.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_listing_id"   name="txt_listing_id"/><input type="hidden" id="txt_featured_cat_id"   name="txt_featured_cat_id"/><input type="hidden" id="txt_account_id"   name="txt_account_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 featured saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  featured</div>
 <table class="new_data_table">


<tr><td>date :</td><td> <input type="text"     name="txt_date" required class="textbox" value="<?php echo trim(chosen_date_upd());?>"   />  </td></tr>
 <tr><td>listing :</td><td> <?php get_listing_combo(); ?>  </td></tr><tr><td>description :</td><td> <input type="text"     name="txt_description" required class="textbox" value="<?php echo trim(chosen_description_upd());?>"   />  </td></tr>
 <tr><td>featured_cat :</td><td> <?php get_featured_cat_combo(); ?>  </td></tr> <tr><td>account :</td><td> <?php get_account_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_featured" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">featured List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_featured();
                    $obj->list_featured($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_listing_combo() {
    $obj = new multi_values();
    $obj->get_listing_in_combo();
}
function get_featured_cat_combo() {
    $obj = new multi_values();
    $obj->get_featured_cat_in_combo();
}
function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}
function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'featured') {               $id = $_SESSION['id_upd'];
               $date = new multi_values();
               return $date->get_chosen_featured_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_listing_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'featured') {               $id = $_SESSION['id_upd'];
               $listing = new multi_values();
               return $listing->get_chosen_featured_listing($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_description_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'featured') {               $id = $_SESSION['id_upd'];
               $description = new multi_values();
               return $description->get_chosen_featured_description($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_featured_cat_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'featured') {               $id = $_SESSION['id_upd'];
               $featured_cat = new multi_values();
               return $featured_cat->get_chosen_featured_featured_cat($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'featured') {               $id = $_SESSION['id_upd'];
               $account = new multi_values();
               return $account->get_chosen_featured_account($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
