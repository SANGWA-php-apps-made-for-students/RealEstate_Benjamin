<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_basic_commercial'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'basic_commercial'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $basic_commercial_id=$_SESSION['id_upd'];
                      
$basic_commercialdeleted = $_POST['txt_basic_commercialdeleted'];
$listing = $_POST['txt_listing_id'];

$bedroom = $_POST['txt_bedroom'];
$bathroom = $_POST['txt_bathroom'];
$compound_size = $_POST['txt_compound_size'];
$living_floors = $_POST['txt_living_floors'];
$total_number_floors = $_POST['txt_total_number_floors'];
$furnished = $_POST['txt_furnished'];


$upd_obj->update_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished,$basic_commercial_id);
unset($_SESSION['table_to_update']);
}}else{$basic_commercialdeleted = $_POST['txt_basic_commercialdeleted'];
$listing =trim( $_POST['txt_listing_id']);
$bedroom = $_POST['txt_bedroom'];
$bathroom = $_POST['txt_bathroom'];
$compound_size = $_POST['txt_compound_size'];
$living_floors = $_POST['txt_living_floors'];
$total_number_floors = $_POST['txt_total_number_floors'];
$furnished = $_POST['txt_furnished'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
basic_commercial</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_basic_commercial.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_listing_id"   name="txt_listing_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 basic_commercial saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  basic_commercial</div>
 <table class="new_data_table">


<tr><td>basic_commercialdeleted :</td><td> <input type="text"     name="txt_basic_commercialdeleted" required class="textbox" value="<?php echo trim(chosen_basic_commercialdeleted_upd());?>"   />  </td></tr>
 <tr><td>listing :</td><td> <?php get_listing_combo(); ?>  </td></tr><tr><td>bedroom :</td><td> <input type="text"     name="txt_bedroom" required class="textbox" value="<?php echo trim(chosen_bedroom_upd());?>"   />  </td></tr>
<tr><td>bathroom :</td><td> <input type="text"     name="txt_bathroom" required class="textbox" value="<?php echo trim(chosen_bathroom_upd());?>"   />  </td></tr>
<tr><td>compound_size :</td><td> <input type="text"     name="txt_compound_size" required class="textbox" value="<?php echo trim(chosen_compound_size_upd());?>"   />  </td></tr>
<tr><td>living_floors :</td><td> <input type="text"     name="txt_living_floors" required class="textbox" value="<?php echo trim(chosen_living_floors_upd());?>"   />  </td></tr>
<tr><td>total_number_floors :</td><td> <input type="text"     name="txt_total_number_floors" required class="textbox" value="<?php echo trim(chosen_total_number_floors_upd());?>"   />  </td></tr>
<tr><td>furnished :</td><td> <input type="text"     name="txt_furnished" required class="textbox" value="<?php echo trim(chosen_furnished_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_basic_commercial" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">basic_commercial List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_basic_commercial();
                    $obj->list_basic_commercial($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_listing_combo() {
    $obj = new multi_values();
    $obj->get_listing_in_combo();
}
function chosen_basic_commercialdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $basic_commercialdeleted = new multi_values();
               return $basic_commercialdeleted->get_chosen_basic_commercial_basic_commercialdeleted($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_listing_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $listing = new multi_values();
               return $listing->get_chosen_basic_commercial_listing($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_bedroom_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $bedroom = new multi_values();
               return $bedroom->get_chosen_basic_commercial_bedroom($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_bathroom_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $bathroom = new multi_values();
               return $bathroom->get_chosen_basic_commercial_bathroom($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_compound_size_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $compound_size = new multi_values();
               return $compound_size->get_chosen_basic_commercial_compound_size($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_living_floors_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $living_floors = new multi_values();
               return $living_floors->get_chosen_basic_commercial_living_floors($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_total_number_floors_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $total_number_floors = new multi_values();
               return $total_number_floors->get_chosen_basic_commercial_total_number_floors($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_furnished_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_commercial') {               $id = $_SESSION['id_upd'];
               $furnished = new multi_values();
               return $furnished->get_chosen_basic_commercial_furnished($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
