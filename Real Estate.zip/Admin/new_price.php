<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_price'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'price'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $price_id=$_SESSION['id_upd'];
                      
$amount = $_POST['txt_amount'];
$currency = $_POST['txt_currency'];
$condition = $_POST['txt_condition'];
$property = $_POST['txt_property_id'];

$Minimum_advance = $_POST['txt_Minimum_advance'];
$deposit_required = $_POST['txt_deposit_required'];
$commission = $_POST['txt_commission'];
$utilities_extra = $_POST['txt_utilities_extra'];
$listing = $_POST['txt_listing_id'];

$amount_per_day = $_POST['txt_amount_per_day'];
$condition_per_day = $_POST['txt_condition_per_day'];
$minimum_advance_per_day = $_POST['txt_minimum_advance_per_day'];
$deposit_required_per_day = $_POST['txt_deposit_required_per_day'];
$commission_per_day = $_POST['txt_commission_per_day'];
$utilities_extra_per_day = $_POST['txt_utilities_extra_per_day'];


$upd_obj->update_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day,$price_id);
unset($_SESSION['table_to_update']);
}}else{$amount = $_POST['txt_amount'];
$currency = $_POST['txt_currency'];
$condition = $_POST['txt_condition'];
$property =trim( $_POST['txt_property_id']);
$Minimum_advance = $_POST['txt_Minimum_advance'];
$deposit_required = $_POST['txt_deposit_required'];
$commission = $_POST['txt_commission'];
$utilities_extra = $_POST['txt_utilities_extra'];
$listing =trim( $_POST['txt_listing_id']);
$amount_per_day = $_POST['txt_amount_per_day'];
$condition_per_day = $_POST['txt_condition_per_day'];
$minimum_advance_per_day = $_POST['txt_minimum_advance_per_day'];
$deposit_required_per_day = $_POST['txt_deposit_required_per_day'];
$commission_per_day = $_POST['txt_commission_per_day'];
$utilities_extra_per_day = $_POST['txt_utilities_extra_per_day'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
price</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_price.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_property_id"   name="txt_property_id"/><input type="hidden" id="txt_listing_id"   name="txt_listing_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 price saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  price</div>
 <table class="new_data_table">


<tr><td>amount :</td><td> <input type="text"     name="txt_amount" required class="textbox" value="<?php echo trim(chosen_amount_upd());?>"   />  </td></tr>
<tr><td>currency :</td><td> <input type="text"     name="txt_currency" required class="textbox" value="<?php echo trim(chosen_currency_upd());?>"   />  </td></tr>
<tr><td>condition :</td><td> <input type="text"     name="txt_condition" required class="textbox" value="<?php echo trim(chosen_condition_upd());?>"   />  </td></tr>
 <tr><td>property :</td><td> <?php get_property_combo(); ?>  </td></tr><tr><td>Minimum_advance :</td><td> <input type="text"     name="txt_Minimum_advance" required class="textbox" value="<?php echo trim(chosen_Minimum_advance_upd());?>"   />  </td></tr>
<tr><td>deposit_required :</td><td> <input type="text"     name="txt_deposit_required" required class="textbox" value="<?php echo trim(chosen_deposit_required_upd());?>"   />  </td></tr>
<tr><td>commission :</td><td> <input type="text"     name="txt_commission" required class="textbox" value="<?php echo trim(chosen_commission_upd());?>"   />  </td></tr>
<tr><td>utilities_extra :</td><td> <input type="text"     name="txt_utilities_extra" required class="textbox" value="<?php echo trim(chosen_utilities_extra_upd());?>"   />  </td></tr>
 <tr><td>listing :</td><td> <?php get_listing_combo(); ?>  </td></tr><tr><td>amount_per_day :</td><td> <input type="text"     name="txt_amount_per_day" required class="textbox" value="<?php echo trim(chosen_amount_per_day_upd());?>"   />  </td></tr>
<tr><td>condition_per_day :</td><td> <input type="text"     name="txt_condition_per_day" required class="textbox" value="<?php echo trim(chosen_condition_per_day_upd());?>"   />  </td></tr>
<tr><td>minimum_advance_per_day :</td><td> <input type="text"     name="txt_minimum_advance_per_day" required class="textbox" value="<?php echo trim(chosen_minimum_advance_per_day_upd());?>"   />  </td></tr>
<tr><td>deposit_required_per_day :</td><td> <input type="text"     name="txt_deposit_required_per_day" required class="textbox" value="<?php echo trim(chosen_deposit_required_per_day_upd());?>"   />  </td></tr>
<tr><td>commission_per_day :</td><td> <input type="text"     name="txt_commission_per_day" required class="textbox" value="<?php echo trim(chosen_commission_per_day_upd());?>"   />  </td></tr>
<tr><td>utilities_extra_per_day :</td><td> <input type="text"     name="txt_utilities_extra_per_day" required class="textbox" value="<?php echo trim(chosen_utilities_extra_per_day_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_price" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">price List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_price();
                    $obj->list_price($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_property_combo() {
    $obj = new multi_values();
    $obj->get_property_in_combo();
}
function get_listing_combo() {
    $obj = new multi_values();
    $obj->get_listing_in_combo();
}
function chosen_amount_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $amount = new multi_values();
               return $amount->get_chosen_price_amount($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_currency_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $currency = new multi_values();
               return $currency->get_chosen_price_currency($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_condition_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $condition = new multi_values();
               return $condition->get_chosen_price_condition($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_property_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $property = new multi_values();
               return $property->get_chosen_price_property($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_Minimum_advance_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $Minimum_advance = new multi_values();
               return $Minimum_advance->get_chosen_price_Minimum_advance($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_deposit_required_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $deposit_required = new multi_values();
               return $deposit_required->get_chosen_price_deposit_required($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_commission_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $commission = new multi_values();
               return $commission->get_chosen_price_commission($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_utilities_extra_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $utilities_extra = new multi_values();
               return $utilities_extra->get_chosen_price_utilities_extra($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_listing_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $listing = new multi_values();
               return $listing->get_chosen_price_listing($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_amount_per_day_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $amount_per_day = new multi_values();
               return $amount_per_day->get_chosen_price_amount_per_day($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_condition_per_day_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $condition_per_day = new multi_values();
               return $condition_per_day->get_chosen_price_condition_per_day($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_minimum_advance_per_day_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $minimum_advance_per_day = new multi_values();
               return $minimum_advance_per_day->get_chosen_price_minimum_advance_per_day($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_deposit_required_per_day_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $deposit_required_per_day = new multi_values();
               return $deposit_required_per_day->get_chosen_price_deposit_required_per_day($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_commission_per_day_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $commission_per_day = new multi_values();
               return $commission_per_day->get_chosen_price_commission_per_day($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_utilities_extra_per_day_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price') {               $id = $_SESSION['id_upd'];
               $utilities_extra_per_day = new multi_values();
               return $utilities_extra_per_day->get_chosen_price_utilities_extra_per_day($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
