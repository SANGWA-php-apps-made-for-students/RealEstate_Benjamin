<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_currency_conversion'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'currency_conversion'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $currency_conversion_id=$_SESSION['id_upd'];
                      
$currency_conversiondeleted = $_POST['txt_currency_conversiondeleted'];
$from = $_POST['txt_from'];
$to = $_POST['txt_to'];
$rate = $_POST['txt_rate'];


$upd_obj->update_currency_conversion($currency_conversiondeleted, $from, $to, $rate,$currency_conversion_id);
unset($_SESSION['table_to_update']);
}}else{$currency_conversiondeleted = $_POST['txt_currency_conversiondeleted'];
$from = $_POST['txt_from'];
$to = $_POST['txt_to'];
$rate = $_POST['txt_rate'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_currency_conversion($currency_conversiondeleted, $from, $to, $rate);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
currency_conversion</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_currency_conversion.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->


      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 currency_conversion saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  currency_conversion</div>
 <table class="new_data_table">


<tr><td>currency_conversiondeleted :</td><td> <input type="text"     name="txt_currency_conversiondeleted" required class="textbox" value="<?php echo trim(chosen_currency_conversiondeleted_upd());?>"   />  </td></tr>
<tr><td>from :</td><td> <input type="text"     name="txt_from" required class="textbox" value="<?php echo trim(chosen_from_upd());?>"   />  </td></tr>
<tr><td>to :</td><td> <input type="text"     name="txt_to" required class="textbox" value="<?php echo trim(chosen_to_upd());?>"   />  </td></tr>
<tr><td>rate :</td><td> <input type="text"     name="txt_rate" required class="textbox" value="<?php echo trim(chosen_rate_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_currency_conversion" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">currency_conversion List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_currency_conversion();
                    $obj->list_currency_conversion($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function chosen_currency_conversiondeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'currency_conversion') {               $id = $_SESSION['id_upd'];
               $currency_conversiondeleted = new multi_values();
               return $currency_conversiondeleted->get_chosen_currency_conversion_currency_conversiondeleted($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_from_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'currency_conversion') {               $id = $_SESSION['id_upd'];
               $from = new multi_values();
               return $from->get_chosen_currency_conversion_from($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_to_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'currency_conversion') {               $id = $_SESSION['id_upd'];
               $to = new multi_values();
               return $to->get_chosen_currency_conversion_to($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_rate_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'currency_conversion') {               $id = $_SESSION['id_upd'];
               $rate = new multi_values();
               return $rate->get_chosen_currency_conversion_rate($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
