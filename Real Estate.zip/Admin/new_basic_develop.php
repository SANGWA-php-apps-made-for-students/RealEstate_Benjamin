<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_basic_develop'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'basic_develop'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $basic_develop_id=$_SESSION['id_upd'];
                      
$basic_developdeleted = $_POST['txt_basic_developdeleted'];
$listing = $_POST['txt_listing_id'];

$bedrooms = $_POST['txt_bedrooms'];
$bathrooms = $_POST['txt_bathrooms'];
$compound_size = $_POST['txt_compound_size'];
$living_floors = $_POST['txt_living_floors'];
$total_number_floors = $_POST['txt_total_number_floors'];


$upd_obj->update_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors,$basic_develop_id);
unset($_SESSION['table_to_update']);
}}else{$basic_developdeleted = $_POST['txt_basic_developdeleted'];
$listing =trim( $_POST['txt_listing_id']);
$bedrooms = $_POST['txt_bedrooms'];
$bathrooms = $_POST['txt_bathrooms'];
$compound_size = $_POST['txt_compound_size'];
$living_floors = $_POST['txt_living_floors'];
$total_number_floors = $_POST['txt_total_number_floors'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
basic_develop</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_basic_develop.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_listing_id"   name="txt_listing_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 basic_develop saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  basic_develop</div>
 <table class="new_data_table">


<tr><td>basic_developdeleted :</td><td> <input type="text"     name="txt_basic_developdeleted" required class="textbox" value="<?php echo trim(chosen_basic_developdeleted_upd());?>"   />  </td></tr>
 <tr><td>listing :</td><td> <?php get_listing_combo(); ?>  </td></tr><tr><td>bedrooms :</td><td> <input type="text"     name="txt_bedrooms" required class="textbox" value="<?php echo trim(chosen_bedrooms_upd());?>"   />  </td></tr>
<tr><td>bathrooms :</td><td> <input type="text"     name="txt_bathrooms" required class="textbox" value="<?php echo trim(chosen_bathrooms_upd());?>"   />  </td></tr>
<tr><td>compound_size :</td><td> <input type="text"     name="txt_compound_size" required class="textbox" value="<?php echo trim(chosen_compound_size_upd());?>"   />  </td></tr>
<tr><td>living_floors :</td><td> <input type="text"     name="txt_living_floors" required class="textbox" value="<?php echo trim(chosen_living_floors_upd());?>"   />  </td></tr>
<tr><td>total_number_floors :</td><td> <input type="text"     name="txt_total_number_floors" required class="textbox" value="<?php echo trim(chosen_total_number_floors_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_basic_develop" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">basic_develop List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_basic_develop();
                    $obj->list_basic_develop($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_listing_combo() {
    $obj = new multi_values();
    $obj->get_listing_in_combo();
}
function chosen_basic_developdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $basic_developdeleted = new multi_values();
               return $basic_developdeleted->get_chosen_basic_develop_basic_developdeleted($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_listing_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $listing = new multi_values();
               return $listing->get_chosen_basic_develop_listing($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_bedrooms_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $bedrooms = new multi_values();
               return $bedrooms->get_chosen_basic_develop_bedrooms($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_bathrooms_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $bathrooms = new multi_values();
               return $bathrooms->get_chosen_basic_develop_bathrooms($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_compound_size_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $compound_size = new multi_values();
               return $compound_size->get_chosen_basic_develop_compound_size($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_living_floors_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $living_floors = new multi_values();
               return $living_floors->get_chosen_basic_develop_living_floors($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_total_number_floors_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'basic_develop') {               $id = $_SESSION['id_upd'];
               $total_number_floors = new multi_values();
               return $total_number_floors->get_chosen_basic_develop_total_number_floors($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
