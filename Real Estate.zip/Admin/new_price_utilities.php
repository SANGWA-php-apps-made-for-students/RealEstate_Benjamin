<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_price_utilities'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'price_utilities'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $price_utilities_id=$_SESSION['id_upd'];
                      
$price_utilitiesdeleted = $_POST['txt_price_utilitiesdeleted'];
$price = $_POST['txt_price_id'];

$utilities = $_POST['txt_utilities_id'];



$upd_obj->update_price_utilities($price_utilitiesdeleted, $price, $utilities,$price_utilities_id);
unset($_SESSION['table_to_update']);
}}else{$price_utilitiesdeleted = $_POST['txt_price_utilitiesdeleted'];
$price =trim( $_POST['txt_price_id']);
$utilities =trim( $_POST['txt_utilities_id']);

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_price_utilities($price_utilitiesdeleted, $price, $utilities);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
price_utilities</title>
      <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_price_utilities.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_price_id"   name="txt_price_id"/><input type="hidden" id="txt_utilities_id"   name="txt_utilities_id"/>
      <?php
            include 'Admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 price_utilities saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  price_utilities</div>
 <table class="new_data_table">


<tr><td>price_utilitiesdeleted :</td><td> <input type="text"     name="txt_price_utilitiesdeleted" required class="textbox" value="<?php echo trim(chosen_price_utilitiesdeleted_upd());?>"   />  </td></tr>
 <tr><td>price :</td><td> <?php get_price_combo(); ?>  </td></tr> <tr><td>utilities :</td><td> <?php get_utilities_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_price_utilities" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">price_utilities List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_price_utilities();
                    $obj->list_price_utilities($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_price_combo() {
    $obj = new multi_values();
    $obj->get_price_in_combo();
}
function get_utilities_combo() {
    $obj = new multi_values();
    $obj->get_utilities_in_combo();
}
function chosen_price_utilitiesdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price_utilities') {               $id = $_SESSION['id_upd'];
               $price_utilitiesdeleted = new multi_values();
               return $price_utilitiesdeleted->get_chosen_price_utilities_price_utilitiesdeleted($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_price_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price_utilities') {               $id = $_SESSION['id_upd'];
               $price = new multi_values();
               return $price->get_chosen_price_utilities_price($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_utilities_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'price_utilities') {               $id = $_SESSION['id_upd'];
               $utilities = new multi_values();
               return $utilities->get_chosen_price_utilities_utilities($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
