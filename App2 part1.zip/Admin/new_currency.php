<?php

require_once '../web_db/multi_values.php';

if (isset($_POST['curncy'])) {
    try {
        $obj = new multi_values();
        $curncy = $_POST['curncy'];
        $amount = $_POST['amount'];
        if ($curncy == 'USD') {
            $res = $obj->get_currency_rate($curncy, 'RWF');
            $tot = $amount * $res;
            $eq = number_format((float) $tot, 1, '.', '');
            echo $eq . ' Rwf<br/>' . $tot / 950 . ' Euro ';
        } else if ($curncy == 'Rwf') {
            $res = $obj->get_currency_rate('USD', $curncy);
            $tot = $amount / $res;
            $eq = number_format((float) $tot, 3, '.', '');
            echo $eq . ' USD<br/>' . ($tot * 850) / 950 . ' Euro ';
        } else if ($curncy == 'Euro') {
            $res = $obj->get_currency_rate('Rwf', $curncy);
            $tot = $amount * $res;
            $eq = number_format((float) $tot, 3, '.', '');
            echo $eq . '  Rwf<br/>' . $tot / 950 . ' USD ';
        }
    } catch (Exception $e) {
        echo 'converting .. local';
    }
}

function conversion($amount, $from, $to, $designation) {
    $url = "https://www.google.com/finance/converter?a=$amount&from=$from&to=$to";
    $data = file_get_contents($url);
    preg_match("/<span class=bld>(.*)<\/span>/", $data, $converted);
    $converted = preg_replace("/[^0-9.]/", "", $converted[1]);
    echo round($converted, 3) . ' <br/>' . $designation;
}
