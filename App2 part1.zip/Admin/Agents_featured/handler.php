<?php

session_start();
if (isset($_POST['id_update'])) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo 'caught:   ' . $_SESSION['id_upd'];
}

if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once 'web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);
}
if (isset($_POST['make_featured'])) {
    $listing = $_POST['make_featured'];
    require_once './web_db/multi_values.php';

    $mul = new multi_values();
    $res = trim($mul->switch_featured($listing));
    if ($res == 'Remove') {
//it should be removed
        require_once './web_db/deletions.php';
        $del = new deletions();
        $del->deleteFrom_featured_by_list($listing);
    } else {
//there should be inserted another featured
        require_once 'web_db/new_values.php';
        $listing_type = $_POST['listing_type'];
        $account = $_SESSION['userid'];
        $date = date("y-m-d");
        $featured_cat = 0;
        $desc = '';
        if ($listing_type == 1) {//this is rent
            $featured_cat = 6; // this miust be also rent in the featured category
        } else if ($listing_type == 2) {// this is sale
            $featured_cat = 5;  // this is also sale in the featured category
        }
        $obj = new new_values();
        $obj->new_featured($date, $listing, $desc, $featured_cat, $account);
        echo $res;
    }
}
if (isset($_POST['make_gen_feat'])) {
    $listing = $_POST['make_gen_feat'];
    require_once 'web_db/new_values.php';
    $account = $_SESSION['userid'];
    $date = date("y-m-d");
    $desc = '';
    $featured_cat = 7;
    $obj = new new_values();
    $res = $obj->new_featured($date, $listing, $desc, $featured_cat, $account);
}
if (isset($_POST['remove_featured'])) {
    echo 'In this case we are going to remove the featured';
}

