<?php

session_start();
if (isset($_SESSION['id_upd'])) {
    header('Location: index.php');
} 