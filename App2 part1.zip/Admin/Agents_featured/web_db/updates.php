<?php

require_once 'connection.php';

class updates {

    function update_agency($website, $office_address, $agency_desc, $logo, $agency_name, $agency_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE agency set website= ?, office_address= ?, agency_desc= ?, logo= ?, agency_name= ? WHERE agency_id=?");
        $stmt->execute(array($website, $office_address, $agency_desc, $logo, $agency_name, $agency_id));
    }

    function update_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $image, $profile_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE profile set name= ?, last_name= ?, email= ?, office_phone= ?, mobile_phone= ?, address= ?, city= ?, country= ?, image= ? WHERE profile_id=?");
        $stmt->execute(array($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $image, $profile_id));
    }

}
