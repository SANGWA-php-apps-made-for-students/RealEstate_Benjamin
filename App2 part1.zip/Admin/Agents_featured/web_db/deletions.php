<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of deletions
 *
 * SANGWA
 */
require_once 'connection.php';

class deletions {

    function deleteFrom_account($account_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM account where account_id =:account_id");
        $smt->bindValue(':account_id', $account_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_featured($featured_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM featured where featured_id =:featured_id");
        $smt->bindValue(':featured_id', $featured_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_featured_by_list($listing) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM featured where listing =:listing");
        $smt->bindValue(':listing', $listing, PDO::PARAM_STR);
        $smt->execute();
    }

    function deleteFrom_featured_cat($featured_cat_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM featured_cat where featured_cat_id =:featured_cat_id");
        $smt->bindValue(':featured_cat_id', $featured_cat_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

}
