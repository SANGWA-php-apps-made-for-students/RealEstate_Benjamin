<?php
require_once 'connection.php';
$con = new my_connection();

class multi_values {

    function All_agency() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  agency_id   from agency";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_message() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  message_id   from message";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_message_by_cat() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  message_id   from message where type=4";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_msg_type() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  msg_type_id   from msg_type";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function list_message() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select message.date,  message.type,  message.message,profile.email, msg_type.name as type from message "
                . "  join msg_type on msg_type.msg_type_id= message.type "
                . "  left join account on message.account = account.account_id 
                    left  join profile on profile.profile_id =account.profile
                    where msg_type.name<>'call'
             order by message.message_id desc ";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table" style="width: 100%; border: none;">
            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr class="white_bg" style="background-color: #cccccc;"> 
                    <td class="account_id_cols message " title="message" >
                        <?php
                        echo 'Email: ';
                        echo $this->_e($row['email']);
                        ?>
                    </td>
                    <td>
                        <?php
                        echo 'Date: ';
                        echo $this->_e($row['date']);
                        ?>
                    </td>
                    <td>
                        <?php
                        echo 'Type: ';
                        echo $this->_e($row['type']);
                        ?>
                    </td>
                    <td>
                        <a href="#" class="message_delete_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="message_update_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Update</a>
                    </td>
                </tr>
                <tr class="white_bg" >
                    <td colspan="6">
                        <?php echo $this->_e($row['message']); ?>
                    </td>
                </tr>
                <tr >
                    <td colspan="6">
                        <br/><br/>
                    </td>
                </tr>
                <?php
                $pages+=1;
            }
            ?>
        </table>
        <?php
    }

    function list_call_message($type) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from message "
                . "join msg_type on msg_type.msg_type_id= message.type "
                . " 
                    where msg_type.name=:name
             ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":name" => $type));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> message </td>
                    <td> account </td><td> date </td>

                    <td> type </td><td> message </td>
                    <td>Delete</td><td>Update</td>
                </tr>
            </thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr class="white_bg"> 

                    <td>
                        <?php echo $row['message_id']; ?>
                    </td>
                    <td class="account_id_cols message " title="message" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>


                    <td>
                        <a href="#" class="message_delete_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="message_update_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Update</a>
                    </td>
                </tr>
                <?php
                $pages+=1;
            }
            ?></table>
        <?php
    }

    function list_msg_type($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from msg_type";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> msg_type </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['msg_type_id']; ?>
                    </td>
                    <td class="name_id_cols msg_type " title="msg_type" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="msg_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="msg_type_update_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function get_first_agency() {
            $con = new dbconnection();
            $sql = "select agency.agency_id from agency
                    order by agency.agency_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['agency_id'];
            return $first_rec;
        }

        function list_agency($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from agency "
                    . " join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id     where agency_name <> 'esercos'  group by agency.agency_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            while ($row = $stmt->fetch()) {
                ?>
            <div class="parts data_pane agent_pane no_paddin_shade_no_Border reverse_border" >
                <div class="parts full_center_two_h heit_free margin_free pane_title">   <?php echo $this->_e($row['agency_name']); ?>  </div>
                <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border">
                    <table class="dataList_table">    
                        <tr>

                        <tr>
                            <td>Agency id</td>
                            <td>
                                <?php echo $row['agency_id']; ?>
                            </td></tr>
                        <tr> <td>Website</td><td class="website_id_cols agency " title="agency" >
                                <?php echo $this->_e($row['website']); ?>
                            </td>  </tr>
                        <tr>  <td>Office address</td><td>
                                <?php echo $this->_e($row['office_address']); ?>
                            </td>  </tr>
                        <tr>  <td>Agency description</td><td>
                                <?php echo $this->_e($row['agency_desc']); ?>
                            </td>  </tr>
                        <tr>
                            <td>Logo</td><td><?php echo $this->_e($row['logo']); ?>  </td> 
                        </tr>
                        <tr>
                            <td> email</td><td><?php echo $this->_e($row['username']); ?>  </td> 
                        </tr>
                        <tr>
                            <td> Password</td><td><?php echo $this->_e($row['password']); ?>  </td> 
                        </tr>

                    </table>
                </div>
                <div class="parts full_center_two_h heit_free margin_free bottom_part">

                    bottom part</div>
            </div>
            <?php
        }
    }

    function list_agency_by_name($name) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from agency where agency_name=:name group by agency.agency_name";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            ?>
            <div class="parts data_pane agent_pane no_paddin_shade_no_Border reverse_border esercos_data_pane" >
                <div class="parts full_center_two_h heit_free margin_free pane_title">   <?php echo $this->_e($row['agency_name']); ?>  </div>
                <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border white_bg">
                    <div class="parts no_paddin_shade_no_Border">
                        <table class="dataList_table">    
                            <tr>
                                <td>Agency id</td><td>
                                    <?php echo $row['agency_id']; ?>
                                </td></tr>
                            <tr> <td>Website</td><td class="website_id_cols agency " title="agency" >
                                    <?php echo $this->_e($row['website']); ?>
                                </td>  </tr>
                            <tr>  <td>Office address</td><td>
                                    <?php echo $this->_e($row['office_address']); ?>
                                </td>  </tr>
                            <tr>  <td>Agency description</td><td>
                                    <?php echo $this->_e($row['agency_desc']); ?>
                                </td>  </tr>
                            <tr><td>Logo</td><td>
                                    <?php echo $this->_e($row['logo']); ?>
                                </td>  </tr>
                        </table>
                    </div> 
                    <div class="parts no_paddin_shade_no_Border">
                        <table>
                            <tr>
                                <td>
                                    name
                                </td><td>
                                    where is that name
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free margin_free bottom_part no_paddin_shade_no_Border">
                    <?php
                    if (!empty($_SESSION['agency_name'])) {
                        if ($_SESSION['agency_name'] == 'esercos') {
                            ?><div class="parts data_agency_id link_cursor" data-table='agency' data-listing_id='<?php echo $row['agency_id'] ?>'>Edit</div>
                            <div class="parts data_agency_id link_cursor " data-listing_id='<?php echo $row['agency_id'] ?>'>Deactivate   </div>
                            <?php
                        } else {
                            ?><div  class="parts data_agency_id margin_free link_cursor" data-table='agency' data-listing_id='<?php echo $row['agency_id'] ?>'>Edit</div>
                            <?php
                        }
                    } else {
                        ?>
                        Not defined
                        <?php
                    }
                    ?>
                </div>
            </div>
            <?php
        }
    }

    function get_last_profile_id() {
        $userid = 0;
        require_once 'connection.php';
        $con = new my_connection();
        $sql = "select    profile.profile_id from profile order by profile_id desc";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_chosen_profile_name($id) {

        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_profile_last_name($id) {

        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    }

    function get_chosen_profile_email($id) {

        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    }

    function get_chosen_profile_home_phone($id) {

        $db = new dbconnection();
        $sql = "select   profile.home_phone from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['home_phone'];
        echo $field;
    }

    function get_chosen_profile_office_phone($id) {

        $db = new dbconnection();
        $sql = "select   profile.office_phone from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['office_phone'];
        echo $field;
    }

    function get_chosen_profile_mobile_phone($id) {

        $db = new dbconnection();
        $sql = "select   profile.mobile_phone from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['mobile_phone'];
        echo $field;
    }

    function get_chosen_profile_address($id) {

        $db = new dbconnection();
        $sql = "select   profile.address from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['address'];
        echo $field;
    }

    function get_chosen_profile_city($id) {

        $db = new dbconnection();
        $sql = "select   profile.city from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['city'];
        echo $field;
    }

    function get_chosen_profile_country($id) {

        $db = new dbconnection();
        $sql = "select   profile.country from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['country'];
        echo $field;
    }

    function get_chosen_profile_image($id) {

        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

    function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function get_chosen_agency_website($id) {

        $db = new dbconnection();
        $sql = "select   agency.website from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['website'];
        echo $field;
    }

    function get_chosen_agency_office_address($id) {

        $db = new dbconnection();
        $sql = "select   agency.office_address from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['office_address'];
        echo $field;
    }

    function get_chosen_agency_agency_desc($id) {

        $db = new dbconnection();
        $sql = "select   agency.agency_desc from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['agency_desc'];
        echo $field;
    }

    function get_chosen_agency_logo($id) {

        $db = new dbconnection();
        $sql = "select   agency.logo from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['logo'];
        echo $field;
    }

    function get_chosen_agency_agency_name($id) {

        $db = new dbconnection();
        $sql = "select   agency.agency_name from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['agency_name'];
        echo $field;
    }

    function get_chosen_agency_account($id) {

        $db = new dbconnection();
        $sql = "select   agency.account from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_image_in_combo() {
        require_once('connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_last_image_id() {
        $con = new my_connection();
        $sql = "select      image.image_id as id from image order by image_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['id'];
        return $userid;
    }

    function getagency_id_by_name($name) {
        $con = new my_connection();
        $sql = "select  agency.agency_id from agency where  agency.agency_name =:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $agencyname = $row['agency_id'];
        return $agencyname;
    }

    function get_Users_by_category_agency($cat, $agency) {//here we want to display the users that are for exaample workers, agents admins and others 
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select agency.agency_id, account.account_id,   profile.name,  profile.last_name,  profile.email,   profile.office_phone,  profile.mobile_phone,  profile.address,  profile.city,
                agent.agency,  agency.agency_name, profile.country ,profile.image
                ,account.username,account.password from agency
                 join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id 
                join account_category on account.account_category = account_category.account_category_id 
                join profile on account.profile = profile.profile_id 
                where agency.agency_name=:agency  and  account_category.name=:category
                group by agency.agency_id, profile.profile_id ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":category" => $cat, ":agency" => $agency));
        ?>
        <?php while ($row = $stmt->fetch()) { ?>
            <div class="parts worker_pane no_paddin_shade_no_Border reverse_border accept_abs white_bg">
                <div class="parts full_center_two_h heit_free margin_free pane_title">
                    <?php echo $row['name'] . ' ' . $row['last_name']; ?>
                </div>
                <div class="parts   full_center_two_h heit_free no_paddin_shade_no_Border  ">
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border ">
                        <table class="dataList_table"  > 
                            <tr><td>Account id</td>  <td><?php echo $row['account_id']; ?> </td></tr>
                            <tr><td>Name</td>        <td><?php echo $row['name']; ?> </td></tr>
                            <tr><td>Last name</td>   <td><?php echo $row['last_name']; ?> </td></tr>
                            <tr><td>Email</td>       <td><?php echo $row['email']; ?> </td></tr>
                            <tr><td>Office phone</td><td><?php echo $row['office_phone']; ?> </td></tr>
                            <tr><td>Username</td><td><?php echo $row['username']; ?> </td></tr>
                        </table>
                    </div>
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border ">
                        <table class="dataList_table"  >
                            <tr><td>Password</td>     <td><?php echo $row['password']; ?> </td></tr>
                            <tr><td>Address</td>     <td><?php echo $row['address']; ?> </td></tr>
                            <tr><td>City</td>        <td><?php echo $row['city']; ?> </td></tr>
                            <tr><td>Country</td>     <td><?php echo $row['country']; ?> </td></tr>
                            <tr><td>Image</td>       <td><?php echo $row['image']; ?> </td></tr>
                            <tr><td>Agency name</td> <td><?php echo $row['agency_name']; ?> </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts bottom_part full_center_two_h heit_free margin_free no_paddin_shade_no_Border reverse_border ">
                    <div class="parts data_agency_idEdit link_cursor"
                         data-agencydata_id='<?php echo $row['account_id']; ?>'
                         data-agencydata_table='account'
                         >Edit</div>
                    <div class="parts data_agency_id link_cursor data_agency_id"
                         data-agencydata_id='<?php echo $row['account_id']; ?>'
                         data-agencydata_table='account'
                         >Delete</div>
                </div>
            </div>
            <?php
        }
    }

    function get_other_usercategories($cat) { // here we want to get other users who may be agents managers aor worker but nor esercos
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   profile.name,  profile.last_name,  profile.email,  profile.home_phone,  profile.office_phone,  profile.mobile_phone,  profile.address,  profile.city,
                agent.agency,  agency.agency_name, profile.country ,profile.image
                from agency
                join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id 
                join account_category on account.account_category = account_category.account_category_id 
                join profile on account.profile = profile.profile_id 
                where agency.agency_name<>'esercos'  and  account_category.name=:category
                group by agency.agency_id, profile.profile_id ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":category" => $cat));
        ?>
        <?php while ($row = $stmt->fetch()) { ?>
            <div class="parts worker_pane no_paddin_shade_no_Border reverse_border accept_abs">
                <div class="parts full_center_two_h heit_free margin_free pane_title">
                    <?php echo $row['name'] . ' ' . $row['last_name']; ?>
                </div>
                <div class="parts   full_center_two_h heit_free no_paddin_shade_no_Border ">
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  > 
                            <tr><td>Account id</td>  <td><?php echo $row['account_id']; ?> </td></tr>
                            <tr><td>Name</td>        <td><?php echo $row['name']; ?> </td></tr>
                            <tr><td>Last name</td>   <td><?php echo $row['last_name']; ?> </td></tr>
                            <tr><td>Email</td>       <td><?php echo $row['email']; ?> </td></tr>
                            <tr><td>Home phone</td>  <td><?php echo $row['home_phone']; ?> </td></tr>
                            <tr><td>Office phone</td><td><?php echo $row['office_phone']; ?> </td></tr>
                        </table>
                    </div>
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  >
                            <tr><td>Mobile phone</td><td><?php echo $row['mobile_phone']; ?> </td></tr>
                            <tr><td>Address</td>     <td><?php echo $row['address']; ?> </td></tr>
                            <tr><td>City</td>        <td><?php echo $row['city']; ?> </td></tr>
                            <tr><td>Country</td>     <td><?php echo $row['country']; ?> </td></tr>
                            <tr><td>Image</td>       <td><?php echo $row['image']; ?> </td></tr>
                            <tr><td>Agency name</td> <td><?php echo $row['agency_name']; ?> </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts bottom_part full_center_two_h heit_free margin_free ">
                    Bottom paart
                </div>

            </div>
            <?php
        }
    }

    function list_agent($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from agent";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> agent </td>
                    <td> agency_desc </td><td> logo </td><td> agency_name </td><td> website </td><td> profile </td><td> account </td><td> agency </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['agent_id']; ?>
                    </td>
                    <td class="agency_desc_id_cols agent " title="agent" >
                        <?php echo $this->_e($row['agency_desc']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['logo']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['website']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency']); ?>
                    </td>


                    <td>
                        <a href="#" class="agent_delete_link" style="color: #000080;" value="
                           <?php echo $row['agent_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="agent_update_link" style="color: #000080;" value="
                           <?php echo $row['agent_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function get_last_acc_id() {
            $con = new my_connection();
            $sql = "select    account.account_id  from account order by account_id desc limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_id'];
            return $userid;
        }

        function get_catId_byName($name) {
            $con = new my_connection();
            $sql = "select    account_category_id  from account_category   where   account_category.name =:name  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":name" => $name));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_category_id'];
            return $userid;
        }

        function get_user_by_catname($cat) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account.account_id,   profile.name,  profile.last_name,  profile.email,    profile.office_phone,  profile.mobile_phone,  profile.address,  profile.city,
                     profile.country ,profile.image
                    from profile
                    join account on account.profile = profile.profile_id 
                    join account_category on account.account_category = account_category.account_category_id 
                    where  account_category.name=:category
                    group by   profile.profile_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":category" => $cat));
            ?>
            <?php while ($row = $stmt->fetch()) { ?>
            <div class="parts worker_pane no_paddin_shade_no_Border reverse_border accept_abs white_bg">
                <div class="parts full_center_two_h heit_free margin_free pane_title">
                    <?php echo $row['name'] . ' ' . $row['last_name']; ?>
                </div>
                <div class="parts   full_center_two_h heit_free no_paddin_shade_no_Border ">
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  > 
                            <tr><td>Account id</td>  <td><?php echo $row['account_id']; ?> </td></tr>
                            <tr><td>Name</td>        <td><?php echo $row['name']; ?> </td></tr>
                            <tr><td>Last name</td>   <td><?php echo $row['last_name']; ?> </td></tr>
                            <tr><td>Email</td>       <td><?php echo $row['email']; ?> </td></tr>
                            <tr><td>Mobile phone</td><td><?php echo $row['mobile_phone']; ?> </td></tr>

                        </table>
                    </div>
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  >
                            <tr><td>Office phone</td><td><?php echo $row['office_phone']; ?> </td></tr>
                            <tr><td>Address</td>     <td><?php echo $row['address']; ?> </td></tr>
                            <tr><td>City</td>        <td><?php echo $row['city']; ?> </td></tr>
                            <tr><td>Country</td>     <td><?php echo $row['country']; ?> </td></tr>
                            <tr><td>Image</td>       <td><?php echo $row['image']; ?> </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts bottom_part full_center_two_h heit_free margin_free ">
                    Bottom paart
                </div>
            </div>
            <?php
        }
    }

    function get_last_agency() {
        $con = new my_connection();
        $sql = "select agency.agency_id from agency     order by agency.agency_id desc
                    limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['agency_id'];
        return $first_rec;
    }

    function get_last_account() {
        $con = new my_connection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }

    function get_logo_byName($agency) {
        $con = new my_connection();
        $sql = "select    agency.logo  from agency   where   agency.agency_name =:name  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $agency));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        echo '<img src="../../web_images/agency_logos/' . $row['logo'] . '" width="100" height="100" />    ';
    }

    function list_featured() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from featured";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> featured </td>
                    <td> date </td><td> listing </td><td> description </td><td> featured_cat </td><td> account </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['featured_id']; ?>
                    </td>
                    <td class="date_id_cols featured " title="featured" >
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['description']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['featured_cat']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="featured_delete_link" style="color: #000080;" value="
                           <?php echo $row['featured_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="featured_update_link" style="color: #000080;" value="
                           <?php echo $row['featured_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_featured_date($id) {

            $db = new dbconnection();
            $sql = "select   featured.date from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_featured_listing($id) {

            $db = new dbconnection();
            $sql = "select   featured.listing from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['listing'];
            echo $field;
        }

        function get_chosen_featured_description($id) {

            $db = new dbconnection();
            $sql = "select   featured.description from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['description'];
            echo $field;
        }

        function get_chosen_featured_featured_cat($id) {

            $db = new dbconnection();
            $sql = "select   featured.featured_cat from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['featured_cat'];
            echo $field;
        }

        function get_chosen_featured_account($id) {

            $db = new dbconnection();
            $sql = "select   featured.account from featured where featured_id=:featured_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':featured_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_featured() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  featured_id   from featured";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_featured() {
            $con = new dbconnection();
            $sql = "select featured.featured_id from featured
                    order by featured.featured_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['featured_id'];
            return $first_rec;
        }

        function get_last_featured() {
            $con = new dbconnection();
            $sql = "select featured.featured_id from featured
                    order by featured.featured_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['featured_id'];
            return $first_rec;
        }

        function list_featured_cat($min) {
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select * from featured_cat";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> featured_cat </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['featured_cat_id']; ?>
                    </td>
                    <td class="name_id_cols featured_cat " title="featured_cat" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="featured_cat_delete_link" style="color: #000080;" value="
                           <?php echo $row['featured_cat_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="featured_cat_update_link" style="color: #000080;" value="
                           <?php echo $row['featured_cat_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function list_web_visits() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from web_visits  join listing on web_visits.listing = listing.listing_id "
                    . "join image on image.listing=listing.listing_id group by web_visits_id "
                    . " order by web_visits.visit_count desc";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <style>
            .web_visit_table td{
                padding: 0px;
            }
            .vist_holder{
                border: 3px solid #fff;
                position: relative;box-shadow: 0px 0px 3px #5404f3;
            }
            .vist_holder:hover{
                box-shadow: 0px 0px 16px #5404f3;
            }
            .vis_counts{
                position: absolute;
                top: -23px;
                right: -9px;
                width: 30px;
                height: 23px;
                background-color: #0052ff;
                color: #ffffff;
                padding: 3px;
                font-size: 11px;
                font-weight: normal;
                text-align: center;
                box-shadow: 0px 0px 5px #000080;
            }
            .bottom_part_vis{
                bottom: 0px;
                position: absolute;
                background-color: #0e192f;
                color: #fff;
                font-size: 11px;
                padding: 5px;
                text-transform: capitalize;

            }
        </style>
        <table class="dataList_table web_visit_table full_center_two_h heit_free">
            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?>
                <div class="parts fixed_box_xx no_paddin_shade_no_Border reverse_border vist_holder left_off_x link_cursor" style="width:200px; height: 170px;">
                    <img src="../../web_images/property/<?php echo $this->_e($row['path']); ?> " width="200"height="170" /> 
                    <div class="parts  vis_counts no_paddin_shade_no_Border reverse_border "><?php echo $row['visit_count']; ?></div>
                    <div class="parts full_center_two_h heit_free bottom_part_vis margin_free no_shade_noBorder"><p><?php echo $row['title']; ?></p> <?php
                        echo 'Last visited: ';
                        echo $this->_e($row['date'])
                        ?>
                    </div>
                </div>

                <?php
                $pages+=1;
            }
            ?></table>

        <?php
    }

    function get_detailed_rpt_listing() {
        ?><div class="parts full_center_two_h" id="rpt_mp"></div><?php
        $con = new my_connection();
        $sql = "select  distinct  price.price_id,listing.listing_id ,listing.description, price.amount,  price.currency,
                    price.property,  price.Minimum_advance,  price.deposit_required,
                    price.commission,  price.utilities_extra,  price.listing,
                    listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                    listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                    image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                    basic_apartment.bedrooms,  basic_apartment.bathrooms,
                    basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from,
                    features.name as feat
                    from listing
                    left  join price on price.listing = listing.listing_id
                    left  join image on image.listing = listing.listing_id
                    left  join location on listing.location = location.location_id
                    left  join cell on location.cell = cell.cell_id
                    left  join sector on cell.sector = sector.sector_id
                    left  join district on sector.district = district.district_id
                    left  join province on district.province = province.province_id
                    left  join basic_apartment on basic_apartment.listing = listing.listing_id
                    left  join basic_land on basic_land.listing = listing.listing_id
                    join  account on listing.account = account.account_id
                    join  listing_type on listing.listing_type = listing_type.listing_type_id
                    join  property on listing.property = property.property_id
                    left  join  property_category on listing.property_category = property_category.property_category_id
                    left   join listing_features on listing_features.features = listing.listing_id
                    left   join features on listing_features.features = features.features_id
                  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        ?>
        <?php
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder xx_titles margin_free  ">' . $row['title'] . ' </div> ';
            echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x" >   LISTING ID: LST- ' . $row['listing_id'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border  full_center_two_h heit_free"  > Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
            echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" >   ' . $row['description'] . ' </div>';
            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Administrative location:  ' . $row['administrative_location'] . '     </div>';
            }
            if ($row['feat'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;">Other Features:  ' . $row['feat'] . '     </div>';
            }

            echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
            echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';
            echo '</div>';
        }

        //the last and long
        $sql1 = "select location.lat,  location.longtd from location join listing on listing.location = location.location_id 
                            where listing.listing_id=:listingid";
        $stmt1 = $con->getCon()->prepare($sql1);
        $stmt1->execute(array(":listingid" => $listingid));

        $lat = '';
        $long = '';
        while ($row1 = $stmt1->fetch()) {
            $lat = $row1['lat'];
            $long = $row1['longtd'];
        }


        //images
        $sql2 = "select path from image where listing=:listingid";
        $stmt2 = $con->getCon()->prepare($sql2);
        $stmt2->execute(array(":listingid" => $listingid));
        while ($row2 = $stmt2->fetch()) {
            echo '<img class="parts no_shade_noBorder" src="../../web_images/property/' . $row2['path'] . '"/>';
        }
        ?>

        <script>
            function initMap() {
                try {
                    var lt =<?php echo $lat; ?>;
                    var lon = <?php echo $long; ?>;
                    var myLatLng = {lat: lt, lng: lon};
                    var map = new google.maps.Map(document.getElementById('rpt_mp'), {
                        zoom: 17,
                        center: myLatLng
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map,
                        title: 'Disired location'
                    });

                } catch (err) {
                    alert(err.message);
                }
            }
        </script>
        <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
        </script>
        <?php
    }

    function get_sumarized_list_by_list_type($type) {
        $con = new my_connection();
        $sql = "select  distinct listing.listing_id, price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                ,listing.active from listing
                left  join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                left join property on listing.property = property.property_id
                left join property_category on listing.property_category = property_category.property_category_id
                where listing_type=:type    group by listing.listing_id    ";

        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":type" => $type));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder feat_rpt_cont wiz_body">';
            if ($row['path'] != '') {
                echo '<img   class="parts no_shade_noBorder" src="../../web_images/property/' . $row['path'] . '" height="200" width="280" style="border: 1px solid #000;"/>';
            } else {
                echo '<img alt="no image" class="parts no_shade_noBorder" src="../web_images/property/' . $row['path'] . '" height="200" width="280" style="border: 1px solid #000;"/> ';
            }
            echo '<div class="parts sixty_percent  no_shade_noBorder  ">';
            echo '<div class="parts sixty_percent smart_font2 no_shade_noBorder " >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }

            echo'<div id="rprt_more_details_btn"  class="parts link_cursor rprt_more_featured_btn" '
            . '       style="clear: left;" id="rprt_more_featured_btn"'
            . 'data-switch="';
            echo $this->switch_featured($row['listing_id']) . '"'
            . ' data-list_type="' . $row['listing_type'] . '">   <span class="off">' . $row['listing_id'] . '</span>';
            echo $this->switch_featured($row['listing_id']) . '</div>';
            echo '</div>'
            . '</div>';
        }
    }

    function get_general_featured() {
        $con = new my_connection();
        $sql = "select  distinct listing.listing_id, price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                ,listing.active from listing
                left  join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                left join property on listing.property = property.property_id
                left join property_category on listing.property_category = property_category.property_category_id
                where  listing.listing_id not in (select listing from featured where featured_cat<> '5' and featured_cat<>'6')   group by listing.listing_id    ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder feat_rpt_cont wiz_body">';
            if ($row['path'] != '') {
                echo '<img   class="parts no_shade_noBorder" src="../../web_images/property/' . $row['path'] . '" height="200" width="280" style="border: 1px solid #000;"/>';
            } else {
                echo '<img alt="no image" class="parts no_shade_noBorder" src="../../web_images/property/' . $row['path'] . '" height="200" width="280" style="border: 1px solid #000;"/> ';
            }
            echo '<div class="parts sixty_percent  no_shade_noBorder  ">';
            echo '<div class="parts sixty_percent smart_font2 no_shade_noBorder " >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }

            echo'<div id="rprt_more_details_btn"  class="parts link_cursor rprt_more_gen_feat_btn" '
            . '       style="clear: left;" id="rprt_more_featured_btn"'
            . 'data-switch="';
            echo $this->switch_featured($row['listing_id']) . '"'
            . ' data-list_type="' . $row['listing_type'] . '">   <span class="off">' . $row['listing_id'] . '</span>';
            echo $this->switch_featured($row['listing_id']) . '</div>';

            echo '</div>'
            . '</div>';
        }
    }

    function listing_status($list_id) {
        $db = new my_connection();
        $con = $db->getCon();
        $sql = "select listing.active from listing where listing.listing_id= :listing_id ";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['active'];
        return ($userid == 'yes') ? 'Disable' : 'Enable';
    }

    function switch_featured($listng) {
        $con = new my_connection();
        $sql = "select  featured_id from featured where listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listng));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['featured_id'];
        return ($userid != '') ? 'Remove' : 'Make Featured';
    }

    function list_comment() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from comment where comment.commentdeleted = 'no' ";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table full_center_two_h heit_free">
            <thead><tr>

                    <td> No. </td>
                    <td> message </td><td> date </td>
                    <td>Delete</td><td>Update</td></tr></thead>
            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?>
                <tr class="white_bg"> 
                    <td>
                        <?php echo $row['comment_id']; ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <a href="#" class="comment_delete_link" style="color: #000080;" value="
                        <?php echo $row['comment_id'];
                        ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="comment_update_link" style="color: #000080;" value="
                           <?php echo $row['comment_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
        <?php
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
