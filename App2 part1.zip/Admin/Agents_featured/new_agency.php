<?php
require_once 'web_db/multi_values.php';
require_once 'web_db/new_values.php';
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
if (isset($_POST['send_agency'])) {
    require_once 'web_db/multi_values.php';
    require_once 'web_db/new_values.php';
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            require_once 'web_db/updates.php';
            $upd_obj = new updates();
            $agency_id = $_SESSION['id_upd'];
            $website = $_POST['txt_website'];
            $office_address = $_POST['txt_office_address'];
            $agency_desc = $_POST['txt_agency_desc'];
            $logo = $_POST['txt_logo'];
            $agency_name = $_POST['txt_agency_name'];
            $upd_obj->update_agency($website, $office_address, $agency_desc, $logo, $agency_name, $agency_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        // <editor-fold defaultstate="collapsed" desc="-----save profile ------">
        $agency_mul = new multi_values();
        $prof_add = new new_values();
        $agency_add = new new_values();
        $agent_add = new new_values();
        $acc_add = new new_values();
        $profile_name = $_POST['txt_admin_name'];
        $prof_add->new_profile($profile_name, '', '', '', ' ', '', '', ' ', '');
        // </editor-fold>
        // 
        // 
        // 
        // <editor-fold defaultstate="collapsed" desc="------save the account (user) ------------">
        $last_profile = $agency_mul->get_last_profile();
        $account_category = $agency_mul->get_catId_byName('Admin');
        $username = $_POST['txt_username'];
        $password = '123';
        $online = 'no';
        $deleted = 'no';
        $date_created = date('y-m-d');
        $acc_add->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
        $last_account = $agency_mul->get_last_acc_id(); //declared here because it will be accessed iin many locatuons
        // </editor-fold>
        // 
        // 
        // <editor-fold defaultstate="collapsed" desc="-------save agency-------------">
        $website = $_POST['txt_website'];
        $office_address = $_POST['txt_office_address'];
        $agency_desc = $_POST['txt_agency_desc'];
        $logo = $_POST['txt_logo'];
        $agency_name = $_POST['txt_agency_name'];
        $agency_add->new_agency($website, $office_address, $agency_desc, $logo, $agency_name, $last_account);

        // </editor-fold>
        // 
        // 
        // 
        // <editor-fold defaultstate="collapsed" desc="-----------save the agent -----------">
        $agency_id = $agency_mul->getagency_id_by_name($agency_name);

        $agent_add->new_agent($last_account, $agency_id);
        // </editor-fold>
    }
}
if (isset($_POST['send_profile'])) {// here is saving the esercos worker
    try {
        require_once 'web_db/new_values.php';
        require_once 'web_db/multi_values.php';
        $mul_obj = new multi_values();
        $add_obj = new new_values();
        //profile fields
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $email = $_POST['txt_email'];

        $office_phone = $_POST['txt_office_phone'];
        $mobile_phone = $_POST['txt_mobile_phone'];
        $address = $_POST['txt_address'];
        $city = $_POST['txt_city'];
        $country = $_POST['txt_country'];

        //account
        $username = $_POST['txt_email'];
        $password = '123';
        $agency_name = '';
        if (isset($_SESSION['agency_name'])) {
            $agency_name = (!empty($_SESSION['agency_name'])) ? $_SESSION['agency_name'] : '';
        } else {
            $agency_name = 'esercos';
        }
        $agency_id = $mul_obj->getagency_id_by_name($agency_name);
        $account_category = $mul_obj->get_catId_byName('worker'); // this is the id of the category "worker" that should not changed on the database
        $online = 'no';
        $deleted = 'no';
        $date_created = date("Y-m-d");
        $obj = new new_values();
        save_image();
        $img = $mul_obj->get_last_image_id();
        if ($account_category != '') {
            $add_obj->new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $img);
            //last profile id
            $last_profile = $mul_obj->get_last_profile_id();
            $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
            // we also have to save the agency withe the account
            // <editor-fold defaultstate="collapsed" desc="---- get last account ------">
            $last_account = $mul_obj->get_last_acc_id();
            $agency = $agency_id; //this is the agent to whom we are going to assign the worker /// we have to change by getting it by name in db
            $add_obj = new new_values();
            $add_obj->new_agent($last_account, $agency);
            // </editor-fold>
            echo 'Data save successfully';
        } else {
            echo'<div class="red_message">' . ' You have not selected the account type or the account type has no users' . '</div>';
        }
    } catch (PDOException $ex) {
        echo 'Saving Data error: ' . $ex;
    }
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
            agency
        </title>
        <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="index.php" method="post" enctype="multipart/form-data">
            <div class="parts full_center_two_h heit_free off sub_c" id="sub_c3">
                <div class="parts eighty_centered xx_titles no_paddin_shade_no_Border">  Agency Registration</div>
                <table class="new_data_table">
                    <tr><td>website :</td><td> <input type="text" autocomplete="off" placeholder=""       name="txt_website" required class="textbox" value="<?php echo trim(chosen_website_upd()); ?>"   />  </td></tr>
                    <tr><td>office_address :</td><td> <input      autocomplete="off" type="text" placeholder=""       name="txt_office_address" required class="textbox" value="<?php echo trim(chosen_office_address_upd()); ?>"   />  </td></tr>
                    <tr><td>agency_desc :</td><td> <input         autocomplete="off"    type="text" placeholder=""       name="txt_agency_desc" required class="textbox" value="<?php echo trim(chosen_agency_desc_upd()); ?>"   />  </td></tr>
                    <tr><td>logo :</td><td> <input type="text"    autocomplete="off" placeholder=""       name="txt_logo" required class="textbox" value="<?php echo trim(chosen_logo_upd()); ?>"   />  </td></tr>
                    <tr><td>agency name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_agency_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                    <tr><td>Administrator name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_admin_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                    <tr>
                        <td colspan="2"></td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td><input type="email" name="txt_username" autocomplete="off" class="textbox" placeholder="email"/>  </td>
                    </tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_agency" value="Save"/>  </td></tr>
                </table>
            </div>
        </form>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
            <div class="parts no_paddin_shade_no_Border link_cursor full_center_two_h heit_free"> 
                <?php if ($_SESSION['agency'] == 'yes') { ?> 
                    <div class="parts submenu_btn underline_sub_menu" id="sub1">
                        Esercos
                    </div> 
                    <div class="parts submenu_btn underline_sub_menu" id="sub2">
                        Others
                    </div>
                    <div class="parts submenu_btn underline_sub_menu" id="sub3">
                        Register more agencies
                    </div><?php } ?>
            </div>
            <div class="parts link_cursor full_center_two_h heit_free sub_c " id="sub_c1">
                <?php
                if (isset($_SESSION['table_to_update'])) {
                    update_my_agency();
                } else if ($_SESSION['agency'] == 'yes') {//this is Esercos
                    $obj1 = new multi_values();
                    $obj1->list_agency_by_name('esercos');
                } else {
                    $obj1 = new multi_values();
                    $obj1->list_agency_by_name($_SESSION['agency_name']);
                }
                ?>
                <div class="parts add_more ">
                    <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Add worker</div>
                </div>
                <div class="parts add_workers">
                    <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Workers List</div> 
                </div>
            </div>
            <div class="parts  full_center_two_h  off other_agencies sub_c" id="sub_c4" style="min-height: 560px;">
                <form action="index.php" method="post" enctype="multipart/form-data">
                    <table class="new_data_table" style="float: left;">
                        <tr><td>Name :</td><td> <input type="text" placeholder="Your name"       name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                        <tr><td>Last name :</td><td> <input type="text" placeholder="Ypou  last name"       name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                        <tr><td>Email :</td><td> <input type="email" placeholder="Your email"       name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                        <tr><td>Office phone :</td><td> <input type="text" placeholder="Office phone"       name="txt_office_phone" required class="textbox" value="<?php echo trim(chosen_office_phone_upd()); ?>"   />  </td></tr>
                        <tr><td>Mobile phone :</td><td> <input type="text" placeholder="Mobile office"       name="txt_mobile_phone" required class="textbox" value="<?php echo trim(chosen_mobile_phone_upd()); ?>"   />  </td></tr>
                        <tr><td>Address :</td><td> <input type="text" placeholder="Address"       name="txt_address" required class="textbox" value="<?php echo trim(chosen_address_upd()); ?>"   />  </td></tr>
                        <tr><td>City :</td><td> <input type="text" placeholder="City"       name="txt_city" required class="textbox" value="<?php echo trim(chosen_city_upd()); ?>"   />  </td></tr>
                        <tr><td>Country :</td><td> <input type="text" placeholder="Country"       name="txt_country" required class="textbox" value="<?php echo trim(chosen_country_upd()); ?>"   />  </td></tr>
                        <tr><td>image :</td><td> <input type="file" name="txt_image" /> </td></tr>

                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_profile" value="Save"/>  </td></tr>
                    </table> <div class="parts add_workers">
                        <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Workers List</div> 
                    </div>
                </form>
            </div>
            <div class="parts  full_center_two_h no_paddin_shade_no_Border off other_agencies sub_c" id="sub_c2">
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_agency();
                $obj->list_agency($first);
                ?>
            </div>
            <div class="parts  full_center_two_h  off  sub_c accept_abs no_paddin_shade_no_Border" id="sub_c5">
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                    Workers for <?php echo $_SESSION['agency_name']; ?>      
                </div>  
                <?php $obj->get_Users_by_category_agency('worker', $_SESSION['agency_name']) ?> 
                <div class="parts add_more ">
                    <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Add worker</div>
                </div>
                <div class="parts add_workers">
                    <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Workers List</div> 
                </div>
            </div>
            <?php if ($_SESSION['agency'] == 'yes') { ?>    <form action="index.php" method="post" enctype="multipart/form-data">
                    <div class="parts full_center_two_h heit_free off sub_c" id="sub_c3">
                        <div class="parts eighty_centered xx_titles no_paddin_shade_no_Border">  Agency Registration</div>
                        <table class="new_data_table">
                            <tr><td>website :</td><td> <input type="text" autocomplete="off" placeholder=""       name="txt_website" required class="textbox" value="<?php echo trim(chosen_website_upd()); ?>"   />  </td></tr>
                            <tr><td>office_address :</td><td> <input      autocomplete="off" type="text" placeholder=""       name="txt_office_address" required class="textbox" value="<?php echo trim(chosen_office_address_upd()); ?>"   />  </td></tr>
                            <tr><td>agency_desc :</td><td> <input         autocomplete="off"    type="text" placeholder=""       name="txt_agency_desc" required class="textbox" value="<?php echo trim(chosen_agency_desc_upd()); ?>"   />  </td></tr>
                            <tr><td>logo :</td><td> <input type="file"    autocomplete="off" placeholder=""       name="txt_logo" required class="textbox" value="<?php echo trim(chosen_logo_upd()); ?>"   />  </td></tr>
                            <tr><td>agency name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_agency_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                            <tr><td>Administrator name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_admin_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                            <tr>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td>Username</td>
                                <td><input type="email" name="txt_username" autocomplete="off" class="textbox" placeholder="email"/>  </td>
                            </tr>
                            <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_agency" value="Save"/>  </td></tr>
                        </table>
                    </div>
                </form><?php } ?>
        </div>
        <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
        <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
        <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
        <div class="parts eighty_centered off saved_dialog">
            agency saved successfully!</div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../date_picker/jquery-ui.min.js" type="text/javascript"></script>

    </body>
</hmtl>
<?php

function get_account_combo() {
    $obj = new multi_values();
//    $obj->get_account_in_combo();
}

function chosen_website_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $website = new multi_values();
            return $website->get_chosen_agency_website($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_office_address_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $office_address = new multi_values();
            return $office_address->get_chosen_agency_office_address($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_agency_desc_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $agency_desc = new multi_values();
            return $agency_desc->get_chosen_agency_agency_desc($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_logo_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $logo = new multi_values();
            return $logo->get_chosen_agency_logo($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_agency_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $agency_name = new multi_values();
            return $agency_name->get_chosen_agency_agency_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_agency_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_agent_dasta_pane() {
    ?>
    <div class="parts data_pane agent_pane no_paddin_shade_no_Border reverse_border" >
        <div class="parts full_center_two_h heit_free margin_free pane_title">Title</div>
        <div class="parts full_center_two_h heit_free margin_free">

        </div>
        <div class="parts full_center_two_h heit_free margin_free bottom_part">bottom part</div>

    </div>
    <?php
}

// <editor-fold defaultstate="collapsed" desc="------- profile -------">

function get_image_combo() {
    $obj = new multi_values();
    $obj->get_image_in_combo();
}

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_profile_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_last_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $last_name = new multi_values();
            return $last_name->get_chosen_profile_last_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_email_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $email = new multi_values();
            return $email->get_chosen_profile_email($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_home_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $home_phone = new multi_values();
            return $home_phone->get_chosen_profile_home_phone($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_office_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $office_phone = new multi_values();
            return $office_phone->get_chosen_profile_office_phone($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_mobile_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $mobile_phone = new multi_values();
            return $mobile_phone->get_chosen_profile_mobile_phone($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_address_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $address = new multi_values();
            return $address->get_chosen_profile_address($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_city_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $city = new multi_values();
            return $city->get_chosen_profile_city($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_country_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $country = new multi_values();
            return $country->get_chosen_profile_country($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_image_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $image = new multi_values();
            return $image->get_chosen_profile_image($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// </editor-fold>

function upload_person_image() {
    require_once 'web_db/new_values.php';
    require_once 'web_db/multi_values.php';
    $add_obj = new new_values();
    $mul_obj = new multi_values();
    $target_dir = "../../web_images/agency_logos/";
    $target_file = $target_dir . basename($_FILES["txt_logo"]["name"]);
    $img = $mul_obj->get_last_image_id() + 1;
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $ExtensionWithDot = '.' . $imageFileType;
    $newname = $img . '.' . $imageFileType;
    $path = $target_dir . $newname;

    $property = 0;
    $deleted = 'no';
    $appear = 'yes';
    //save the image in the db (save path)
    $add_obj->new_image($path, $property, $deleted, $appear);
    $check = getimagesize($_FILES["txt_logo"]["tmp_name"]);
    if ($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

function upload_agency_logo() {
    require_once 'web_db/new_values.php';
    require_once 'web_db/multi_values.php';
    $add_obj = new new_values();
    $mul_obj = new multi_values();
    $target_dir = "../../web_images/agency_logos/";
    $target_file = $target_dir . basename($_FILES["txt_logo"]["name"]);
    $img = $mul_obj->get_last_agency() + 1;
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $ExtensionWithDot = '.' . $imageFileType;
    $newname = $img . '.' . $imageFileType;
    $path = $target_dir . $newname;
    $check = getimagesize($_FILES["txt_logo"]["tmp_name"]);
    if ($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

function save_image() {

    // Check if image file is a actual image or fake image
    if (isset($_POST["send"])) {
        
    }
    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["txt_image"]["size"] > 3000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["txt_image"]["tmp_name"], $new_target_file)) {
            echo "The file " . basename($_FILES["txt_image"]["name"]) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

//update my agency form
// <editor-fold defaultstate="collapsed" desc=" ----- update agency form ------">
function update_my_agency() {
    ?>
    <form action="index.php" method="post">
        <div class="parts full_center_two_h heit_free  sub_c" id="sub_c3">
            <div class="parts eighty_centered xx_titles no_paddin_shade_no_Border">  Agency Registration</div>
            <table class="new_data_table">
                <tr><td>website :</td><td> <input type="text" autocomplete="off" placeholder=""       name="txt_website" required class="textbox" value="<?php echo trim(chosen_website_upd()); ?>"   />  </td></tr>
                <tr><td>office_address :</td><td> <input      autocomplete="off" type="text" placeholder=""       name="txt_office_address" required class="textbox" value="<?php echo trim(chosen_office_address_upd()); ?>"   />  </td></tr>
                <tr><td>agency_desc :</td><td> <input         autocomplete="off"    type="text" placeholder=""       name="txt_agency_desc" required class="textbox" value="<?php echo trim(chosen_agency_desc_upd()); ?>"   />  </td></tr>
                <tr><td>logo :</td><td> <input type="text"    autocomplete="off" placeholder=""       name="txt_logo" required class="textbox" value="<?php echo trim(chosen_logo_upd()); ?>"   />  </td></tr>
                <tr><td>agency name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_agency_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                <tr><td>Administrator name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_admin_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                <tr>
                    <td colspan="2"></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="email" name="txt_username" autocomplete="off" class="textbox" placeholder="email"/>  </td>
                </tr>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_agency" value="Save"/>  </td></tr>
            </table>
        </div>
    </form>



    <?php
}

// </editor-fold>


