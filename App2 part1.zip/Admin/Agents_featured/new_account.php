<?php
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
?>
<html>
    <head>
        <title>
            account
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            p{
                margin: 20px;
                color: #4c1758;
                text-decoration: underline;
            }
            .new_data_table td{
                padding: 5px;
            }
            #sp_table td{
                padding: 10px;

            }
            #sp_table{
                border-collapse: collapse;
            }
        </style>
    </head> 
    <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <?php
//            include './sidemenu.php';
            ?>
            <input type="hidden" id="acc_typeid" class=""  name="userid"/>
            <span id="d" class="off">

            </span>
            <div class="parts eighty_centered dialogBox no_shade_noBorder ">
                <?php
                save_account();
                echo ' here is where the text is going to be displayed';
                ?>
            </div>
            <table  class="parts new_data_table top_off_x margin_free smart_parts" style="border: 1px solid #fff;" > 
                <tr><td colspan="2">
                        <table   class="new_data_table" style="margin-top: 0px;">
                            <tr>
                                <td>&nbsp;&nbsp; Username :<br/>
                                    <input type="text"     name="txt_username" required class="parts" /> </td>
                                <td>&nbsp;&nbsp; Password :<br/><input type="password"     name="txt_password" required class="parts" /></td>
                                <td>&nbsp; &nbsp;Account category :     <br/>  <?php
                                    if (isset($_SESSION['cat'])) {
                                        get_user_category_combo();
                                    } else {
                                        ?><input type="text" name="simpleUser"><?php
                                    }
                                    ?>
                                </td> 
                            </tr>
                        </table>
                    </td>
                </tr> 
                <?php // require_once './new_profile.php';  ?>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_account" value="Save"/>  </td></tr>
            </table>
        </div>
        <div class="parts eighty_centered datalist_box no_paddin_shade_no_Border" >
            <?php
            if (isset($_SESSION['cat'])) {
                if ($_SESSION['cat'] == 'admin') {
                    ?>
                    <div class="parts xx_titles no_paddin_shade_no_Border">
                        Users list
                    </div>
                    <?php
                    require_once 'web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_account();
                }
            }
            ?>
        </div>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </form>
</body>
</hmtl>
<?php

function get_user_category_combo() {
    require_once 'web_db/connection.php';
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "select account_category_id,   account_category.name from account_category";
    ?>
    <select class="parts combo_user_cat" style="width: 200px;"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
    </select>
    <?php
}

function save_account() {
    if (isset($_POST['send_account'])) {
        try {
            require_once 'web_db/new_values.php';
            require_once 'web_db/multi_values.php';
            //account
            $username = $_POST['txt_username'];
            $password = $_POST['txt_password'];
            $account_category = $_POST['userid'];
            $online = 'no';
            $deleted = 'no';
            $date_created = date("Y-m-d");
            $obj = new new_values();
            $add_obj = new new_values();
            $mul_obj = new multi_values();
            if ($account_category != '') {
//                $add_obj->new_profile($name, $last_name, $email, $home_phone, $office_phone, $mobile_phone, $address, $city, $country, $img);
                //last profile id
                $last_profile = $mul_obj->get_last_profile_id();
                $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
                echo 'Data save successfully';
            }
        } catch (PDOException $ex) {
            echo 'Saving Data error: ' . $ex;
        }
    }
}
