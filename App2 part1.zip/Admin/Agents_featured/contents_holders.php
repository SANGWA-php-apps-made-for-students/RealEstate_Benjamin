<?php

class holders {

    function agency() {
        Esercos_subMenu();
        ?>
        <div class="parts no_shade_noBorder xx_titles">My Agency</div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_1" >
            <?php
            $obj1 = new multi_values();
            $obj1->list_agency_by_name('esercos');
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_2 off">
            <?php
            $obj = new multi_values();
            $first = $obj->get_first_agency();
            $obj->list_agency($first);
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_3 off">
            <?php add_agencies(); ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_4 off">
            <?php
            $mul_obj = new multi_values();
            $mul_obj->get_Users_by_category_agency('worker', $_SESSION['agency_name']);
            ?> 
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_5 off">
            <?php add_worker(); ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_6 off">
            <?php
            $mul_obj = new multi_values();
            $mul_obj->get_Users_by_category_agency('manager', $_SESSION['agency_name']);
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_7 off">
            <?php add_manager(); ?>
        </div>
        <?php
    }

    function message() {
        message_submenu();
        ?><div class="parts no_shade_noBorder xx_titles">Messages</div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_1 off">
            <?php
            $obj = new multi_values();
            $obj->list_message();
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_2 off">
            <?php
            $obj->list_web_visits();
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_3 off">
            <?php
            $obj->list_call_message('call');
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_4 off">

            emails
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_5 off">
            <?php
            $obj->list_comment();
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_6 off">
            Sub contents 6
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_7 off">
            Sub contents 7
        </div><?php
    }

    function featured() {
        sub_menu();
        ?><div class="parts no_shade_noBorder xx_titles"> Featured</div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_1 off">
            <?php
            require_once 'web_db/multi_values.php';
            $obj = new multi_values();
            $obj->get_sumarized_list_by_list_type(2); //2 is for sale
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_2 off">
            <?php $obj->get_sumarized_list_by_list_type(1); //2 is for rent
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_3 off">
            <?php $obj->get_general_featured(); //these are those not in featured
            ?>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_4 off">
            Sub contents 4
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_5 off">
            Sub contents 5
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_6 off">
            Sub contents 6
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_7 off">
            Sub contents 7
        </div><?php
    }

    function comments() {
        sub_menu();
        ?>
        <div class="parts no_shade_noBorder xx_titles">Property owners</div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_1 off">
            Sub contents 3
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_2 off">
            Sub contents 2
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_3 off">
            Sub contents 3
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_4 off">
            Sub contents 4
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_5 off">
            Sub contents 5
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_6 off">
            Sub contents 6
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border suub_contents sub_contents_7 off">
            Sub contents 7
        </div>
        <?php
    }

}
