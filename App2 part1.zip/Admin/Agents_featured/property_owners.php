<?php
require_once 'web_db/new_values.php';
require_once 'web_db/multi_values.php';
$mul_obj = new multi_values();
$add_obj = new new_values();
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}

if (isset($_POST['send_prop_owner_prfl'])) {
    try {
        //profile fields
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $email = $_POST['txt_email'];

        $office_phone = $_POST['txt_office_phone'];
        $mobile_phone = $_POST['txt_mobile_phone'];
        $address = $_POST['txt_address'];
        $city = $_POST['txt_city'];
        $country = $_POST['txt_country'];

        //account
        $username = $_POST['txt_email'];
        $password = '123';
        $account_category = $mul_obj->get_catId_byName('prop_owner'); // this is the id of the category "worker" that should not changed on the database
        $online = 'no';
        $deleted = 'no';
        $date_created = date("Y-m-d");
        $obj = new new_values();
        save_image();
        $img = $mul_obj->get_last_image_id();
        if ($account_category != '') {
            $add_obj->new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $img);
            //last profile id
            $last_profile = $mul_obj->get_last_profile_id();
            $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
            // we also have to save the agency withe the account
            // <editor-fold defaultstate="collapsed" desc="---- get last account ------">
            $last_account = $mul_obj->get_last_acc_id();

            // </editor-fold>
            echo 'Data save successfully';
        } else {
            echo'<div class="red_message">' . ' You have not selected the account type or the account type has no users' . '</div>';
        }
    } catch (PDOException $ex) {
        echo 'Saving Data error: ' . $ex;
    }
}
?>
<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
    <div class="parts no_paddin_shade_no_Border link_cursor full_center_two_h heit_free "> 
        <?php if ($_SESSION['agency'] == 'yes') { ?>    <div class="parts submenu_btn propOwnerbtn underline_sub_menu" id="propOwnerbtn1">
                Esercos   
            </div>
            <div class="parts submenu_btn propOwnerbtn underline_sub_menu" id="propOwnerbtn2">
                Others
            </div><?php } ?>
    </div>
    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
        <div class="parts   full_center_two_h heit_free propOwnerbtn_sub_c no_paddin_shade_no_Border "  id="propOwner_sub_c1">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border"> 1. Property owners for <?php echo $_SESSION['agency_name']; ?>   </div>
            <?php $mul_obj->get_Users_by_category_agency('prop_owner', 'esercos'); ?> 

            <div class="parts add_more btn_new_propOwner" style="background-size: 65%;">
                <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part margin_free" >Add Propery owner</div>
            </div>
            <div class="parts add_workers btn_list_mngr" style="background-size: 70%;">
                <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part margin_free">Property owners list</div> 
            </div>
        </div>  
        <div class="parts  full_center_two_h heit_free propOwnerbtn_sub_c no_paddin_shade_no_Border  off"   id="propOwner_sub_c2">
            2.Others <?php $mul_obj->get_other_usercategories('prop_owner'); ?>  
        </div> 
        <div class="parts  full_center_two_h heit_free propOwnerbtn_sub_c no_paddin_shade_no_Border off"   id="propOwner_sub_c3">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                Property owner Registration
            </div>
            <form action="index.php" method="post" enctype="multipart/form-data">
                <table class="new_data_table" style="float: left;">
                    <tr><td>Name :</td><td> <input type="text" placeholder="Your name"       name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                    <tr><td>Last name :</td><td> <input type="text" placeholder="Ypou  last name"       name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                    <tr><td>Email :</td><td> <input type="text" placeholder="Your email"       name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                    <tr><td>Office phone :</td><td> <input type="text" placeholder="Office phone"       name="txt_office_phone" required class="textbox" value="<?php echo trim(chosen_office_phone_upd()); ?>"   />  </td></tr>
                    <tr><td>Mobile phone :</td><td> <input type="text" placeholder="Mobile office"       name="txt_mobile_phone" required class="textbox" value="<?php echo trim(chosen_mobile_phone_upd()); ?>"   />  </td></tr>
                    <tr><td>Address :</td><td> <input type="text" placeholder="Address"       name="txt_address" required class="textbox" value="<?php echo trim(chosen_address_upd()); ?>"   />  </td></tr>
                    <tr><td>City :</td><td> <input type="text" placeholder="City"       name="txt_city" required class="textbox" value="<?php echo trim(chosen_city_upd()); ?>"   />  </td></tr>
                    <tr><td>Country :</td><td> <input type="text" placeholder="Country"       name="txt_country" required class="textbox" value="<?php echo trim(chosen_country_upd()); ?>"   />  </td></tr>
                    <tr><td>image :</td><td> <input type="file" name="txt_image" /> </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_prop_owner_prfl" value="Save"/>  </td></tr>
                </table>
                <div class="parts add_workers margin_free">
                    <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part margin_free">Managers List</div> 
                </div>
            </form>
        </div> 
        <div class="parts  full_center_two_h heit_free propOwnerbtn_sub_c no_paddin_shade_no_Border"   id="propOwner_sub_c4">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">

            </div>
            <?php $mul_obj->get_user_by_catname('prop_owner') ?> 
        </div> 
    </div>

</div>