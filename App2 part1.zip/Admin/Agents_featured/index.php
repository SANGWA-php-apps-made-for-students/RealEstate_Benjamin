<!DOCTYPE html>
<?php
session_start();
require_once './contents_holders.php';
if (!isset($_SESSION['login_token'])) {
    header('location:../../index.php');
}
?><html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="styles.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <?php require_once 'Admin_header.php'; ?>
        <div class="parts ninenty_centered">
            <div class="parts side_menu no_paddin_shade_no_Border  margin_free">
                <div class="parts  logo no_bg margin_free no_paddin_shade_no_Border"><?php
                    require_once './web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->get_logo_byName($_SESSION['agency_name']);
                    ?> 
                </div>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free top_off_x first_menu_on" id="side_btn1">
                    <?php
                    if ($_SESSION['agency'] == 'yes') {
                        echo ' Esercos';
                    } else {
                        echo ' My Profile';
                    }
                    ?></div>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free" id="side_btn2"> Messages </div>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free" id="side_btn3" > Featured</div>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free " id="side_btn4"> Finace</div>
            </div>
            <?php
            if (isset($_SESSION['table_to_update'])) {
                echo 'Udpating...';
                ?><form action="index.php" method="post">
                    <?php
                    if (isset($_POST['cancel'])) {
                        unset($_SESSION['table_to_update']);
                    }
                    ?>

                    <input type="submit" name="cancel">
                </form>
                <?php
                if ($_SESSION['table_to_update'] == 'agency') {
                    update_my_agency();
                } else if ($_SESSION['table_to_update'] == 'worker') {
                    update_user();
                }
            } else {
                ?>
                <div class="parts eighty_right no_paddin_shade_no_Border  contents " id="contents_1">
                    <?php
                    $getter = new holders();
                    $getter->agency();
                    ?>
                </div>
                <div class="parts eighty_right no_paddin_shade_no_Border contents off" id="contents_2">
                    <?php
                    $getter->message();
                    ?>
                </div>
                <div class="parts eighty_right no_paddin_shade_no_Border contents off" id="contents_3">
                    <?php
                    $getter->featured();
                    ?>
                </div>
                <div class="parts eighty_right no_paddin_shade_no_Border contents off" id="contents_4">
                    <?php $getter->comments() ?>
                </div>
                <?php
            }
            ?>
        </div>
        <script src="../../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="scriptsAddon/my_script.js" type="text/javascript"></script>
    </body>
</html>
<?php

function update_user() {
    require_once '../web_db/updates.php';
    $upd_obj = new updates();
    $profile_id = $_SESSION['id_upd'];

    $name = $_POST['txt_name'];
    $last_name = $_POST['txt_last_name'];
    $email = $_POST['txt_email'];
    $home_phone = $_POST['txt_home_phone'];
    $office_phone = $_POST['txt_office_phone'];
    $mobile_phone = $_POST['txt_mobile_phone'];
    $address = $_POST['txt_address'];
    $city = $_POST['txt_city'];
    $country = $_POST['txt_country'];
    $image = $_POST['txt_image_id'];

    $upd_obj->update_profile($name, $last_name, $email, $home_phone, $office_phone, $mobile_phone, $address, $city, $country, $image, $profile_id);
    unset($_SESSION['table_to_update']);
}

function Esercos_subMenu() {
    ?>
    <div class = "parts full_center_two_h heit_free no_paddin_shade_no_Border margin_free">
        <div class = "parts submenu_btn submenu_btn1 link_cursor first_menu_on" >My agency</div>
        <?php if ($_SESSION['agency'] == 'yes') { ?> <div class = "parts submenu_btn submenu_btn2 link_cursor">Other agencies</div><?php } ?>
        <?php if ($_SESSION['agency'] == 'yes') { ?> <div class = "parts submenu_btn submenu_btn3 link_cursor">Add agencies</div><?php } ?>
        <div class = "parts submenu_btn submenu_btn4 link_cursor">Workers List </div>
        <div class = "parts submenu_btn submenu_btn5 link_cursor">Add worker</div>
        <div class = "parts submenu_btn submenu_btn6 link_cursor">Managers</div>
        <div class = "parts submenu_btn submenu_btn7 link_cursor">Add Manager</div>
    </div><?php
}

function message_submenu() {
    ?>
    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border margin_free">
        <div class="parts submenu_btn submenu_btn1 link_cursor" >    <?php
            $obj = new multi_values();
            echo $obj->All_message() . '  ';
            ?>New Message 

        </div>
        <div class = "parts submenu_btn submenu_btn2 link_cursor">
            <?php
            $obj = new multi_values();
            echo $obj->All_message() . '  ';
            ?>
            Propert views </div>
        <div class = "parts submenu_btn submenu_btn3 link_cursor">
            <?php echo $obj->All_message_by_cat(); ?>
            Property calls</div>
        <div class = "parts submenu_btn submenu_btn4 link_cursor">Emails </div>
        <div class = "parts submenu_btn submenu_btn5 link_cursor">Comments</div>
        <div class = "parts submenu_btn submenu_btn6 link_cursor">Sub 1</div>
        <div class = "parts submenu_btn submenu_btn7 link_cursor">Sub 1</div>
    </div>
    <?php
}

function sub_menu() {
    ?>
    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border margin_free">
        <div class="parts submenu_btn submenu_btn1 link_cursor" >Sales Featured </div>
        <div class="parts submenu_btn submenu_btn2 link_cursor">Rentals Featured</div>
        <div class="parts submenu_btn submenu_btn3 link_cursor">General Featured </div>
        <div class="parts submenu_btn submenu_btn4 link_cursor">Sub 1</div>
        <div class="parts submenu_btn submenu_btn5 link_cursor">Sub 1</div>
        <div class="parts submenu_btn submenu_btn6 link_cursor">Sub 1</div>
        <div class="parts submenu_btn submenu_btn7 link_cursor">Sub 1</div>
    </div>     
    <?php
}

function add_agencies() {
    if (isset($_POST['send_agency'])) {
        require_once 'web_db/new_values.php';
        // <editor-fold defaultstate="collapsed" desc="-----save profile ------">
        $agency_mul = new multi_values();
        $prof_add = new new_values();
        $agency_add = new new_values();
        $agent_add = new new_values();
        $acc_add = new new_values();
        $profile_name = $_POST['txt_admin_name'];
        $prof_add->new_profile($profile_name, '', '', '', ' ', '', '', ' ', '');
        // </editor-fold>
        // 
        // 
        // 
        // <editor-fold defaultstate="collapsed" desc="------save the account (user) ------------">
        $last_profile = $agency_mul->get_last_profile();
        $account_category = $agency_mul->get_catId_byName('Admin');
        $username = $_POST['txt_username'];
        $password = '123';
        $online = 'no';
        $deleted = 'no';
        $date_created = date('y-m-d');
        $acc_add->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
        $last_account = $agency_mul->get_last_acc_id(); //declared here because it will be accessed iin many locatuons
        // </editor-fold>
        // 
        // 
        // <editor-fold defaultstate="collapsed" desc="-------save agency-------------">
        $website = $_POST['txt_website'];
        $office_address = $_POST['txt_office_address'];
        $agency_desc = $_POST['txt_agency_desc'];
        $logo = $_POST['txt_logo'];
        $agency_name = $_POST['txt_agency_name'];
        $agency_add->new_agency($website, $office_address, $agency_desc, $logo, $agency_name, $last_account);

        // </editor-fold>
        // 
        // 
        // 
        // <editor-fold defaultstate="collapsed" desc="-----------save the agent -----------">
        $agency_id = $agency_mul->getagency_id_by_name($agency_name);

        $agent_add->new_agent($last_account, $agency_id);
    }
    ?>
    <form action="index.php" method="post" enctype="multipart/form-data">

        <div class="parts no_paddin_shade_no_Border reverse_border big_data_entry" > 
            <div class="parts margin_free pane_title_bg full_center_two_h heit_free header">
                Agency REgistration
            </div>
            <table class="new_data_table">
                <tr><td>website :</td><td> <input type="text" autocomplete="off" placeholder=""       name="txt_website" required class="textbox"   />  </td></tr>
                <tr><td>office_address :</td><td> <input      autocomplete="off" type="text" placeholder=""       name="txt_office_address" required class="textbox"    />  </td></tr>
                <tr><td>agency_desc :</td><td> <input         autocomplete="off"    type="text" placeholder=""       name="txt_agency_desc" required class="textbox"    />  </td></tr>
                <tr><td>logo :</td><td> <input type="text"    autocomplete="off" placeholder=""       name="txt_logo" required class="textbox"    </td></tr>
                <tr><td>agency name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_agency_name" required class="textbox"    />  </td></tr>
                <tr><td>Administrator name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_admin_name" required class="textbox"      />  </td></tr>
                <tr>
                    <td colspan="2"></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="email" name="txt_username" autocomplete="off" class="textbox" placeholder="email"/>  </td>
                </tr>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_agency" value="Save"/>  </td></tr>
            </table>
        </div>
    </form>
    <?php
}

// <editor-fold defaultstate="collapsed" desc="-------Chosen agency ---------">

function chosen_website_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $website = new multi_values();
            return $website->get_chosen_agency_website($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_office_address_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $office_address = new multi_values();
            return $office_address->get_chosen_agency_office_address($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_agency_desc_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $agency_desc = new multi_values();
            return $agency_desc->get_chosen_agency_agency_desc($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_logo_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $logo = new multi_values();
            return $logo->get_chosen_agency_logo($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_agency_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'agency') {
            $id = $_SESSION['id_upd'];
            $agency_name = new multi_values();
            return $agency_name->get_chosen_agency_agency_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// </editor-fold>

function add_worker() {
    ?>
    <div class="parts  no_paddin_shade_no_Border   other_agencies sub_c" id="sub_c4" style="min-height: 560px;">
        <form action="index.php" method="post" enctype="multipart/form-data">
            <div class="parts no_paddin_shade_no_Border reverse_border" style="max-width: 570px;"> 
                <div class="parts margin_free pane_title_bg full_center_two_h heit_free header">
                    Worker Registration
                </div>
                <table class="new_data_table" style="float: left;">
                    <tr><td>Name :</td><td> <input type="text" placeholder="Your name"       name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                    <tr><td>Last name :</td><td> <input type="text" placeholder="Ypou  last name"       name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                    <tr><td>Email :</td><td> <input type="email" placeholder="Your email"       name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                    <tr><td>Office phone :</td><td> <input type="text" placeholder="Office phone"       name="txt_office_phone" required class="textbox" value="<?php echo trim(chosen_office_phone_upd()); ?>"   />  </td></tr>
                    <tr><td>Mobile phone :</td><td> <input type="text" placeholder="Mobile office"       name="txt_mobile_phone" required class="textbox" value="<?php echo trim(chosen_mobile_phone_upd()); ?>"   />  </td></tr>
                    <tr><td>Address :</td><td> <input type="text" placeholder="Address"       name="txt_address" required class="textbox" value="<?php echo trim(chosen_address_upd()); ?>"   />  </td></tr>
                    <tr><td>City :</td><td> <input type="text" placeholder="City"       name="txt_city" required class="textbox" value="<?php echo trim(chosen_city_upd()); ?>"   />  </td></tr>
                    <tr><td>Country :</td><td> <input type="text" placeholder="Country"       name="txt_country" required class="textbox" value="<?php echo trim(chosen_country_upd()); ?>"   />  </td></tr>
                    <tr class="off"><td>image :</td><td> <input type="file" name="txt_image" /> </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_worker" value="Save"/>  </td></tr>
                </table></div> <div class="parts add_workers">
                <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Workers List</div> 
            </div>
        </form>
    </div>
    <?php
    if (isset($_POST['send_worker'])) {// here is saving the esercos worker
        try {
            require_once 'web_db/new_values.php';
            require_once 'web_db/multi_values.php';
            $mul_obj = new multi_values();
            $add_obj = new new_values();
            //profile fields
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $email = $_POST['txt_email'];

            $office_phone = $_POST['txt_office_phone'];
            $mobile_phone = $_POST['txt_mobile_phone'];
            $address = $_POST['txt_address'];
            $city = $_POST['txt_city'];
            $country = $_POST['txt_country'];

            //account
            $username = $_POST['txt_email'];
            $password = '123';
            $agency_name = '';
            if (isset($_SESSION['agency_name'])) {
                $agency_name = (!empty($_SESSION['agency_name'])) ? $_SESSION['agency_name'] : '';
            } else {
                $agency_name = 'esercos';
            }
            $agency_id = $mul_obj->getagency_id_by_name($agency_name);
            $account_category = $mul_obj->get_catId_byName('worker'); // this is the id of the category "worker" that should not changed on the database
            $online = 'no';
            $deleted = 'no';
            $date_created = date("Y-m-d");
            $obj = new new_values();
//            save_image();
            $img = $mul_obj->get_last_image_id();
            if ($account_category != '') {
                $add_obj->new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $img);
                //last profile id
                $last_profile = $mul_obj->get_last_profile_id();
                $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
                // we also have to save the agency withe the account
                // <editor-fold defaultstate="collapsed" desc="---- get last account ------">
                $last_account = $mul_obj->get_last_acc_id();
                $agency = $agency_id; //this is the agent to whom we are going to assign the worker /// we have to change by getting it by name in db
                $add_obj = new new_values();
                $add_obj->new_agent($last_account, $agency);
                // </editor-fold>
                echo 'Data save successfully';
            } else {
                echo'<div class="red_message">' . ' You have not selected the account type or the account type has no users' . '</div>';
            }
        } catch (PDOException $ex) {
            echo 'Saving Data error: ' . $ex;
        }
    }
}

function add_manager() {
    if (isset($_POST['send_worker_prfl'])) {
        try {
            require_once 'web_db/multi_values.php';
            require_once 'web_db/new_values.php';
            //profile fields
            $add_obj = new new_values();
            $mul_obj = new multi_values();
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $email = $_POST['txt_email'];

            $office_phone = $_POST['txt_office_phone'];
            $mobile_phone = $_POST['txt_mobile_phone'];
            $address = $_POST['txt_address'];
            $city = $_POST['txt_city'];
            $country = $_POST['txt_country'];

            //account
            $username = $_POST['txt_email'];
            $password = '123';
            $agency_id = $mul_obj->getagency_id_by_name($_SESSION['agency_name']);
            $account_category = $mul_obj->get_catId_byName('manager'); // this is the id of the category "worker" that should not changed on the database
            $online = 'no';
            $deleted = 'no';
            $date_created = date("Y-m-d");
//          save_image();
            $img = $mul_obj->get_last_image_id();
            if ($account_category != '') {
                $add_obj->new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $img);
                //last profile id
                $last_profile = $mul_obj->get_last_profile_id();
                $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
                // we also have to save the agency withe the account
                // <editor-fold defaultstate="collapsed" desc="---- get last account ------">

                $last_account = $mul_obj->get_last_acc_id();
                $agency = $agency_id; //this is the agent to whom we are going to assign the worker /// we have to change by getting it by name in db
                $add_obj = new new_values();
                $add_obj->new_agent($last_account, $agency);
                // </editor-fold>
                echo 'Data save successfully';
            } else {
                echo'<div class="red_message">' . ' You have not selected the account type or the account type has no users' . '</div>';
            }
        } catch (PDOException $ex) {
            echo 'Saving Data error: ' . $ex->getMessage();
        }
    }
    ?> <form action="index.php" method="post" enctype="multipart/form-data">
        <div class="parts big_data_entry no_paddin_shade_no_Border reverse_border ">
            <div class="parts margin_free pane_title_bg full_center_two_h heit_free header">
                Manager Registration
            </div>
            <table class="new_data_table" style="margin: 0px; float: left;">
                <tr><td>Name :</td><td> <input type="text" placeholder="Your name"       name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                <tr><td>Last name :</td><td> <input type="text" placeholder="Ypou  last name"       name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                <tr><td>Email :</td><td> <input type="text" placeholder="Your email"       name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                <tr><td>Office phone :</td><td> <input type="text" placeholder="Office phone"       name="txt_office_phone" required class="textbox" value="<?php echo trim(chosen_office_phone_upd()); ?>"   />  </td></tr>
                <tr><td>Mobile phone :</td><td> <input type="text" placeholder="Mobile office"       name="txt_mobile_phone" required class="textbox" value="<?php echo trim(chosen_mobile_phone_upd()); ?>"   />  </td></tr>
                <tr><td>Address :</td><td> <input type="text" placeholder="Address"       name="txt_address" required class="textbox" value="<?php echo trim(chosen_address_upd()); ?>"   />  </td></tr>
                <tr><td>City :</td><td> <input type="text" placeholder="City"       name="txt_city" required class="textbox" value="<?php echo trim(chosen_city_upd()); ?>"   />  </td></tr>
                <tr><td>Country :</td><td> <input type="text" placeholder="Country"       name="txt_country" required class="textbox" value="<?php echo trim(chosen_country_upd()); ?>"   />  </td></tr>
                <tr class="off"><td>image :</td><td> <input type="file" name="txt_image" /> </td></tr>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_worker_prfl" value="Save"/>  </td></tr>
            </table></div></form> <?php
}

function agencies_list() {
    $obj = new multi_values();
    $first = $obj->get_first_agency();
    $obj->list_agency($first);
}

// <editor-fold defaultstate="collapsed" desc="------- profile -------">

function get_image_combo() {
    $obj = new multi_values();
    $obj->get_image_in_combo();
}

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_profile_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_last_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $last_name = new multi_values();
            return $last_name->get_chosen_profile_last_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_email_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $email = new multi_values();
            return $email->get_chosen_profile_email($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_home_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $home_phone = new multi_values();
            return $home_phone->get_chosen_profile_home_phone($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_office_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $office_phone = new multi_values();
            return $office_phone->get_chosen_profile_office_phone($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_mobile_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $mobile_phone = new multi_values();
            return $mobile_phone->get_chosen_profile_mobile_phone($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_address_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $address = new multi_values();
            return $address->get_chosen_profile_address($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_city_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $city = new multi_values();
            return $city->get_chosen_profile_city($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_country_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $country = new multi_values();
            return $country->get_chosen_profile_country($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_image_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $image = new multi_values();
            return $image->get_chosen_profile_image($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// </editor-fold>

function update_my_agency() {
    ?>
    <form action="index.php" method="post">
        <div class="parts full_center_two_h heit_free  sub_c" id="sub_c3">
            <div class="parts eighty_centered xx_titles no_paddin_shade_no_Border">  Agency Registration</div>
            <table class="new_data_table">
                <tr><td>website :</td><td> <input type="text" autocomplete="off" placeholder=""       name="txt_website" required class="textbox" value="<?php echo trim(chosen_website_upd()); ?>"   />  </td></tr>
                <tr><td>office_address :</td><td> <input      autocomplete="off" type="text" placeholder=""       name="txt_office_address" required class="textbox" value="<?php echo trim(chosen_office_address_upd()); ?>"   />  </td></tr>
                <tr><td>agency_desc :</td><td> <input         autocomplete="off"    type="text" placeholder=""       name="txt_agency_desc" required class="textbox" value="<?php echo trim(chosen_agency_desc_upd()); ?>"   />  </td></tr>
                <tr><td>logo :</td><td> <input type="text"    autocomplete="off" placeholder=""       name="txt_logo" required class="textbox" value="<?php echo trim(chosen_logo_upd()); ?>"   />  </td></tr>
                <tr><td>agency name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_agency_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                <tr><td>Administrator name :</td><td> <input          autocomplete="off" type="text" placeholder=""       name="txt_admin_name" required class="textbox" value="<?php echo trim(chosen_agency_name_upd()); ?>"   />  </td></tr>
                <tr>
                    <td colspan="2"></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="email" name="txt_username" autocomplete="off" class="textbox" placeholder="email"/>  </td>
                </tr>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_agency" value="Save"/>  </td></tr>
            </table>
        </div>
    </form>
    <?php
}
