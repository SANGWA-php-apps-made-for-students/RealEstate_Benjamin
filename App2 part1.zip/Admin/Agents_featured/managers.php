<?php
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
if (isset($_POST['send_worker_prfl'])) {
    try {
        require_once 'web_db/multi_values.php';
        require_once 'web_db/new_values.php';
        //profile fields
        $add_obj = new new_values();
        $mul_obj = new multi_values();
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $email = $_POST['txt_email'];

        $office_phone = $_POST['txt_office_phone'];
        $mobile_phone = $_POST['txt_mobile_phone'];
        $address = $_POST['txt_address'];
        $city = $_POST['txt_city'];
        $country = $_POST['txt_country'];

        //account
        $username = $_POST['txt_email'];
        $password = '123';
        $agency_id = $mul_obj->getagency_id_by_name($_SESSION['agency_name']);
        $account_category = $mul_obj->get_catId_byName('manager'); // this is the id of the category "worker" that should not changed on the database
        $online = 'no';
        $deleted = 'no';
        $date_created = date("Y-m-d");

        save_image();
        $img = $mul_obj->get_last_image_id();
        if ($account_category != '') {
            $add_obj->new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $img);
            //last profile id
            $last_profile = $mul_obj->get_last_profile_id();
            $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
            // we also have to save the agency withe the account
            // <editor-fold defaultstate="collapsed" desc="---- get last account ------">

            $last_account = $mul_obj->get_last_acc_id();
            $agency = $agency_id; //this is the agent to whom we are going to assign the worker /// we have to change by getting it by name in db
            $add_obj = new new_values();
            $add_obj->new_agent($last_account, $agency);
            // </editor-fold>
            echo 'Data save successfully';
        } else {
            echo'<div class="red_message">' . ' You have not selected the account type or the account type has no users' . '</div>';
        }
    } catch (PDOException $ex) {
        echo 'Saving Data error: ' . $ex->getMessage();
    }
}
?>
<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
    <div class="parts no_paddin_shade_no_Border link_cursor full_center_two_h heit_free"> 
        <?php if ($_SESSION['agency'] == 'yes') { ?>   <div class="parts submenu_btn mngerbtn underline_sub_menu" id="mngerbtn1">
                Esercos 
            </div>
            <div class="parts submenu_btn mngerbtn underline_sub_menu" id="mngerbtn2">
                Managers from other agencies
            </div><?php } ?>
    </div>
    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
        <div class="parts   full_center_two_h heit_free mnger_sub_c no_paddin_shade_no_Border"  id="mnger_sub_c1">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">    Managers for <?php echo $_SESSION['agency_name']; ?>            </div>
            <?php
            $mul_obj = new multi_values();
            $mul_obj->get_Users_by_category_agency('manager', $_SESSION['agency_name']);
            ?> 
            <div class="parts add_more btn_new_mgnr">
                <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part margin_free">Add manager</div>
            </div>
            <div class="parts add_workers btn_list_mngr">
                <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part margin_free">managers List</div> 
            </div>
        </div>  
        <div class="parts  full_center_two_h heit_free mnger_sub_c no_paddin_shade_no_Border"   id="mnger_sub_c2">
            <?php $mul_obj->get_other_usercategories('manager'); ?>  
        </div> 
        <div class="parts  full_center_two_h heit_free mnger_sub_c no_paddin_shade_no_Border off"   id="mnger_sub_c3">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                Manager Registration
            </div>

            <form action="index.php" method="post" enctype="multipart/form-data">
                <div class="parts no_paddin_shade_no_Border"> 
                    <table class="new_data_table" style="margin: 0px; float: left;">
                        <tr><td>Name :</td><td> <input type="text" placeholder="Your name"       name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                        <tr><td>Last name :</td><td> <input type="text" placeholder="Ypou  last name"       name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                        <tr><td>Email :</td><td> <input type="text" placeholder="Your email"       name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                        <tr><td>Office phone :</td><td> <input type="text" placeholder="Office phone"       name="txt_office_phone" required class="textbox" value="<?php echo trim(chosen_office_phone_upd()); ?>"   />  </td></tr>
                        <tr><td>Mobile phone :</td><td> <input type="text" placeholder="Mobile office"       name="txt_mobile_phone" required class="textbox" value="<?php echo trim(chosen_mobile_phone_upd()); ?>"   />  </td></tr>
                        <tr><td>Address :</td><td> <input type="text" placeholder="Address"       name="txt_address" required class="textbox" value="<?php echo trim(chosen_address_upd()); ?>"   />  </td></tr>
                        <tr><td>City :</td><td> <input type="text" placeholder="City"       name="txt_city" required class="textbox" value="<?php echo trim(chosen_city_upd()); ?>"   />  </td></tr>
                        <tr><td>Country :</td><td> <input type="text" placeholder="Country"       name="txt_country" required class="textbox" value="<?php echo trim(chosen_country_upd()); ?>"   />  </td></tr>
                        <tr><td>image :</td><td> <input type="file" name="txt_image" /> </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_worker_prfl" value="Save"/>  </td></tr>
                    </table> 
                </div>
                <div class="parts add_workers margin_free">
                    <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part margin_free">Managers List</div> 
                </div>
            </form>
        </div> 
        <div class="parts  full_center_two_h heit_free mnger_sub_c no_paddin_shade_no_Border"   id="mnger_sub_c4">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                Managers from <?php echo $_SESSION['agency_name']; ?>
            </div>

            <?php
            $agency = $_SESSION['agency_name'];
            $mul_obj->get_Users_by_category_agency('manager', $agency);
            ?> 
        </div> 
    </div>

</div>
