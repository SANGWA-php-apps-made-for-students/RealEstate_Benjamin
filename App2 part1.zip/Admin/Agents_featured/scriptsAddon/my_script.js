$(document).ready(function () {
    defaults();
    switch_main_contents();
    switch_sub_contents();
    Edit_myAgency();
    edit_worker();
    featured();
});
function switch_main_contents() {
//highlight the clicked menu
    $('.menu_btn').click(function () {
        $('.menu_btn').removeClass('highlight_menu');
        $(this).addClass('highlight_menu');
    });
    $('#side_btn1').click(function () {
        $('.contents').hide();
        $('#contents_1').show();
        highlight_this_sub();
    });
    $('#side_btn2').click(function () {
        $('.contents').hide();
        $('#contents_2').show();
        highlight_this_sub();
    });
    $('#side_btn3').click(function () {
        $('.contents').hide();
        $('#contents_3').show();
        highlight_this_sub();
    });
    $('#side_btn4').click(function () {
        $('.contents').hide();
        $('#contents_4').show();
        highlight_this_sub();
    });
    $('#side_btn5').click(function () {
        $('.contents').hide();
        $('#contents_5').show();
        highlight_this_sub();
    });

}
function switch_sub_contents() {

    $('.submenu_btn1').unbind('click').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_1').show();
        subMnu_hilit(this);
    });
    $('.submenu_btn2').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_2').show();
        subMnu_hilit(this);
    });
    $('.submenu_btn3').unbind('click').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_3').show();
        subMnu_hilit(this);
    });
    $('.submenu_btn4').unbind('click').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_4').show();
        subMnu_hilit(this);
    });
    $('.submenu_btn5').unbind('click').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_5').show();
        subMnu_hilit(this);
    });
    $('.submenu_btn6').unbind('click').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_6').show();
        subMnu_hilit(this);
    });
    $('.submenu_btn7').unbind('click').click(function () {
        $('.suub_contents').hide();
        $('.sub_contents_7').show();
        subMnu_hilit(this);
    });
}
function defaults() {
    $('.first_menu_on').addClass('highlight_menu');

}
function highlight_this_sub() {//where clicked side menu 
    $('.submenu_btn').removeClass('highlight_menu');
    $('.submenu_btn1').addClass('highlight_menu');
    //dipslay first sub pane
    $('.suub_contents').hide();
    $('.sub_contents_1').show();
}
function subMnu_hilit(item) {//when clicke sub top menu
    $('.submenu_btn').removeClass('highlight_menu');
    $(item).addClass('highlight_menu');
}
function Edit_myAgency() {
    $('.data_agency_id').unbind('click').click(function () {
        var id_update = $(this).data('listing_id');
        var table_to_update = $(this).data('table');
        $.post('handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });
}
function edit_worker() {
    $('.data_agency_id').unbind('click').click(function () {
        var id_delete = $(this).data('agencydata_id');
        var table_to_delete = $(this).data('agencydata_table');
        var item = $(this);
        $.post('handler.php', {table_to_delete: table_to_delete, id_delete: id_delete}, function (data) {

        }).complete(function () {
            $(item).parent('.worker_pane').slideUp();
        });
        return false;
    });
    $('.data_agency_idEdit').unbind('click').click(function () {
        var id_update = $(this).data('agencydata_id');
        var table_to_update = $(this).data('agencydata_table');
      
        $.post('handler.php', {table_to_update: table_to_update, id_update: id_update}, function (data) {
          
        }).complete(function () {
//            window.location.replace('redirect.php');
        });


    });




}


//<editor-fold defaultstate="collapsed" desc="-----Featiured -------">
function featured() {
    featured_click();
    rprt_more_gen_feat_btn();//this is general featured. (With Genera)
}
function featured_click() {//these are the rent and sale
    $('.rprt_more_featured_btn').unbind('click').click(function () {
        var make_featured = $(this).children('span:first').html();
        var listing_type = $(this).data('list_type');
        var switchs = $(this).data('switch');

        var item = $(this);
        var res = '';

        $.post('handler.php', {make_featured: make_featured, listing_type: listing_type}, function (data) {
            res = data;
        }).complete(function () {
            window.location.reload();

            //thse needs to be checked if the property is coming to be changed
            $('.contents').hide();
            $('#contents_3').show();
            highlight_this_sub();

            $('.suub_contents').hide();
            $('.sub_contents_3').show();
            subMnu_hilit(this);
        });
    });
}

function rprt_more_gen_feat_btn() {// these are the general featured
    $('.rprt_more_gen_feat_btn').click(function () {
        var make_gen_feat = $(this).children('span:first').html();
        var listing_type = $(this).data('list_type');
        var cont = 'c';
        $.post('handler.php', {make_gen_feat: make_gen_feat}, function (data) {
            alert(data);
        }).complete(function () {
//      window.location.reload();
        });

    });
}

//</editor-fold>


