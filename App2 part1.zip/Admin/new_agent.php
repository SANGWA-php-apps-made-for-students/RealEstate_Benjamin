<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_agent'])) {
    $agency_desc = $_POST['txt_agency_desc'];
    $logo = $_POST['txt_logo'];
    $agency_name = $_POST['txt_agency_name'];
    $website = $_POST['txt_website'];
    $profile = $_POST['txt_profile'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_agent($agency_desc, $logo, $agency_name, $website, $profile);
}
?>
<html>
    <head>
        <title>
            agent</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body>
        <form action="new_agent.php" method="post" enctype="multipart/form-data">

            <div class="parts eighty_centered">
                <?php
                include 'Admin_header.php';
                ?>
            </div>
            <div class="parts eighty_centered">

                <div class="parts eighty_centered">
                    agent saved successfully!</div>

                <div class="parts eighty_centered">
                    <div class="title">  agent</div>
                    <table class="new_data_table">
                        <tr><td>agency_desc :</td><td> <input type="text"     name="txt_agency_desc" required class="textbox"   </td></tr>
                        <tr><td>logo :</td><td> <input type="text"     name="txt_logo" required class="textbox"   </td></tr>
                        <tr><td>agency_name :</td><td> <input type="text"     name="txt_agency_name" required class="textbox"   </td></tr>
                        <tr><td>website :</td><td> <input type="text"     name="txt_website" required class="textbox"   </td></tr>
                        <tr><td>profile :</td><td> <input type="text"     name="txt_profile" required class="textbox"   </td></tr>


                        <tr><td colspan="2"> <input type="submit" class="button" name="send_agent" value="Save"/>  </td></tr>
                    </table>
                </div>

                <div class="datalist_box" >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_agent();
                    ?>
                </div>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
