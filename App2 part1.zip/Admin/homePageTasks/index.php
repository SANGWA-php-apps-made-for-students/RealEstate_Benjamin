<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../../index.php');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Esercos | Agents, users</title>
        <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include './header.php';
        ?>
        <div class="parts ninenty_centered no_paddin_shade_no_Border">
            <div class="parts side_menu no_paddin_shade_no_Border  margin_free">
                <div class="parts  logo no_bg margin_free no_paddin_shade_no_Border"><?php
                    require_once './web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->get_logo_byName($_SESSION['agency_name']);
                    ?> </div>
                <?php if ($_SESSION['agency'] == 'yes') { ?>
                    <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free top_off_x" id="side_btn1">Agencies </div>
                <?php } else { ?>
                    <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free top_off_x" id="side_btn1">Profile </div>
                <?php } ?>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free" id="side_btn2"> Managers </div>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free" id="side_btn3" > Workers</div>
                <div class="parts menu_btn link_cursor full_center_two_h heit_free margin_free " id="side_btn4"> Property owners</div>
            </div>
            <div class="parts    vary_contents accept_abs">
                <div class="parts full_center_two_h heit_free abs_child margin_free no_paddin_shade_no_Border" id="disp1">
                    <div class="parts  title no_bg no_paddin_shade_no_Border">

                    </div>
                    <?php require_once './new_agency.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free abs_child margin_free no_paddin_shade_no_Border  off" id="disp2">
                    <div class="parts  title no_bg no_paddin_shade_no_Border">
                        title
                    </div> 
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <?php require_once './managers.php'; ?>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free abs_child margin_free no_paddin_shade_no_Border off" id="disp3">
                    <div class="parts margin_free title no_bg no_paddin_shade_no_Border">
                        title
                    </div> 
                    <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                        <?php require_once './workers.php'; ?>
                    </div>
                </div> 
                <div class="parts full_center_two_h heit_free abs_child margin_free no_paddin_shade_no_Border off" id="disp4">
                    <div class="parts margin_free title">
                        title
                    </div>  
                    <div class="parts">
                        <?php require_once './property_owners.php'; ?>
                    </div>
                </div> 
                <div class="parts full_center_two_h heit_free abs_child margin_free no_paddin_shade_no_Border off" id="disp5">
                    <div class="parts margin_free title">
                        title
                    </div>  
                    <div class="parts">
                        <?php require_once './new_account.php'; ?>
                    </div>
                </div> 
            </div>
        </div>
        <script src="../../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="scriptsAddon/my_script.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                defaults();
                switch_panelvl_1();
            });

            function defaults() {
                $('.mnger_sub_c').hide();
                $('#mnger_sub_c1').show();
                $('#esercos_sub1').addClass('highlight_menu');
            }
            function switch_panelvl_1() {
                $('#mngerbtn1').click(function () {
                    $('#mnger_sub_c2').hide();
                    $('#mnger_sub_c1').show();

                });
                $('#mngerbtn2').click(function () {
                    $('#mnger_sub_c1').hide();
                    $('#mnger_sub_c2').show();
                    $('#esercos_sub1').removeClass('highlight_menu');
                });
                $('#esercos_sub3').click(function () {
                    $('.mnger_sub_c').hide();
                    $('#esaercos_sub_c3').show();
                    $('#esercos_sub1').removeClass('highlight_menu');
                });//<editor-fold defaultstate="collapsed" desc="----for workers -----">
                $('#wrkrz1').click(function () {
                    $('.wrkrz_sub_c').hide();
                    $('#wrkrz_sub_c1').show();
                });
                $('#wrkrz2').click(function () {
                    $('.wrkrz_sub_c').hide();
                    $('#wrkrz_sub_c2').show();
                    $('#wrkrz_sub_c2').removeClass('highlight_menu');

                });
                $('#wrkrz3').click(function () {
                    $('.wrkrz_sub_c').hide();
                    $('#wrkrz_sub_c3').show();
                    $('#esercos_sub1').removeClass('highlight_menu');
                });

                //</editor-fold>

            }
        </script>
    </body>
</html>
