$(document).ready(function () {
    highlight_selectd_mnu('#side_btn1');//hightlight the first menu by default
    switch_side_menu_contents();
    switch_submenu_underline();
    combobox_selected();
    Edit_myAgency();edit_worker();
});
$(window).load(function () {
    get_side_menu_fullheight();
});
function get_side_menu_fullheight() {
    var parent_height = $('window').height();
    var content_width = $('.vary_contents').parent().width() - $('.side_menu').width();
    $('.side_menu').height(parent_height);
    $('.vary_contents').height(parent_height);
}
function switch_side_menu_contents() {
    $('#side_btn1').unbind('click').click(function () {
        $('.title').html('Manage ' + $(this).html());
        $('.vary_contents .abs_child').hide();
        $('#disp1').show();
        highlight_selectd_mnu('#side_btn1');
    });
    $('#side_btn2').unbind('click').click(function () {
        $('.title').html('Manage ' + $(this).html());
        $('.vary_contents .abs_child').hide();
        $('#disp2').show();
        highlight_selectd_mnu('#side_btn2');
    });
    $('#side_btn3').unbind('click').click(function () {
        $('.title').html('Manage ' + $(this).html());
        highlight_selectd_mnu('#side_btn3');
        $('.vary_contents .abs_child').hide();
        $('#disp3').show();
        highlight_selectd_mnu($(this));
    });
    $('#side_btn4').unbind('click').click(function () {
        $('.title').html('Manage ' + $(this).html());
        $('.vary_contents .abs_child').hide();
        $('#disp4').show();

        highlight_selectd_mnu($(this));
    });
    $('#side_btn5').unbind('click').click(function () {
        $('.title').html('Manage ' + $(this).html());
        $('.vary_contents .abs_child').hide();
        $('#disp5').show();
    });
    $('#side_btn6').unbind('click').click(function () {
        $('.title').html('Manage ' + $(this).html());
        $('.vary_contents .abs_child').hide();
        $('#disp6').show();

        highlight_selectd_mnu($(this));
    });


}
function highlight_selectd_mnu(menu) {
    $('.menu_btn').removeClass('highlight_menu');
    $(menu).addClass('highlight_menu');
    $('#sub1').addClass('underline');
}
function switch_submenu_underline() {
    $('.underline_sub_menu').click(function () {
        $('.underline_sub_menu').removeClass('underline');
        $(this).addClass('underline');
    });
    $('#sub1').click(function () {
        $('.sub_c').hide();
        $('#sub_c1').show();

    });
    $('#sub2').click(function () {
        $('.sub_c').hide();
        $('#sub_c2').show();
    });
    $('#sub3').click(function () {
        $('.sub_c').hide();
        $('#sub_c3').show();
    });
    $('.add_more').click(function () {
        $('.sub_c').hide();
        $('.sub_c').hide();
        $('#sub_c4').show();
    });
    $('.add_workers').click(function () {
        $('.sub_c').hide();
        $('#sub_c5').show();
    });


    //<editor-fold defaultstate="collapsed" desc="-----sub contents managers -------">
    $('.btn_new_mgnr').unbind('click').click(function () {
        $('.mnger_sub_c').hide();
        $('#mnger_sub_c3').show();
    });
    $('.btn_list_mngr').unbind('click').click(function () {
        $('.mnger_sub_c').hide();
        $('#mnger_sub_c4').show();
    });
    $('#propOwnerbtn1').unbind('click').click(function () {
        $('.propOwnerbtn').removeClass('highlight_menu');
        $(this).addClass('highlight_menu');
        $('.propOwnerbtn_sub_c').hide();
        $('#propOwner_sub_c1').show();
    });
    $('#propOwnerbtn2').unbind('click').click(function () {
        $('.propOwnerbtn').removeClass('highlight_menu');
        $(this).addClass('highlight_menu');
        $('.propOwnerbtn_sub_c').hide();
        $('#propOwner_sub_c2').show();
    });
    $('.btn_new_propOwner').unbind('click').click(function () {
        $('.propOwnerbtn_sub_c').hide();
        $('#propOwner_sub_c3').show();
    });
    //</editor-fold>


}
function combobox_selected() {
    $('.combo_user_cat').change(function () {
        var userid = $(this).val();
        $('#acc_typeid').val(userid);
    });
}

function Edit_myAgency() {
    $('.data_agency_id').unbind('click').click(function () {
        var id_update = $(this).data('listing_id');
        var table_to_update = $(this).data('table');
        $.post('handler.php', {id_update: id_update, table_to_update:table_to_update}, function (data) {
             
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });
}
function edit_worker() {
    $('.data_agency_id').unbind('click').click(function () {
        var id_delete = $(this).data('agencydata_id');
        var table_to_delete = $(this).data('agencydata_table');
        var item=$(this);
        $.post('handler.php', {table_to_delete:table_to_delete,id_delete: id_delete}, function (data) {
            
        }).complete(function () {
            $(item).parent('.worker_pane').slideUp();
        });
        return false;
    });
    $('.data_agency_idEdit').unbind('click').click(function () {
         var id_update = $(this).data('agencydata_id');
         var table_to_update = $(this).data('agencydata_table');
         alert(table_to_update);
       $.post('handler.php', {table_to_update:table_to_update,id_update: id_update}, function (data) {
//             alert(data);
        }).complete(function () {
//           window.location.replace();
        });
       
       
    });
    
    
  
    
    
    
    
}