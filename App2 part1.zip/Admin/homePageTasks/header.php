<?php

function admin_menu() {
    if ($_SESSION['agency'] == 'yes') {
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border menu dash_menu"> 
            <a id="dshM_menu_lnk_list" href="../new_wizard.php">Listings</a> <a class="dash_main_menu_link" id="dshM_menu_lnk_feat" href="#">Features </a>
            <a class="dash_main_menu_link" id="dshM_menu_lnk_Properties" href="#">Properties </a>
            <a id="dshM_menu_lnk_requests" href="../Admin/new_report_request.php">Requests</a>
            <a class="dash_main_menu_link off" id="dshM_menu_lnk_currencies" href="#">Currency conversion</a>
            <a id="dshM_menu_lnk_loc" href="../new_location.php">Locations /Area</a>
            <a  id="dshM_menu_lnk_loc" href="../new_report.php" title="Agents, comments and users">Report</a>
            <a  id="dshM_menu_lnk_loc" href="../homePageTasks/" title="Agemts, Comments, Requests">More</a>
            <a  id="dshM_menu_lnk_loc" href="../../logout.php" style="float: right;">  Logout</a>
        </div>
        <div class="parts eighty_centered heit_free no_paddin_shade_no_Border sub_menu off" id="users_sm">
            <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_account.php">Users</a></div>
            <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_account_category.php">Users categories</a></div>
        </div>
        <div class="parts eighty_centered heit_free no_paddin_shade_no_Border sub_menu" id="feat_sm">
            <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_features_cat.php">Feature category</a></div>
            <div class="parts no_paddin_shade_no_Border sm_link">  <a  href="new_features.php">Features</a></div>
        </div>
        <div class="parts eighty_centered heit_free no_paddin_shade_no_Border sub_menu" id="prpty_sm">
            <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_property_type.php">property Categories</a></div>
            <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_property_category.php"> Property sub categories</a></div>
        </div>

    <?php } else {
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border menu dash_menu"> 
            <a id="dshM_menu_lnk_list" href="../admin_dashboard.php">Dashboard</a>
            <a class="dash_main_menu_link" id="dshM_menu_lnk_feat" href="#">Listing </a>
            <a class="dash_main_menu_link" id="dshM_menu_lnk_Properties" href="#">My agents </a>
            <a  id="dshM_menu_lnk_loc" href="../new_report.php">Report</a> 
            <a  id="dshM_menu_lnk_loc" href="../../logout.php" style="float: right;">  Logout</a>
        </div>
        <?php
    }
}

function manager_menu() {
    ?>
    <div class="parts eighty_centered no_paddin_shade_no_Border menu dash_menu"> 
        <a id="dshM_menu_lnk_list" href="new_wizard.php">Listings</a> <a class="dash_main_menu_link" id="dshM_menu_lnk_feat" href="#">Features </a>
        <a class="dash_main_menu_link" id="dshM_menu_lnk_Properties" href="#">Properties </a>
        <a id="dshM_menu_lnk_requests" href="../Admin/new_report_request.php">Requests</a>
        <a class="dash_main_menu_link off" id="dshM_menu_lnk_currencies" href="#">Currency conversion</a>
        <a id="dshM_menu_lnk_loc" href="new_location.php">Locations /Area</a>
        <a  id="dshM_menu_lnk_loc" href="new_report.php">Report</a>
        <a  id="dshM_menu_lnk_loc" href="../logout.php" style="margin-left: 150px;">  Logout</a>
    </div>
    <div class="parts eighty_centered heit_free no_paddin_shade_no_Border sub_menu off" id="users_sm">
        <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_account.php">Users</a></div>
        <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_account_category.php">Users categories</a></div>
    </div>
    <div class="parts eighty_centered heit_free no_paddin_shade_no_Border sub_menu" id="feat_sm">
        <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_features_cat.php">Feature category</a></div>
        <div class="parts no_paddin_shade_no_Border sm_link">  <a  href="new_features.php">Features</a></div>
    </div>
    <div class="parts eighty_centered heit_free no_paddin_shade_no_Border sub_menu" id="prpty_sm">
        <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_property_type.php">property Categories</a></div>
        <div class="parts no_paddin_shade_no_Border sm_link"> <a  href="new_property_category.php"> Property sub categories</a></div>
    </div>    

    <?php
}

function workers() {
    
}
?>

<div class=" parts  full_center_two_h heit_free  margin_free skin no_shade_noBorder" id="adm_header">
    <?php
    if (!empty($_SESSION['cat']) && $_SESSION['cat'] == 'Admin') {
        admin_menu();
    } else if (!empty($_SESSION['cat'] && $_SESSION['cat'] == 'manager')) {
        manager_menu();
    } else {
        ?>
        <script type="text/javascript">alert('the category is:' + <?php echo $_SESSION['cat']; ?>);</script>
        <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border  link_cursor ">
            <a href="../index.php" value="" class="logout">Logout</a>
        </div><?php
    }
    ?>
</div>



