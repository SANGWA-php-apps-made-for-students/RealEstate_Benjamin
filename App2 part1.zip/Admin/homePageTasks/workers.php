<?php
$mul_obj = new multi_values();
$add_obj = new new_values();
?>
<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
    <div class="parts no_paddin_shade_no_Border link_cursor full_center_two_h heit_free"> 
        <?php if ($_SESSION['agency'] == 'yes') { ?>  
            <div class="parts submenu_btn wkrs_mnu underline_sub_menu" id="wrkrz1">
                Esercos
            </div>
            <div class="parts submenu_btn wkrs_mnu underline_sub_menu" id="wrkrz2">
                Workers from other agencies
            </div><?php } ?>
    </div>
    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
        <div class="parts  full_center_two_h heit_free wrkrz_sub_c no_paddin_shade_no_Border" id="wrkrz_sub_c1">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                <?php echo $_SESSION['agency_name'] . ' Workers'; ?> 
            </div>
            <?php $mul_obj->get_Users_by_category_agency('worker', $_SESSION['agency_name']); ?>  
        </div> 
        <div class="parts   full_center_two_h heit_free wrkrz_sub_c off"  id="wrkrz_sub_c2">
            <?php $mul_obj->get_other_usercategories('worker'); ?> 
        </div>
        <div class="parts add_more off">
            <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Add worker</div>
        </div>
        <div class="parts add_workers off">
            <div class="parts  no_paddin_shade_no_Border full_center_two_h heit_free bottom_part">Workers List</div> 
        </div>
    </div>
</div>
<script src="../../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
<script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        defaults();
        switch_panelvl_1();
    });

    function defaults() {
//        $('.mnger_sub_c').hide();
        $('#esaercos_sub_c1').show();
        $('#esercos_sub1').addClass('highlight_menu');
    }
    function switch_panelvl_1() {

    }
</script>
