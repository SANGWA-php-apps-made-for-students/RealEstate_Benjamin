<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of deletions
 *
 * SANGWA
 */
require_once 'connection.php';

class deletions {

    function deleteFrom_account($account_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM account where account_id =:account_id");
        $smt->bindValue(':account_id', $account_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

}
