<?php
require_once 'connection.php';
$con = new my_connection();

class multi_values {

    function All_agency() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  agency_id   from agency";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_message() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  message_id   from message";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_msg_type() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  msg_type_id   from msg_type";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function list_message($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from message";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> message </td>
                    <td> account </td><td> date </td>
                    <td> listing </td>
                    <td> type </td><td> message </td>
                    <td>Delete</td><td>Update</td>
                </tr>
            </thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['message_id']; ?>
                    </td>
                    <td class="account_id_cols message " title="message" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['listing']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>


                    <td>
                        <a href="#" class="message_delete_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="message_update_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Update</a>
                    </td>
                </tr>
                <?php
                $pages+=1;
            }
            ?></table>
        <?php
    }

    function list_msg_type($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from msg_type";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> msg_type </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['msg_type_id']; ?>
                    </td>
                    <td class="name_id_cols msg_type " title="msg_type" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="msg_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="msg_type_update_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function get_first_agency() {
            $con = new dbconnection();
            $sql = "select agency.agency_id from agency
                    order by agency.agency_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['agency_id'];
            return $first_rec;
        }

        function list_agency($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from agency "
                    . " join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id     where agency_name <> 'esercos'  group by agency.agency_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            while ($row = $stmt->fetch()) {
                ?>
            <div class="parts data_pane agent_pane no_paddin_shade_no_Border reverse_border" >
                <div class="parts full_center_two_h heit_free margin_free pane_title">   <?php echo $this->_e($row['agency_name']); ?>  </div>
                <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border">
                    <table class="dataList_table">    
                        <tr>

                        <tr>
                            <td>Agency id</td><td>
                                <?php echo $row['agency_id']; ?>
                            </td></tr>
                        <tr> <td>Website</td><td class="website_id_cols agency " title="agency" >
                                <?php echo $this->_e($row['website']); ?>
                            </td>  </tr>
                        <tr>  <td>Office address</td><td>
                                <?php echo $this->_e($row['office_address']); ?>
                            </td>  </tr>
                        <tr>  <td>Agency description</td><td>
                                <?php echo $this->_e($row['agency_desc']); ?>
                            </td>  </tr>
                        <tr>
                            <td>Logo</td><td><?php echo $this->_e($row['logo']); ?>  </td> 
                        </tr>
                        <tr>
                            <td> email</td><td><?php echo $this->_e($row['username']); ?>  </td> 
                        </tr>

                    </table>
                </div>
                <div class="parts full_center_two_h heit_free margin_free bottom_part">

                    bottom part</div>
            </div>
            <?php
        }
    }

    function list_agency_by_name($name) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from agency where agency_name=:name group by agency.agency_name";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            ?>
            <div class="parts data_pane agent_pane no_paddin_shade_no_Border reverse_border esercos_data_pane" >
                <div class="parts full_center_two_h heit_free margin_free pane_title">   <?php echo $this->_e($row['agency_name']); ?>  </div>
                <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border white_bg">
                    <div class="parts no_paddin_shade_no_Border">
                        <table class="dataList_table">    
                            <tr>
                                <td>Agency id</td><td>
                                    <?php echo $row['agency_id']; ?>
                                </td></tr>
                            <tr> <td>Website</td><td class="website_id_cols agency " title="agency" >
                                    <?php echo $this->_e($row['website']); ?>
                                </td>  </tr>
                            <tr>  <td>Office address</td><td>
                                    <?php echo $this->_e($row['office_address']); ?>
                                </td>  </tr>
                            <tr>  <td>Agency description</td><td>
                                    <?php echo $this->_e($row['agency_desc']); ?>
                                </td>  </tr>
                            <tr><td>Logo</td><td>
                                    <?php echo $this->_e($row['logo']); ?>
                                </td>  </tr>
                        </table>
                    </div> 
                    <div class="parts no_paddin_shade_no_Border">
                        <table>
                            <tr>
                                <td>
                                    name
                                </td><td>
                                    where is that name
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free margin_free bottom_part no_paddin_shade_no_Border">
                    <?php
                    if (!empty($_SESSION['agency_name'])) {
                        if ($_SESSION['agency_name'] == 'esercos') {
                            ?><div class="parts data_agency_id link_cursor" data-table='agency' data-listing_id='<?php echo $row['agency_id'] ?>'>Edit</div>
                            <div class="parts data_agency_id link_cursor " data-listing_id='<?php echo $row['agency_id'] ?>'>Deactivate   </div>
                            <?php
                        } else {
                            ?><div  class="parts data_agency_id margin_free link_cursor" data-table='agency' data-listing_id='<?php echo $row['agency_id'] ?>'>Edit</div>
                            <?php
                        }
                    } else {
                        ?>
                        Not defined
                        <?php
                    }
                    ?>
                </div>
            </div>
            <?php
        }
    }

    function get_last_profile_id() {
        $userid = 0;
        require_once 'connection.php';
        $con = new my_connection();
        $sql = "select    profile.profile_id from profile order by profile_id desc";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_chosen_profile_name($id) {

        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_profile_last_name($id) {

        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    }

    function get_chosen_profile_email($id) {

        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    }

    function get_chosen_profile_home_phone($id) {

        $db = new dbconnection();
        $sql = "select   profile.home_phone from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['home_phone'];
        echo $field;
    }

    function get_chosen_profile_office_phone($id) {

        $db = new dbconnection();
        $sql = "select   profile.office_phone from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['office_phone'];
        echo $field;
    }

    function get_chosen_profile_mobile_phone($id) {

        $db = new dbconnection();
        $sql = "select   profile.mobile_phone from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['mobile_phone'];
        echo $field;
    }

    function get_chosen_profile_address($id) {

        $db = new dbconnection();
        $sql = "select   profile.address from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['address'];
        echo $field;
    }

    function get_chosen_profile_city($id) {

        $db = new dbconnection();
        $sql = "select   profile.city from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['city'];
        echo $field;
    }

    function get_chosen_profile_country($id) {

        $db = new dbconnection();
        $sql = "select   profile.country from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['country'];
        echo $field;
    }

    function get_chosen_profile_image($id) {

        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

    function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function get_chosen_agency_website($id) {

        $db = new dbconnection();
        $sql = "select   agency.website from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['website'];
        echo $field;
    }

    function get_chosen_agency_office_address($id) {

        $db = new dbconnection();
        $sql = "select   agency.office_address from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['office_address'];
        echo $field;
    }

    function get_chosen_agency_agency_desc($id) {

        $db = new dbconnection();
        $sql = "select   agency.agency_desc from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['agency_desc'];
        echo $field;
    }

    function get_chosen_agency_logo($id) {

        $db = new dbconnection();
        $sql = "select   agency.logo from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['logo'];
        echo $field;
    }

    function get_chosen_agency_agency_name($id) {

        $db = new dbconnection();
        $sql = "select   agency.agency_name from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['agency_name'];
        echo $field;
    }

    function get_chosen_agency_account($id) {

        $db = new dbconnection();
        $sql = "select   agency.account from agency where agency_id=:agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':agency_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_image_in_combo() {
        require_once('connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_last_image_id() {
        $con = new my_connection();
        $sql = "select      image.image_id as id from image order by image_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['id'];
        return $userid;
    }

    function getagency_id_by_name($name) {
        $con = new my_connection();
        $sql = "select  agency.agency_id from agency where  agency.agency_name =:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $agencyname = $row['agency_id'];
        return $agencyname;
    }

    function get_Users_by_category_agency($cat, $agency) {//here we want to display the users that are for exaample workers, agents admins and others 
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select agency.agency_id, account.account_id,   profile.name,  profile.last_name,  profile.email,   profile.office_phone,  profile.mobile_phone,  profile.address,  profile.city,
                agent.agency,  agency.agency_name, profile.country ,profile.image
                from agency
                 join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id 
                join account_category on account.account_category = account_category.account_category_id 
                join profile on account.profile = profile.profile_id 
                where agency.agency_name=:agency  and  account_category.name=:category
                group by agency.agency_id, profile.profile_id ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":category" => $cat, ":agency" => $agency));
        ?>
        <?php while ($row = $stmt->fetch()) { ?>
            <div class="parts worker_pane no_paddin_shade_no_Border reverse_border accept_abs white_bg">
                <div class="parts full_center_two_h heit_free margin_free pane_title">
                    <?php echo $row['name'] . ' ' . $row['last_name']; ?>
                </div>
                <div class="parts   full_center_two_h heit_free no_paddin_shade_no_Border  ">
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border ">
                        <table class="dataList_table"  > 
                            <tr><td>Account id</td>  <td><?php echo $row['account_id']; ?> </td></tr>
                            <tr><td>Name</td>        <td><?php echo $row['name']; ?> </td></tr>
                            <tr><td>Last name</td>   <td><?php echo $row['last_name']; ?> </td></tr>
                            <tr><td>Email</td>       <td><?php echo $row['email']; ?> </td></tr>

                            <tr><td>Office phone</td><td><?php echo $row['office_phone']; ?> </td></tr>
                        </table>
                    </div>
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border ">
                        <table class="dataList_table"  >
                            <tr><td>Address</td>     <td><?php echo $row['address']; ?> </td></tr>
                            <tr><td>City</td>        <td><?php echo $row['city']; ?> </td></tr>
                            <tr><td>Country</td>     <td><?php echo $row['country']; ?> </td></tr>
                            <tr><td>Image</td>       <td><?php echo $row['image']; ?> </td></tr>
                            <tr><td>Agency name</td> <td><?php echo $row['agency_name']; ?> </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts bottom_part full_center_two_h heit_free margin_free no_paddin_shade_no_Border reverse_border ">
                    <div class="parts data_agency_idEdit link_cursor"
                         data-agencydata_id='<?php echo $row['account_id']; ?>'
                         data-agencydata_table='account'
                         >Edit</div>
                    <div class="parts data_agency_id link_cursor data_agency_id"
                         data-agencydata_id='<?php echo $row['account_id']; ?>'
                         data-agencydata_table='account'
                         >Delete</div>
                </div>
            </div>
            <?php
        }
    }

    function get_other_usercategories($cat) { // here we want to get other users who may be agents managers aor worker but nor esercos
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   profile.name,  profile.last_name,  profile.email,  profile.home_phone,  profile.office_phone,  profile.mobile_phone,  profile.address,  profile.city,
                agent.agency,  agency.agency_name, profile.country ,profile.image
                from agency
                join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id 
                join account_category on account.account_category = account_category.account_category_id 
                join profile on account.profile = profile.profile_id 
                where agency.agency_name<>'esercos'  and  account_category.name=:category
                group by agency.agency_id, profile.profile_id ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":category" => $cat));
        ?>
        <?php while ($row = $stmt->fetch()) { ?>
            <div class="parts worker_pane no_paddin_shade_no_Border reverse_border accept_abs">
                <div class="parts full_center_two_h heit_free margin_free pane_title">
                    <?php echo $row['name'] . ' ' . $row['last_name']; ?>
                </div>
                <div class="parts   full_center_two_h heit_free no_paddin_shade_no_Border ">
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  > 
                            <tr><td>Account id</td>  <td><?php echo $row['account_id']; ?> </td></tr>
                            <tr><td>Name</td>        <td><?php echo $row['name']; ?> </td></tr>
                            <tr><td>Last name</td>   <td><?php echo $row['last_name']; ?> </td></tr>
                            <tr><td>Email</td>       <td><?php echo $row['email']; ?> </td></tr>
                            <tr><td>Home phone</td>  <td><?php echo $row['home_phone']; ?> </td></tr>
                            <tr><td>Office phone</td><td><?php echo $row['office_phone']; ?> </td></tr>
                        </table>
                    </div>
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  >
                            <tr><td>Mobile phone</td><td><?php echo $row['mobile_phone']; ?> </td></tr>
                            <tr><td>Address</td>     <td><?php echo $row['address']; ?> </td></tr>
                            <tr><td>City</td>        <td><?php echo $row['city']; ?> </td></tr>
                            <tr><td>Country</td>     <td><?php echo $row['country']; ?> </td></tr>
                            <tr><td>Image</td>       <td><?php echo $row['image']; ?> </td></tr>
                            <tr><td>Agency name</td> <td><?php echo $row['agency_name']; ?> </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts bottom_part full_center_two_h heit_free margin_free ">
                    Bottom paart
                </div>

            </div>
            <?php
        }
    }

    function list_agent($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from agent";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> agent </td>
                    <td> agency_desc </td><td> logo </td><td> agency_name </td><td> website </td><td> profile </td><td> account </td><td> agency </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['agent_id']; ?>
                    </td>
                    <td class="agency_desc_id_cols agent " title="agent" >
                        <?php echo $this->_e($row['agency_desc']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['logo']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['website']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['agency']); ?>
                    </td>


                    <td>
                        <a href="#" class="agent_delete_link" style="color: #000080;" value="
                           <?php echo $row['agent_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="agent_update_link" style="color: #000080;" value="
                           <?php echo $row['agent_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function get_last_acc_id() {
            $con = new my_connection();
            $sql = "select    account.account_id  from account order by account_id desc limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_id'];
            return $userid;
        }

        function get_catId_byName($name) {
            $con = new my_connection();
            $sql = "select    account_category_id  from account_category   where   account_category.name =:name  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":name" => $name));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_category_id'];
            return $userid;
        }

        function get_user_by_catname($cat) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account.account_id,   profile.name,  profile.last_name,  profile.email,    profile.office_phone,  profile.mobile_phone,  profile.address,  profile.city,
                     profile.country ,profile.image
                    from profile
                    join account on account.profile = profile.profile_id 
                    join account_category on account.account_category = account_category.account_category_id 
                    where  account_category.name=:category
                    group by   profile.profile_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":category" => $cat));
            ?>
            <?php while ($row = $stmt->fetch()) { ?>
            <div class="parts worker_pane no_paddin_shade_no_Border reverse_border accept_abs white_bg">
                <div class="parts full_center_two_h heit_free margin_free pane_title">
                    <?php echo $row['name'] . ' ' . $row['last_name']; ?>
                </div>
                <div class="parts   full_center_two_h heit_free no_paddin_shade_no_Border ">
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  > 
                            <tr><td>Account id</td>  <td><?php echo $row['account_id']; ?> </td></tr>
                            <tr><td>Name</td>        <td><?php echo $row['name']; ?> </td></tr>
                            <tr><td>Last name</td>   <td><?php echo $row['last_name']; ?> </td></tr>
                            <tr><td>Email</td>       <td><?php echo $row['email']; ?> </td></tr>
                            <tr><td>Mobile phone</td><td><?php echo $row['mobile_phone']; ?> </td></tr>

                        </table>
                    </div>
                    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border margin_free">
                        <table class="dataList_table"  >
                            <tr><td>Office phone</td><td><?php echo $row['office_phone']; ?> </td></tr>
                            <tr><td>Address</td>     <td><?php echo $row['address']; ?> </td></tr>
                            <tr><td>City</td>        <td><?php echo $row['city']; ?> </td></tr>
                            <tr><td>Country</td>     <td><?php echo $row['country']; ?> </td></tr>
                            <tr><td>Image</td>       <td><?php echo $row['image']; ?> </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts bottom_part full_center_two_h heit_free margin_free ">
                    Bottom paart
                </div>
            </div>
            <?php
        }
    }

    function get_last_agency() {
        $con = new my_connection();
        $sql = "select agency.agency_id from agency     order by agency.agency_id desc
                    limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['agency_id'];
        return $first_rec;
    }

    function get_last_account() {
        $con = new my_connection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }

    function get_logo_byName($agency) {
        $con = new my_connection();
        $sql = "select    agency.logo  from agency   where   agency.agency_name =:name  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $agency));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        echo '<img src="../../web_images/agency_logos/' . $row['logo'] . '" width="100" height="100" />    ';
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
