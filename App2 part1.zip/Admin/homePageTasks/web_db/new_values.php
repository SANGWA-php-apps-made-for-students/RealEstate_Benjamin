<?php

require_once 'connection.php';

class new_values {

    function new_account($username, $password, $account_category, $online, $deleted, $date_created, $profile) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category,  :online,  :deleted,  :date_created,  :profile)");
        $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category, ':online' => $online, ':deleted' => $deleted, ':date_created' => $date_created, ':profile' => $profile));
    }

    function new_account_category($name) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
        $stm->execute(array(':account_category_id' => 0, ':name' => $name));
    }

    function new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $image) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into profile values(:profile_id, :name,  :last_name,  :email,    :office_phone,  :mobile_phone,  :address,  :city,  :country,  :image)");
        $stm->execute(array(':profile_id' => 0, ':name' => $name, ':last_name' => $last_name, ':email' => $email, ':office_phone' => $office_phone, ':mobile_phone' => $mobile_phone, ':address' => $address, ':city' => $city, ':country' => $country, ':image' => $image
        ));
    }

    function new_property($name) {
        //
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into property values(:property_id, :name)");
        $stm->execute(array(':property_id' => 0, ':name' => $name));
    }

    function new_property_category($name, $property_type) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_category values(:property_category_id, :name,  :property_type)");
        $stm->execute(array(':property_category_id' => 0, ':name' => $name, ':property_type' => $property_type
        ));
    }

    function new_property_subcategory($property_subcategory) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_subcategory values(:property_subcategory_id, :property_subcategory)");
        $stm->execute(array(':property_subcategory_id' => 0, ':property_subcategory' => $property_subcategory
        ));
    }

    function new_features($name, $property_type) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into features values(:features_id, :name,  :property_type)");
        $stm->execute(array(':features_id' => 0, ':name' => $name, ':property_type' => $property_type
        ));
    }

    function new_listing($listing_date, $account, $listing_type, $property, $title, $description, $purpose, $property_category, $location, $active) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into listing values(:listing_id, :listing_date,  :account,  :listing_type,  :property,  :title,:description,  :purpose,  :property_category,  :location,  :active)");
            $stm->execute(array(':listing_id' => 0, ':listing_date' => $listing_date, ':account' => $account, ':listing_type' => $listing_type, ':property' => $property, ':title' => $title, ':description' => $description, ':purpose' => $purpose, ':property_category' => $property_category, ':location' => $location, ':active' => $active));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_listing_type($name) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into listing_type values(:listing_type_id, :name)");
        $stm->execute(array(':listing_type_id' => 0, ':name' => $name
        ));
    }

    function new_image($path, $listing, $deleted, $appear) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into image values(:image_id, :path,  :listing,  :deleted,  :appear)");
        $stm->execute(array(':image_id' => 0, ':path' => $path, ':listing' => $listing, ':deleted' => $deleted, ':appear' => $appear
        ));
    }

    function new_location($appear, $property, $cell, $lat, $long, $area, $address) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into location values(:location_id, :appear,  :property,  :cell,  :lat,  :long,  :area,  :address)");
            $stm->execute(array(':location_id' => 0, ':appear' => $appear, ':property' => $property, ':cell' => $cell, ':lat' => $lat, ':long' => $long, ':area' => $area, ':address' => $address
            ));
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    function new_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $price_square_meter_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $curr_month, $curr_day) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into price values(:price_id, :amount,  :currency,  :cond,  :property,  :Minimum_advance,  :deposit_required,  :commission,  :utilities_extra,  :listing,  :amount_per_day,  :price_square_meter_per_day,  :minimum_advance_per_day,  :deposit_required_per_day,  :commission_per_day,  :utilities_extra_per_day, :currency_month,:currency_day)");
            $stm->execute(array(':price_id' => 0, ':amount' => $amount, ':currency' => $currency, ':cond' => $condition, ':property' => $property, ':Minimum_advance' => $Minimum_advance, ':deposit_required' => $deposit_required, ':commission' => $commission, ':utilities_extra' => $utilities_extra, ':listing' => $listing, ':amount_per_day' => $amount_per_day, ':price_square_meter_per_day' => $price_square_meter_per_day, ':minimum_advance_per_day' => $minimum_advance_per_day, ':deposit_required_per_day' => $deposit_required_per_day, ':commission_per_day' => $commission_per_day, ':utilities_extra_per_day' => $utilities_extra_per_day, ':currency_month' => $curr_month, ':currency_day' => $curr_day));
        } catch (PDOException $e) {
            echo $e->getMessage();
        } catch (Exception $ne) {
            echo $ne;
        }
    }

    function new_property_visitor($property) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_visitor values(:property_visitor_id, :property)");
        $stm->execute(array(':property_visitor_id' => 0, ':property' => $property
        ));
    }

    function new_basic_info($name, $property_type) {

        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into basic_info values(:basic_info_id, :name,  :property_type)");
        $stm->execute(array(':basic_info_id' => 0, ':name' => $name, ':property_type' => $property_type));
    }

    function new_comment($commentdeleted, $message, $account, $date, $listing) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into comment values(:comment_id, :commentdeleted,  :message,  :account,  :date,  :listing)");
            $stm->execute(array(':comment_id' => 0, ':commentdeleted' => $commentdeleted, ':message' => $message, ':account' => $account, ':date' => $date, ':listing' => $listing
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_comment_replies($comment_repliesdeleted, $message, $date, $account, $comment) {
        try {

            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into comment_replies values(:comment_replies_id, :comment_repliesdeleted,  :message,  :date,  :account,  :comment)");
            $stm->execute(array(':comment_replies_id' => 0, ':comment_repliesdeleted' => $comment_repliesdeleted, ':message' => $message, ':date' => $date, ':account' => $account, ':comment' => $comment));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_agency($website, $office_address, $agency_desc, $logo, $agency_name) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into agency values(:agency_id, :website,  :office_address,  :agency_desc,  :logo,  :agency_name)");
            $stm->execute(array(':agency_id' => 0, ':website' => $website, ':office_address' => $office_address, ':agency_desc' => $agency_desc, ':logo' => $logo, ':agency_name' => $agency_name));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_message($account, $date, $listing, $type, $message) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into message values(:message_id, :account,  :date,  :listing,  :type,  :message)");
            $stm->execute(array(':message_id' => 0, ':account' => $account, ':date' => $date, ':listing' => $listing, ':type' => $type, ':message' => $message
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_msg_type($name) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into msg_type values(:msg_type_id, :name)");
            $stm->execute(array(':msg_type_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_agent($account, $agency) {
        try {
            require_once('connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into agent values(:agent_id, :account,  :agency)");
            $stm->execute(array(':agent_id' => 0, ':account' => $account, ':agency' => $agency
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
