<?php

session_start();
echo $_SESSION['id_upd'];
if (isset($_SESSION['id_upd'])) {
    header('Location: index.php');
} 