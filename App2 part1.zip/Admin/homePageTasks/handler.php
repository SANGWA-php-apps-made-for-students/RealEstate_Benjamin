<?php

session_start();
if (isset($_POST['id_update'])) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo 'caught:   ' . $_SESSION['id_upd'];
}


if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once 'web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);
}