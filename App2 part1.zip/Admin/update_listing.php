<?php
session_start();
current_step();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
$obj = new multi_values();
$list_type_res = $obj->get_last_listing_type();
$last_prop_cat = $obj->get_last_listing_prop_category();
?>
<html>
    <head>
        <style>
            #update_link a{
                color: #fff;
                text-decoration: none;
                text-align: center;
                font-family: arial;
            }
            .listing_type_data_res{
                text-align: center;
                font-size: 15px;
            }
            #the_last_prop_category_b{
                font-size: 16px;
            }
            .combo_property_type_toUpdate{
                width: 100px;
                display: none;
            }
            #my_cat_res{
                display: none;
            }
        </style>
        <title>
            Listing
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="update_listing.php" method="post" enctype="multipart/form-data">
            <input type="text" class="textbox off" placeholder="property type"      name="txt_property_type_id" value="<?php echo $list_type_res; ?>"  id="txt_property_type_id">
            <input type="text" class="textbox  left_off_eighty" placeholder="last listing id"      name="txt_last_listing_id"  id="txt_last_listing_id">
            <input type="text" class="textbox off" placeholder="proprty cat"        name="txt_property_cat_id"  value="<?php echo $last_prop_cat; ?>"  id="txt_property_cat_id">
            <input type="text" class="textbox off  " style="margin-left: 300px;" placeholder="property name"      name="txt_prop_name"                 id="prop_name" />
            <input type="text" class="textbox off" placeholder="Current step"       name="txt_current_step"                                            id="current_step" value="<?php echo $_SESSION['current_step']; ?>"/>
            <input type="text" class="textbox off" placeholder="lisitng type" name="txt_listing_type"                                                  id="listing_type" />
            <div class="off" id="d">
            </div>
            <?php
            include 'Admin_header.php';
//            include './steps.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border ">
                <div class="parts full_center_two_h heit_free no_shade_noBorder ">
                    <select id="test_auto_select " class="off">
                        <option></option>
                        <option>Maven</option>
                        <option>SOA</option>
                    </select>
                </div>

                <div class="parts left_off_eighty off">
                    <div id="the_last_title_b">

                    </div>
                    <div id="the_last_type_b">

                    </div>

                    <div id="the_last_listing_location_b">

                    </div>

                </div>  <br/>

                <div class="parts link_cursor">
                    Last listing
                </div>
                <div class="parts link_cursor">
                    Search listing
                </div>
            </div> <div class="parts two_fifty_right " style="margin-right: 20px;">
                <?php include_once './update_listing_sp.php'; ?>
            </div>
            <div class="parts fifty_centered  new_data_box ">


                <div class="parts   xx_titles no_paddin_shade_no_Border ">Listing update
                    <?php
                    if (isset($_POST['send_listing'])) {
                        try {
                            require_once '../web_db/new_values.php';
                            require_once './dbConnection.php';
                            $con = new my_connection();
                            //Entities engaged
                            //=>Listing table
                            //=>Account id from account
                            //=>property by its property category id
                            //=>location by cell id
                            //posted vars and global vars

                            $account = $_SESSION['userid'];
                            $listing_date = date("y-m-d");
                            $listing_type = $_POST['txt_listing_type'];

                            //listing
                            // $property = $listing_typeid;
                            //property fields
                            $title = $_POST['txt_title'];
                            $description = $_POST['txt_desc'];
                            $basic_info = '';
                            $property_type_id = $_POST['txt_property_type_id'];
                            $property_category = $_POST['txt_property_cat_id'];
                            //property  category
                            $purpose = $listing_type;
                            $obj = new new_values();
                            $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), trim(get_property_id()), trim($title), trim($description), trim($purpose), trim($property_category), 0);
                            //Last listng
                            $mul_obj = new multi_values();
                            $last_listingid = $mul_obj->get_lastlisting();
                            $_SESSION['last_listng'] = $last_listingid;
                            $_SESSION['listing_done'] = 'done';
                            //save the features with the last listing

                            $prop_type = trim($_POST['txt_prop_name']);

                            if ($prop_type == 'Apartment') {
                                $features = $_POST['features'];
                                foreach ($features as $feat) {
                                    $obj->new_listing_features($last_listingid, $feat);
                                }
                                basic_aparts();
                            } else if ($prop_type == 'House') {
                                $features = $_POST['features'];
                                foreach ($features as $feat) {
                                    $obj->new_listing_features(trim($last_listingid), trim($feat));
                                }
                                basic_house();
                            } else if ($prop_type == 'Land') {
                                $features = $_POST['features'];
                                foreach ($features as $feat) {
                                    $obj->new_listing_features($last_listingid, $feat);
                                }
                                basic_land();
                            }
//                            header('location: new_price.php');
                        } catch (PDOException $e) {
                            echo 'Error while saving data! ' . $e->getMessage();
                        }
                        //save features
                    }
                    ?>
                </div>
                <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                    This the last listing The loaded data can be updated
                </div>
                <table   class="new_data_table " border="1">
                    <tr>
                        <td>Listing purpose:</td>
                        <td><span id="listing_type_chosen"></span>
                            <div class="parts two_fifty_left heit_free no_shade_noBorder  reverse_border listing_type_data_res" id="rent_part">Rent</div>
                            <div class="parts two_fifty_left heit_free no_shade_noBorder  reverse_border listing_type_data_res" id="sale_part">Sale</div>    </td>
                    </tr>
                    <tr><td>Property Type :</td><td> <div class="parts no_paddin_shade_no_Border" style="color: #000066; font-size: 16px; text-decoration: none;" id="the_last_prop_type_b"> </div> <div class="parts no_paddin_shade_no_Border"><a href="#" id="changeable_link_property">Change</a></div>     <?php get_property_type_combo(); ?></td></tr>
                    <tr><td><span id="property_subCat_label" class="">property category:</span></td>
                        <td> <div class="parts no_paddin_shade_no_Border" id="the_last_prop_category_b"> </div><div class="parts full_center_two_h x_height_one_h" id="my_cat_res">
                            </div>
                        </td>
                    </tr>
                    <tr><td>Property Title :</td><td><input type="text" name="txt_title" placeholder="Property title" id="prop_text_id" class="textbox" />   </td></tr>
                    <tr><td>Description :</td><td><textarea id="desc_txt" style="height: 100px;" name="txt_desc" placeholder="Property description" class="textbox" ></textarea>   </td></tr>
                    <?php
                    include './basic_info/new_basic_apartment.php';
                    include './basic_info/new_basic_house.php';
                    include './basic_info/new_basic_land.php';
                    ?>
                </table>
                <div class="parts full_center_two_h no_paddin_shade_no_Border x_titles heit_free">Features</div>
                <div class="parts full_center_two_h heit_free no_shade_noBorder" id="features_box">
                </div>
            </div>
            <div class="parts eighty_centered">
                <a href="update_listing.php">  <div class="parts   confirm_buttons two_fifty_left heit_free" style="float: left; " id="update_link">
                        <center>  UPDATE</center>
                    </div></a>
                <input type="submit" class="confirm_buttons" name="send_listing" id="btn_send_listing" value="SAVE AND CONTINUE">
            </div>
            <div class="parts eighty_centered">
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_listing_to_update();
                ?>
            </div>
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('.aparts_rows').slideUp();
                $('.house_rows').slideUp();
                $('.land_rows').slideUp();
                $('.date_pick').datepicker({
                    dateFormat: 'yy-mm-dd',
                    minDate: new Date()
                });
                try {
                    Get_last_listing_fields();
                    changeable_link_property();
                } catch (err) {
                    alert(err.message);
                }
            });
            function Get_last_listing_fields() {
                var working_listing_id = 0;

                //the property type
                var listing_type = 0;
                try {
                    var last_listing = 'c';
                    $.post('../Admin/handler.php', {last_listing: last_listing}, function (data) {
                        $('#d').html(data);
                        working_listing_id = $('#d').text().trim();
//                        alert(working_listing_id);
                        $('#txt_last_listing_id').val(working_listing_id);
                        $('#txt_upd_last_listing_id').val(working_listing_id);
                    }).complete(function () {
                        var the_last_type = 'c';
                        $.post('handler.php', {the_last_type: the_last_type}, function (data) {
                            var d = '';
                            $('#the_last_type_b').html('list type: ' + data);
                            $('#listing_type').val(data);
                            $('#d').html(data);
                            $('#txt_upd_listing_type').val($('#d').text().trim());
                        }).complete(function () {
                            //get the listng type
                            listing_type = $('#d').text().trim();
                            if (listing_type == 2) {
                                $('.listing_type_data_res').css('background-color', 'transparent').css('color', '#000080');
                                $('#sale_part').css('background-color', '#000080').css('color', '#fff');
                            } else {
                                $('.listing_type_data_res').css('background-color', 'transparent').css('color', '#000080');
                                $('#rent_part').css('background-color', '#000080').css('color', '#fff');
                            }
                            //get the category
                            var the_last_prop_type = 'c';
                            $.post('handler.php', {the_last_prop_type: the_last_prop_type}, function (data) {
                                $('#the_last_prop_type_b').html(data);
                                $('#txt_property_type_id').val(data);
                                $('#d').html(data);
                                $('#txt_upd_property_type_id').val($('#d').text().trim());
                                var value = $('#d').text().trim();
                                var prop_type = value;
                                if (prop_type == 'Apartment') {
                                    $('.aparts_rows').slideDown(200);
                                    $('.house_rows').slideUp(200);
                                    $('.land_rows').slideUp(200);
                                    //Get the data from apartment
                                    var the_last_apart = 'c';
                                    $.post('handler.php', {working_listing_id: working_listing_id, the_last_apart: the_last_apart}, function (data) {
                                        $('#d').html(data);
                                        var c = $('#d').text().trim();
                                        if (c == 'exists') {
                                            $('#d').html(data);
                                            Last_house_details(data);
                                        } else {

                                        }
                                    });
                                } else if (prop_type == 'House') {
                                    $('.aparts_rows').slideUp(200);
                                    $('.house_rows').slideDown(200);
                                    $('.land_rows').slideUp(200);
                                    //Get the data from house
                                    var the_last_house = 'c';
                                    $.post('handler.php', {working_listing_id: working_listing_id, the_last_house: the_last_house}, function (data) {
                                        $('#d').html(data);
                                        var c = $('#d').text().trim();
                                        if (c == 'exists') {
                                            $('#d').html(data);
                                        } else {

                                        }
                                    });
                                } else if (prop_type == 'Land') {
                                    $('.aparts_rows').slideUp(200);
                                    $('.house_rows').slideUp(200);
                                    $('.land_rows').slideDown(200);
                                    //get the data from land
                                    var the_last_land = 'c';
                                    $.post('handler.php', {working_listing_id: working_listing_id, the_last_land: the_last_land}, function (data) {
                                        Last_land_details(data);
                                    }).complete(function () {
//                                        alert('finished');
                                    });
                                } else {
                                    $('.aparts_rows').slideUp(200);
                                    $('.house_rows').slideUp(200);
                                    $('.land_rows').slideUp(200);
                                    //get the data from dev
                                    var the_last_dev = 'c';
//                                    $.post('handler.php', {the_last_dev: the_last_dev}, function (data) {
//
//                                    });
                                }
                            }).complete(function () {
                                //get the category
                                var the_last_prop_category = 'c';
                                $.post('handler.php', {the_last_prop_category: the_last_prop_category}, function (data) {
                                    $('#the_last_prop_category_b').html(data);
                                    $('#txt_property_cat_id').val(data);
                                    $('#txt_upd_property_cat_id').val($('#the_last_prop_category_b').text().trim());
                                }).complete(function () {
                                    var the_last_listing_location = 'c';
                                    $.post('handler.php', {the_last_listing_location: the_last_listing_location}, function (data) {
                                        $('#the_last_listing_location_b').html('listing location: ' + data);
                                    }).complete(function () {
                                        var the_last_listing_title = 'c';
                                        $.post('handler.php', {the_last_listing_title: the_last_listing_title}, function (data) {
                                            $('#the_last_title_b').html('listing title: ' + data);
                                            $('#d').html(data);
                                            $('#prop_text_id').val($('#d').text().trim());
                                            $('#txt_prop_upd_text_id').val($('#d').text().trim());
                                        }).complete(function () {
                                            var the_last_listing_desc = 'c';
                                            $.post('handler.php', {the_last_listing_desc: the_last_listing_desc}, function (data) {
                                                $('#the_last_title_b').html(data);
                                                $('#d').html(data);
                                                $('#desc_txt').val($('#d').text().trim());
                                                $('#txt_desc_upd_txt').val($('#d').text().trim());
                                            });

                                        });
                                    });
                                });
                            });
                        });
                    });
                } catch (err) {
                    alert(err.message);
                }
            }
            function Last_land_details(res) {
                $('#d').html(res);
                var c = $('#d').text().trim();
                var last_plotNum_land = 'c', last_plotsize_land = 'c', last_lotUse_land = 'c',
                        last_available_land = 'c';
                if (c == 'exists') {
                    var last_adminLoc_land = 'c';
                    $.post('handler.php', {last_adminLoc_land: last_adminLoc_land}, function (data) {
                        $('#d').html(data);
                        var c = $('#d').text().trim();
                        $('#txt_administrative_loc').val(c);
                    }).complete(function () {
                        $.post('handler.php', {last_plotNum_land: last_plotNum_land}, function (data) {
                            $('#d').html(data);
                            var c = $('#d').text().trim();
                            $('#txt_plot_number').val(c);
                        }).complete(function () {
                            $.post('handler.php', {last_plotsize_land: last_plotsize_land}, function (data) {
                                $('#d').html(data);
                                var c = $('#d').text().trim();
                                $('#txt_plot_size').val(c);
                            }).complete(function () {
                                $.post('handler.php', {last_lotUse_land: last_lotUse_land}, function (data) {
                                    $('#d').html(data);
                                    var c = $('#d').text().trim();
                                    $('#txt_lot_use').val(c);
                                }).complete(function () {
                                    $.post('handler.php', {last_available_land: last_available_land}, function (data) {
                                        $('#d').html(data);
                                        var c = $('#d').text().trim();
                                        $('#txt_plot_available_from').val(c);
                                    });
                                });
                            });
                        });
                    });
                } else {
                }
            }

            function Last_house_details(res) {
                $('#d').html(res);
                var c = $('#d').text().trim();
                var last_furnished_house = 'c',
                        last_available_land = 'c';
                if (c == 'exists') {
                    var last_adminLoc_land = 'c';
                    $.post('handler.php', {last_furnished_house: last_furnished_house}, function (data) {
                        $('#d').html(data);
                        var c = $('#d').text().trim();
                        $('#house_def_furnished').val(c);
                    }).complete(function () {
                        $.post('handler.php', {last_available_house: last_available_house}, function (data) {
                            $('#d').html(data);
                            var c = $('#d').text().trim();
                            $('#txt_house_available_from').val(c);
                        });
                    });
                }
            }
            function Last_apart_details(res) {
                $('#d').html(res);
                var c = $('#d').text().trim();
                var last_furnished_house = 'c',
                        last_available_land = 'c';
                if (c == 'exists') {
                    var last_bedroom_apart = 'c',
                            last_bathroom_apart = 'c',
                            last_floorno_apart = 'c',
                            last_totalfloor_apart = 'c',
                            last_furnished_apart = 'c';
                    $.post('handler.php', {last_bedroom_apart: last_bedroom_apart}, function (data) {
                        $('#d').html(data);
                        var c = $('#d').text().trim();
                        $('#txt_apart_bedrooms').val(c);
                    }).complete(function () {
                        $.post('handler.php', {last_bathroom_apart: last_bathroom_apart}, function (data) {
                            $('#d').html(data);
                            var c = $('#d').text().trim();
                            $('#txt_apart_bathrooms').val(c);
                        }).complete(function () {
                            $.post('handler.php', {last_floorno_apart: last_floorno_apart}, function (data) {
                                $('#d').html(data);
                                var c = $('#d').text().trim();
                                $('#txt_apart_floorNo').val(c);
                            }).complete(function () {
                                $.post('handler.php', {last_totalfloor_apart: last_totalfloor_apart}, function (data) {
                                    $('#d').html(data);
                                    var c = $('#d').text().trim();
                                    $('#txt_apart_totFlor').val(c);
                                }).complete(function () {
                                    $.post('handler.php', {last_furnished_apart: last_furnished_apart}, function (data) {
                                        $('#d').html(data);
                                        var c = $('#d').text().trim();
                                        $('#txt_house_available_from').val(c);
                                    });
                                });

                            });

                        });
                    });
                }
            }
            function changeable_link_property() {
                $('#changeable_link_property').click(function () {
                    $('.combo_property_type_toUpdate').slideDown(200);
                    return false;
                });
            }
        </script>
        <script type = "text/javascript" >
            function initMap() {
                var myLatLng = {lat: -1.9706, lng: 30.1044};
                var map = new google.maps.Map(document.getElementById('map'), {
                    zoom: 15,
                    center: myLatLng
                });
                var marker = new google.maps.Marker({
                    position: myLatLng,
                    map: map,
                    title: 'Glory to God Main Church'
                });
            }
        </script>
        <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
        </script>
    </body>
</hmtl>
<?php

function get_property_type_combo() {
    $bean = new multi_values();
    $bean->get_prop_type_combo_to_update();
}

function get_provinces_boxes() {
    $bean = new multi_values();
    $bean->get_provinces_boxes();
}

function get_district_boxes() {
    $bean = new multi_values();
    $bean->get_districts_boxes();
}

function get_sector_boxes() {
    $bean = new multi_values();
    $bean->get_sectors_boxes();
}

function get_cells_boxes() {
    $bean = new multi_values();
    $bean->get_cells_boxes();
}

function get_provinces_combo() {
    $bean = new multi_values();
    $bean->get_provinces_combo2();
}

function get_sectors_combo() {
    $bean = new multi_values();
    $bean->get_sectors_combo();
}

function map() {
    include './my_map.php';
}

function get_property_id() {
    $con = new my_connection();
    $prop_name = $_POST['txt_prop_name'];
    $property_id = '';
    $sql = "select    property.property_id from property_type join property on property_type.property=property.property_id where property_type.property_type_id in(select property_type.property from property_type where name=:name);";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":name" => $prop_name));
    while ($row = $stmt->fetch()) {
        $property_id = $row['property_id'];
    }
    return $property_id;
}

function get_last_location() {
    $con = new my_connection();
    $sql3 = "select  location.location_id from location order by location.location_id desc limit 1";
    $stmt = $con->getCon()->prepare($sql3);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $last_locationid = $row['location_id'];
    return $last_locationid;
}

class More_onListing {

    function get_propertyCat_by_proerty_types($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select     property_category.name from property_category join property_type on property_type.property_type_id=property_category.type where property_type.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts  full_center_two_h margin_free heit_free no_paddin_shade_no_Border res_item">' . $row['name'] . '</div>';
        }
    }

}

function basic_aparts() {
    $basic_apartmentdeleted = 'no';
    $mul_obj = new multi_values();
    $listing = $mul_obj->get_lastlisting();
    $bedrooms = $_POST['txt_bedrooms'];
    $bathrooms = $_POST['txt_bathrooms'];
    $floor_number = $_POST['txt_floor_number'];
    $total_number_floors = $_POST['txt_total_number_floors'];
    $furnished = $_POST['txt_furnished'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished);
}

function basic_house() {
    $basic_housedeleted = 'no';
    $mul_obj = new multi_values();
    $listing = trim($mul_obj->get_lastlisting());
    $furnished = trim($_POST['txt_house_furnished']);
    $available_from = trim($_POST['txt_houae_available_from']);
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_basic_house($basic_housedeleted, $listing, $furnished, $available_from);
}

function basic_land() {
    $basic_landdeleted = 'no';
    $mul_obj = new multi_values();
    $listing = $mul_obj->get_lastlisting();
    $administrative_location = trim($_POST['txt_administrative_location']);
    $plot_number = trim($_POST['txt_plot_number']);
    $plot_size = trim($_POST['txt_plot_size'] . ' ' . $_POST['plot_measure']);
    $lot_use = trim($_POST['txt_lot_use']);
    $available_from = trim($_POST['txt_land_available_from']);
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_basic_land(trim($basic_landdeleted), trim($listing), trim($administrative_location), trim($plot_number), trim($plot_size), trim($lot_use), trim($available_from));
}

function current_step() {
    $_SESSION['current_step'] = 1;
}

//get last title
if (isset($_SESSION['listing_done'])) {
    $las_obj = new multi_values();
    $last_prop_category = $las_obj->get_last_listing_property_category();
}

function get_last_title() {
    $las_obj = new multi_values();
    return $last_title = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_title() : '';
}

function get_last_list_type() {
    $las_obj = new multi_values();
    return $last_list_type = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_listing_type() : '';
}

function get_last_purpose() {
    $las_obj = new multi_values();
    return $last_list_purpose = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_purpose() : '';
}

function get_last_prop_cat() {
    $las_obj = new multi_values();
    return $last_list_cat = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_property_category() : '';
}
