<?php

require('fpdf/fpdf.php');

class PDF extends FPDF {

    function Header() {
        $this->SetFont('Times', '', 12);
        $this->SetY(0.25);
        $this->Cell(0, .25, "Listings " . $this->PageNo(), 'T', 2, "R");
        //reset Y
        $this->SetY(1);
    }

    function Footer() {
        //This is the footer; it's repeated on each page.
        //enter filename: phpjabber logo, x position: (page width/2)-half the picture size,
        //y position: rough estimate, width, height, filetype, link: click it!
    }

}

//class instantiation
$pdf = new PDF("P", "in", "Letter");
$pdf->SetMargins(.5, 1, 1);
$pdf->AddPage();
$pdf->SetFont('Times', '', 12);


$lipsum1 = "This is the Report of graduates and jobs";
$lipsum2 = "This may be a body";
$lipsum3 = "another p of the body or the footer";

$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Times', 'B', 11);

//Cell(float w[,float h[,string txt[,mixed border[,
//int ln[,string align[,boolean fill[,mixed link]]]]]]])

require_once('../../Admin/dbConnection.php');
$con = new my_connection();
$sql = "select  distinct  price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                    from listing
                     join price on price.listing = listing.listing_id
                      left  join image on image.listing = listing.listing_id
                      left join location on listing.location = location.location_id
                       join cell on location.cell = cell.cell_id
                        join sector on cell.sector = sector.sector_id
                        join district on sector.district = district.district_id
                        join province on district.province = province.province_id
                        left join basic_apartment on basic_apartment.listing = listing.listing_id
                        left join basic_land on basic_land.listing = listing.listing_id
                        join account on listing.account = account.account_id
                        join listing_type on listing.listing_type = listing_type.listing_type_id
                        join property on listing.property = property.property_id
                        join property_category on listing.property_category = property_category.property_category_id
                     where listing.listing_date=:list_date  group by listing.listing_id    ";

$stmt = $con->getCon()->prepare($sql);
$list_date = date("yy-mm-dd");
$stmt->execute(array(":list_date" => $list_date));
$c = 0;
while ($row = $stmt->fetch()) {
    $c+=1;
    $pdf->Write(0.3, $row['title']);
    $pdf->Ln();
    $amount = $row['amount'];
    $pdf->Write(0.3, "Amount:  " . $row['currency'] . ' ' . $row['amount']);

    $pdf->Ln();
    $pdf->Write(0.3, "Location: " . $row['province'] . ', ' . $row['district'] . ', ' . $row['sector'] . ', ' . $row['cell']);
    $pdf->Ln();
    $pdf->Write(0.3, "Listing: " . $row['listing']);
    $pdf->Ln();
    $pdf->Write(0.3, "Amount: " . $row['currency'] .  ' ' . $amount);

    $pdf->Image('../../web_images/pic5.png', 100, 100, -300);
    $pdf->Ln();


    if ($row['bedrooms'] != '') {
        $pdf->Write(0.3, "Bedrooms: " . $row['bedrooms']);
        $pdf->Ln();
    }
    if ($row['bathrooms'] != '') {
        $pdf->Write(0.3, "Bathrooms: " . $row['bathrooms']);
        $pdf->Ln();
    }
    if ($row['plot_size'] != '') {
        $pdf->Write(0.3, "Plot size: " . $row['plot_size']);
        $pdf->Ln();
    }
    if ($row['available_from'] != '') {
        $pdf->Write(0.3, ">Available from: " . $row['available_from']);
        $pdf->Ln();
    }
    if ($row['administrative_location'] != '') {
        $pdf->Write(0.3, "Administrative location: " . $row['administrative_location']);
        $pdf->Ln();
    } $pdf->Ln();
    $pdf->Ln();
}
$height = $pdf->GetY() * 10;
//$pdf->Write(0.3, "The height of all contents: " . $height);
//$pdf->SetFont('Arial', 'B', 30);
$pdf->Cell(80);
$pdf->Cell(20, 10, 'Title', 1, 1,'L', 'C');

$pdf->Output();
