<?php
    session_start();
    if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }

    class Page_load {

        function process() {
            try {
                if ((!empty($this->lack_price()) || $this->lack_price() != 0 ) && empty($_SESSION['complete_updating'])) {
                    return 'price';
                } else
                if ($this->lack_location() != '' && ($this->lack_location() == 0) && empty($_SESSION['complete_updating'])) {
                    return 'location';
                } else if ($this->lack_image() != '' && empty($_SESSION['complete_updating'])) {
                    return 'image';
                } else if (!empty($this->just_upadting())) {
                    return 'just_updating';
                } else {
                    return 'complete';
                }
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

        function lack_price() {
            require_once './dbConnection.php';
            $user = $_SESSION['userid'];
            $database = new my_connection();
            $db = $database->getCon();
            $sql2 = " select  listing_id  from listing  where listing.listing_id not in (select listing from price where listing <>'null') and listing.account=:user  ";
            $stmt2 = $db->prepare($sql2);
            $stmt2->execute(array(":user" => $user));
            $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
            $price = $row2['listing_id'];
            return (!empty(trim($price)) && trim($price) != '');
        }

        function lack_location() {
            require_once './dbConnection.php';
            $user = $_SESSION['userid'];
            $database = new my_connection();
            $db = $database->getCon();
            $sql3 = " select  listing.location  from listing where  listing.location = 0 and listing.account=:user";
            $stmt3 = $db->prepare($sql3);
            $stmt3->execute(array(":user" => $user));
            $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
            $loc = trim($row3['location']);
            return $loc;
        }

        function lack_image() {
            require_once './dbConnection.php';
            $user = trim($_SESSION['userid']);
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select    listing_id  from listing  where listing.listing_id not in (select listing from image where listing <>'null') and listing.account=:the_user";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":the_user" => $user));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $image = trim($row['listing_id']);
            return (!empty($image) && $image != '') ? $image : '';
        }

        function just_upadting() {
            if (isset($_SESSION['complete_updating'])) {
                return (!empty($_SESSION['complete_updating'])) ? 'just_updasting' : '';
            }
        }

        function get_html() {
            if ($this->process() == 'complete') {
                require_once './html_fields.php';
                $obj = new html();
                $obj->html_Fresh();
                ?><script>//alert('Complete .. ');</script><?php
            } else if ($this->process() == 'just_updating') {
                require_once './html_fields.php';
                $obj = new html();
                $obj->Existing();
                ?><script>//alert('Complete .. ');</script><?php
            } else {
                require_once './html_fields.php';
                $obj = new html();
                $obj->Existing();
                ?><script> //alert('Existing, not complete .. ');</script><?php
            }
        }

        function get_changes() {
            echo $change = (!empty($_SESSION['changes'])) ? $_SESSION['changes'] : "no changes";
        }

    }

    class Events {

        function wizard_clicks() {
            ?>
            <script>
                $('#wiz_1').unbind('click').click(function () {
                    var the_step = $('#txt_process').val().trim();
                    var changes = $('#changes').val();

                    if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
                        wiz_step1();
                        $('#Editing_mode').val('update');
                        // $('#property_desc_title').slideUp(500).slideDown(700).html('UDPATING LISTING');
                        var prop_type = $('#update_property_type_id').val().trim();
                        var prop_cat = $('#update_property_category_name').val();

                        $('#property_subCat_label').show();
                        //            $('#my_cat_res').show().html('<div class="parts res_item pro_cat_data_item"><span class="off">' + prop_type + '</span>' + prop_cat + '</div>');
                        $('#my_cat_res').show();
                        $('.list_type_combo').val($('#update_listing_type').val());
                        $('.combo_property_type').val($('#update_property_type_id').val());
                        $('#txt_title').val($('#update_title').val());
                        var desc = $('#update_description').val();
                        $('#txt_desc').val(desc);
                        if (prop_type == 8) {//this is the basic partment of the house
                            $('.aparts_rows').slideDown(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideUp(200);
                            Last_apart_details();
                            display_relative_features(prop_type);
                        } else if (prop_type == 9) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideDown();
                            $('.development_rows').slideUp(200);
                            Last_comm_details();
                            display_relative_features(prop_type);
                        } else if (prop_type == 10) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideDown(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideUp(200);
                            Last_house_details();
                            display_relative_features(prop_type);
                        } else if (prop_type == 11) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideDown(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideUp(200);
                            Last_land_details();
                            display_relative_features(prop_type);
                        } else if (prop_type == 12) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideDown();
                            Last_dev_details();
                        }
                    }
                });
                $('#wiz_2').unbind('click').click(function () {
                    var the_step = $('#txt_process').val().trim();
                    var changes = $('#changes').val();
                    if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
                        wiz_step2();
                        toggle_rent_sale_price();
                    }
                    if (the_step == 'location' || the_step == 'image') {
                        $('#Editing_mode').val('update');
                        $('#Editing_mode_price').val('update');
                        $('#txt_amount').val($('#update_price_amount').val());
                        $('#txt_month_currency').val($('#update_price_currency').val());
                        $('#txt_minimum_advance').val($('#update_price_Minimum_advance').val());
                        $('#deposity').val($('#update_price_deposit_required').val());
                        $('#txt_commission').val($('#update_price_commission').val());
                        $('#price_condition').val($('#update_price_condition').val());
                        $('#utilities_combo').val($('#update_price_utilities_extra').val());
                        $('#price_condition').val($('#update_price_condition_per_day').val());
                        $('#txt_amount_per_day').val($('#update_price_amount_per_day').val());
                        $('#txt_condition_per_day').val($('#update_price_condition_per_day').val());
                        $('#txt_minimum_advance_per_day').val($('#update_price_minimum_advance_per_day').val());
                        $('#txt_deposit_required_per_day').val($('#update_price_deposit_required_per_day').val());
                        $('#txt_commission_per_day').val($('#update_price_commission_per_day').val());
                        //            $('#txt_utilities_extra_per_day').val($('#update_price_utilities_extra_per_day').val());
                        var utilities_chk = 'c';
                        $.post('../Admin/handler.php', {utilities_chk: utilities_chk}, function (data) {
                            $('#d').html(data);
                            var c = $('#d').text().trim();
                            var parsed = $.parseJSON(c);
                            var arr = [];
                            for (var x in parsed) {
                                arr.push(parsed[x]);
                            }
                            for (var i = 0; i < arr.length; i++) {
                                console.log(arr[i]);
                                var chk = arr[i].trim();
                                //                $(":checkbox[value=" + chk + "]").prop("checked", "true");
                                $("#utilities_box").find("input[type=checkbox][value=" + chk + "]").prop("checked", true);
                            }
                        }).complete(function () {
                            $("#utilities_box").css('background', '$00ddcc');
                        });
                        toggle_rent_sale_price();
                    }
                });
                $('#wiz_3').unbind('click').click(function () {
                    var the_step = $('#txt_process').val().trim();
                    var changes = $('#changes').val();
                    $('.aparts_rows').slideUp(200);
                    $('.house_rows').slideUp(200);
                    $('.land_rows').slideUp(200);
                    $('.commercial_rows').slideUp();
                    $('.development_rows').slideUp(200);
                    if (the_step == 'location' || the_step == 'image') {
                        wiz_step3();
                        $('#Editing_mode').val('update');
                    }
                    if (the_step == 'image') {
                        var cell, sector, district, province, long, lat, area;
                        var address, cell_name;
                        cell = $('#updateLoc_txt_cell_id').val();
                        cell_name = $('#updateLoc_txt_cell_name').val();
                        sector = $('#updateLoc_txt_sector_id').val();
                        district = $('#updateLoc_txt_district_id').val();
                        province = $('#updateLoc_txt_province_id').val();

                        long = $('#updateLoc_txt_loc_long').val();
                        lat = $('#updateLoc_txt_loc_lat').val();
                        area = $('#updateLoc_txt_area').val();
                        address = $('#updateLoc_txt_address').val();

                        $('#txt_cell_id').val(cell);
                        $('#txt_loc_lat').val(lat);
                        $('#txt_new_listing_area').val(area);
                        $('#txt_loc_lng').val(long);
                        $('#txt_addressf').val(address);

                        $('#chosen_province').html(province);
                        $('#chosen_district').html(district);
                        $('#chosen_sector').html(sector);
                        $('#chosen_cell').html(cell_name);// this is the cell name for user
                        $('#txt_cell_id').html(cell_name);//this is the cell id for db

                        $('#loc_all_prov').slideUp(300);
                        $('#loc_all_distr').slideUp(300);
                        $('#loc_all_sectors').slideUp(300);
                        $('#loc_all_cells').slideUp(300);
                    }
                });
                $('#wiz_4').unbind('click').click(function () {
                    var the_step = $('#txt_process').val().trim();
                    var changes = $('#changes').val();
                    if (the_step == 'image') {
                        wiz_step4();
                    }
                    $('#Editing_mode').val('update');
                });
            </script><?php
        }

    }

    $obj = new Page_load();
    $ev = new Events();
    $obj->get_html();


    