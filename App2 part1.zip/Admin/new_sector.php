<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}require_once '../web_db/multi_values.php';

if (isset($_POST['ok'])) {
    require_once '../web_db/new_values.php';
    $sector = $_POST['sector_txt_name'];
    $district_id = $_POST['txt_district_id'];
    if ($sector != '' && $district_id != '') {

        $newdata = new new_values();
        $newdata->new_sector($sector, $district_id);
        echo 'saved successfully';
    } else {
        echo'All the fields must be initialized';
    }
}
?>
<html>
    <head>
        <title>
            sector
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="parts loc_p">
            <form action="new_location.php" method="post" enctype="multipart/form-data">
                <input type="text" class="textbox off" name="txt_district_id" id="txt_district_id">
                <span class="" id="d"></span>
                <div class="parts  no_paddin_shade_no_Border x_titles margin_free smart_font">  sector</div>
                <table class="new_data_table" >
                    <tr><td>District :</td><td>
                            <?php
                            get_districts_combo();
                            ?>
                        </td></tr>
                    <tr><td>name :</td><td> <input type="text"     name="sector_txt_name" required /> </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="ok" value="Save"/>  </td></tr>
                </table>

                <!--<div class="datalist_box" >-->
                <?php
//                require_once '../web_db/multi_values.php';
//                $obj = new multi_values();
//                $obj->list_sector();
                ?>
                <!--</div>-->
            </form>
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </hmtl>
    <?php

    function get_districts_combo() {
        $bean = new multi_values();
        $bean->get_districts_combo();
    }
    