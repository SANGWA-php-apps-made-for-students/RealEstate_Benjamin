<?php

require_once '../dbConnection.php';
echo get_listing_no_image();

function get_listing_no_image() {
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "  select    count(listing_id) as tot  from listing  where listing.listing_id not in (select listing from image) and listing.listing_id in (select listing from price)";
    foreach ($db->query($sql) as $row) {
        $c = $row['tot'];
    }
    return $c;
}
