<?php

require_once '../dbConnection.php';
echo All_prop_types();

   function All_prop_types() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_type.name from property_type";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }