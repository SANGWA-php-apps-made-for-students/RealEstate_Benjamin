<?php

require_once '../dbConnection.php';
echo All_agents();
   function All_agents() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    count(property_request_id)as tot from property_request where received='no'";
        foreach ($db->query($sql) as $row) {
            $c=$row['tot'];
        }
        return $c;
    }