<html>
    <head>
        <title>title</title>
        <style>

        </style>
    </head>
    <body>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border clear_request_btn">
            <div class="parts two_fifty_right heit_free link_cursor confirm_buttons">
                Clear all received requests
            </div>
        </div>
        <div class="parts fifty_percent_two_h heit_free no_shade_noBorder ">
            <div class="parts full_center_two_h heit_free no_shade_noBorder">
                <div class="parts xx_titles no_paddin_shade_no_Border">
                    Non-received
                </div>
            </div>
            <?php
            require_once '../dbConnection.php';
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select * from property_request   where received='no'";
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> property request id</td>
                        <td> names </td>
                        <td> telephone </td>
                        <td> listing </td>
                        <td> Option</td>
                    </tr></thead>
                <?php foreach ($db->query($sql) as $row) { ?><tr>
                        <td class="request_col">
                            <?php echo $row['property_request_id']; ?>
                        </td>
                        <td>
                            <?php echo $row['names']; ?>
                        </td>
                        <td>
                            <?php echo $row['telephone']; ?>
                        </td>
                        <td>
                            <?php echo $row['listing']; ?>
                        </td>

                        <td>
                            <a class="request_link" href="#" value="<?php echo $row['listing']; ?>">
                                Receive
                            </a>
                        </td>
                    </tr>
                <?php } ?></table>
        </div>
        <div class="parts fifty_percent_two_h heit_free no_shade_noBorder">

            <div class="parts full_center_two_h heit_free   no_shade_noBorder ">
                <div class="parts xx_titles no_paddin_shade_no_Border">
                    Received
                </div>
            </div>
            <?php
            require_once '../dbConnection.php';
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select * from property_request   where received='yes'";
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> property request id</td>
                        <td> names </td>
                        <td> telephone </td>
                        <td> listing </td>

                    </tr></thead>
                <?php foreach ($db->query($sql) as $row) { ?><tr>
                        <td>
                            <?php echo $row['property_request_id']; ?>
                        </td>
                        <td>
                            <?php echo $row['names']; ?>
                        </td>
                        <td>
                            <?php echo $row['telephone']; ?>
                        </td>
                        <td>
                            <?php echo $row['listing']; ?>
                        </td>



                    </tr>
                <?php } ?></table>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border clear_request_btn">
            <div class="parts two_fifty_right heit_free link_cursor confirm_buttons">
                Clear all received requests
            </div>
        </div>
    </body>
</html>

<html>
    <head>
        <title>title</title>
    </head>
    <body>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>

