<?php

  
require_once '../dbConnection.php';
echo All_admin();
 function All_admin() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    account_category.name from account_category where account_category.name='Admin'";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
