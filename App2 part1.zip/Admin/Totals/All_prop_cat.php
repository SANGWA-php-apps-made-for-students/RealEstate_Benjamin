<?php
require_once '../dbConnection.php';
echo All_prop_cat();

   function All_prop_cat() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_category.name from property_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }