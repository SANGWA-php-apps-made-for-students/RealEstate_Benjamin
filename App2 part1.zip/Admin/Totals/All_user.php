<?php

require_once '../dbConnection.php';
echo All_accounts();

function All_accounts() {
    $c = 0;
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "select * from account";
    foreach ($db->query($sql) as $row) {
        $c+=1;
    }
    return $c;
}
