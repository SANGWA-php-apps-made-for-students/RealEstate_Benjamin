<?php
 require_once '../dbConnection.php';
echo All_account_cat();

 function All_account_cat() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    account_category.name from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
