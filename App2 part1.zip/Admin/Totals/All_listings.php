<?php
require_once '../dbConnection.php';
echo get_all_listings();
function get_all_listings() {
    $c = 0;
    $database = new my_connection();
    $db = $database->getCon();
    $sql = " select   count(listing.listing_id)as tot from listing";
    foreach ($db->query($sql) as $row) {
        $c=$row['tot'];
    }
    return $c;
}
