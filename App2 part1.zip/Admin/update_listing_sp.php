<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"   id="txt_upd_last_listing_id">
<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"   id="txt_upd_property_type_id">
<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"   id="txt_upd_property_cat_id">
<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"   id="txt_prop_upd_text_id">
<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"   id="txt_desc_upd_txt">
<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"  id="txt_property_type_id">
<input type="text" class="textbox " placeholder="property type"      name="txt_property_type_id"  id="txt_property_type_id">