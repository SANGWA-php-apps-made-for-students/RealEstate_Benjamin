<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
?>
<html>
    <head>
        <title>title</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_property_category.php" method="post" enctype="multipart/form-data">
            <input type="text" class="textbox off" name="txt_property_type_id" id="txt_property_type_id">
            <input type="text" class="textbox off" name="txt_prop_type_id" id="txt_prop_type_id">

            <?php
            include 'Admin_header.php';
            ?><div class="parts eighty_centered no_shade_noBorder  smart_font"> property_category</div>
            <div class="parts eighty_centered  new_data_box ">
                <div class="parts eighty_centered margin_free no_shade_noBorder">
                    <?php save_property_cate(); ?>
                </div>

                <div class="parts " >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_property_category_vs_property();
                    ?>
                </div> <div class="parts">
                    <table class="new_data_table">
                        <tr><td>Type :</td><td>
                                <?php
                                get_property_type_combo();
                                ?>
                            </td></tr>
                        <tr><td>name :</td><td> <input type="text"  name="txt_name" required class="textbox"   </td></tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="send_prop_cat" class="confirm_buttons two_fifty_left heit_free" value="Save">
                            </td>
                        </tr>
                    </table>
                </div>
            </div>


        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('.pt').change(function () {
                    var c = $('.pt option:selected').val();
                    $('#txt_prop_type_id').val(c);
                });
            });
        </script>
    </body>
</html>
<?php

function save_property_cate() {
    try {
        if (isset($_POST['send_prop_cat'])) {
            $name = $_POST['txt_name'];
            $prop_cat = $_POST['txt_prop_type_id'];
            if ($name != '') {
                //property category
                if (!empty($prop_cat)) {
                    require_once '../web_db/new_values.php';
                    $obj = new new_values();
                    $obj->new_property_category($name, $prop_cat);
                    echo 'saved successfully';
                } else {
                    echo 'You have to choose the property type';
                }
            } else {
                echo '<div class="red_message>" You have to provide the name the of the category</div>';
            }
        }
    } catch (Exception $e) {
        echo $e . message;
    }
}

function get_property_type_combo() {
    $bean = new multi_values();
    $bean->get_prop_type_combo();
}
