<?php

require_once 'connection.php';

class updates {
    
}
