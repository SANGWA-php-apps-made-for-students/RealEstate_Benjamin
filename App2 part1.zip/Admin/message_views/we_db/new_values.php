<?php

require_once 'connection.php';

class new_values {

    function new_featured($date, $listing, $description, $featured_cat, $account) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into featured values(:featured_id, :date,  :listing,  :description,  :featured_cat,  :account)");
            $stm->execute(array(':featured_id' => 0, ':date' => $date, ':listing' => $listing, ':description' => $description, ':featured_cat' => $featured_cat, ':account' => $account
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_featured_cat($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into featured_cat values(:featured_cat_id, :name)");
            $stm->execute(array(':featured_cat_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_listing_comment($date, $listing, $message) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into listing_comment values(:listing_comment_id, :date,  :listing,  :message)");
            $stm->execute(array(':listing_comment_id' => 0, ':date' => $date, ':listing' => $listing, ':message' => $message
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_web_visits($date, $visit_count) {
        try {

            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into web_visits values(:web_visits_id, :date,  :visit_count)");
            $stm->execute(array(':web_visits_id' => 0, ':date' => $date, ':visit_count' => $visit_count
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_message($account, $date, $type, $message) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into message values(:message_id, :account,  :date,  :type,  :message)");
            $stm->execute(array(':message_id' => 0, ':account' => $account, ':date' => $date, ':type' => $type, ':message' => $message
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_msg_type($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into msg_type values(:msg_type_id, :name)");
            $stm->execute(array(':msg_type_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
