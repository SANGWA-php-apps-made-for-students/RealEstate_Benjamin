<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_message($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from message";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> message </td>
                    <td> account </td><td> date </td><td> type </td><td> message </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['message_id']; ?>
                    </td>
                    <td class="account_id_cols message " title="message" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>
                    <td>
                        <a href="#" class="message_delete_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="message_update_link" style="color: #000080;" value="
                           <?php echo $row['message_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_message_account($id) {

            $db = new dbconnection();
            $sql = "select   message.account from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_message_date($id) {

            $db = new dbconnection();
            $sql = "select   message.date from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_message_type($id) {

            $db = new dbconnection();
            $sql = "select   message.type from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['type'];
            echo $field;
        }

        function get_chosen_message_message($id) {

            $db = new dbconnection();
            $sql = "select   message.message from message where message_id=:message_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':message_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['message'];
            echo $field;
        }

        function All_message() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  message_id   from message";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_message() {
            $con = new dbconnection();
            $sql = "select message.message_id from message
                    order by message.message_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['message_id'];
            return $first_rec;
        }

        function get_last_message() {
            $con = new dbconnection();
            $sql = "select message.message_id from message
                    order by message.message_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['message_id'];
            return $first_rec;
        }

        function list_msg_type($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from msg_type";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> msg_type </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['msg_type_id']; ?>
                    </td>
                    <td class="name_id_cols msg_type " title="msg_type" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="msg_type_delete_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="msg_type_update_link" style="color: #000080;" value="
                           <?php echo $row['msg_type_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_msg_type_name($id) {

            $db = new dbconnection();
            $sql = "select   msg_type.name from msg_type where msg_type_id=:msg_type_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':msg_type_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_msg_type() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  msg_type_id   from msg_type";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_msg_type() {
            $con = new dbconnection();
            $sql = "select msg_type.msg_type_id from msg_type
                    order by msg_type.msg_type_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['msg_type_id'];
            return $first_rec;
        }

        function get_last_msg_type() {
            $con = new dbconnection();
            $sql = "select msg_type.msg_type_id from msg_type
                    order by msg_type.msg_type_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['msg_type_id'];
            return $first_rec;
        }

        function list_web_visits() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from web_visits";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> web_visits </td>
                    <td> date </td><td> visit_count </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['web_visits_id']; ?>
                    </td>
                    <td class="date_id_cols web_visits " title="web_visits" >
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['visit_count']); ?>
                    </td>


                    <td>
                        <a href="#" class="web_visits_delete_link" style="color: #000080;" value="
                           <?php echo $row['web_visits_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="web_visits_update_link" style="color: #000080;" value="
                           <?php echo $row['web_visits_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_web_visits_date($id) {

        $db = new dbconnection();
        $sql = "select   web_visits.date from web_visits where web_visits_id=:web_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':web_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    }

    function get_chosen_web_visits_visit_count($id) {

        $db = new dbconnection();
        $sql = "select   web_visits.visit_count from web_visits where web_visits_id=:web_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':web_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['visit_count'];
        echo $field;
    }

    function All_web_visits() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  web_visits_id   from web_visits";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function get_first_web_visits() {
        $con = new dbconnection();
        $sql = "select web_visits.web_visits_id from web_visits
                    order by web_visits.web_visits_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['web_visits_id'];
        return $first_rec;
    }

    function get_last_web_visits() {
        $con = new my_connection();
        $sql = "select web_visits.web_visits_id from web_visits
                    order by web_visits.web_visits_id desc
                    limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['web_visits_id'];
        return $first_rec;
    }

    function functionName($name) {
        $db = new dbconnection();
        $sql = "select agency.office_phone from agency 
                  join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id   
                 join profile on account.profile = profile.profile_id 
                where agency_name =:name
                group by agency.agency_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute(array(":name" => name));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $phone_n = $row['office_phone'];
        echo $phone_n;
    }

}
