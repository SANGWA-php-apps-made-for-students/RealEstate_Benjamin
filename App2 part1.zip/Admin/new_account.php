<?php
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
?>
<html>
    <head>
        <title>
            account
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            p{
                margin: 20px;
                color: #4c1758;
                text-decoration: underline;
            }
            .new_data_table td{
                padding: 5px;
            }
            #sp_table td{
                padding: 10px;

            }
            #sp_table{
                border-collapse: collapse;
            }
        </style>
    </head> 
    <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <?php
            include 'Admin_header.php';
//            include './sidemenu.php';
            ?>
            <input type="text" id="acc_typeid" class="off"  name="userid"/>
            <span id="d" class="off">

            </span>
            <div class="parts eighty_centered dialogBox no_shade_noBorder ">
                <?php
                save_account();
                ?>
            </div>
            <div class="parts eighty_centered margin_free no_paddin_shade_no_Border new_data_box ">
                <div class="parts margin_free  xx_titles no_paddin_shade_no_Border smart_font">  Account</div>
                <table  class="parts new_data_table top_off_x margin_free smart_parts" style="border: 1px solid #fff;" > 
                    <tr><td colspan="2">
                            <p>ACCOUNT DETAILS</p>
                            <table   class="new_data_table" style="margin-top: 0px;">
                                <tr>
                                    <td>&nbsp;&nbsp; Username :<br/>  <input type="text"     name="txt_username" required class="parts" /> </td>
                                    <td>&nbsp;&nbsp; Password :<br/><input type="password"     name="txt_password" required class="parts" /></td>
                                    <td>&nbsp; &nbsp;Account category :     <br/>  <?php
                                        if (isset($_SESSION['cat'])) {
                                            get_user_category_combo();
                                        } else {
                                            ?><input type="text" name="simpleUser"><?php
                                        }
                                        ?>
                                    </td> 
                                </tr>
                            </table>
                        </td>
                    </tr> 
                    <?php require_once './new_profile.php'; ?>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_account" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box no_paddin_shade_no_Border" >
                <?php
                if (isset($_SESSION['cat'])) {
                    if ($_SESSION['cat'] == 'admin') {
                        ?>
                        <div class="parts xx_titles no_paddin_shade_no_Border">
                            Users list
                        </div>
                        <?php
                        require_once '../web_db/multi_values.php';
                        $obj = new multi_values();
                        $obj->list_account();
                    }
                }
                ?>
            </div>
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
            <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
            <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        </form>
    </body>
</hmtl>
<?php

function get_user_category_combo() {
    require_once '../Admin/dbConnection.php';
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "select account_category_id,   account_category.name from account_category";
    ?>
    <select class="parts combo_user_cat" style="width: 200px;"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
    </select>
    <?php
}

function save_account() {
    if (isset($_POST['send_account'])) {
        try {
            require_once '../web_db/new_values.php';
            require_once '../web_db/multi_values.php';
            $mul_obj = new multi_values();
            $add_obj = new new_values();
            //profile fields
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $email = $_POST['txt_email'];
            $home_phone = $_POST['txt_home_phone'];
            $office_phone = $_POST['txt_office_phone'];
            $mobile_phone = $_POST['txt_mobile_phone'];
            $address = $_POST['txt_address'];
            $city = $_POST['txt_city'];
            $country = $_POST['txt_country'];

            //account
            $username = $_POST['txt_username'];
            $password = $_POST['txt_password'];
            $account_category = $_POST['userid'];
            $online = 'no';
            $deleted = 'no';
            $date_created = date("Y-m-d");
            $obj = new new_values();
            save_image();
            $img = $mul_obj->get_last_image_id();
            if ($account_category != '') {
                $add_obj->new_profile($name, $last_name, $email, $home_phone, $office_phone, $mobile_phone, $address, $city, $country, $img);
                //last profile id
                $last_profile = $mul_obj->get_last_profile_id();
                $add_obj->new_account($username, $password, $account_category, $online, $deleted, $date_created, $last_profile);
                echo 'Data save successfully';
            } else {
                echo'<div class="red_message">' . ' You have not selected the account type or the account type has no users' . '</div>';
            }
        } catch (PDOException $ex) {
            echo 'Saving Data error: ' . $ex;
        }
    }
}

function save_image() {

    //save the data
    //get the last post
    //save image with the last post image name
    require_once '../web_db/new_values.php';
    require_once '../web_db/multi_values.php';
    $add_obj = new new_values();
    $mul_obj = new multi_values();
    $target_dir = "../web_images/people/";
    $target_file = $target_dir . basename($_FILES["txt_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $ExtensionWithDot = '.' . $imageFileType;

    $file_with_noExtension = basename($target_file, $ExtensionWithDot);
    //save the image in folder (upload)
    $img = $mul_obj->get_last_image_id() + 1;
    $desiredname = $img;
    $newname = $desiredname . '.' . $imageFileType;
    $new_target_file = $target_dir . $newname;
    $target_file_for_db = $new_target_file;
    $path = $target_file_for_db;
    $property = 0;
    $deleted = 'no';
    $appear = 'yes';
    //save the image in the db (save path)
    $add_obj->new_image($path, $property, $deleted, $appear);

    // Check if image file is a actual image or fake image
    if (isset($_POST["send"])) {
        $check = getimagesize($_FILES["txt_image"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }
    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["txt_image"]["size"] > 3000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["txt_image"]["tmp_name"], $new_target_file)) {
            echo "The file " . basename($_FILES["txt_image"]["name"]) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
