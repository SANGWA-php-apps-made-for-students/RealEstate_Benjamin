<?php

class html {

    function html_Fresh() {
        ?>
        <html>
            <head>
                <title>New listing</title>
                <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
                <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
            </head>
            <body>
                <?php
                // <editor-fold defaultstate="collapsed" desc="-- new fold">
                include './Admin_header.php';
                $obj_load = new Page_load();
                ?> 
                <input type=  "hidden" class="textbox  left_off_eighty " name="txt_changes" id="txt_changes"   />
                <input type=  "hidden" class="parts left_off_eighty" id="data_found"/>   
                <!--this hidden fields are to keep values before saving-->

                <input  type="hidden" class="left_off_eighty " id="txt_process" name="txt_process" value="<?php echo $obj_load->process(); ?>" />
                <input type="hidden" class="parts left_off_eighty" id="data_found"/>
                <!--<input type = "hidden" class = "textbox " placeholder = "proprty cat" name = "txt_property_cat_id" id = "txt_property_cat_id" value="<?php echo $_SESSION['property_category']; ?>" >-->
                <div class="parts eighty_centered no_paddin_shade_no_Border">                                            
                    <div class="parts link_cursor wizard_steps" id="wiz_1"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon1"></div>1 PROPERTY DESCRIPTION</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_2"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon2"></div>2 PRICE</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_3"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon3"></div>3 LOCATION</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_4"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon4"></div>4 ATTACHMENTS(IMAGES)</div>
                    <div class="parts off" id="counter">
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step1">
                    <?php include './new_listing.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step2">
                    <?php include './new_price.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step3">
                    <?php include './new_property_location.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step4">
                    <?php include './new_image.php'; ?>
                </div>
                <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
                <!--<script src="../web_scripts/wizard_scripts.js" type="text/javascript"></script>-->
                <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
                <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
                <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script> 
                <script>
                    $(document).ready(function name() {
                        var progress = $('#txt_process').val();
                        $('.date_pick').datepicker({
                            dateFormat: 'yy-mm-dd',
                            minDate: new Date()
                        });
                        wiz_step1();

                    });
                    function wiz_step1() {
                        $("#wiz_step1").show("drop", {direction: "down"}, 600);
                        $('#wiz_step2').hide();
                        $('#wiz_step3').hide();
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_1').css('border-color', '#000086');
                        $('#wiz_1').css('background-color', '#fff');
                    }

                </script>

                <script async defer
                        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
                </script>
            </body>
        </html><?php
    }

    function Existing() {
        ?>
        <html>
            <head>
                <title>New listing</title>
                <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
                <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
                <meta name="viewport" content="width=device-width, initial scale=1.0"/>
                <style>
                    .textbox_price{
                        width: 250px;
                        float: left;
                        padding: 14px;
                        margin-left: 0px;
                    }
                    .new_data_table td{
                        padding: 5px;
                    }
                    /*images*/
                    input[type="file"] {
                        display: block;
                    }
                    .imageThumb {
                        max-height: 75px;
                        border: 2px solid;
                        padding: 1px;
                        cursor: pointer;
                    }
                    .pip {
                        display: inline-block;
                        margin: 10px 10px 0 0;
                    }
                    .remove {
                        display: block;
                        background: #444;
                        border: 1px solid black;
                        color: white;
                        text-align: center;
                        cursor: pointer;
                    }
                    .remove:hover {
                        background: white;
                        color: black;
                    }

                </style>
            </head>
            <body class="wiz_body">
                <?php
                include './Admin_header.php';
                $obj_load = new Page_load();

                require_once './dbConnection.php';
                $user = $_SESSION['userid'];
                $database = new my_connection();
                $db = $database->getCon();
                $sql3 = " select  listing.location  from listing where  listing.location = 0 and listing.account=:user";
                $stmt3 = $db->prepare($sql3);
                $stmt3->execute(array(":user" => $user));
                $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                ?>
                <input type="hidden" class="left_off_eighty " id="txt_process" name="txt_process" value="<?php echo $obj_load->process(); ?>" />
                <input type="hidden" class="textbox  left_off_eighty " placeholder="changes, currently you are adding/changing property" name="txt_changes" id="txt_changes" value="<?php $obj_load->get_changes(); ?>"  />
                <input type="hidden" class="parts left_off_eighty" id="data_found"/>   
                <div class="parts eighty_centered no_paddin_shade_no_Border">
                    <div class="parts link_cursor wizard_steps" id="wiz_1"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon1"></div>1 PROPERTY DESCRIPTION</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_2"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon2"></div>2 PRICE</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_3"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon3"></div>3 LOCATION</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_4"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon4"></div>4 ATTACHMENTS(IMAGES)</div>
                    <div class="parts off" id="counter">
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step1">
                    <?php include './new_listing.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step2">
                    <?php include './new_price.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step3">
                    <?php include './new_property_location.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step4">
                    <?php include './new_image.php'; ?>
                </div>
                <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
                <!--<script src="../web_scripts/wizard_scripts.js" type="text/javascript"></script>-->
                <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
                <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
                <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script> 
                <script>
                    var upating_specific = $('#updating_specific').val().trim();
                    $(document).ready(function () {
                        try {
                            var progress = $('#txt_process').val();
                            $('.date_pick').datepicker({
                                dateFormat: 'yy-mm-dd',
                                minDate: new Date()
                            });
                            get_uncomplete_steps();

                            $('.warning').animate({marginTop: '100'}, 600);
                            $('#wiz_1').unbind('click').click(function () {
                                try {
                                    wiz_step1();
                                    if (progress != 'complete') {
                                        $('#Editing_mode').val(progress);
                                    }
                                } catch (err) {
                                    alert('wiz one: ' + err.message);
                                }
                            });
                            $('#wiz_2').unbind('click').click(function () {
                                var the_step = $('#txt_process').val().trim();
                                if (progress != 'complete') {
                                    $('#Editing_mode_price').val(progress);
                                }
                                if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
                                    wiz_step2();
                                    toggle_rent_sale_price();
                                }
                                if (the_step == 'location' || the_step == 'image') {
                                    wiz_step2();
                                    // $('#txt_utilities_extra_per_day').val($('#update_price_utilities_extra_per_day').val());
                                    var utilities_chk = 'c';
                                    toggle_rent_sale_price();
                                }
                                var upating_specific = $('#updating_specific').val().trim();
                                if (upating_specific != '') {//it means the user has chosen a particular listing to update
                                    var prop_type = $('#txt_property_type_id').val().trim();
                                    wiz_step2();
                                }
                            });
                            $('#wiz_3').unbind('click').click(function () {
                                var the_step = $('#txt_process').val().trim();
                                var changes = $('#changes').val();
                                if (progress != 'complete') {
                                    $('#Editing_mode').val(progress);
                                }
                                if (the_step == 'location' || the_step == 'image') {
                                    wiz_step3();
                                    $('#Editing_mode').val('update');
                                }
                                if (the_step == 'image') {
                                    var cell, sector, district, province, long, lat, area;
                                    var address, cell_name;
                                    cell = $('#updateLoc_txt_cell_id').val();
                                    cell_name = $('#updateLoc_txt_cell_name').val();
                                    sector = $('#updateLoc_txt_sector_id').val();
                                    district = $('#updateLoc_txt_district_id').val();
                                    province = $('#updateLoc_txt_province_id').val();
                                    long = $('#updateLoc_txt_loc_long').val();
                                    lat = $('#updateLoc_txt_loc_lat').val();
                                    area = $('#updateLoc_txt_area').val();
                                    address = $('#updateLoc_txt_address').val();
                                    $('#txt_cell_id').val(cell);
                                    $('#txt_loc_lat').val(lat);
                                    $('#txt_new_listing_area').val(area);
                                    $('#txt_loc_lng').val(long);
                                    $('#txt_addressf').val(address);
                                    $('#chosen_province').html(province);
                                    $('#chosen_district').html(district);
                                    $('#chosen_sector').html(sector);
                                    $('#chosen_cell').html(cell_name); // this is the cell name for user
                                    $('#txt_cell_id').html(cell_name); //this is the cell id for db

                                    $('#loc_all_prov').slideUp(300);
                                    $('#loc_all_distr').slideUp(300);
                                    $('#loc_all_sectors').slideUp(300);
                                    $('#loc_all_cells').slideUp(300);
                                }
                                var upating_specific = $('#updating_specific').val().trim();
                                if (upating_specific != '') {//it means the user has chosen a particular listing to update
                                    var prop_type = $('#txt_property_type_id').val().trim();
                                    wiz_step3();
                                }

                            });
                            $('#wiz_4').unbind('click').click(function () {
                                var the_step = $('#txt_process').val().trim();
                                var changes = $('#changes').val();
                                if (the_step == 'image') {
                                    wiz_step4();
                                }
                                var upating_specific = $('#updating_specific').val().trim();
                                if (upating_specific != '') {//it means the user has chosen a particular listing to update
                                    var prop_type = $('#txt_property_type_id').val().trim();
                                    wiz_step4();
                                }
                                $('#Editing_mode').val('update');
                            });
                            location_instant_search();
                        } catch (err) {
                            alert(err.message);
                        }
                    });
                    function wiz_step1() {
                        $("#wiz_step1").show("drop", {direction: "down"}, 600);
                        $('#wiz_step2').hide();
                        $('#wiz_step3').hide();
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_1').css('border-color', '#000086');
                        $('#wiz_1').css('background-color', '#fff');
                    }
                    function wiz_step2() {
                        $('#wiz_step1').hide();
                        $("#wiz_step2").show("drop", {direction: "down"}, 600);
                        $('#wiz_step3').hide();
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_2').css('border-color', '#000086');
                        $('#wiz_2').css('background-color', '#fff');
                        toggle_rent_sale_price();
                    }
                    function wiz_step3() {
                        var upating_specific = $('#updating_specific').val().trim();
                        if (upating_specific == '') {//it means the user has chosen a particular listing to update
                            //                            $('.aparts_rows').hide();
                            //                            $('.commercial_rows').hide();
                            //                            $('.development_rows').hide();
                        }
                        $('#wiz_step1').hide();
                        $('#wiz_step2').hide();
                        $("#wiz_step3").show("drop", {direction: "down"}, 600);
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_3').css('border-color', '#000086').css('background-color', '#fff');
                    }
                    function wiz_step4() {
                        $('#wiz_step1').hide();
                        $('#wiz_step2').hide();
                        $('#wiz_step3').hide();
                        $("#wiz_step4").show("drop", {direction: "down"}, 600);
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_4').css('border-color', '#000086');
                        $('#wiz_4').css('background-color', '#fff');
                    }
                    function toggle_rent_sale_price() {
                        //this displays the fields of square meter, on price wizard step
                        var listing_type = '';
                        var listing_type = $('#listing_type').val().trim();
                        var listing_type = (prop_type != '') ? prop_type : propertt_type_new;
                        if (listing_type == 1) {
                            $('#equivalent_price_day').show();
                            $('#currency_amount').show();
                        } else {
                            $("#hide_amount_day").hide();
                            $('#equivalent_price_day').hide();
                            $('#currency_amount').hide();
                        }
                    }
                    function get_uncomplete_steps() {
                        check_previous_step();
                    }
                    function check_previous_step() {
                        initialize_page(); //where it initializes the combo boxes of property types, category and features.
                        var the_step = $('#txt_process').val().trim();
                        if (the_step == 'price') {
                            wiz_step2();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                            tick_finished_steps('price');
                        } else if (the_step == 'location') {
                            wiz_step3();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                            tick_finished_steps('location');
                        } else if (the_step == 'image') {
                            wiz_step4();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                            tick_finished_steps('image');
                        } else {
                            wiz_step1();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                        }
                        $('#remove_previous_listing').click(function () {
                            var last_listing = 'c';
                            $.post('../Admin/handler.php', {last_listing: last_listing}, function (data) {
                                $('#d').html(data);
                                working_listing_id = $('#d').text().trim();
                            }).complete(function () {
                                var lising_delete = working_listing_id;
                                $.post('../Admin/handler.php', {lising_delete: lising_delete}, function (data) {
                                }).complete(function () {
                                    window.location.replace('http://localhost/Restate/Admin/redirect.php');
                                });
                            });
                        });
                        $('#complete_prev_listing').click(function () {
                            if (the_step == 'price') {
                                wiz_step2();
                            } else if (the_step == 'location') {
                                wiz_step3();
                            } else if (the_step == 'image') {
                                wiz_step4();
                            } else {
                                wiz_step1();
                            }
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                        });
                    }
                    function tick_finished_steps(current_step) {
                        if (current_step == 'price') {
                            $('.step_icons').removeClass('tick');
                            $('#step_icon1').addClass('tick');
                        } else if (current_step == 'location') {
                            $('.step_icons').removeClass('tick');
                            $('#step_icon1').addClass('tick');
                            $('#step_icon2').addClass('tick');
                        } else if (current_step == 'image') {
                            $('.step_icons').removeClass('tick');
                            $('#step_icon1').addClass('tick');
                            $('#step_icon2').addClass('tick');
                            $('#step_icon3').addClass('tick');
                        }
                    }
                    function toggle_rent_sale_price() {
                        //this displays the fields of square meter, on price wizard step
                        var listing_type = '';
                        var prop_type = $('#txt_property_type_id').val().trim();
                        var propertt_type_new = '';
                        if (listing_type == '') {
                            propertt_type_new = $('#txt_update_listing_type').val().trim();
                            var listing_type = propertt_type_new;
                        } else {
                            propertt_type_new = $('#listing_type').val().trim();
                            var listing_type = propertt_type_new;
                        }
                        if (propertt_type_new == 1) {
                            $('#hide_amount_day').show();
                            $('#equivalent_price_day').show();
                            $('#currency_amount').show();
                            $('.hidable_row_prc_sqr_meter').hide();
                        } else {
                            $("#hide_amount_day").hide();
                            $('#equivalent_price_day').hide();
                            $('#currency_amount').hide();
                        }
                    }
                    function initialize_page() {
                        //var chosen_update =<?php //echo $res = (empty($_SESSION['complete_updating'])) ? '' : $_SESSION['complete_updating'];                                                                                                                                                                                                                   ?>;
                        $('.list_type_combo').val($('#txt_update_listing_type').val());
                        var the_step = $('#txt_process').val().trim();
                        var prop_type = $('#txt_property_type_id').val().trim();
                        var prop_cat = $('#update_txt_property_cat_id').val();
                        $('.combo_property_type').val(prop_type);
                        $('#last_prop_cat_combo').val(prop_cat);
                        if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
                            $('#property_subCat_label').show();
                            $('#my_cat_res').show();
                            if (prop_type == 8) {//this is the basic partment of the house
                                $('.aparts_rows').slideDown(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideUp(200);
                                var furnished = $('#update_txt_aprt_furnished').val();
                                $('#apart_furnished').val(furnished);
                                display_relative_features(prop_type);
                            } else if (prop_type == 9) {// this is the 
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideDown();
                                $('.development_rows').slideUp(200);
                                var furnished_comm = $('#basic_commercial_frunished').val();
                                $('#txt_comm_furnished').val(furnished_comm);
                                display_relative_features(prop_type);
                            } else if (prop_type == 10) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideDown(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideUp(200);

                                var furnished_comm = $('#basic_house_frunished').val();
                                $('#txt_house_furnished').val(furnished_comm);
                                display_relative_features(prop_type);
                            } else if (prop_type == 11) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideDown(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideUp(200);
                                display_relative_features(prop_type);
                            } else if (prop_type == 12) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideDown();
                            }
                            //                            $(".pro_cat_data_item:contains(" + prop_cat + ")").css("background-color", "#ff6666").css('color', '#fff');
                            $('#combo_tofill').val(prop_cat);
                        }
                        if (the_step == 'location' || the_step == 'image') {
                            $('#wiz_step3').hide();
                            //<editor-fold defaultstate="collapsed" desc="---price utilities-------">
                            var c2 = $('#checked_utils').text().trim();
                            var parsed2 = $.parseJSON(c2);
                            var arr2 = [];
                            for (var x in parsed2) {
                                arr2.push(parsed2[x]);
                            }
                            for (var i2 = 0; i2 < arr2.length; i2++) {
                                var chk2 = arr2[i2].trim();
                                $('#utilities_box').find("input[type=checkbox][value=" + chk2 + "]").prop("checked", true);
                            }
                            //</editor-fold>

                            //<editor-fold defaultstate="collapsed" desc="------currency -------">

                            $('#txt_month_currency').val($('#curr_month').val());
                            $('#perSqaure_select').val($('#curr_day').val());
                            $('#amount_day_select').val($('#curr_day').val());
                            //</editor-fold>
                        }
                        if (the_step == 'image') {
                            var cell, sector, district, province, long, lat, area;
                            var address, cell_name;
                            cell = $('#updateLoc_txt_cell_name').val();
                            sector = $('#updateLoc_txt_sector_id').val();
                            district = $('#updateLoc_txt_district_id').val();
                            province = $('#updateLoc_txt_province_id').val();
                            $('#sp_combo_prov option:selected').text(province);
                            $('#sp_combo_distr').val(district);
                            $('#sp_combo_sectr').val(sector);
                            $('#sp_combo_cell').val(cell);

                            $("#sp_combo_distr").empty();
                            $("#sp_combo_sectr").empty();
                            $("#sp_combo_cell").empty();

                            $("#sp_combo_distr").append('<option value="23">' + district + '</option>');
                            $("#sp_combo_sectr").append('<option value="23">' + sector + '</option>');
                            $("#sp_combo_cell").append('<option value="23">' + cell + '</option>');

                            $('#loc_all_prov').slideUp(300);
                            $('#loc_all_distr').slideUp(300);
                            $('#loc_all_sectors').slideUp(300);
                            $('#loc_all_cells').slideUp(300);


                        }

                        var upating_specific = $('#updating_specific').val().trim();
                        if (upating_specific != '') {//it means the user has chosen a particular listing to update
                            show_property_specific_type(prop_type);
                            //<editor-fold defaultstate="collapsed" desc="------currency -------">
                            $('#txt_month_currency').val($('#curr_month').val());
                            $('#perSqaure_select').val($('#curr_day').val());
                            $('#txt_month_currency').val($('#curr_day').val());
                            $('#amount_day_select').val($('#curr_day').val());

                            $('.step_icons').addClass('editing');
                            var c2 = $('#checked_utils').text().trim();
                            var parsed2 = $.parseJSON(c2);
                            var arr2 = [];
                            for (var x in parsed2) {
                                arr2.push(parsed2[x]);
                            }
                            for (var i2 = 0; i2 < arr2.length; i2++) {
                                var chk2 = arr2[i2].trim();
                                $('#utilities_box').find("input[type=checkbox][value=" + chk2 + "]").prop("checked", true);
                            }
                            var cell, sector, district, province, long, lat, area;
                            var address, cell_name;
                            cell = $('#updateLoc_txt_cell_name').val();
                            sector = $('#updateLoc_txt_sector_id').val();
                            district = $('#updateLoc_txt_district_id').val();
                            province = $('#updateLoc_txt_province_id').val();
                            $('#sp_combo_prov option:selected').text(province);
                            $('#sp_combo_distr').val(district);
                            $('#sp_combo_sectr').val(sector);
                            $('#sp_combo_cell').val(cell);

                            $("#sp_combo_distr").empty();
                            $("#sp_combo_sectr").empty();
                            $("#sp_combo_cell").empty();

                            $("#sp_combo_distr").append('<option value="23">' + district + '</option>');
                            $("#sp_combo_sectr").append('<option value="23">' + sector + '</option>');
                            $("#sp_combo_cell").append('<option value="23">' + cell + '</option>');
                            //                            editing
                            //</editor-fold>
                        }
                    }
                    function display_relative_features(prop_type) {
                        var features_by_prop_type = $('.combo_property_type option:selected').val().trim();
                        $.post('handler.php', {features_by_prop_type: features_by_prop_type}, function (data) {
                            $('#features_box').html(data);
                        }).complete(function () {
                            var features_by_prop_type = prop_type;
                            var features_last_listing = 'c';
                            var changes = $('#data_found').val().trim();
                            var c = $('#d').text().trim();
                            var parsed = $.parseJSON(c);
                            //      $("#" + data[i]).attr("checked", "checked");
                            var arr = [];
                            for (var x in parsed) {
                                arr.push(parsed[x]);
                            }
                            for (var i = 0; i < arr.length; i++) {
                                console.log(arr[i]);
                                var chk = arr[i].trim();
                                //                $(":checkbox[value=" + chk + "]").prop("checked", "true");
                                $("#features_box").find("input[type=checkbox][value=" + chk + "]").prop("checked", true);
                            }
                        });
                    }
                    function location_instant_search() {
                        $('.loc_sear_rows').click(function () {
                            var item = $(this).text().trim();
                            $('#myInput').val(item);
                            $('#myTable').hide();

                        });
                    }
                    function show_property_specific_type(prop_type) {
                        var prop_type = $('#txt_property_type_id').val().trim();//this is the id 
                        var prop_type_name = $('#txt_property_type_name').val().trim();//this is the prop_type name
                        var prop_type_cat = prop_type_name.trim();

                        $.post('../Admin/handler.php', {prop_type_cat: prop_type_cat}, function (data) {
                            $('#my_cat_res').show().html(data);
                            $('#property_subCat_label').show();

                            $('#combo_tofill').empty();
                            //                $('#combo_tofill').append('<option> -- Select the option -- </option>');
                            var final = $.parseJSON(data);
                            $.each(final, function (i, option) {
                                $('#combo_tofill').append($('<option/>').attr("value", option.id).text(option.name));
                            });
                        });
                        var prop_cat = $('#update_txt_property_cat_id').val();

                        $('.combo_property_type').val(prop_type);
                        if (prop_type == 8) {//this is the basic partment of the house
                            $('.aparts_rows').slideDown(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideUp(200);
                            var furnished = $('#update_txt_aprt_furnished').val();
                            $('#apart_furnished').val(furnished);
                            display_relative_features(prop_type);
                        } else if (prop_type == 9) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideDown();
                            $('.development_rows').slideUp(200);
                            var furnished = $('#basic_commercial_frunished').val();
                            $('#txt_comm_furnished').val(furnished);
                            display_relative_features(prop_type);
                        } else if (prop_type == 10) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideDown(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideUp(200);
                            var furnished_comm = $('#basic_house_frunished').val();
                            $('#txt_house_furnished').val(furnished_comm);
                            display_relative_features(prop_type);
                        } else if (prop_type == 11) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideDown(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideUp(200);
                            display_relative_features(prop_type);
                        } else if (prop_type == 12) {
                            $('.aparts_rows').slideUp(200);
                            $('.house_rows').slideUp(200);
                            $('.land_rows').slideUp(200);
                            $('.commercial_rows').slideUp();
                            $('.development_rows').slideDown();
                        }
                    }

                </script>
                <script type = "text/javascript">
                    function initMap() {
                        var myLatLng = {lat: -1.9706, lng: 30.1044};
                        var map = new google.maps.Map(document.getElementById('map'), {
                            zoom: 15,
                            center: myLatLng
                        });
                        var marker = new google.maps.Marker({
                            position: myLatLng,
                            map: map,
                            title: 'Disired location'
                        });
                    }
                </script>
                <script async defer
                        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
                </script>
            </body>
        </html><?php
    }

    function empty_html() {
        ?>
        <html>
            <head>
                <title>New listing</title>
                <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
                <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>

            </head>
            <body class="wiz_body">
                <?php
                include './Admin_header.php';
                $obj_load = new Page_load();
                ?> 
                <input type="hidden"  class="left_off_eighty " id="txt_process" name="txt_process" />
                <input type="hidden" class="textbox  left_off_eighty " placeholder="changes, currently you are adding/changing property" name="txt_changes" id="txt_changes"   />
                <input type="hidden" class="parts left_off_eighty" id="data_found"/>   
                <input type = "hidden" class = "textbox left_off_eighty" placeholder = "property type" name = "txt_property_type_id"  id = "txt_property_type_id">
                <div class="parts eighty_centered no_paddin_shade_no_Border">
                    <div class="parts link_cursor wizard_steps" id="wiz_1"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon1"></div>1 PROPERTY DESCRIPTION</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_2"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon2"></div>2 PRICE</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_3"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon3"></div>3 LOCATION</div>
                    <div class="parts link_cursor wizard_steps" id="wiz_4"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon4"></div>4 ATTACHMENTS(IMAGES)</div>
                    <div class="parts off" id="counter">
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border " id="wiz_step1">
                    <?php include './new_listing.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border off" id="wiz_step2">
                    <?php include './new_price.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border off" id="wiz_step3"  >
                    <?php include './new_property_location.php'; ?>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  off" id="wiz_step4">
                    <?php include './new_image.php'; ?>
                </div>
                <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
                <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
                <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
                <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script> 
                <script>
                    $(document).ready(function () {
                        try {
                            var progress = $('#txt_process').val();
                            //                            $('.aparts_rows').slideUp();
                            //                            $('.house_rows').slideUp();
                            //                            $('.land_rows').slideUp();
                            $('.date_pick').datepicker({
                                dateFormat: 'yy-mm-dd',
                                minDate: new Date()
                            });
                            get_uncomplete_steps();
                            $('.warning').animate({marginTop: '100'}, 600);
                            $('#wiz_1').unbind('click').click(function () {
                                try {
                                    wiz_step1();
                                    if (progress != 'complete') {
                                        $('#Editing_mode').val(progress);
                                    }
                                } catch (err) {
                                    alert('wiz one: ' + err.message);
                                }
                            });
                            $('#wiz_2').unbind('click').click(function () {
                                var the_step = $('#txt_process').val().trim();
                                if (progress != 'complete') {
                                    $('#Editing_mode_price').val(progress);
                                }
                                if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
                                    wiz_step2();
                                    toggle_rent_sale_price();
                                }
                                if (the_step == 'location' || the_step == 'image') {
                                    wiz_step2();
                                    // $('#txt_utilities_extra_per_day').val($('#update_price_utilities_extra_per_day').val());
                                    var utilities_chk = 'c';
                                    toggle_rent_sale_price();
                                }
                            });
                            $('#wiz_3').unbind('click').click(function () {
                                var the_step = $('#txt_process').val().trim();
                                var changes = $('#changes').val();
                                if (progress != 'complete') {
                                    $('#Editing_mode').val(progress);
                                }
                                if (the_step == 'location' || the_step == 'image') {
                                    wiz_step3();
                                    $('#Editing_mode').val('update');
                                }
                                if (the_step == 'image') {
                                    var cell, sector, district, province, long, lat, area;
                                    var address, cell_name;
                                    cell = $('#updateLoc_txt_cell_id').val();
                                    cell_name = $('#updateLoc_txt_cell_name').val();
                                    sector = $('#updateLoc_txt_sector_id').val();
                                    district = $('#updateLoc_txt_district_id').val();
                                    province = $('#updateLoc_txt_province_id').val();
                                    long = $('#updateLoc_txt_loc_long').val();
                                    lat = $('#updateLoc_txt_loc_lat').val();
                                    area = $('#updateLoc_txt_area').val();
                                    address = $('#updateLoc_txt_address').val();
                                    $('#txt_cell_id').val(cell);
                                    $('#txt_loc_lat').val(lat);
                                    $('#txt_new_listing_area').val(area);
                                    $('#txt_loc_lng').val(long);
                                    $('#txt_addressf').val(address);
                                    $('#chosen_province').html(province);
                                    $('#chosen_district').html(district);
                                    $('#chosen_sector').html(sector);
                                    $('#chosen_cell').html(cell_name); // this is the cell name for user
                                    $('#txt_cell_id').html(cell_name); //this is the cell id for db

                                    $('#loc_all_prov').slideUp(300);
                                    $('#loc_all_distr').slideUp(300);
                                    $('#loc_all_sectors').slideUp(300);
                                    $('#loc_all_cells').slideUp(300);
                                }

                            });
                            $('#wiz_4').unbind('click').click(function () {
                                var the_step = $('#txt_process').val().trim();
                                var changes = $('#changes').val();
                                if (the_step == 'image') {
                                    wiz_step4();
                                }
                                $('#Editing_mode').val('update');
                            });
                        } catch (err) {
                            alert(err.message);
                        }
                    });
                    function wiz_step1() {
                        $("#wiz_step1").show("drop", {direction: "down"}, 600);
                        $('#wiz_step2').hide();
                        $('#wiz_step3').hide();
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_1').css('border-color', '#000086');
                        $('#wiz_1').css('background-color', '#fff');
                    }
                    function wiz_step2() {
                        $('#wiz_step1').hide();
                        $("#wiz_step2").show("drop", {direction: "down"}, 600);
                        $('#wiz_step3').hide();
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_2').css('border-color', '#000086');
                        $('#wiz_2').css('background-color', '#fff');
                        toggle_rent_sale_price();
                    }
                    function wiz_step3() {
                        $('.aparts_rows').hide();
                        $('.commercial_rows').hide();
                        $('.development_rows').hide();
                        $('#wiz_step1').hide();
                        $('#wiz_step2').hide();
                        $("#wiz_step3").show("drop", {direction: "down"}, 600);
                        $('#wiz_step4').hide();
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_3').css('border-color', '#000086').css('background-color', '#fff');
                    }
                    function wiz_step4() {
                        $('#wiz_step1').hide();
                        $('#wiz_step2').hide();
                        $('#wiz_step3').hide();
                        $("#wiz_step4").show("drop", {direction: "down"}, 600);
                        $('.wizard_steps').css('background-color', 'transparent');
                        $('.wizard_steps').css('border-color', '#fff');
                        $('#wiz_4').css('border-color', '#000086');
                        $('#wiz_4').css('background-color', '#fff');
                    }
                    function toggle_rent_sale_price() {
                        //this displays the fields of square meter, on price wizard step
                        var listing_type = '';
                        var listing_type = $('#listing_type').val().trim();
                        var listing_type = (prop_type != '') ? prop_type : propertt_type_new;
                        if (listing_type == 1) {
                            $('#equivalent_price_day').show();
                            $('#currency_amount').show();
                        } else {
                            $("#hide_amount_day").hide();
                            $('#equivalent_price_day').hide();
                            $('#currency_amount').hide();
                        }
                    }
                    function get_uncomplete_steps() {
                        check_previous_step();
                    }
                    function check_previous_step() {
                        initialize_page(); //where it initializes the combo boxes of property types, category and features.
                        var the_step = $('#txt_process').val().trim();
                        if (the_step == 'price') {
                            wiz_step2();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                            tick_finished_steps('price');
                        } else if (the_step == 'location') {
                            wiz_step3();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                            tick_finished_steps('location');
                        } else if (the_step == 'image') {
                            wiz_step4();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                            tick_finished_steps('image');
                        } else {
                            wiz_step1();
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                        }
                        $('#remove_previous_listing').click(function () {
                            var last_listing = 'c';
                            $.post('../Admin/handler.php', {last_listing: last_listing}, function (data) {
                                $('#d').html(data);
                                working_listing_id = $('#d').text().trim();
                            }).complete(function () {
                                var lising_delete = working_listing_id;
                                $.post('../Admin/handler.php', {lising_delete: lising_delete}, function (data) {
                                }).complete(function () {
                                    window.location.replace('http://localhost/Restate/Admin/redirect.php');
                                });
                            });
                        });
                        $('#complete_prev_listing').click(function () {
                            if (the_step == 'price') {
                                wiz_step2();
                            } else if (the_step == 'location') {
                                wiz_step3();
                            } else if (the_step == 'image') {
                                wiz_step4();
                            } else {
                                wiz_step1();
                            }
                            $('.warning').slideUp(10);
                            $('.wizard_steps').slideDown(200);
                        });
                    }
                    function tick_finished_steps(current_step) {
                        if (current_step == 'price') {
                            $('.step_icons').removeClass('tick');
                            $('#step_icon1').addClass('tick');
                        } else if (current_step == 'location') {
                            $('.step_icons').removeClass('tick');
                            $('#step_icon1').addClass('tick');
                            $('#step_icon2').addClass('tick');
                        } else if (current_step == 'image') {
                            $('.step_icons').removeClass('tick');
                            $('#step_icon1').addClass('tick');
                            $('#step_icon2').addClass('tick');
                            $('#step_icon3').addClass('tick');
                        }
                    }
                    function toggle_rent_sale_price() {
                        //this displays the fields of square meter, on price wizard step
                        var listing_type = '';
                        var prop_type = $('#txt_property_type_id').val().trim();
                        var propertt_type_new = '';
                        if (listing_type == '') {
                            propertt_type_new = $('#txt_update_listing_type').val().trim();
                            var listing_type = propertt_type_new;
                        } else {
                            propertt_type_new = $('#listing_type').val().trim();
                            var listing_type = propertt_type_new;
                        }
                        if (propertt_type_new == 1) {
                            $('#hide_amount_day').show();
                            $('#equivalent_price_day').show();
                            $('#currency_amount').show();
                            $('.hidable_row_prc_sqr_meter').hide();
                        } else {
                            $("#hide_amount_day").hide();
                            $('#equivalent_price_day').hide();
                            $('#currency_amount').hide();
                        }
                    }
                    function initialize_page() {
                        //var chosen_update =<?php //echo $res = (empty($_SESSION['complete_updating'])) ? '' : $_SESSION['complete_updating'];                                                                                                                                                                                                                   ?>;

                        $('.list_type_combo').val($('#txt_update_listing_type').val());
                        var the_step = $('#txt_process').val().trim();
                        var prop_type = $('#txt_property_type_id').val().trim();
                        var prop_cat = $('#update_txt_property_cat_id').val();
                        $('.combo_property_type').val(prop_type);
                        if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
                            $('#property_subCat_label').show();
                            $('#my_cat_res').show();
                            if (prop_type == 8) {//this is the basic partment of the house
                                $('.aparts_rows').slideDown(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideUp(200);

                                var furnished = $('#update_txt_aprt_furnished').val();
                                $('#apart_furnished').val(furnished);
                                display_relative_features(prop_type);
                            } else if (prop_type == 9) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideDown();
                                $('.development_rows').slideUp(200);
                                display_relative_features(prop_type);
                            } else if (prop_type == 10) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideDown(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideUp(200);
                                display_relative_features(prop_type);
                            } else if (prop_type == 11) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideDown(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideUp(200);
                                display_relative_features(prop_type);
                            } else if (prop_type == 12) {
                                $('.aparts_rows').slideUp(200);
                                $('.house_rows').slideUp(200);
                                $('.land_rows').slideUp(200);
                                $('.commercial_rows').slideUp();
                                $('.development_rows').slideDown();
                            }
                            //                            $(".pro_cat_data_item:contains(" + prop_cat + ")").css("background-color", "#ff6666").css('color', '#fff');
                            $('#combo_tofill').val(prop_cat);
                        }
                        if (the_step == 'location' || the_step == 'image') {
                            $('#wiz_step3').hide();
                            //<editor-fold defaultstate="collapsed" desc="---price utilities-------">
                            var c2 = $('#checked_utils').text().trim();
                            var parsed2 = $.parseJSON(c2);
                            var arr2 = [];
                            for (var x in parsed2) {
                                arr2.push(parsed2[x]);
                            }
                            for (var i2 = 0; i2 < arr2.length; i2++) {
                                var chk2 = arr2[i2].trim();
                                $('#utilities_box').find("input[type=checkbox][value=" + chk2 + "]").prop("checked", true);
                            }
                            //</editor-fold>

                            //<editor-fold defaultstate="collapsed" desc="------currency -------">
                            $('#txt_month_currency').val($('#curr_month').val());
                            $('#perSqaure_select').val($('#curr_day').val());
                            $('#txt_month_currency').val($('#curr_day').val());
                            $('#amount_day_select').val($('#curr_day').val());
                            //</editor-fold>
                        }

                    }
                    function display_relative_features(prop_type) {
                        var features_by_prop_type = $('.combo_property_type option:selected').val().trim();
                        $.post('handler.php', {features_by_prop_type: features_by_prop_type}, function (data) {
                            $('#features_box').html(data);
                        }).complete(function () {
                            var features_by_prop_type = prop_type;
                            var features_last_listing = 'c';
                            var changes = $('#data_found').val().trim();
                            var c = $('#d').text().trim();
                            var parsed = $.parseJSON(c);
                            //      $("#" + data[i]).attr("checked", "checked");
                            var arr = [];
                            for (var x in parsed) {
                                arr.push(parsed[x]);
                            }
                            for (var i = 0; i < arr.length; i++) {
                                console.log(arr[i]);
                                var chk = arr[i].trim();
                                //                $(":checkbox[value=" + chk + "]").prop("checked", "true");
                                $("#features_box").find("input[type=checkbox][value=" + chk + "]").prop("checked", true);
                            }


                        });
                    }

                </script>

            </body>
        </html><?php
    }

}
