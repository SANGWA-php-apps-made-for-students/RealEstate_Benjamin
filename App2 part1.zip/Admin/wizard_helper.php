<?php
require_once '../web_db/updates.php';
require_once '../web_db/multi_values.php';

class wizard_helper {

    function page_load_freshPage() {
        //this means that there is no session. the user had closed the web browser
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $last_lst_id = $obj->get_lastlisting();
        $last_lst_acc = $obj->get_last_listing_account();
        $last_lst_date = $obj->get_last_listing_title();
        $last_lst_type = $obj->get_last_listing_type();
        $last_lst_prop_type = $obj->get_last_listing_prop_type_by_listing_id();
        $last_lst_prop_cat = $obj->get_last_listing_prop_cat_noDiv(); //this is just the id
        $last_lst_prop_cat_name = $obj->get_property_cat_name_by_property_cat_id($last_lst_prop_cat);
        $last_lst_title = $obj->get_last_listing_title();
        $last_lst_location = $obj->get_last_listing_location();
        $last_lst_purpose = $obj->get_last_listing_purpose();
        $last_lst_desc = $obj->get_last_listing_desc();
        $last_descriptioon = $obj->get_last_description();
        ?>
        <input type = "hidden" placeholder = "the account kept" id = "update_listing_id" name = "working_listing" value = "<?php echo $last_lst_id; ?>" />
        <input type = "hidden" placeholder = "the account kept" id = "update_account" name = "update_account" value = "<?php echo $last_lst_acc; ?>" />
        <input type = "hidden" placeholder = "the listing type kept" id = "update_listing_type" name = "update_listing_type" value = "<?php echo $last_lst_type; ?>" />
        <input type = "hidden" placeholder = "the title kept" id = "update_title" name = "update_title" value = "<?php echo $last_lst_title; ?>" />
        <input type = "hidden" placeholder = "the desc kept" id = "update_description" name = "update_description" value = "<?php echo strip_tags($last_descriptioon); ?>" />
        <input type = "hidden" placeholder = "the purpose kept" id = "update_purpose" name = "update_purpose" value = "<?php echo $last_lst_purpose; ?>" />
        <input type = "hidden" placeholder = "property type" name = "update_property_type_id" id="update_property_type_id" value="<?php echo $last_lst_prop_type; ?>" >
        <input type = "hidden" placeholder = "the property cat kept" id = "update_property_category" name = "update_property_category" value = "<?php echo $last_lst_prop_cat; ?>" />
        <input type = "hidden" placeholder = "the property cat kept" id = "update_property_category_name" name = "update_property_category_name" value = "<?php echo $last_lst_prop_cat_name; ?>" />
        <?php
        if ($last_lst_prop_type == 8) {
            $last_bas_aprt_bedroom = $obj->get_last_bedroom_apartment();
            $last_bas_aprt_bathroom = $obj->get_last_bathrooms_apartment();
            $last_bas_aprt_flor_no = $obj->get_last_floor_number_apartment();
            $last_bas_aprt_tot_flor = $obj->get_last_total_floor_nbr_apartment();
            $last_bas_aprt_furnished = $obj->get_last_furnished_apartment();
            ?>
            <input type = "hidden" placeholder = "the basic aprt bedroom cat kept" id = "update_basic_aprt_bedrooms" name = "update_bas_apart_bedroom" value = "<?php echo $last_bas_aprt_bedroom; ?>" />
            <input type = "hidden" placeholder = "the basic aprt bathroom cat kept" id = "update_basic_aprt_bathrooms" name = "update_bas_apart_bathroom" value = "<?php echo $last_bas_aprt_bathroom; ?>" />
            <input type = "hidden" placeholder = "the basic aprt flor n"                   id = "update_basic_aprt_flor_no" name = "update_bas_apart_floor_no" value = "<?php echo $last_bas_aprt_flor_no; ?>" />
            <input type = "hidden" placeholder = "the basic aprt tot flor  " id = "update_basic_aprt_tot_no" name = "update_bas_apart_tot_floor" value = "<?php echo $last_bas_aprt_tot_flor; ?>" />
            <input type = "hidden" placeholder = "the basic aprt furnished  " id = "update_basic_aprt_furnished" name = "update_bas_apart_furnished" value = "<?php echo $last_bas_aprt_furnished; ?>" />
            <?php
        } else if ($last_lst_prop_type == 9) {
            $last_basic_comm_bedroom = $obj->get_last_basic_commercial_bedroom();
            $last_basic_comm_bathroom = $obj->get_last_basic_commercial_bathroom();
            $last_basic_comm_compound_size = $obj->get_last_basic_commercial_compound_size();
            $last_basic_comme_living_flors = $obj->get_last_basic_commercial_living_flors();
            $last_basic_comm_totaln_flors = $obj->get_last_basic_commercial_totalnumber_flors();
            $last_basic_comm_furnished = $obj->get_last_basic_commercial_furnished();
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "basic_comm_bedrooms" name = "basic_comm_bedrooms" value = "<?php echo $last_basic_comm_bedroom; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_comm_bathrooms" name = "update_basic_comm_bathrooms" value = "<?php echo $last_basic_comm_bathroom; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_comm_compound_size" name = "update_basic_comm_compound_size" value = "<?php echo $last_basic_comm_compound_size; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_comm_living_flor" name = "update_basic_comm_living_flor" value = "<?php echo $last_basic_comme_living_flors; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_comm_total_noFlor" name = "basic_comm_total_noFlor" value = "<?php echo $last_basic_comm_totaln_flors; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_last_basic_comm_furnished" name = "basic_last_basic_comm_furnished" value = "<?php echo $last_basic_comm_furnished; ?>" />
            <?php
        } else if ($last_lst_prop_type == 10) {
            $last_basic_house_furnished = $obj->get_last_furnished_house();
            $last_basic_house_available = $obj->get_last_available_house();
            $last_basic_house_bedroom = $obj->get_last_bedroom_house();
            $last_basic_house_bathroom = $obj->get_last_bathroom_house();
            $last_basic_house_comp_size = $obj->get_last_compound_size_house();
            $last_basic_house_living_flors = $obj->get_last_living_floors_house();
            $last_basic_house_tot_n_floors = $obj->get_last_total_number_floors_house();
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_house_furnished" name = "update_basic_house_furnished" value = "<?php echo $last_basic_house_furnished; ?>" />
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_available_from" name = "update_basic_available_from" value = "<?php echo $last_basic_house_available; ?>" />
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_house_bedrooms" name = "update_basic_house_bedrooms" value = "<?php echo $last_basic_house_bedroom; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_house_bathrooms" name = "update_basic_house_bathrooms" value = "<?php echo $last_basic_house_bathroom; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_house_compound_size" name = "update_basic_house_compound_size" value = "<?php echo $last_basic_house_comp_size; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_house_living_floor" name = "update_basic_house_living_floor" value = "<?php echo $last_basic_house_living_flors; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_total_number_floors" name = "update_basic_total_number_floors" value = "<?php echo $last_basic_house_tot_n_floors; ?>" />
            <?php
        } else if ($last_lst_prop_type == 11) {
            $basic_administrative_location = $obj->get_last_admin_loc_land();
            $basic_land_plot_no = $obj->get_last_plotno_land();
            $basic_land_plot_size = $obj->get_last_plotsize_land();
            $basic_lot_use = $obj->get_last_lotuse_land();
            $basic_land_available_from = $obj->get_last_available_land();
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_administrative_location" name = "update_basic_administrative_location" value = "<?php echo $basic_administrative_location; ?>" />
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_land_plot_no" name = "update_basic_land_plot_no" value = "<?php echo $basic_land_plot_no; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_land_plot_size" name = "update_basic_land_plot_size" value = "<?php echo $basic_land_plot_size ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_lot_use" name = "update_basic_lot_use" value = "<?php echo $basic_lot_use; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_land_available_from" name = "update_basic_land_available_from" value = "<?php echo $basic_land_available_from; ?>" />
            <?php
        } else if ($last_lst_prop_type == 12) {
            $basic_administrative_location = $obj->get_last_admin_loc_land();
            $basic_land_plot_no = $obj->get_last_plotno_land();
            $basic_land_plot_size = $obj->get_last_plotsize_land();
            $basic_lot_use = $obj->get_last_lotuse_land();
            $basic_land_available_from = $obj->get_last_available_land();
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_dev_bedrooms" name = "updatebasic_dev_bedrooms" value = "<?php echo $_SESSION['basic_dev_bedrooms']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_dev_bathrooms" name = "update_basic_dev_bathrooms" value = "<?php echo $_SESSION['basic_dev_bathrooms']; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_dev_compound_size" name = "update_basic_dev_compound_size" value = "<?php echo $_SESSION['basic_dev_compound_size']; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_dev_living_flor" name = "update_basic_dev_living_flor" value = "<?php echo $_SESSION['basic_dev_living_flor']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_dev_total_N_Floo" name = "update_basic_dev_total_N_Floo" value = "<?php echo $_SESSION['basic_dev_total_N_Floo']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_dev_furnished" name = "update_basic_dev_furnished" value = "<?php echo $_SESSION['basic_dev_furnished']; ?>" />
            <?php
        }
        ?>
        <input type = "hidden" placeholder = "the listing kept"       id = "update_listing_date"      name = "update_listing_date"      value = "<?php echo $last_lst_date ?>" />
        <input type = "hidden" placeholder = "the account kept"       id = "update_account"           name = "update_account"           value = "<?php echo $last_lst_acc; ?>" />
        <input type = "hidden" placeholder = "the listing type kept"  id = "update_listing_type"      name = "update_listing_type"      value = "<?php echo $last_lst_type; ?>" />
        <input type = "hidden" placeholder = "the title kept"         id = "update_title"             name = "update_title"             value = "<?php echo $last_lst_date; ?>" />
        <input type = "hidden" placeholder = "the desc kept"          id = "update_description"       name = "update_description"       value = "<?php echo $last_lst_desc; ?>" />
        <input type = "hidden" placeholder = "the purpose kept"       id = "update_purpose"           name = "update_purpose"           value = "<?php echo $last_lst_purpose; ?>" />
        <input type = "hidden" placeholder = "the property type kept" id = "update_property_type"     name = "update_property_category" value = "<?php echo $last_lst_prop_type; ?>" />
        <input type = "hidden" placeholder = "the property cat kept"  id = "update_property_category" name = "update_property_category" value = "<?php echo $last_lst_prop_cat; ?>" />
        <?php
    }

    function page_load_existing() {
        ?>
        <input type = "hidden" placeholder = "the account kept" id = "update_account" name = "update_account" value = "<?php echo $_SESSION['account']; ?>" />
        <input type = "hidden" placeholder = "the listing type kept" id = "update_listing_type" name = "update_listing_type" value = "<?php echo $_SESSION['listing_type']; ?>" />
        <input type = "hidden" placeholder = "the title kept" id = "update_title" name = "update_title" value = "<?php echo $_SESSION['title']; ?>" />
        <input type = "hidden"   placeholder = "the desc kept" id = "update_description" name = "update_description" value = "<?php echo strip_tags($_SESSION['last_descriptioon']); ?>" />
        <input type = "hidden" placeholder = "the purpose kept" id = "update_purpose" name = "update_purpose" value = "<?php echo $_SESSION['purpose']; ?>" />
        <input type = "hidden" placeholder = "the property cat kept" id = "update_property_category" name = "update_property_category" value = "<?php echo $_SESSION['property_category']; ?>" />
        <input type = "hidden" placeholder = "property type id" name = "update_property_type_id" id="update_property_type_id" value="<?php echo $_SESSION['property_type_id']; ?>" >
        <?php
        $prop_type = $_SESSION['property_type_id'];
        if ($prop_type == 8) {
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_aprt_bedrooms" name = "update_basic_aprt_bedrooms" value = "<?php echo $_SESSION['basic_aprt_bedrooms']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_aprt_bathrooms" name = "update_basic_aprt_bathrooms" value = "<?php echo $_SESSION['basic_aprt_bathrooms']; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_aprt_flor_no" name = "update_basic_aprt_flor_no" value = "<?php echo $_SESSION['basic_aprt_flor_no']; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_aprt_tot_no" name = "update_basic_aprt_tot_no" value = "<?php echo $_SESSION['basic_aprt_tot_no']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_aprt_furnished" name = "update_basic_aprt_furnished" value = "<?php echo $_SESSION['basic_aprt_furnished']; ?>" />
            <?php
        } else if ($prop_type == 9) {
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "basic_comm_bedrooms" name = "basic_comm_bedrooms" value = "<?php echo $_SESSION['basic_comm_bedrooms']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_comm_bathrooms" name = "update_basic_comm_bathrooms" value = "<?php echo $_SESSION['basic_comm_bathrooms']; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_comm_compound_size" name = "update_basic_comm_compound_size" value = "<?php echo $_SESSION['basic_comm_compound_size']; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_comm_living_flor" name = "update_basic_comm_living_flor" value = "<?php echo $_SESSION['basic_comm_living_flor']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_comm_total_noFlor" name = "basic_comm_total_noFlor" value = "<?php echo $_SESSION['basic_comm_total_noFlor']; ?>" />
            <?php
        } else if ($prop_type == 10) {
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_house_furnished" name = "update_basic_house_furnished" value = "<?php echo $_SESSION['update_basic_house_furnished']; ?>" />
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_available_from" name = "update_basic_available_from" value = "<?php echo $_SESSION['basic_available_from']; ?>" />
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_house_bedrooms" name = "update_basic_house_bedrooms" value = "<?php echo $_SESSION['basic_house_bedrooms']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_house_bathrooms" name = "update_basic_house_bathrooms" value = "<?php echo $_SESSION['basic_house_bathrooms']; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_house_compound_size" name = "update_basic_house_compound_size" value = "<?php echo $_SESSION['basic_house_compound_size']; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_house_living_floor" name = "update_basic_house_living_floor" value = "<?php echo $_SESSION['basic_house_living_floor']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_total_number_floors" name = "update_basic_total_number_floors" value = "<?php echo $_SESSION['basic_total_number_floors']; ?>" />
            <?php
        } else if ($prop_type == 11) {
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_administrative_location" name = "update_basic_administrative_location" value = "<?php echo $_SESSION['basic_administrative_location']; ?>" />
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_land_plot_no" name = "update_basic_land_plot_no" value = "<?php echo $_SESSION['basic_land_plot_no']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_land_plot_size" name = "update_basic_land_plot_size" value = "<?php echo $_SESSION['basic_land_plot_size']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_lot_use" name = "update_basic_lot_use" value = "<?php echo $_SESSION['basic_lot_use']; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_land_available_from" name = "update_basic_land_available_from" value = "<?php echo $_SESSION['basic_land_available_from']; ?>" />
            <?php
        } else if ($prop_type == 12) {
            ?>
            <input type = "hidden" placeholder = "the account kept" id = "update_basic_dev_bedrooms" name = "updatebasic_dev_bedrooms" value = "<?php echo $_SESSION['basic_dev_bedrooms']; ?>" />
            <input type = "hidden" placeholder = "the listing type kept" id = "update_basic_dev_bathrooms" name = "update_basic_dev_bathrooms" value = "<?php echo $_SESSION['basic_dev_bathrooms']; ?>" />
            <input type = "hidden" placeholder = "the title kept" id = "update_basic_dev_compound_size" name = "update_basic_dev_compound_size" value = "<?php echo $_SESSION['basic_dev_compound_size']; ?>" />
            <input type = "hidden" placeholder = "the desc kept" id = "update_basic_dev_living_flor" name = "update_basic_dev_living_flor" value = "<?php echo $_SESSION['basic_dev_living_flor']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_dev_total_N_Floo" name = "update_basic_dev_total_N_Floo" value = "<?php echo $_SESSION['basic_dev_total_N_Floo']; ?>" />
            <input type = "hidden" placeholder = "the purpose kept" id = "update_basic_dev_furnished" name = "update_basic_dev_furnished" value = "<?php echo $_SESSION['basic_dev_furnished']; ?>" />
            <?php
        }
    }

    function save_new_listing() {
        try {
            if (!empty($_POST['txt_listing_type'])) {
                require_once '../web_db/new_values.php';
                require_once './dbConnection.php';
                $con = new my_connection();
                $account = $_SESSION['userid'];
                $listing_date = date("y-m-d");
                $listing_type = $_POST['txt_listing_type'];
                $_SESSION['my_listing_type'] = $listing_type;
                $title = trim($_POST['txt_title']);
                $description = $_POST['txt_desc'];
                $basic_info = $_POST['house_or_land'];
                $property_type_id = '8';
                $property_category = $_POST['txt_property_cat_id'];
                //property  category  
                $purpose = $listing_type;
                $obj = new new_values();
                $prop_type = trim($_POST['txt_prop_name']);
                if (empty($prop_type)) {
                    ?><script>alert('You have to specify the property type');</script><?php
                } else if ((empty($property_category) || $property_category < 1 ) && $prop_type != 'Development') {
                    ?><script>alert('You have to specify the property category');</script><?php
                } else if (empty($title)) {
                    ?><script>alert('You have to specify the property Title');</script><?php
                } else {
                    $this->save_listing($listing_date, $account, $listing_type, $property_type_id, $title, $description, $purpose, $prop_type, $property_category);
                }
                ?>
                <script>
                //                     window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
                    window.location.replace('http://localhost/REstate/Admin/redirect.php');
                </script>
                <?php
            } else {
                ?><script>alert('You have to choose the listing type');</script><?php
            }
        } catch (PDOException $e) {
            echo 'Error while saving data! ' . $e->getMessage();
        }
    }

    function update_existing_listing($listing) { //last l
        require_once './dbConnection.php';

        //fot the listing of the listing is not fresh we
        $listing_type = (!empty($_POST['txt_listing_type'])) ? $_POST['txt_listing_type'] : trim($_POST['update_listing_type']);
        $title = $_POST['txt_title'];
        $description = $_POST['txt_desc'];
        $basic_info = '';
        $property_type_id = $_POST['txt_property_type_id'];
        $prop_type = $_POST['cbo_property_name'];
        $property_category = (!empty($_POST['txt_property_cat_id'])) ? $_POST['txt_property_cat_id'] : $_POST['update_txt_property_cat_id'];
        $purpose = $listing_type;
        require_once '../web_db/multi_values.php';
        require_once '../web_db/deletions.php';
        require_once '../web_db/new_values.php';
        $del = new deletions();
        $new = new new_values();
        $mul = new multi_values();
        $list_id = $listing;

        $_SESSION['last_descriptioon'] = $description;
        // <editor-fold defaultstate="collapsed" desc="----for reserve data only-----">
        $account = $_SESSION['userid'];
        $today_date = $mul->get_last_listing_date();
        $obj = new updates();
        $prop_name = $mul->get_property_type_name_by_prop_name($prop_type); //this is the property type name of the last listing
        if (!empty($_SESSION['complete_updating'])) {
            $list_id = $list_id;
            $del->deleteFrom_listing_features($list_id);
            $obj->update_listing($listing_type, $title, $description, $purpose, $property_category, $list_id);
            $this->get_save_features($prop_type, $listing);
        } else {
            if ($mul->get_last_listing_prop_type_by_listing_id() != $prop_type) {
                $propLast = $mul->get_last_listing_prop_type_by_listing_id();
                $this->delete_basic_info_by_listing($propLast, $listing); //the listing may be a specific (chosen) listing id or the last
                //update with the new basic info and new features
                $list_id = $list_id;
                $del->deleteFrom_listing_features($list_id);
                $obj->update_listing($listing_type, $title, $description, $purpose, $property_category, $list_id);
                $this->get_save_features($prop_type, $listing); //here wee save the features and the basic information
//                $this->delete_feature_by_listingid($listing); // the listin is a chosen 
                ?><script>alert('<?php echo $listing . ' protype: ' . $propLast . ' '; ?>This is the listing that is going to be deleted!!');</script><?php
            } else {
                $list_id = $list_id;
                $del->deleteFrom_listing_features($list_id);
                $obj->update_listing($listing_type, $title, $description, $purpose, $property_category, $list_id);
                //  $this->reserve_data_listing($today_date, $account, $listing_type, $title, $description, $purpose, $property_category, $prop_type);
                $this->get_save_features($prop_type, $listing); //here wee save the features and the basic information
            }
        }
        ?>
        <script>
            window.location.replace('http://localhost/Restate/Admin/redirect.php');
        </script>
        <?php
    }

    function get_save_features($prop_type, $list_id) {
        $new = new new_values();
        if ($prop_type == 8) {
            if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                $features = $_POST['features'];
                foreach ($features as $feat) {
                    $new->new_listing_features($list_id, $feat);
                }
            }
            $this->get_basic_aprt_update();
            unset($_SESSION['sess_array']);
        } else if ($prop_type == 10) {
            if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                $features = $_POST['features'];
                foreach ($features as $feat) {
                    $new->new_listing_features(trim($list_id), trim($feat));
                }unset($_SESSION['sess_array']);
            }
            $this->get_basic_house_update();
        } else if ($prop_type == 11) {
            if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                $features = $_POST['features'];
                foreach ($features as $feat) {
                    $new->new_listing_features($list_id, $feat);
                }unset($_SESSION['sess_array']);
            }
            $this->get_basic_land_update();
        } else if ($prop_type == 9) {
            if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                $features = $_POST['features'];
                foreach ($features as $feat) {
                    $new->new_listing_features($list_id, $feat);
                }unset($_SESSION['sess_array']);
            }
            $this->get_basic_comm_update();
        } else if ($prop_type == 12) {
            if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                $features = $_POST['features'];
                foreach ($features as $feat) {
                    $new->new_listing_features($list_id, $feat);
                }unset($_SESSION['sess_array']);
            }
            $this->get_basic_dev_update();
        }
    }

    function clear_all_sessions() {

//        }
    }

    // <editor-fold defaultstate="collapsed" desc="-------------update basic info----------">
    function get_basic_aprt_update() {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = (!empty($_SESSION['complete_updating'])) ? $_SESSION['complete_updating'] : 0;

        $basic_apartmentdeleted = 'no';
        $mul_obj = new multi_values();
        $listing = $mul_obj->get_lastlisting();
        $bedrooms = $_POST['txt_aprt_bedrooms'];
        $bathrooms = $_POST['txt_aprt_bathrooms'];
        $floor_number = $_POST['txt_aprt_floor_number'];
        $total_number_floors = $_POST['txt_aprt_total_number_floors'];
        $furnished = $_POST['txt_aprt_furnished'];
        $upd_obj = new updates();
        $mult = new multi_values();
        $aprt_id = (!empty($_SESSION['complete_updating'])) ? $chosenid->get_chosen_apartment_id($id) : $mult->get_lastbasic_apartment();
        $upd_obj->update_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished, $aprt_id);

        $_SESSION['basic_aprt_bedrooms'] = $bedrooms;
        $_SESSION['basic_aprt_bathrooms'] = $bathrooms;
        $_SESSION['basic_aprt_flor_no'] = $floor_number;
        $_SESSION['basic_aprt_tot_no'] = $total_number_floors;
        $_SESSION['basic_aprt_furnished'] = $furnished;
    }

    function get_basic_comm_update() {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = (!empty($_SESSION['complete_updating'])) ? $_SESSION['complete_updating'] : 0;

        $basic_commercialdeleted = 'no';
        $mul_obj = new multi_values();
        $listing = (!empty($_SESSION['complete_updating'])) ? $_SESSION['complete_updating'] : trim($mul_obj->get_lastlisting());
        $furnished = trim($_POST['txt_comm_furnished']);
        $bedroom = ($_POST['txt_comm_bedroom'] > 0) ? $_POST['txt_comm_bedroom'] : 0;
        $bathroom = ($_POST['txt_comm_bathroom'] > 0) ? $_POST['txt_comm_bathroom'] : 0;
        $compound_size = ($_POST['txt_comm_compound_size'] > 0) ? $_POST['txt_comm_compound_size'] : 0;
        $living_floors = ($_POST['txt_comm_living_floors'] > 0) ? $_POST['txt_comm_living_floors'] : 0;
        $total_number_floors = ($_POST['txt_comm_total_number_floors'] > 0) ? $_POST['txt_comm_total_number_floors'] : 0;
        $upd_obj = new updates();
        $mult = new multi_values();
        $comm_id = (!empty($_SESSION['complete_updating'])) ? $chosenid->get_chosen_basic_commercial__id($id) : $mult->get_last_listing_basic_commercial();
        $upd_obj->update_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished, $comm_id);

        $_SESSION['basic_comm_bedrooms'] = $bedroom;
        $_SESSION['basic_comm_bathrooms'] = $bathroom;
        $_SESSION['basic_comm_compound_size'] = $compound_size;
        $_SESSION['basic_comm_living_flor'] = $living_floors;
        $_SESSION['basic_comm_total_noFlor'] = $total_number_floors;
    }

    function get_basic_house_update() {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = (!empty($_SESSION['complete_updating'])) ? $_SESSION['complete_updating'] : 0;

        $basic_housedeleted = 'no';
        $mul_obj = new multi_values();
        $listing = trim($mul_obj->get_lastlisting());
        $furnished = trim($_POST['txt_house_furnished']);
        $available_from = trim($_POST['txt_houae_available_from']);
        $bedroom = $_POST['txt_house_bedroom'];
        $bathroom = $_POST['txt_house_bathroom'];
        $compound_size = $_POST['txt_house_compound_size'];
        $living_floors = $_POST['txt_house_living_floors'];
        $total_number_floors = $_POST['txt_house_total_number_floors'];
        $upd_obj = new updates();
        $mult = new multi_values();
        $house_id = (!empty($_SESSION['complete_updating'])) ? $chosenid->get_chosen_house_id($id) : $mult->get_lastbasic_house();
        $upd_obj->update_basic_house($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $house_id);
        $_SESSION['update_basic_house_furnished'] = $furnished;
        $_SESSION['basic_available_from'] = $available_from;
        $_SESSION['basic_house_bedrooms'] = $bedroom;
        $_SESSION['basic_house_bathrooms'] = $bathroom;
        $_SESSION['basic_house_compound_size'] = $compound_size;
        $_SESSION['basic_house_living_floor'] = $living_floors;
        $_SESSION['basic_total_number_floors'] = $total_number_floors;
    }

    function get_basic_land_update() {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = (!empty($_SESSION['complete_updating'])) ? $_SESSION['complete_updating'] : 0;

        $basic_landdeleted = 'no';
        $mul_obj = new multi_values();
        $listing = $mul_obj->get_lastlisting();
        $administrative_location = trim($_POST['txt_administrative_location']);
        $plot_number = trim($_POST['txt_plot_number']);
        $plot_size = trim($_POST['txt_plot_size'] . ' ' . $_POST['plot_measure']);
        $lot_use = trim($_POST['txt_lot_use']);
        $available_from = trim($_POST['txt_land_available_from']);
        $upd_obj = new updates();
        $mult = new multi_values();
        $land_id = (!empty($_SESSION['complete_updating'])) ? $chosenid->get_chosen_land_id($id) : $mult->get_lastbasic_land();
        $upd_obj->update_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from, $land_id);

        $_SESSION['basic_administrative_location'] = $administrative_location;
        $_SESSION['basic_land_plot_no'] = $plot_number;
        $_SESSION['basic_land_plot_size'] = $plot_number;
        $_SESSION['basic_lot_use'] = $lot_use;
        $_SESSION['basic_land_available_from'] = $available_from;
    }

    function get_basic_dev_update() {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = (!empty($_SESSION['complete_updating'])) ? $_SESSION['complete_updating'] : 0;

        $basic_develop_id = (!empty($_SESSION['complete_updating'])) ? $chosenid->get_chosen_dev_id($id) : $mult->get_last_listing_basic_dev();
        $basic_developdeleted = 'no';
        $mul_obj = new multi_values();
        $listing = trim($mul_obj->get_lastlisting());
        $bedrooms = $_POST['txt_dev_bedroom'];
        $bathrooms = $_POST['txt_dev_bathroom'];
        $compound_size = $_POST['txt_dev_compound_size'];
        $living_floors = $_POST['txt_dev_living_floors'];
        $total_number_floors = $_POST['txt_dev_total_number_floors'];
        $furnished = $_POST['txt_dev_furnished'];
        $upd_obj = new updates();
        $upd_obj->update_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished, $basic_develop_id);
    }

// </editor-fold>

    function reserve_data($listing_date, $account, $listing_type, $title, $description, $purpose, $property_category, $prop_type) {
        $_SESSION['listing_date'] = $listing_date;
        $_SESSION['account'] = $account;
        $_SESSION['listing_type'] = $listing_type;
        $_SESSION['title'] = $title;
        $_SESSION['description'] = $description;
        $_SESSION['purpose'] = $purpose;
        $_SESSION['property_category'] = $property_category;
        $_SESSION['property_type_id'] = $prop_type = $_POST['cbo_property_name'];

        if ($prop_type == 'Apartment') {
            if (isset($_POST['feat_chosen'])) {
                $features = $_POST['features'];
                $feat_box = array();
                foreach ($features as $feat) {
                    $feat_box[] = $feat;
                }
            }
            $this->basic_aparts();
        } else if ($prop_type == 'House') {
            if (isset($_POST['feat_chosen'])) {
                $features = $_POST['features'];
                $feat_box = array();
                foreach ($features as $feat) {
                    $feat_box[] = $feat;
                }
            }
            basic_house();
        } else if ($prop_type == 'Land') {
            if (isset($_POST['feat_chosen'])) {
                $features = $_POST['features'];
                $feat_box = array();
                foreach ($features as $feat) {
                    $feat_box[] = $feat;
                }
            }
            basic_land();
        } else if ($prop_type == 'Commercial') {
            if (isset($_POST['feat_chosen'])) {
                $features = $_POST['features'];
                $feat_box = array();
                foreach ($features as $feat) {
                    $feat_box[] = $feat;
                }
            }
            basic_commercial();
        } else if ($prop_type == 'Development') {
            if (isset($_POST['feat_chosen'])) {
                $features = $_POST['features'];
                $feat_box = array();
                foreach ($features as $feat) {
                    $feat_box[] = $feat;
                }
            }
            basic_dev();
        }
    }

    function reserve_data_listing($listing_date, $account, $listing_type, $title, $description, $purpose, $property_category, $prop_type) {
        $_SESSION['listing_date'] = $listing_date;
        $_SESSION['account'] = $account;
        $_SESSION['listing_type'] = $listing_type;
        $_SESSION['title'] = $title;
        $_SESSION['description'] = $description;
        $_SESSION['purpose'] = $purpose;
        $_SESSION['property_category'] = $property_category;
        $_SESSION['property_type_id'] = $prop_type = $_POST['cbo_property_name'];
    }

    function only_keep_bas_apart($bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished) {
        $_SESSION['basic_aprt_bedrooms'] = $bedrooms;
        $_SESSION['basic_aprt_bathrooms'] = $bathrooms;
        $_SESSION['basic_aprt_flor_no'] = $floor_number;
        $_SESSION['basic_aprt_tot_no'] = $total_number_floors;
        $_SESSION['basic_aprt_furnished'] = $furnished;
    }

    function only_keep_bas_comm($bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors) {
        $_SESSION['basic_comm_bedrooms'] = $bedroom;
        $_SESSION['basic_comm_bathrooms'] = $bathroom;
        $_SESSION['basic_comm_compound_size'] = $compound_size;
        $_SESSION['basic_comm_living_flor'] = $living_floors;
        $_SESSION['basic_comm_total_noFlor'] = $total_number_floors;
    }

    function only_keep_bas_house($furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors) {
        $_SESSION['update_basic_house_furnished'] = $furnished;
        $_SESSION['basic_available_from'] = $available_from;
        $_SESSION['basic_house_bedrooms'] = $bedroom;
        $_SESSION['basic_house_bathrooms'] = $bathroom;
        $_SESSION['basic_house_compound_size'] = $compound_size;
        $_SESSION['basic_house_living_floor'] = $living_floors;
        $_SESSION['basic_total_number_floors'] = $total_number_floors;
    }

    function only_keep_bas_land($administrative_location, $plot_number, $lot_use, $available_from) {
        $_SESSION['basic_administrative_location'] = $administrative_location;
        $_SESSION['basic_land_plot_no'] = $plot_number;
        $_SESSION['basic_land_plot_size'] = $plot_number;
        $_SESSION['basic_lot_use'] = $lot_use;
        $_SESSION['basic_land_available_from'] = $available_from;
    }

    function only_keep_bas_dev($bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished) {
        $_SESSION['basic_dev_bedrooms'] = $bedrooms;
        $_SESSION['basic_dev_bathrooms'] = $bathrooms;
        $_SESSION['basic_dev_compound_size'] = $compound_size;
        $_SESSION['basic_dev_living_flor'] = $living_floors;
        $_SESSION['basic_dev_total_N_Floo'] = $total_number_floors;
        $_SESSION['basic_dev_furnished'] = $furnished;
    }

    function save_listing($listing_date, $account, $listing_type, $property_type_id, $title, $description, $purpose, $prop_type, $property_category) {
        $obj = new new_values();
        $active = 'no';
        if ($prop_type == 'Apartment') {
            $basic_apartmentdeleted = 'no';
            $mul_obj = new multi_values();
            $bedrooms = $_POST['txt_aprt_bedrooms'];
            $bathrooms = $_POST['txt_aprt_bathrooms'];
            $floor_number = $_POST['txt_aprt_floor_number'];
            $total_number_floors = $_POST['txt_aprt_total_number_floors'];
            $furnished = $_POST['txt_aprt_furnished'];
            if (empty($bedrooms) || empty($bathrooms) || empty($floor_number) || empty($total_number_floors) || empty($furnished)) {
                ?><script>alert('You have to provide (Apartment) basic information');</script><?php
            } else {
                $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), $property_type_id, trim($title), $description, trim($purpose), trim($property_category), 0, $active);
                //Last listng
                $mul_obj = new multi_values();
                $last_listingid = $mul_obj->get_lastlisting($_SESSION['userid']);
                if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                    ?><script> //alert('the feature has been chosen. So it will be save, if not check the saving method');</script><?php
                    $features = $_POST['features'];
                    $sess_array = array();
                    foreach ($features as $feat) {
                        $obj->new_listing_features($last_listingid, $feat);
                        $sess_array[] = trim($feat);
                    }
                    $_SESSION['sess_array'] = $sess_array;
                } else {
                    ?><script>alert('the feature has not been chosen so it wont be saved. sorry for the inconience.');</script><?php
                }
                $this->save_aparts($basic_apartmentdeleted, $last_listingid, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished);
            }
        } else if ($prop_type == 'House') {
            $basic_housedeleted = 'no';
            $mul_obj = new multi_values();
            $furnished = trim($_POST['txt_house_furnished']);
            $available_from = (empty(trim($_POST['txt_houae_available_from']))) ? 'null' : trim($_POST['txt_houae_available_from']);
            $bedroom = (empty($_POST['txt_house_bedroom'])) ? 0 : $_POST['txt_house_bedroom'];
            $bathroom = (empty($_POST['txt_house_bathroom'])) ? 0 : $_POST['txt_house_bathroom'];
            $compound_size = (empty($_POST['txt_house_compound_size'])) ? 0 : $_POST['txt_house_compound_size'];
            $living_floors = (empty($_POST['txt_house_living_floors'])) ? 0 : $_POST['txt_house_living_floors'];
            $total_number_floors = (empty($_POST['txt_house_total_number_floors']))? : $_POST['txt_house_total_number_floors'];
            if (empty($basic_housedeleted) || empty($furnished) || empty($available_from) || empty($bedroom) || empty($bathroom) || empty($compound_size) || empty($living_floors) || empty($total_number_floors)) {
                ?><script>alert('You have to provide (House) basic information');</script><?php
            } else {
                $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), $property_type_id, trim($title), $description, trim($purpose), trim($property_category), 0, $active);
                $mul_obj = new multi_values();
                $last_listingid = $mul_obj->get_lastlisting($_SESSION['userid']);

                if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                    $features = $_POST['features'];
                    $sess_array = array();
                    foreach ($features as $feat) {
                        $obj->new_listing_features(trim($last_listingid), trim($feat));
                        $sess_array[] = trim($feat);
                    }
                    $_SESSION['sess_array'] = $sess_array;
                }
                $this->save_basic_house($basic_housedeleted, $last_listingid, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors);
            }
        } else if ($prop_type == 'Land') {
            $basic_landdeleted = 'no';
            $mul_obj = new multi_values();
            $listing = $mul_obj->get_lastlisting();
            $administrative_location = trim($_POST['txt_administrative_location']);
            $plot_number = trim($_POST['txt_plot_number']);
            $plot_size = trim($_POST['txt_plot_size'] . ' ' . $_POST['plot_measure']);
            $lot_use = trim($_POST['txt_lot_use']);
            $available_from = trim($_POST['txt_land_available_from']);
            if (empty($basic_landdeleted) || empty($administrative_location) || empty($plot_number) || empty($plot_size) || empty($lot_use) || empty($available_from)) {
                ?><script>alert('You have to provide (Land) basic information');</script><?php
            } else {
                $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), $property_type_id, trim($title), $description, trim($purpose), trim($property_category), 0, $active);
                $mul_obj = new multi_values();
                $last_listingid = $mul_obj->get_lastlisting($_SESSION['userid']);
                if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                    $features = $_POST['features'];
                    $sess_array = array();
                    foreach ($features as $feat) {
                        $obj->new_listing_features($last_listingid, $feat);
                        $sess_array[] = trim($feat);
                    } $_SESSION['sess_array'] = $sess_array;
                }
                $this->save_basic_land($basic_landdeleted, $last_listingid, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from);
            }
        } else if ($prop_type == 'Commercial') {
            $basic_commercialdeleted = 'no';
            $mul_obj2 = new multi_values();
            $listing = $mul_obj2->get_lastlisting();
            $furnished = trim($_POST['txt_comm_furnished']);
            $bedroom = ($_POST['txt_comm_bedroom'] > 0) ? $_POST['txt_comm_bedroom'] : 0;
            $bathroom = ($_POST['txt_comm_bathroom'] > 0) ? $_POST['txt_comm_bathroom'] : 0;
            $compound_size = ($_POST['txt_comm_compound_size'] > 0) ? $_POST['txt_comm_compound_size'] : 0;
            $living_floors = ($_POST['txt_comm_living_floors'] > 0) ? $_POST['txt_comm_living_floors'] : 0;
            $total_number_floors = ($_POST['txt_comm_total_number_floors'] > 0) ? $_POST['txt_comm_total_number_floors'] : 0;
            if (empty($basic_commercialdeleted) || empty($bedroom) || empty($bathroom) || empty($compound_size) || empty($living_floors) || empty($total_number_floors) || empty($furnished)) {
                ?><script>alert('You have to provide (Commercial) basic information');</script><?php
            } else {
                $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), $property_type_id, trim($title), $description, trim($purpose), trim($property_category), 0, $active);
                //Last listng
                $mul_obj = new multi_values();
                $last_listingid = $mul_obj->get_lastlisting($_SESSION['userid']);
                if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                    $features = $_POST['features'];
                    $sess_array = array();
                    foreach ($features as $feat) {
                        $obj->new_listing_features($last_listingid, $feat);
                        $sess_array[] = trim($feat);
                    }
                    $_SESSION['sess_array'] = $sess_array;
                }
                $this->save_basic_commercial($basic_commercialdeleted, $last_listingid, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished);
            }
        } else if ($prop_type == 'Development') {
            $basic_developdeleted = 'no';
            $mul_obj = new multi_values();
            $listing = trim($mul_obj->get_lastlisting($_SESSION['userid']));
            $bedrooms = $_POST['txt_dev_bedroom'];
            $bathrooms = $_POST['txt_dev_bathroom'];
            $compound_size = $_POST['txt_dev_compound_size'];
            $living_floors = $_POST['txt_dev_living_floors'];
            $total_number_floors = $_POST['txt_dev_total_number_floors'];
            $furnished = $_POST['txt_dev_furnished'];
            if (empty($basic_developdeleted) || empty($bedrooms) || empty($bathrooms) || empty($compound_size) || empty($living_floors) || empty($total_number_floors) || empty($furnished)) {
                ?><script>alert('You have to provide (Development) basic information');</script><?php
            } else {
                $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), $property_type_id, trim($title), $description, trim($purpose), trim($property_category), 0, $active);
                //Last listng
                $mul_obj = new multi_values();
                $last_listingid = $mul_obj->get_lastlisting($_SESSION['userid']);
                if (!empty($_POST['feat_chosen']) || !empty($_POST['last_feat'])) {
                    $features = $_POST['features'];
                    $sess_array = array();
                    foreach ($features as $feat) {
                        $obj->new_listing_features($last_listingid, $feat);
                        $sess_array[] = trim($feat);
                    } $_SESSION['sess_array'] = $sess_array;
                }
                $this->save_basic_dev($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="-----------new basic info---------------------">

    function get_dev_fields() {
        
    }

    function save_aparts($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished) {
        require_once '../web_db/new_values.php';
        $obj_new = new new_values();
        $obj_new->new_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished);
    }

    function save_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished) {
        require_once '../web_db/new_values.php';
        $obj_new = new new_values();
        $obj_new->new_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished);
    }

    function save_basic_house($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors) {
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_basic_house($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors);

        $_SESSION['update_basic_house_furnished'] = $furnished;
        $_SESSION['basic_available_from'] = $available_from;
        $_SESSION['basic_house_bedrooms'] = $bedroom;
        $_SESSION['basic_house_bathrooms'] = $bathroom;
        $_SESSION['basic_house_compound_size'] = $compound_size;
        $_SESSION['basic_house_living_floor'] = $living_floors;
        $_SESSION['basic_total_number_floors'] = $total_number_floors;
    }

    function save_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from) {
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_basic_land(trim($basic_landdeleted), trim($listing), trim($administrative_location), trim($plot_number), trim($plot_size), trim($lot_use), trim($available_from));
    }

    function save_basic_dev($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished) {
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished);

        $_SESSION['basic_dev_bedrooms'] = $bedrooms;
        $_SESSION['basic_dev_bathrooms'] = $bathrooms;
        $_SESSION['basic_dev_compound_size'] = $compound_size;
        $_SESSION['basic_dev_living_flor'] = $living_floors;
        $_SESSION['basic_dev_total_N_Floo'] = $total_number_floors;
        $_SESSION['basic_dev_furnished'] = $furnished;
    }

// </editor-fold>

    function delete_basic_info_by_listing($prop_type, $listing) {
        require_once '../web_db/deletions.php';
        require_once './new_wizard.php';
        $bean = new Page_load();
        $obj = new deletions();
        if ($prop_type == 8) {//this is the apartment
            if (isset($_SESSION['complete_updating'])) {
                $id = $_SESSION['compelte_updating'];
                $obj->deleteFrom_bas_aprt_by_listing($id);
            } else if ($bean->process() != 'complete') {
                $obj->deleteFrom_bas_aprt_by_listing($listing);
            } else {
                return '';
            }
        } else if ($prop_type == 9) {//the=is is the commercial
            if (isset($_SESSION['complete_updating'])) {
                $id = $_SESSION['compelte_updating'];
                $obj->deleteFrom_bas_comm_by_listing($id);
            } else if ($bean->process() != 'complete') {
                $obj->deleteFrom_bas_comm_by_listing($listing);
            } else {
                return '';
            }
        } else if ($prop_type == 10) {//this is the house
            if (isset($_SESSION['complete_updating'])) {
                $id = $_SESSION['complete_updating'];
                $obj->deleteFrom_bas_aprt_by_listing($id);
            } else if ($bean->process() != 'complete') {
                $obj->deleteFrom_bas_aprt_by_listing($listing);
            } else {
                return '';
            }
        } else if ($prop_type == 11) {// this is the land
            if (isset($_SESSION['complete_updating'])) {
                $id = $_SESSION['complete_updating'];
                $obj->deleteFrom_bas_land_by_listing($id);
            } else if ($bean->process() != 'complete') {
                $obj->deleteFrom_bas_land_by_listing($listing);
            }
        } else if ($prop_type == 12) {// here we have the development
            if (isset($_SESSION['complete_updating'])) {
                $id = $_SESSION['complete_updating'];
                $obj->deleteFrom_bas_develop_by_listing($listing);
            } else if ($bean->process() != 'complete') {
                $obj->deleteFrom_bas_develop_by_listing($listing);
            } else {
                return '';
            }
        }
    }

    function delete_feature_by_listingid($listing) {
        require_once '../web_db/deletions.php';
        $del = new deletions();
        $del->deleteFrom_listing_features($listing);
    }

}

class display_switch {

    function load_fresh() {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $last_lst_id = $obj->get_lastlisting();
        $last_lst_acc = $obj->get_last_listing_account();
        $last_lst_date = $obj->get_last_listing_title();
        $last_lst_type = $obj->get_last_listing_type();
        $last_lst_prop_type = $obj->get_last_listing_prop_type_by_listing_id();
        $last_lst_prop_cat = $obj->get_last_listing_prop_cat_noDiv(); //this is just the id
        $last_lst_prop_cat_name = $obj->get_property_cat_name_by_property_cat_id($last_lst_prop_cat);
        $last_lst_title = $obj->get_last_listing_title();
        $last_lst_location = $obj->get_last_listing_location();
        $last_lst_purpose = $obj->get_last_listing_purpose();
        $last_lst_desc = $obj->get_last_listing_desc();
        ?>

        <input type = "hidden" class = "textbox " placeholder = "property type" name = "txt_property_type_id" id = "txt_property_type_id">
        <input type = "hidden" class = "textbox " placeholder = "proprty cat" name = "txt_property_cat_id" id = "txt_property_cat_id" value="<?php echo get_prop_cat(); ?>">
        <input type = "hidden" class = "parts   off " style = "margin-left: 300px;" placeholder = "property name" name = "txt_prop_name" id = "prop_name" />
        <input type = "hidden" class = "textbox off" placeholder = "Current step" name = "txt_current_step" id = "current_step" value = "<?php echo $_SESSION['current_step']; ?>"/>
        <input type = "hidden" class = "textbox off" placeholder = "lisitng type" name = "txt_listing_type" id = "listing_type" />
        <input type = "hidden" class = "textbox off" placeholder = "Editing mode" name = "Editing_mode" id = "Editing_mode" />
        <input type = "hidden" class = "textbox off" placeholder = "Features chosen " name = "feat_chosen" id = "feat_chosen" />
        <input type = "hidden" class = "textbox off" placeholder = "working_listing" name = "working_listing" id = "working_listing" />
        <div class = "off" id = "d">
            <?php
            feature_by_session();
            ?>
        </div>
        <div class = "parts eighty_centered  new_data_box">
            <div class = "parts   xx_titles no_paddin_shade_no_Border "id = "property_desc_title">Listing
            </div>
            <table class = "new_data_table " border = "1">
                <tr>
                    <td><span id = "listing_type_chosen"></span>Property type:</td>
                    <td> <?php include './new_listing_type.php';
            ?></td>
                </tr>
                <tr><td>Property Category :</td><td> <?php get_property_type_combo(); ?></td></tr>
                <tr><td><span id="property_subCat_label" class="off">Property Sub category:</span></td>
                    <td><div class="parts no_paddin_shade_no_Border reverse_border full_center_two_h x_height_one_h" id="my_cat_res">
                            <?php
                            require_once '../web_db/multi_values.php';
                            $obj = new multi_values();
                            $last_lst_prop_type = $obj->get_last_listing_prop_type_by_listing_id();
                            if (isset($last_lst_prop_type)) {
                                $obj->get_propertyCat_by_proerty_type_id($last_lst_prop_type);
                            } else if (isset($_SESSION['property_type_id'])) {
                                $res = $obj->get_propertyCat_by_proerty_type_id($_SESSION['property_type_id']);
                            }
                            ?>
                        </div>
                    </td>
                </tr>
                <tr><td>Property Title :</td>
                    <td><input required  type="text"  name="txt_title" placeholder="Property title" id="txt_title" class="textbox" value="<?php get_my_type(); ?>" />   </td></tr>
                <tr><td>Description :</td><td><textarea   style="height: 100px;" name="txt_desc" placeholder="Property description" id="txt_desc" class="textbox tinymce" ></textarea>   </td></tr>
                <?php
                include './basic_info/new_basic_apartment.php';
                include './basic_info/new_basic_house.php';
                include './basic_info/new_basic_land.php';
                include './basic_info/new_basic_commercial.php';
                include './basic_info/new_basic_develop.php';
                ?>
            </table>
            <div class="parts full_center_two_h no_paddin_shade_no_Border x_titles heit_free">Features</div>
            <div class="parts full_center_two_h heit_free no_shade_noBorder" id="features_box">
            </div>
        </div>
        <div class="parts eighty_centered">
            <input type="submit" class="confirm_buttons" name="send_listing" id="btn_send_listing" value="SAVE AND CONTINUE">
        </div>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>    
        <?php
    }

    function load_existing() {
        
    }

}

class dialogs {

    function full_bg() {
        return' <div class="new_absfull " style="    
             position: fixed;
             width: 100%;
             height: 100%;
             opacity: 0.8;
             background-color: #49676d;
             top: 0px;
             left: 0px;
             z-index: 4;">
        </div>';
    }

    function small_dialog() {
        return ' <div class="parts fifty_centered " style="
        position: fixed;
        z-index: 5;
        background-color: #ffffff;
        min-height: 300px;
        border: 10px">
        <div style="position: relative;">
        
            <div class="link_cursor roundclose_btn"  style="
                 width: 32px;
                 height: 32px;
                 position: absolute;
                 z-index: 6;
                 right: -30px;
                 top: -30px;
                  background-image: url(../web_images/close.png);">
            </div>
        </div>
    </div>';
    }

    function smaller_dialog($msg) {
        ?><script>

        </script><?php
        return '
                   <div class="off msg_dialog"  style="
                     position: fixed;
                     background-color: #ffffff;
                     width: 30%;
                     height: 100px;
                    left: 35%;
                    z-index: 5;
                    box-shadow: 0px 0px 10px #00ff00;
                    border: 1px solid #0099ff;">
                    <div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border" style="position: relative; height: 100%;">
                        <div class="parts margin_free no_paddin_shade_no_Border link_cursor roundclose_btn"  style="
                            width: 32px;
                            height: 32px;
                            position: absolute;
                            z-index: 6;
                            right: -30px;
                            top: -30px;
                            background-image: url(../web_images/close.png);">
                        </div>
                        <div class="parts margin_free full_center_two_h  heit_free"> ' . $msg . '</div>
                        <div class="parts margin_free full_center_two_h heit_free no_shade_noBorder"  style="
                            left: 0px;
                            bottom: 0px;
                            height: 50px;
                            position: absolute;
                            background-color: #dbeae9;">
                        </div>
                        <div class="parts margin_free full_center_two_h no_shade_noBorder heit_free" style="
                                     position: absolute;
                                     left: 0px;
                                     bottom: 0px;
                                     ">
                                 <div class="parts" id="dlog_btnYes" style="
                                     position: absolute;
                                     left: 0px;
                                     bottom: 0px;
                                     padding: 10px;
                                     width: 48%;
                                     background-color: #a1dad7;
                                     text-align: center;">
                                      Yes</div>
                                     
                                <div class="parts" id="dlog_btnNo" style="
                                     position: absolute;
                                     right: 0px;
                                     bottom: 0px;
                                     padding: 10px;
                                     text-align: center;
                                     width: 48%;
                                     background-color: #a1dad7;">no</div>
                            </div>
                    </div>
                </div>';
    }

    function script_event() {
        return "";
    }

    function test() {
        ?>
        <div class="fifty_right  full_center_two_h heit_free no_shade_noBorder" style="
             left: 0px;
             bottom: 0px;
             background-color: #dbeae9;
             background-size: 100%;
             box-shadow: 0px 0px 10px #fff;
             left: 15%;
             float: left;
             border: 1px solid #0099ff;

             background-image: url(../web_images/close.png);"></div><?php
    }

}
