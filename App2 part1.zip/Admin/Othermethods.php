<?php
require_once('../web_db/connection.php');

class Othermethods {

    function list_property_type() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from property_type";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> property </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['property']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_property_combo() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property.property_id,  property.name from property";
        ?>
        <select class="textbox combo_user_cat"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

}
