<?php

session_start();
if (isset($_POST['sent'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_userid_by_Acc_cat($_POST['sent']);
    echo $id;
}
if (isset($_POST['prop'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_id_property($_POST['prop']);
    echo $id;
}
if (isset($_POST['prop_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_id_property_type($_POST['prop_type']);
    echo $id;
}

//Here we return totals of the entities
if (isset($_POST['count_users'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->All_accounts();
    return $id;
}
if (isset($_POST['prop_type_cat'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $_POST['prop_type_cat'];
    $res = $obj->get_prop_cat_combo($_POST['prop_type_cat']);
    echo $res;
}
if (isset($_POST['features_by_prop_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_features_checkbox($_POST['features_by_prop_type']);
    return $res;
}
if (isset($_POST['basic_by_prop_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_basic_info_name_by_property_type($_POST['basic_by_prop_type']);
    return $res;
}
if (isset($_POST['prop_cat'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_propertyCat_id_by_prop_cat_Name($_POST['prop_cat']);
    return $res;
}
if (isset($_POST['province'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_provinceId_by_Name($_POST['province']);
    return $res;
}
if (isset($_POST['district'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_DistrctId_by_name($_POST['district']);
    return $res;
}
if (isset($_POST['district_by_prov'])) {
    require_once '../web_db/multi_values.php';
    $obj = new location_new();
    $res = $obj->specl_district_by_prov($_POST['district_by_prov']);
    echo $res;
}
if (isset($_POST['sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_SectorId_by_name($_POST['sector']);
    return $res;
}
if (isset($_POST['sectors_by_district'])) {
    require_once '../web_db/multi_values.php';
    $obj = new location_new();
    $res = $obj->specl_sectors_by_district($_POST['sectors_by_district']);
    echo $res;
}
if (isset($_POST['feature_item'])) {
//get the
    echo 'From php  ' . $_POST['feature_item'];
    require_once '../web_db/multi_values.php';
    require_once '../web_db/new_values.php';
    $obj_get = new multi_values();
    $obj_add = new new_values();
    $featureid = $obj_get->get_featureId_by_name($_POST['feature_item']);
    $res = $obj_add->new_features_listing($featureid, $_SESSION['last_listng']);
}
if (isset($_POST['cell_by_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new location_new();
    $res = $obj->specl_cells_by_sectors($_POST['cell_by_sector']);
    echo $res;
}
if (isset($_POST['cell_id'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_cellsName_by_id($_POST['cell_id']);
// $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['listi_typeid'])) {
    $id = $_POST['listi_typeid'];
    $_SESSION['listi_typeid'] = $id;
    echo $_SESSION['listi_typeid'];
}
if (isset($_POST['search_area_typed'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_location_area_name_like($_POST['search_area_typed']);
    return $res;
}
if (isset($_POST['last_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_lastlisting();
    echo $res;
}

if (isset($_POST['listing_date'])) {
    require_once '../web_db/multi_values.php';
    $end_date = $_POST['end_date'];
    $obj = new multi_values();
    $res = $obj->get_rpt_listing_by_date($_POST['listing_date'], $end_date);
    return $res;
}
if (isset($_POST['listing_date_year'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_listing_by_year($_POST['listing_date_year']);
    return $res;
}
if (isset($_POST['listing_date_prop_type_date'])) {
    require_once '../web_db/multi_values.php';
    $listing_date_prop_type = $_POST['listing_date_prop_type'];
    $obj = new multi_values();
    $res = $obj->get_listing_date_prop_type($_POST['listing_date_prop_type_date'], $listing_date_prop_type);
    return $res;
}
if (isset($_POST['det_report'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_detailed_rpt_listing($_POST['det_report']);
    return $res;
}
if (isset($_POST['det_report2'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_rpt_only_map($_POST['det_report2']);
    echo $res;
}
if (isset($_POST['lising_delete'])) {
    require_once '../web_db/multi_values.php';
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $mul = new multi_values();
    $res = $obj->deleteFrom_listing($_POST['lising_delete']);
    $res2 = $obj->deleteFrom_image($_POST['lising_delete']); //this is the deleting all images of the listing from the folder
    //now get the property type to delete the coresponding basic information (Apartment, commercial,house, land or develpment)

    $res3 = $mul->get_last_listing_prop_type_by_list_id($_POST['lising_delete']);
    $id = $_POST['lising_delete'];
    if ($res3 = 8) {
        $obj->deleteFrom_basic_apartment($id);
    } else if ($res = 9) {
        $obj->deleteFrom_basic_commercial($id);
    } else if ($res = 10) {
        $obj->deleteFrom_basic_house($id);
    } else if ($res = 11) {
        $obj->deleteFrom_basic_land($id);
    } else if ($res = 12) {
        $obj->deleteFrom_basic_develop($id);
    }
    echo $res2;
}
if (isset($_POST['lst_comple_update'])) {
    $_SESSION['complete_updating'] = $_POST['lst_comple_update'];
    echo $_POST['lst_comple_update'];
}
//the new location format
if (isset($_POST['new_district_by_prov'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_districts_by_prov_new_format($_POST['new_district_by_prov']);
    return $res;
}
if (isset($_POST['new_sectors_by_district'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_sectors_by_distr_new_format($_POST['new_sectors_by_district']);
    return $res;
}
if (isset($_POST['new_cell_by_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_cells_by_sect_new_format($_POST['new_cell_by_sector']);
    return $res;
}

//get last listing (in updatin listing)
if (isset($_POST['the_last_listing_title'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_title();
    echo $res;
}
if (isset($_POST['the_last_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_type();
    echo $res;
}
if (isset($_POST['the_last_prop_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_prop_category();
    echo $res;
}
if (isset($_POST['the_last_prop_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_prop_type_by_listing_id();
    echo $res;
}
if (isset($_POST['the_last_listing_location'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_location();
    echo $res;
}
if (isset($_POST['the_last_listing_desc'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_desc();
    echo $res;
}

if (isset($_POST['the_last_apart'])) {
//compare the last listing id with the last listing id from the apartment

    $working_listing_id = $_POST['working_listing_id'];
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_id_basic_aparts();
    if ($res == 1) {
        echo'exists';
    } else {
        return 'not';
    }
}
if (isset($_POST['the_last_house'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_basic_house();
    if ($res == 1) {
        echo'exists';
    } else {
        return 'not';
    }
}
if (isset($_POST['the_last_land'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_listing_id_basic_land();
    if ($res == 1) {
        echo 'exists';
    } else {
        echo 'not';
    }
}
if (isset($_POST['the_last_dev'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_cells_by_sect_new_format($_POST['new_cell_by_sector']);
    return $res;
}
if (isset($_POST['cont_rpt_all'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_all_listing();
    return $res;
}
//allbasic apartment fields (here we retrieve last fields from basic details, this is case dependent
// <editor-fold defaultstate="collapsed" desc="-------------All basics--------------">
// <editor-fold defaultstate="collapsed" desc="----------------Apartment-----------------">
if (isset($_POST['last_bedroom_apart'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_bedroom_apartment();
    echo $res;
}
if (isset($_POST['last_bathroom_apart'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_bathrooms_apartment();
    echo $res;
}
if (isset($_POST['last_floorno_apart'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_floor_number_apartment();
    echo $res;
}
if (isset($_POST['last_totalfloor_apart'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_total_floor_nbr_apartment();
    echo $res;
}
if (isset($_POST['last_furnished_apart'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_furnished_apartment();
    echo $res;
}
// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="----------------House-------------------">
if (isset($_POST['last_furnished_house'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_furnished_house();
    return $res;
}
if (isset($_POST['last_available_house'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_available_house();
    return $res;
}
// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="----------------Land-------------------">
if (isset($_POST['last_adminLoc_land'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_admin_loc_land();
    echo 'The location is: ' . $res;
}
if (isset($_POST['last_plotNum_land'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_plotno_land();
    echo $res;
}
if (isset($_POST['last_plotsize_land'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_plotsize_land();
    echo $res;
}
if (isset($_POST['last_lotUse_land'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_lotuse_land();
    echo $res;
}
if (isset($_POST['last_available_land'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_available_land();
    echo $res;
}
// </editor-fold>
// </editor-fold>


if (isset($_POST['features_last_listing'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->features_last_listing();
    return $res;
}
if (isset($_POST['utilities_chk'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->utililites_last_price();
    return $res;
}
//send request from homepage
if (isset($_POST['send_request'])) {
    require_once '../web_db/new_values.php';
    $listing_id = $_POST['listing_id'];
    $names = $_POST['names'];
    $phone = $_POST['phone'];

    $property_requestdeleted = 'no';
    $txt_email_names = $_POST['txt_contact_email'];
    $listing = $listing_id;
    $received = 'no';
    $account = 0;
    $obj = new new_values();
    $obj->new_property_request($property_requestdeleted, $names, $phone, $txt_email_names, $listing, $received, $account);
}
if (isset($_POST['clear_all_request'])) {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $obj->delete_all_property_request();
}
if (isset($_POST['delete_image'])) {
    require_once '../web_db/deletions.php';
    $del = new deletions();
    $del->deleteFrom_image_table($_POST['image_id']);
    unlink('../web_images/property/' . $_POST['delete_image']);
    echo 'Image deleted';
}
if (isset($_POST['req_accepted'])) {
    require_once '../web_db/updates.php';
    $obj = new updates();
    $res = $obj->update_property_request($_POST['req_accepted']);
    echo 'Request received';
}

//price last price field
if (isset($_POST['price_amount'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_price_amount();
    echo $res;
}
if (isset($_POST['price_currency'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_price_currency();
    echo $res;
}
if (isset($_POST['price_min_adv'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_price_min_advance();
    echo $res;
}
if (isset($_POST['price_price_day'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_last_price_price_day();
    echo $res;
}


//home page
if (isset($_POST['reply_value'])) {
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $commentid = $_POST['comment'];
    $reply = $_POST['reply_value'];
    $res = $obj->new_comment_replies('no', $reply, date('y-m-d'), $_SESSION['userid'], $commentid);
    echo $res;
}
if (isset($_POST['table_to_update'])) {

    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}

if (isset($_POST['delete_All_image_bySession'])) {
    require_once '../web_db/deletions.php';
    $del = new deletions();
    $del->deleteFrom_image($_SESSION['complete_updating']);

    echo 'Image deleted';
}
if (isset($_POST['call_dialog'])) {
    require_once './wizard_helper.php';
    $msg = $_POST['call_dialog'];
    $dialog = new dialogs();
    echo $dialog->smaller_dialog($msg) . $dialog->full_bg();
}

if (isset($_POST['enable_listing'])) {
    require_once '../web_db/updates.php';
    $obj = new updates();
    $status = ($_POST['status'] == 'Enable') ? 'yes' : 'no';
    $res = $obj->update_listing_enable($status, $_POST['enable_listing']);
    echo $status;
}

if (isset($_POST['two_dates_report'])) {

//    $_SESSION['rep_date1'] = $_POST['date1'];
//    $_SESSION['rep_date2'] = $_POST['date2'];
//    echo $_SESSION['rep_date1'] . '  ' . $_SESSION['rep_date2'];
    echo 'received';
}






