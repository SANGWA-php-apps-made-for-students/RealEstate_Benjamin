<?php
session_start();
current_step();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once './dbConnection.php';
$con = new my_connection();
$sql2 = "select    listing.listing_id from listing order by  listing.listing_id desc limit 1";
$stmt2 = $con->getCon()->prepare($sql2);
$stmt2->execute();
$row = $stmt2->fetch(PDO::FETCH_ASSOC);
$listing_id = $row['listing_id'];
$last_listingid = $listing_id;
$property = $listing_id;
if (!isset($_SESSION['listing_done'])) {
    
}
if (isset($_POST['send_price'])) {
    $amount = $_POST['txt_amount'];
    $currency = $_POST['txt_currency'];
    $combo = $_POST['condition_combo'];
    $condition = empty($_POST['txt_other_condition']) ? $combo : $_POST['txt_other_condition'];
    $commission = $_POST['txt_commission'];
    $deposit_required = $_POST['deposity'];
    $utilities_extra = $_POST['condition_combo'];
    require_once '../web_db/multi_values.php';
    $obj_nmul = new multi_values();
    $last_listing = $obj_nmul->get_lastlisting();
    foreach ($deposit_required as $dep) {
        $depo = $dep;
    }
    $Minimum_advance = $_POST['txt_minimum_advance'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_price($amount, $currency, $condition, $property, $Minimum_advance, $depo, $commission, $utilities_extra, $last_listing);
}
?>
<html>
    <head>
        <title>
            price
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="parts margin_free no_paddin_shade_no_Border" id="homePage_holder">

        </div>
        <form action="new_price.php" method="post" enctype="multipart/form-data">
            <input type="text" class="textbox off" placeholder="Current step" name="txt_current_step"id="current_step" value="<?php echo $_SESSION['current_step']; ?>"/>
            <input type="text" class="textbox off" id="txt_condition_id" />

            <div class="parts abs_full   margin_free off" id="rpt_details_dialog">

            </div>
            <div class="parts abs_child skin2 eighty_centered off"  id="rpt_det_contents" style="position: fixed; height: 100%; overflow: scroll;">

            </div>
            <?php
            include 'Admin_header.php';
            ?>

            <div class="parts  eighty_centered no_shade_noBorder smart_font">  Listings  Reports</div>

            <div class="parts  eighty_centered">
                <div class="parts no_paddin_shade_no_Border">
                    <select id="search_option_combo">
                        <option></option>
                        <option>By a date</option>
                        <!--  <option>By a year</option>
                                                <option>By a listing type & date</option>-->
                    </select>
                </div>
                <div class="parts no_paddin_shade_no_Border " >
                    <table style="margin: 0px;">
                        <tr>
                            <td> <?php get_property_type(); ?></td>
                            <td><input type="text" autocomplete="off" placeholder="Start date" id="txt_date_pick" />
                                &nbsp;<input type="text" autocomplete="off" class="end_date" id="txt_date_pick2" placeholder="End date"  /></td>
                            <td> <input class="off textbox"  placeholder="year" type="text" id="txt_year_pick" /></td>
                        </tr>
                    </table>
                </div>
                <div class="parts link_cursor" id="listing_btn">
                    Search by date range
                </div>
                <div class="parts link_cursor" id="listing_btn_all">
                    View all
                </div>

                <!--                <div class="parts link_cursor" id="listing_btn">
                                    <a href="Printings/Today_listings.php"> Print</a>
                                </div>
                                <div class="parts link_cursor" id="listing_btn">
                                    Share
                                </div>-->
            </div>
            <div class="parts eighty_centered" id="rprt_res_box">
            </div>
            <div class="parts eighty_centered"  id="rprt_res_today_report">
                <div class="parts    xx_titles no_paddin_shade_no_Border smart_font">
                    <?php echo 'Today\'s report (' . all_today_listings() . ')'; ?>
                </div>
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_listing_by_today();
                ?>
            </div>
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/my_scripts.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('#txt_date_pick').datepicker({
                    dateFormat: 'yy-mm-dd',
                    onSelect: function () {
                        var dt2 = $('#txt_date_pick2');
                        var startDate = $(this).datepicker('getDate');
                        //add 30 days to selected date
                        startDate.setDate(startDate.getDate() + 100);
                        var minDate = $(this).datepicker('getDate');
                        //minDate of dt2 datepicker = dt1 selected day
                        dt2.datepicker('setDate', minDate);
                        //sets dt2 maxDate to the last day of 30 days window
//                        dt2.datepicker('option', 'maxDate', startDate);
                        //first day which can be selected in dt2 is selected date in dt1
                        dt2.datepicker('option', 'minDate', minDate);
                        //same for dt1
//                        $(this).datepicker('option', 'minDate', minDate);
                    }
                });
                $('#txt_date_pick2').datepicker({
                    dateFormat: 'yy-mm-dd'
                });
//                initMap();
            });
            $('#txt_year_pick, .date_pickers').datepicker({
                dateFormat: 'yy',
                changeMonth: false,
                maxDate: new Date(),
                changeYear: true,
                showButtonPanel: true,
                onClose: function (dateText, inst) {
                    var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                    $('#txt_year_pick').val(year);
                }
            });
        </script>

    </body>
</hmtl>
<?php

function get_features_checkbox() {
    require_once '../Admin/dbConnection.php';
    $con = new my_connection();
    $db = $con->getCon();
    $sql = " select   property_category.name from property_category join property_type on property_type.property_type_id=property_category.type where property_type.name='house'";
    foreach ($db->query($sql) as $row) {
        echo "<label for=\"feat\"> <input class=\"feat\" class=\"checkboxes\" name=\"feat\" type=\"checkbox\" value=" . $row['name'] . ">" . $row['name'] . "</label>";
    }
}

function all_today_listings() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_total_listing_by_today();
    return $res;
}

function current_step() {
    $_SESSION['current_step'] = 3;
    if (true) {
        
    }
}

function get_property_type() {

    $database = new my_connection();
    $db = $database->getCon();
    $sql = "SELECT  property_category.property_category_id,  property_category.name from property_category";
    ?>
    <select class="textbox off" id="txt_prop_type_combo">
        <?php
        foreach ($db->query($sql) as $row) {
            echo "<option value=" . $row['property_category_id'] . ">" . $row['name'] . " </option>";
        }
        ?>
    </select>
    <?php
}
