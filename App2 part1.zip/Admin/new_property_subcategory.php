
 
<div class="parts no_paddin_shade_no_Border eighty_centered">
    <div class="parts  xx_titles margin_free no_paddin_shade_no_Border">  property_subcategory</div>
    <table class="new_data_table">
        <tr><td>property_subcategory :</td><td> <input type="text"     name="txt_property_subcategory" required class="textbox"   </td></tr>
        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_property_subcategory" value="Save"/>  </td></tr>
    </table>
</div>
<!--<div class="parts eighty_centered" >-->
<?php
//                require_once '../web_db/multi_values.php';
//                $obj = new multi_values();
//                $obj->list_property_subcategory();
?>

<!--</div>-->

