<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="Admin_style.css" rel="stylesheet" type="text/css"/>
        <style>
            .Capitl{
                text-transform: uppercase;

            }
        </style>
    </head>
    <body>
        <?php
        include 'Admin_header.php';
        include './sidemenu.php';
        ?>
        <div class="parts eighty_centered">
            <div class="parts logo margin_free"></div>
            <div class="parts x_titles no_paddin_shade_no_Border margin_free smart_font">
                <u class="Capitl"> <?php echo $_SESSION['agency_name']; ?></u> Dashboard
            </div>
            <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border top_off_x" id="admin_rep" >
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_users_cat" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">    Users categories</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_users_cat"> </div>
                </div>
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_users" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Users</span></span> 
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_users"> </div>
                </div>
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_admins"><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Admin</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_admins"> </div>
                </div>
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_managers" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Managers</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_managers"> </div>
                </div>
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_agents" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Agents</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_agents"> </div>
                </div>
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_prop_types" id="c_prop_types_box" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Property types</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_prop_types"> </div>
                </div>

                <div class="parts link_cursor fixed_box_xxx  heit_free off c_prop_cat" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Property categories</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_prop_cat">  </div>

                </div>
                <div class="parts link_cursor fixed_box_xxx  heit_free off c_listings" style="color: #1a0829;" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Listings</span>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_listings">  </div>

                </div>
                <a href="../Admin/other_pages/Addon_images.php">
                    <div class="parts link_cursor fixed_box_xxx  heit_free off c_listings_no_image" id="c_listings_no_imagebox" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Listings without images</span>
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_listings_no_image">  </div>
                    </div>
                </a>
                <a href="../Admin/other_pages/Addon_prices.php" >
                    <div class="parts link_cursor fixed_box_xxx  heit_free off" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Listings without prices</span>
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_listings_no_prices">  </div>
                    </div>
                </a>
                <a href="new_report_request.php" >
                    <div class="parts link_cursor fixed_box_xxx  heit_free c_requests" ><span class="parts no_shade_noBorder full_center_two_h heit_free margin_free ">Requests</span>
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_requests">  </div>
                    </div>
                </a>

            </div>
        </div>
        <?php
        // put your code here
        ?>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="Admin_script.js" type="text/javascript"></script>  
    </body>

</html>
