<?php
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>
<html>
    <head>
        <title>
            listing_type</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_listing.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="list_type" class="textbox" id="listing_typeid"/>

            <?php
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            $obj->list_listing_type();
            ?>
        </form>

        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script   type="text/javascript">
            $(document).ready(function () {
                get_listing_type();
                Data_hover_listing_type();
                //combo_property_cat
            });
            function get_listing_type() {
                $('.list_typebtn').click(function () {
                    try {
                        var listi_typeid = $(this).children('span:first').html();
                        $.post('../Admin/handler.php', {listi_typeid: listi_typeid}, function (data) {
                            $('.data_hover_box > .data_id_span').html(data);
                        });
                    } catch (err) {
                        alert(err.message);
                    }
                });
            }
//Data hover
//
            function Data_hover_listing_type() {
                $('.data_hover_box').click(function () {
                    try {
                        $('.data_menu_items').slideToggle(150);
                    } catch (err) {
                        alert(err.message);
                    }
                });
            }
        </script>
    </body>
</hmtl>
<?php
if (isset($_POST['send_listing_type'])) {
    //get the listing type id
    $list_type = $_POST['list_type'];
    if ($list_type != '') {
        $_SESSION['list_type_id'] = $list_type;
        header('location:new_listing.php');
    } else {
        echo'You have to choose the listing type';
    }
//    $name = $_POST['txt_name'];
//    require_once '../web_db/new_values.php';
//    $obj = new new_values();
//    $obj->new_listing_type($name);
}

