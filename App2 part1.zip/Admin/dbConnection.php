<?php

class my_connection {

    function getCon() {
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}

class conn_login {

    function log_con() {
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}
