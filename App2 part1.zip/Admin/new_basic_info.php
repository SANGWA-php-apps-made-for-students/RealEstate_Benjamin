<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
?>
<html>
    <head>
         <title>
            basic_info
         </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>   <body>
        <form action="new_basic_info.php" method="post" enctype="multipart/form-data">
            <input type="text" class="textbox off" name="txt_propertyid" id="txt_property_type_id">
            <span id="d" class="off"></span>
            <?php
            include 'Admin_header.php';
            ?>
            
            <div class="parts eighty_centered no_paddin_shade_no_Border">

                <div class="parts eighty_centered no_shade_noBorder">
                    <?php
                    save_basic_info();
                    ?></div>

                <div class="part eighty_centered new_data_box ">
                    <div class="parts eighty_centered off ">  basic_info</div>
                    <table class="new_data_table">
                        <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox"   </td></tr>
                        <tr><td>property :</td><td>  <?php
                                $obj = new multi_values();
                                $obj->get_prop_type_combo();
                                ?>   </td></tr>

                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_basic_info" value="Save"/>  </td></tr>
                    </table>
                </div>
                <div class="parts eighty_centered no_paddin_shade_no_Border " >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_basic_info();
                    ?>
                </div>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function save_basic_info() {
    if (isset($_POST['send_basic_info'])) {
        $name = $_POST['txt_name'];
        $property = $_POST['txt_propertyid'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_basic_info($name, $property);
        echo 'Saved successfully!';
    }
}
