<?php

// <editor-fold defaultstate="collapsed" desc="------DESCRIPTION----------">
//this means that there is no session. the user had closed the web browser
require_once '../web_db/multi_values.php';
$obj = new multi_values();
$last_lst_id = $obj->get_lastlisting();
$last_lst_acc = $obj->get_last_listing_account();
$last_lst_date = $obj->get_last_listing_date();
$last_lst_type = $obj->get_last_listing_type();
$last_lst_prop_type = $obj->get_last_listing_prop_type_by_listing_id();
$last_lst_prop_cat = $obj->get_last_listing_prop_cat_noDiv(); //this is just the id
$last_lst_prop_cat_name = $obj->get_property_cat_name_by_property_cat_id($last_lst_prop_cat);
$last_lst_title = $obj->get_last_listing_title();
$last_lst_location = $obj->get_last_listing_location();
$last_lst_purpose = $obj->get_last_listing_purpose();
$last_lst_desc = $obj->get_last_listing_desc();
$last_descriptioon = $obj->get_last_description();

$curr_month = $obj->get_last_price_cur_month();
$curr_day = $obj->get_last_price_curr_day();

//get sessions
/*
  $_SESSION['listing_date'] = $last_lst_date;
  $_SESSION['listing_type'] = $last_lst_type;
  $_SESSION['title'] = $last_lst_title;
  $_SESSION['last_descriptioon'] = $last_descriptioon;
  $_SESSION['purpose'] = $last_lst_purpose;
  $_SESSION['property_category'] = $last_lst_prop_cat;
  $_SESSION['property_type_id'] = $last_lst_prop_type;
  $_SESSION['commission'] = $last_lst_prop_type;

  $_SESSION['curr_month'] = $curr_month;
  $_SESSION['curr_day'] = $curr_day;


 */


//curr month
//    $prop_type = $_SESSION['property_type_id'];
if ($last_lst_prop_type == 8) {
    $last_bas_aprt_bedroom = $obj->get_last_bedroom_apartment();
    $last_bas_aprt_bathroom = $obj->get_last_bathrooms_apartment();
    $last_bas_aprt_flor_no = $obj->get_last_floor_number_apartment();
    $last_bas_aprt_tot_flor = $obj->get_last_total_floor_nbr_apartment();
    $last_bas_aprt_furnished = $obj->get_last_furnished_apartment();

    //store in sessions
//    $_SESSION['basic_aprt_bedrooms'] = $last_bas_aprt_bedroom;
//    $_SESSION['basic_aprt_bathrooms'] = $last_bas_aprt_bathroom;
//    $_SESSION['basic_aprt_flor_no'] = $last_bas_aprt_flor_no;
//    $_SESSION['basic_aprt_tot_no'] = $last_bas_aprt_tot_flor;
//    $_SESSION['basic_aprt_furnished'] = $last_bas_aprt_furnished;
} else if ($last_lst_prop_type == 9) {
    $last_basic_comm_bedroom = $obj->get_last_basic_commercial_bedroom();
    $last_basic_comm_bathroom = $obj->get_last_basic_commercial_bathroom();
    $last_basic_comm_compound_size = $obj->get_last_basic_commercial_compound_size();
    $last_basic_comme_living_flors = $obj->get_last_basic_commercial_living_flors();
    $last_basic_comm_totaln_flors = $obj->get_last_basic_commercial_totalnumber_flors();
    $last_basic_comm_furnished = $obj->get_last_basic_commercial_furnished();

    //store in sessions
//    $_SESSION['basic_comm_bedrooms'] = $last_basic_comm_bedroom;
//    $_SESSION['basic_comm_bathrooms'] = $last_basic_comm_bathroom;
//    $_SESSION['basic_comm_compound_size'] = $last_basic_comm_compound_size;
//    $_SESSION['basic_comm_living_flor'] = $last_basic_comme_living_flors;
//    $_SESSION['basic_comm_total_noFlor'] = $last_basic_comm_totaln_flors;
//    $_SESSION['basic_comm_furnished'] = $last_basic_comm_furnished;
} else if ($last_lst_prop_type == 10) {
    $last_basic_house_furnished = $obj->get_last_furnished_house();
    $last_basic_house_available = $obj->get_last_available_house();
    $last_basic_house_bedroom = $obj->get_last_bedroom_house();
    $last_basic_house_bathroom = $obj->get_last_bathroom_house();
    $last_basic_house_comp_size = $obj->get_last_compound_size_house();
    $last_basic_house_living_flors = $obj->get_last_living_floors_house();
    $last_basic_house_tot_n_floors = $obj->get_last_total_number_floors_house();

    //store in sessions
//    $_SESSION['update_basic_house_furnished'] = $last_basic_house_furnished;
//    $_SESSION['basic_available_from'] = $last_basic_house_available;
//    $_SESSION['basic_house_bedrooms'] = $last_basic_house_bedroom;
//    $_SESSION['basic_house_bathrooms'] = $last_basic_house_bathroom;
//    $_SESSION['basic_house_compound_size'] = $last_basic_house_comp_size;
//    $_SESSION['basic_house_living_floor'] = $last_basic_house_living_flors;
//    $_SESSION['basic_total_number_floors'] = $last_basic_house_tot_n_floors;
} else if ($last_lst_prop_type == 11) {
    $basic_administrative_location = $obj->get_last_admin_loc_land();
    $basic_land_plot_no = $obj->get_last_plotno_land();
    $basic_land_plot_size = $obj->get_last_plotsize_land();
    $basic_lot_use = $obj->get_last_lotuse_land();
    $basic_land_available_from = $obj->get_last_available_land();


    //store in sessions
//    $_SESSION['basic_administrative_location'] = $basic_administrative_location;
//    $_SESSION['basic_land_plot_no'] = $basic_land_plot_no;
//    $_SESSION['basic_land_plot_size'] = $basic_land_plot_size;
//    $_SESSION['basic_lot_use'] = $basic_lot_use;
//    $_SESSION['basic_land_available_from'] = $basic_land_available_from;
} else if ($last_lst_prop_type == 12) {
    $basic_administrative_location = $obj->get_last_admin_loc_land();
    $basic_land_plot_no = $obj->get_last_plotno_land();
    $basic_land_plot_size = $obj->get_last_plotsize_land();
    $basic_lot_use = $obj->get_last_lotuse_land();
    $basic_land_available_from = $obj->get_last_available_land();
    //store in sessions
    //shall do it later because it doesn't have the prop categories
}

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="----------PRICE-------------">

// </editor-fold>
