<?php
require_once './wizard_helper.php';
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
if (!isset($_SESSION['last_listng'])) {
//     header('location: new_listing.php');
}
$fillbg = new dialogs();
?>
<form action="new_image.php" method="post" enctype="multipart/form-data">
    <div class="off warn_dialogs"> <?php
        echo $fillbg->full_bg() . $fillbg->smaller_dialog();
        ?></div>
    <div id="more_dialogs"></div>
    <div class="parts eighty_centered smart_parts">
        <?php if (isset($_SESSION['complete_updating'])) { ?>
            <div class="parts full_center_two_h heit_free smart_font no_shade_noBorder">Add more or remove existing images</div>
        <?php } else { ?>
            <div class="parts full_center_two_h heit_free smart_font no_shade_noBorder">Add new images of the property</div> <?php } ?>
        <div class="parts eighty_centered no_shade_noBorder no_paddin_shade_no_Border">
            <?php
            if (isset($_POST['send_upload'])) {
                require_once './wizard_helper.php';
                $wiz_helper = new wizard_helper();
                $path = '../web_images/property/';
                echo "No. files uploaded : " . count($_FILES['files']['name']) . "<br>";
                for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
                    echo "File names : " . $_FILES['files']['name'][$i] . "<br>";
                    $ext = substr(strrchr($_FILES['files']['name'][$i], "."), 1);
                    require_once '../web_db/multi_values.php';
                    require_once '../web_db/new_values.php';
                    $obj1 = new new_values();
                    $obj2 = new multi_values();
                    //Last listng
                    $img = $obj2->get_last_image_id() + 1;

                    $deleted = 'no';
                    $appear = 'yes';
                    $listing = $obj2->get_lastlisting($_SESSION['userid']);
                    session_start();
                    $fPath = $img . ".$ext";
                    //new image in database => this is to save the path
                    $obj1->new_image($fPath, $listing, $deleted, $appear);
                    $wiz_helper->clear_all_sessions();
                    // generate a random new file name to avoid name conflict
                    // if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                    //     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                    //     $uploadOk = 0;
                    // }
                    echo "File paths : " . $_FILES['files']['tmp_name'][$i] . "<br>";
                    $result = move_uploaded_file($_FILES['files']['tmp_name'][$i], $path . $fPath);
                    if (strlen($ext) > 0) {
                        echo "Uploaded " . $fPath . " succefully. <br>";
                    }
                }
                ?>
                <script>
                    //                                window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
                    window.location.replace('http://localhost/REstate/Admin/redirect.php');
                </script>
                <?php
            }
            ?>
        </div>
        <div class="field" align="left">
            <?php if (empty($_SESSION['complete_updating'])) { ?>
                <table class="left_off_eighty top_off_x">
                    <tr>
                        <td>Image:</td>
                        <td> <input type="file" id="files"required=""  name="files[]" multiple /></td>
                    </tr>
                </table>
                <?php
            } else {
                ?><div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                    <div class="parts tab_buttons link_cursor" id="tab1">Add more images</div>
                    <div class="parts tab_buttons link_cursor" id="tab2">Options</div>
                </div> 
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border reverse_border" id="image_tabcontents" >
                    <div class="parts eighty_centered no_paddin_shade_no_Border off tab_content " id="tab1_content">
                        <table  style="font-size: 13px;">
                            <tr>
                                <td>Choose image:</td>
                                <td> <input type="file" required="" id="files"  name="files[]" multiple /></td>
                            </tr>
                        </table>
                    </div>
                    <div class="parts eighty_centered off tab_content no_paddin_shade_no_Border" id="tab2_content">
                        <div class="parts no_shade_noBorder margin_free"> <a href="#" id="select_all_images" style="font-size: 13px;">Select all</a></div>
                        <div class="parts no_shade_noBorder margin_free"><a href="#"  id="deleteAll_images"> Delete All</a></div>
                    </div>
                </div>
                <?php
                $obj2 = new multi_values();
                $listing = $_SESSION['complete_updating'];
                $obj2->get_images_by_listing($listing);
            }
            ?>
        </div> 
    </div>
    <div class="parts  eighty_centered smart_parts">  
        <?php if (!empty($_SESSION['complete_updating'])) { ?>
            <input type="submit" class="confirm_buttons" value="Confirm updates" name="send_Upd_upload">

        <?php } else { ?>
            <input type="submit" class="confirm_buttons" value="Confirm" name="send_upload">
        <?php } ?>
    </div>
    <div class="parts eighty_centered no_paddin_shade_no_Border off" >
        <?php
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
//     $obj->list_image();
        ?>
    </div>
    <div class=" parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</form>
<?php

function save_image() {
    $target_dir = "../web_images/property/";
    $target_file = $target_dir . basename($_FILES["txt_path"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $ExtensionWithDot = '.' . $imageFileType;
    $file_with_noExtension = basename($target_file, $ExtensionWithDot);
//save the image in folder (upload)

    require_once '../web_db/multi_values.php';
    $obj2 = new multi_values();
//Last listng
    $img = $obj2->get_last_image_id();


    $newname = $img . '.' . $imageFileType;
    $new_target_file = $target_dir . $newname;
    $target_file_for_db = $new_target_file;
//save the image in the db (save path)
//save the pathe in the db
// Check if image file is a actual image or fake image
    if (isset($_POST["send"])) {
        $check = getimagesize($_FILES["txt_path"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }
// Check if file already exists
    if (file_exists($target_file)) {
//        echo "Sorry, file already exists.";
//        $uploadOk = 0;
    }
// Check file size
    if ($_FILES["txt_path"]["size"] > 3000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
//                    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
// Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["txt_path"]["tmp_name"], $new_target_file)) {
            echo "The file " . basename($_FILES["txt_path"]["name"]) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

if (isset($_POST['send_Upd_upload'])) {
    if (!empty($_FILES)) {
        require_once './wizard_helper.php';
        $wiz_helper = new wizard_helper();

        $path = '../web_images/property/';
        echo "No. files uploaded : " . count($_FILES['files']['name']) . "<br>";
        for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
            echo "File names : " . $_FILES['files']['name'][$i] . "<br>";
            $ext = substr(strrchr($_FILES['files']['name'][$i], "."), 1);

            require_once '../web_db/multi_values.php';
            require_once '../web_db/new_values.php';
            $obj1 = new new_values();
            $obj2 = new multi_values();

            //Last listng
            $img = $obj2->get_last_image_id() + 1;

            $deleted = 'no';
            $appear = 'yes';

            $fPath = $img . ".$ext";
            //new image in database => this is to save the path
            session_start();
            $obj1->new_image($fPath, $_SESSION['complete_updating'], $deleted, $appear);
            $wiz_helper->clear_all_sessions();
            // generate a random new file name to avoid name conflict
            // if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            //     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            //     $uploadOk = 0;
            // }
            echo "File paths : " . $_FILES['files']['tmp_name'][$i] . "<br>";
            $result = move_uploaded_file($_FILES['files']['tmp_name'][$i], $path . $fPath);
            if (strlen($ext) > 0) {
                echo "Uploaded " . $fPath . " succefully. <br>";
            }
        }
        ?>
        <script>
            //                                window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
            window.location.replace('http://localhost/REstate/Admin/redirect.php');
        </script>
        <?php
        unset($_SESSION['complete_updating']);
    } else {
        unset($_SESSION['complete_updating']);
        ?>
        <script>
            //                                window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
            window.location.replace('http://localhost/REstate/Admin/redirect.php');
        </script><?php
    }
}
if (isset($_POST['Cancel'])) {
    unset($_SESSION['complete_updating']);
    ?>        <script>
            //                                window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
            window.location.replace('http://localhost/REstate/Admin/redirect.php');
    </script><?php
}