<?php
session_start();
current_step();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>
<html>
    <head>
        <style>
            #update_link a{
                color: #fff;
                text-decoration: none;
                text-align: center;
                font-family: arial;
            }
        </style>
        <title>
            Listing
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_listing.php" method="post" enctype="multipart/form-data">
            <input type="text" class="textbox off" placeholder="property type"      name="txt_property_type_id"  id="txt_property_type_id">
            <input type="text" class="textbox off" placeholder="proprty cat"        name="txt_property_cat_id"   id="txt_property_cat_id">
            <input type="text" class="parts off  " style="margin-left: 300px;" placeholder="property name"      name="txt_prop_name"         id="prop_name" />
            <input type="text" class="textbox off" placeholder="Current step"       name="txt_current_step"      id="current_step" value="<?php echo $_SESSION['current_step']; ?>"/>
            <input type="text" class="textbox off" placeholder="lisitng type" name="txt_listing_type" id="listing_type" />
            <div class="off" id="d">
            </div>
            <?php
            include 'Admin_header.php';
            include './steps.php';
            ?>
            <div class="parts eighty_centered  new_data_box ">
                <div class="parts   xx_titles no_paddin_shade_no_Border ">listing
                    <?php
                    if (isset($_POST['send_listing'])) {
                        try {
                            require_once '../web_db/new_values.php';
                            require_once './dbConnection.php';
                            $con = new my_connection();
                            //Entities engaged
                            //=>Listing table
                            //=>Account id from account
                            //=>property by its property category id
                            //=>location by cell id
                            //posted vars and global vars

                            $account = $_SESSION['userid'];
                            $listing_date = date("y-m-d");
                            $listing_type = $_POST['txt_listing_type'];

                            //listing
                            // $property = $listing_typeid;
                            //property fields
                            $title = $_POST['txt_title'];
                            $description = $_POST['txt_desc'];
                            $basic_info = '';
                            $property_type_id = $_POST['txt_property_type_id'];
                            $property_category = $_POST['txt_property_cat_id'];
                            //property  category
                            $purpose = $listing_type;
                            $obj = new new_values();
                            $obj->new_listing(trim($listing_date), trim($account), trim($listing_type), trim(get_property_id()), trim($title), trim($description), trim($purpose), trim($property_category), 0);
                            //Last listng
                            $mul_obj = new multi_values();
                            $last_listingid = $mul_obj->get_lastlisting();
                            $_SESSION['last_listng'] = $last_listingid;
                            $_SESSION['listing_done'] = 'done';
                            //save the features with the last listing

                            $prop_type = trim($_POST['txt_prop_name']);

                            if ($prop_type == 'Apartment') {
                                $features = $_POST['features'];
                                foreach ($features as $feat) {
                                    $obj->new_listing_features($last_listingid, $feat);
                                }
                                basic_aparts();
                            } else if ($prop_type == 'House') {
                                $features = $_POST['features'];
                                foreach ($features as $feat) {
                                    $obj->new_listing_features(trim($last_listingid), trim($feat));
                                }
                                basic_house();
                            } else if ($prop_type == 'Land') {
                                $features = $_POST['features'];
                                foreach ($features as $feat) {
                                    $obj->new_listing_features($last_listingid, $feat);
                                }
                                basic_land();
                            }
                            ?>
                            <script>
                                window.location.replace('http://localhost/Restate/Admin/new_price.php');
                            </script>
                            <?php
                        } catch (PDOException $e) {
                            echo 'Error while saving data! ' . $e->getMessage();
                        }
                        //save features
                    }
                    ?>
                </div>
                <table   class="new_data_table " border="1">
                    <tr>
                        <td>Listing purpose:</td>
                        <td><span id="listing_type_chosen"></span> <?php include './new_listing_type.php'; ?></td>
                    </tr>
                    <tr><td>Property Type :</td><td> <?php get_property_type_combo(); ?></td></tr>
                    <tr><td><span id="property_subCat_label" class="off">property category:</span></td>
                        <td><div class="parts full_center_two_h x_height_one_h" id="my_cat_res">
                            </div>
                        </td>
                    </tr>
                    <tr><td>Property Title :</td><td><input required  type="text" required="" name="txt_title" placeholder="Property title" class="textbox" />   </td></tr>
                    <tr><td>Description :</td><td><textarea required style="height: 100px;" name="txt_desc" placeholder="Property description" class="textbox" ></textarea>   </td></tr>
                    <?php
                    include './basic_info/new_basic_apartment.php';
                    include './basic_info/new_basic_house.php';
                    include './basic_info/new_basic_land.php';
                    ?>
                </table>
                <div class="parts full_center_two_h no_paddin_shade_no_Border x_titles heit_free">Features</div>
                <div class="parts full_center_two_h heit_free no_shade_noBorder" id="features_box">
                </div>
            </div>
            <div class="parts eighty_centered  ">
                <a href="update_listing.php">
                    <div class="parts   confirm_buttons two_fifty_left heit_free" style="float: left; " id="update_link">
                        <center> UPDATE</center>
                    </div></a>
                <input type="submit" class="confirm_buttons" name="send_listing" id="btn_send_listing" value="SAVE AND CONTINUE">
            </div>
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        </form>


    </body>
</hmtl>
<?php

function get_property_type_combo() {
    $bean = new multi_values();
    $bean->get_prop_type_combo();
}

function get_provinces_boxes() {
    $bean = new multi_values();
    $bean->get_provinces_boxes();
}

function get_district_boxes() {
    $bean = new multi_values();
    $bean->get_districts_boxes();
}

function get_sector_boxes() {
    $bean = new multi_values();
    $bean->get_sectors_boxes();
}

function get_cells_boxes() {
    $bean = new multi_values();
    $bean->get_cells_boxes();
}

function get_provinces_combo() {
    $bean = new multi_values();
    $bean->get_provinces_combo2();
}

function get_sectors_combo() {
    $bean = new multi_values();
    $bean->get_sectors_combo();
}

function map() {
    include './my_map.php';
}

function get_property_id() {
    $con = new my_connection();
    $prop_name = $_POST['txt_prop_name'];
    $property_id = '';
    $sql = "select    property.property_id from property_type join property on property_type.property=property.property_id where property_type.property_type_id in(select property_type.property from property_type where name=:name);";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":name" => $prop_name));
    while ($row = $stmt->fetch()) {
        $property_id = $row['property_id'];
    }
    return $property_id;
}

function get_last_location() {
    $con = new my_connection();
    $sql3 = "select  location.location_id from location order by location.location_id desc limit 1";
    $stmt = $con->getCon()->prepare($sql3);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $last_locationid = $row['location_id'];
    return $last_locationid;
}

class More_onListing {

    function get_propertyCat_by_proerty_types($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select     property_category.name from property_category join property_type on property_type.property_type_id=property_category.type where property_type.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts  full_center_two_h margin_free heit_free no_paddin_shade_no_Border res_item">' . $row['name'] . '</div>';
        }
    }

}

function basic_aparts() {
    $basic_apartmentdeleted = 'no';
    $mul_obj = new multi_values();
    $listing = $mul_obj->get_lastlisting();
    $bedrooms = $_POST['txt_bedrooms'];
    $bathrooms = $_POST['txt_bathrooms'];
    $floor_number = $_POST['txt_floor_number'];
    $total_number_floors = $_POST['txt_total_number_floors'];
    $furnished = $_POST['txt_furnished'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished);
}

function basic_house() {
    $basic_housedeleted = 'no';
    $mul_obj = new multi_values();
    $listing = trim($mul_obj->get_lastlisting());
    $furnished = trim($_POST['txt_house_furnished']);
    $available_from = trim($_POST['txt_houae_available_from']);
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_basic_house($basic_housedeleted, $listing, $furnished, $available_from);
}

function basic_land() {
    $basic_landdeleted = 'no';
    $mul_obj = new multi_values();
    $listing = $mul_obj->get_lastlisting();
    $administrative_location = trim($_POST['txt_administrative_location']);
    $plot_number = trim($_POST['txt_plot_number']);
    $plot_size = trim($_POST['txt_plot_size'] . ' ' . $_POST['plot_measure']);
    $lot_use = trim($_POST['txt_lot_use']);
    $available_from = trim($_POST['txt_land_available_from']);
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_basic_land(trim($basic_landdeleted), trim($listing), trim($administrative_location), trim($plot_number), trim($plot_size), trim($lot_use), trim($available_from));
}

function current_step() {
    $_SESSION['current_step'] = 1;
}
