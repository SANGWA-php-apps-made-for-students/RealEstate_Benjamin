<?php
session_start();
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
require_once '../web_db/new_values.php';
?>
<html>
    <head>
        <title>
            property_type</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>   
    <body>
        <form action="new_property_type.php" method="post" enctype="multipart/form-data">
            <input type="hidden" class="textbox" name="txt_propertyid" id="txt_propertyid">
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered no_shade_noBorder">
                <?php
                save_prop_type();
                ?>
            </div>
            <div class="parts no_shade_noBorder eighty_centered smart_font">  Property categories</div>
            <div class="parts eighty_centered no_paddin_shade_no_Border new_data_box off">
                <table class="new_data_table">
                    <tr><td>property :</td><td> 
                            <?php
                            $obj = new multi_values();
                            $obj->get_property_combo();
                            ?>
                        </td></tr>
                    <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox"   </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="button" name="send_property_type" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered" >
                <?php
                $obj->list_property_type();
                ?>
            </div>
            <div class=" parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>

    </body>
</hmtl>
<?php

function save_prop_type() {
    if (isset($_POST['send_property_type'])) {
        $name = $_POST['txt_name'];
        $prop_id = $_POST['txt_propertyid'];
        if ($name != '') {
            if ($prop_id != '') {
                $obj = new new_values();
                $obj->new_property_type($name, $prop_id);
                echo 'saved successfully';
            } else {
                echo '<div class="red_message>" You have to choose the property name</div>';
            }
        } else {
            echo '<div class="red_message>" You have to provide the name the of the category</div>';
        }
    }
}
