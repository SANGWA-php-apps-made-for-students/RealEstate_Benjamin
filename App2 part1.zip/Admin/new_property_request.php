<?php
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_property_request'])) {

    $property_requestdeleted = $_POST['txt_property_requestdeleted'];
    $names = $_POST['txt_names'];
    $telephone = $_POST['txt_telephone'];
    $email = $_POST['txt_email'];
    $listing = $_POST['txt_listing_id'];
    $received = $_POST['txt_received'];
    $account = $_POST['txt_account'];

    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_property_request($property_requestdeleted, $names, $telephone, $email, $listing, $received, $account);
}
?>

<html>
    <head>
        <title>
            property_request</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_property_request.php" method="post" enctype="multipart/form-data">


            <input type="hidden" id="txt_listing_id"   name="txt_listing_id"/>
            <?php
            include 'Admin_header.php';
            ?>

            <div class="parts eighty_centered no_paddin_shade_no_Border">    <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div><div class="parts eighty_centered off saved_dialog">
                property_request saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  property_request</div>
                <table class="new_data_table">


                    <tr><td>property_requestdeleted :</td><td> <input type="text"     name="txt_property_requestdeleted" required class="textbox" />  </td></tr>
                    <tr><td>names :</td><td> <input type="text"     name="txt_names" required class="textbox" />  </td></tr>
                    <tr><td>telephone :</td><td> <input type="text"     name="txt_telephone" required class="textbox" />  </td></tr>
                    <tr><td>email :</td><td> <input type="text"     name="txt_email" required class="textbox" />  </td></tr>
                    <tr><td>listing :</td><td> <?php get_listing_combo(); ?>  </td></tr><tr><td>received :</td><td> <input type="text"     name="txt_received" required class="textbox" />  </td></tr>
                    <tr><td>account :</td><td> <input type="text"     name="txt_account" required class="textbox" />  </td></tr>


                    <tr><td colspan="2"> <input type="submit" class="button" name="send_property_request" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <?php
                $obj = new multi_values();
                $obj->list_property_request();
                ?>

            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_listing_combo() {
    $obj = new multi_values();
    $obj->get_listing_in_combo();
}
