<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../dbConnection.php';
$con = new my_connection();

if (!isset($_SESSION['listing_done'])) {
//    header('location: new_listing.php');
}
if (isset($_POST['send_price'])) {
    $listing_id = $_POST['txt_listing_id'];
    $last_listingid = $listing_id;
    $property = $listing_id;
    $amount = $_POST['txt_amount'];
    $amount_per_day = $_POST['txt_amount_per_day'];
    if ($amount < 1 && $amount_per_day < 1) {
        ?>
        <script>
            alert('You have provide the amount paid either per month or per day');
        </script>
        <?php
    } else {
        $currency = trim($_POST['txt_currency']);
        $combo = trim($_POST['condition_combo']);
        $condition = empty($_POST['txt_other_condition']) ? $combo : $_POST['txt_other_condition'];
        $commission = trim($_POST['txt_commission']);
        $deposit_required = (isset($_pos['txt_deposit_toggle'])) ? 'required' : 'not required';
        $utilities_extra = trim($_POST['condition_combo']);
        $condition_per_day = trim($_POST['txt_condition_per_day']);
        $minimum_advance_per_day = trim($_POST['txt_minimum_advance_per_day']);
        $deposit_required_per_day = trim($_POST['txt_deposit_required_per_day']);
        $commission_per_day = trim($_POST['txt_commission_per_day']);
        $utilities_extra_per_day = trim($_POST['txt_utilities_extra_per_day']);

        $last_listing = $_POST['txt_listing_id'];
        //    foreach ($deposit_required as $dep) {
        //        $depo = $dep;
        //    }
        $Minimum_advance = $_POST['txt_minimum_advance'];
        new_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $last_listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day);
    }
}
?>
<html>
    <head>
        <title>
            account
        </title>
        <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            input[type="file"] {
                display: block;
            }
            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }
            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }
            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }
            .remove:hover {
                background: white;
                color: black;
            }
            p{
                margin: 20px;
                color: #4c1758;
                text-decoration: underline;
            }
            .new_data_table td{
                padding: 5px;
            }
            #sp_table td{
                padding: 10px;

            }
            #sp_table{
                border-collapse: collapse;
            }
        </style>
        <style>
            .textbox_price{
                width: 250px;
                float: left;
                padding: 14px;
                margin-left: 0px;

            }
            .new_data_table td{
                padding: 5px;
            }
        </style>
    </head>
    <body>
        <form action="Addon_prices.php" method="post" enctype="multipart/form-data">

            <div class="parts abs_full margin_free off" id="images_dialog">
            </div>
            <div class="parts abs_child eighty_centered skin3 off" id="child_dialog">
                <div class="parts full_center_two_h heit_free  off"id="title_prop"  >
                    The tile of the property
                </div>
                <div class="parts full_center_two_h heit_free">
                    <?php
                    if (isset($_POST['send_updates_images'])) {
                        $path = '../../web_images/property/';
                        echo "No. files uploaded : " . count($_FILES['files']['name']) . "<br>";
                        for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
                            echo "File names : " . $_FILES['files']['name'][$i] . "<br>";
                            $ext = substr(strrchr($_FILES['files']['name'][$i], "."), 1);
                            //Last listng

                            $last_listing = $_POST['txt_listing_id'];
                            $deleted = 'no';
                            $appear = 'yes';

                            //new image in database => this is to save the path
                            new_image($last_listing . '.' . $ext, $last_listing, $deleted, $appear);
                            // generate a random new file name to avoid name conflict
                            $fPath = $last_listing . ".$ext";
                            // if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                            //     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                            //     $uploadOk = 0;
                            // }
                            echo "File paths : " . $_FILES['files']['tmp_name'][$i] . "<br>";
                            $result = move_uploaded_file($_FILES['files']['tmp_name'][$i], $path . $fPath);
                            if (strlen($ext) > 0) {
                                echo "Uploaded " . $fPath . " succefully. <br>";
                            }
                        }
                    }
                    ?>
                </div>

                <div class="parts full_center_two_h heit_free">
                    <div class="field" align="left">

                    </div>
                </div>
                <div class="parts full_center_two_h heit_free">
                    <input type="submit" value="Confirm" class="confirm_buttons" name="send_updates_images">
                </div>
            </div>

            <div class="parts abs_child eighty_centered off" id="child_prices" style="background-color: #2c7489;">
                <?php
                require_once 'completer_listing_prices.php';
                ?>
            </div>
            <?php
            include 'Admin_header.php';
//            include './sidemenu.php';
            ?> <div class="parts two_fifty_right heit_free">
                <a href="../admin_dashboard.php">Home</a>
            </div>
            <input type="text" id="acc_typeid" class="off"  name="userid"/>
            <span id="d" class="off"></span>
            <div class="parts eighty_centered dialogBox no_shade_noBorder ">

            </div>
            <div class="parts eighty_centered margin_free no_paddin_shade_no_Border new_data_box ">
                <div class="parts margin_free  xx_titles no_paddin_shade_no_Border">  These listings have no prices</div>
                <br/>
                <?php get_listing_to_update_price(); ?>
            </div>
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
            <script src="../../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
            <script src="../../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        </form>
    </body>
</hmtl>
<?php

function new_image($path, $listing, $deleted, $appear) {

    $database = new my_connection();
    $db = $database->getCon();
    $stm = $db->prepare("insert into image values(:image_id, :path,  :listing,  :deleted,  :appear)");
    $stm->execute(array(':image_id' => 0, ':path' => $path, ':listing' => $listing, ':deleted' => $deleted, ':appear' => $appear
    ));
}

function get_listing_to_update_price() {

    $con = new my_connection();
    $db = $con->getCon();
    $sql = "select listing.listing_id,  listing.listing_date,  listing.account,  listing.listing_type,  listing.property,  listing.title,  listing.purpose,  listing.property_category,  listing.location
            from listing    where listing.listing_id not in (select listing from price where listing <>'null')
             ";
    ?>
    <table class="dataList_table">
        <thead><tr><td> listing_id </td><td> listing_date </td><td> title </td><td> purpose </td>
                <td> location </td><td> Option </td>
            </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr>
                <td>        <?php echo $row['listing_id']; ?> </td>
                <td>        <?php echo $row['listing_date']; ?> </td>
                <td class="listing_title_col">        <?php echo $row['title']; ?> </td>
                <td>        <?php echo $row['purpose']; ?> </td>
                <td>        <?php echo $row['location']; ?> </td>
                <td>
                    <a href="#" class="id_listing_to_update_price" value="<?php echo $row['listing_id']; ?>">Select and add price</a>
                </td>
            </tr>
        <?php } ?></table>
    <?php
}

function get_lastlisting() {
    $db = new my_connection();
    $sql = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
    $stmt = $db->getCon()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['listing_id'];
    return $userid;
}

function new_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day) {
    $database = new my_connection();
    $db = $database->getCon();
    $stm = $db->prepare("insert into price values(:price_id, :amount,  :currency,  :condition,  :property,  :Minimum_advance,  :deposit_required,  :commission,  :utilities_extra,  :listing,  :amount_per_day,  :condition_per_day,  :minimum_advance_per_day,  :deposit_required_per_day,  :commission_per_day,  :utilities_extra_per_day)");
    $stm->execute(array(':price_id' => 0, ':amount' => $amount, ':currency' => $currency, ':condition' => $condition, ':property' => $property, ':Minimum_advance' => $Minimum_advance, ':deposit_required' => $deposit_required, ':commission' => $commission, ':utilities_extra' => $utilities_extra, ':listing' => $listing, ':amount_per_day' => $amount_per_day, ':condition_per_day' => $condition_per_day, ':minimum_advance_per_day' => $minimum_advance_per_day, ':deposit_required_per_day' => $deposit_required_per_day, ':commission_per_day' => $commission_per_day, ':utilities_extra_per_day' => $utilities_extra_per_day));
}
