<div class=" parts  full_center_two_h heit_free  margin_free skin no_shade_noBorder">
    <div class="parts margin_free ">
        <div class="parts  logo skin no_shade_noBorder margin_free" id="my_logo" style="border: 1px solid #fff; position: fixed;top:4px; left: 5px; background-color: #fff; height: 100px; ">

        </div>
    </div>  
    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border  link_cursor x_width_two_h">
        <a href="../logout.php" value="" class="logout">Logout</a>
    </div>
    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border  link_cursor x_width_two_h"> 
        <?php echo 'Welcome dear, ' . $_SESSION['names'] . '  (' . $_SESSION['cat'].')'; ?>
    </div> 
    <div class="parts no_paddin_shade_no_Border iconed">
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="c_users_cat">
        </div>
    </div>
    <div class="parts margin_free no_shade_noBorder two_fifty_right  heit_free allow_drop " >
       

    </div>
</div>