<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../dbConnection.php';
$con = new my_connection();
?>
<html>
    <head>
        <title>
            account
        </title>
        <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style> input[type="file"] {
                display: block;
            }
            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }
            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }
            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }
            .remove:hover {
                background: white;
                color: black;
            }
            p{
                margin: 20px;
                color: #4c1758;
                text-decoration: underline;
            }
            .new_data_table td{
                padding: 5px;
            }
            #sp_table td{
                padding: 10px;

            }
            #sp_table{
                border-collapse: collapse;
            }
        </style>
    </head>
    <body>
        <form action="Addon_images.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="txt_listing_id" id="txt_listing_id" />
            <div class="parts abs_full margin_free off" id="images_dialog">
            </div>

            <div class="parts abs_child eighty_centered skin3 off" id="child_dialog"style="background-color: #fff;">
                <div class="parts full_center_two_h heit_free  off"id="title_prop"  >
                    The tile of the property
                </div>
                <div class="parts full_center_two_h heit_free"> 
                    <?php
                    if (isset($_POST['send_updates_images'])) {
                        $listing = $_POST['send_updates_images'];
                        if (Listing_without_Images($listing) > 0) {//check if the listing has the price in order to prevent to jump the wizard step
                            $path = '../../web_images/property/';
                            echo "No. files uploaded : " . count($_FILES['files']['name']) . "<br>";
                            for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
                                echo "File names : " . $_FILES['files']['name'][$i] . "<br>";
                                $ext = substr(strrchr($_FILES['files']['name'][$i], "."), 1);
                                //Last listng
                                $last_listing = $_POST['txt_listing_id'];
                                $img = get_last_image_id() + 1;
                                $fPath = $img . ".$ext";

                                $deleted = 'no';
                                $appear = 'yes';

                                //new image in database => this is to save the path
                                new_image($img . '.' . $ext, $last_listing, $deleted, $appear);
                                // generate a random new file name to avoid name conflict
                                // if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                                //     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                                //     $uploadOk = 0;
                                // }
                                echo "File paths : " . $_FILES['files']['tmp_name'][$i] . "<br>";
                                $result = move_uploaded_file($_FILES['files']['tmp_name'][$i], $path . $fPath);
                                if (strlen($ext) > 0) {
                                    echo "Uploaded " . $fPath . " succefully. <br>";
                                }
                            }
                        } else {
                            ?><script>alert('the listing must have price first before adding images');</script><?php
                        }
                    }
                    ?>
                </div>
                <div class="parts full_center_two_h heit_free" >
                    <div class="field" align="left">
                        <input type="file" id="files" name="files[]" multiple /></td>

                    </div>
                </div>
                <div class="parts full_center_two_h heit_free">
                    <input type="submit" value="Confirm" class="confirm_buttons" name="send_updates_images">
                </div>

            </div>
            <?php
            include 'Admin_header.php';
//            include './sidemenu.php';
            ?> <div class="parts two_fifty_right heit_free">
                <a href="../admin_dashboard.php">Home</a>
            </div>
            <input type="text" id="acc_typeid" class="off"  name="userid"/>
            <span id="d" class="off"></span>

            <div class="parts eighty_centered dialogBox no_shade_noBorder ">

            </div>
            <div class="parts eighty_centered margin_free no_paddin_shade_no_Border new_data_box ">
                <div class="parts margin_free  xx_titles no_paddin_shade_no_Border">  These listings have no images</div>
                <br/>
                <?php
                get_listing_to_update_image();
                ?>
            </div>

            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
            <script src="../../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
            <script src="../../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        </form>
    </body>
</hmtl>
<?php

function new_image($path, $listing, $deleted, $appear) {

    $database = new my_connection();
    $db = $database->getCon();
    $stm = $db->prepare("insert into image values(:image_id, :path,  :listing,  :deleted,  :appear)");
    $stm->execute(array(':image_id' => 0, ':path' => $path, ':listing' => $listing, ':deleted' => $deleted, ':appear' => $appear
    ));
}

function get_listing_to_update_image() {

    $con = new my_connection();
    $db = $con->getCon();
    $sql = "select listing.listing_id,  listing.listing_date,  listing.account,  listing.listing_type,  listing.property,  listing.title,  listing.purpose,  listing.property_category,  listing.location
            from listing   where listing.listing_id not in (select listing from image)
             ";
    ?>
    <table class="dataList_table">
        <thead><tr><td> listing_id </td><td> listing_date </td><td> title </td><td> purpose </td>
                <td> location </td><td> Option </td>
            </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr>
                <td>        <?php echo $row['listing_id']; ?> </td>
                <td>        <?php echo $row['listing_date']; ?> </td>


                <td class="listing_title_col">        <?php echo $row['title']; ?> </td>
                <td>        <?php echo $row['purpose']; ?> </td>

                <td>        <?php echo $row['location']; ?> </td>
                <td>
                    <a href="#" class="id_listing_to_update" value="<?php echo $row['listing_id']; ?>">Select and add image</a>
                </td>
            </tr>
        <?php } ?></table>
        <?php
}

function get_last_image_id() {
    $con = new my_connection();
    $sql = "select      image.image_id as id from image order by image_id desc limit 1";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['id'];
    return $userid;
}

function Listing_without_Images($listing) {
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "  select    count(listing_id) as tot  from listing  where listing.listing_id not in (select listing from image) and listing.listing_id in (select listing from price) where listing.listing_id=:listing";
    $stmt = $db->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    while ($row = $stmt->fetch()) {
        $c = $row['tot'];
    }
    return $c;
}
