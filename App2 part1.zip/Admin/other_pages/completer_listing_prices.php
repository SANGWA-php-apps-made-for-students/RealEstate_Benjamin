<?php
current_step();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../dbConnection.php';
$con = new my_connection();
?>

<input type="text" class="textbox_price off" placeholder="Current step" name="txt_current_step"id="current_step" value="<?php echo $_SESSION['current_step']; ?>"/>
<input type="text" class="textbox_price off" id="txt_condition_id" />
<input type="text" class="off" name="txt_listing_id" id="txt_listing_id" />
<input type="text" class="off" name="txt_deposit_toggle" id="txt_deposit_toggle" />
<div class="parts eighty_centered off ">
    price saved successfully!</div>
<div class="parts eighty_centered margin_free no_paddin_shade_no_Border">
    <div class="part eighty_centered no_paddin_shade_no_Border">
        <div class="parts full_center_two_h heit_free xx_titles no_paddin_shade_no_Border whilte_text">
            You can update listing by adding the price here below
        </div>
    </div>
    <a href="#">
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" style="color: #fff;" id="listing_title">

        </div>
    </a>
</div>

<div class="parts eighty_centered no_shade_noBorder ">
    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border">
        <table class="new_data_table">

            <td colspan="2">
                <div class="parts two_fifty_left heit_free no_paddin_shade_no_Border xx_titles">
                    Price per month
                </div>
            </td>
            </tr>
            <tr>
                <td>Amount</td>     <td>   <input type="text"   value="0"  name="txt_amount" required class="textbox_price only_numbers" /> </td>
            </tr>

            <tr>
                <td></td>
                <td> <input type="text" class="textbox_price off only_numbers" id="price_cond_textfield" placeholder="Specify the condition" name="txt_other_condition" style="width: 200px;" /></td>
            </tr>
            <tr>
                <td>Minimum advance:</td><td> <input type="text" class="textbox_price only_numbers" required name="txt_minimum_advance" /></td>
            </tr>
            <tr>
                <td> <label style="float: left;" for="deposity">Deposit required</label></td>
                <td colspan="2"><input type="checkbox" name="deposity" value="deposity" id="deposity" /></td>
            </tr>
            <tr>
                <td>Commission: </td><td><input type="text" class="textbox_price " name="txt_commission" /> </td>
            </tr>
            <tr>
                <td>Currency</td>
                <td> <select name="txt_currency" class="textbox_price" ><option></option>
                        <option  name="txt_currency" >
                            USD
                        </option>
                        <option  name="txt_currency" >
                            Rwf
                        </option>
                        <option  name="txt_currency" >
                            Shs
                        </option>
                    </select></td>
            </tr>
            <tr>
                <td>Condition</td><td> <select id="price_condition" name="condition_combo" class=" textbox_price"  >
                        <option>
                        </option>
                        <option>N/A</option>
                        <option>Fixed</option>
                        <option>Negotiable</option>
                        <option>Other</option>
                    </select>

                </td>
            </tr>
            <tr><td>Utilities / Extra included in price:</td><td>
                    <select id="utilities_combo" name="condition_combo" style="width: 250px;">
                        <option>

                        </option>
                        <option>electricity</option>
                        <option>water</option>
                        <option>local security & waste collection fees</option>
                        <option>Gym</option>
                        <option>swimming pool</option>
                        <option>DSTV</option>
                        <option>Other</option>
                    </select>

                </td>
            </tr>
            <tr><td></td>
                <td>
                    <input type="text" name="txt_utilities_other"  class="textbox_price off" id="txt_utilities" placeholder="Specify other utilities">
                </td>
            </tr>
        </table>
    </div>
    <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border">
        <table class="new_data_table" >
            <td colspan="2">
                <div class="parts two_fifty_left heit_free no_paddin_shade_no_Border xx_titles">
                    Price per day
                </div>
            </td>
            <tr>
                <td>Amount per day</td>
                <td><input type="text" value="0"    name="txt_amount_per_day"  class="textbox_price" /></td>
            </tr>
            <tr class="off">
                <td>Condition</td>
                <td> <input type="text"     name="txt_condition_per_day"  class="textbox_price "  /></td>
            </tr>
            <tr class="off">
                <td>Advance</td>
                <td> <input type="text"     name="txt_minimum_advance_per_day"  class="textbox_price " /></td>
            </tr>
            <tr class="off">
                <td>deposit required: </td>
                <td><input type="text"     name="txt_deposit_required_per_day"  class="textbox_price " /></td>
            </tr>
            <tr class="off"l>
                <td>commission: </td>
                <td><input type="text"     name="txt_commission_per_day"  class="textbox_price " /></td>
            </tr>
            <tr class="off">
                <td>utilities_extra_per_day</td>
                <td><input type="text"     name="txt_utilities_extra_per_day" placeholder="utilisties (per day)"  class="textbox_price off" /><br/>
                </td>
            </tr>

        </table>
    </div>
    <div class=" parts full_center_two_h heit_free heit_free no_shade_noBorder">
        <input type="submit" class="confirm_buttons"  style="margin-top: 0px;" name="send_price" id="send_features" value="UPDATE"/>
    </div>
</div>

<div class="parts eighty_centered no_shade_noBorder">
    <?php
//                require_once '../web_db/multi_values.php';
//                $obj = new multi_values();
//                $obj->list_price();
    ?>
</div>
<?php

function get_features_checkbox() {
    require_once '../Admin/dbConnection.php';
    $con = new my_connection();
    $db = $con->getCon();
    $sql = " select   property_category.name from property_category join property_type on property_type.property_type_id=property_category.type where property_type.name='house'";
    foreach ($db->query($sql) as $row) {
        echo "<label for=\"feat\"> <input class=\"feat\" class=\"checkboxes\" name=\"feat\" type=\"checkbox\" value=" . $row['name'] . ">" . $row['name'] . "</label>";
    }
}

function current_step() {
    $_SESSION['current_step'] = 3;
    if (true) {

    }
}
