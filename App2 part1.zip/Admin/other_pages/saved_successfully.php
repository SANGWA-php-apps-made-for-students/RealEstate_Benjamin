<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>
<html>
    <head>
        <title>
            cell
        </title>
        <link href="../web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            #saved_box{
                background-image: url('../../web_images/saved_successfully.png');
                background-size: 50%;
                background-repeat: no-repeat;
                background-position-x: 300px;
            }
            #saved_message{
                color: #acee99;
                text-align: center;
            }
            #back_link{
                font-size: 30px;
            }
        </style>
    </head>
    <body>

        <form action="new_location.php" method="post" enctype="multipart/form-data">

            <input type="text" class="textbox off" name="txt_sector_id" id="txt_sector_id">
            <span class="off" id="d"></span>
            <?php include 'Admin_header.php'; ?>
            <div class="parts  eighty_centered x_height_5x no_paddin_shade_no_Border" id="saved_box">

                <div class="parts full_center_two_h heit_free no_shade_noBorder" id="saved_message">
                    Your data have been saved successfully!!
                </div>
                <div class="parts two_fifty_right heit_free" id="back_link">
                    <a href="../new_wizard.php" >Go back</a>
                </div>
            </div>
        </form>

        <script src="../../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script src="../../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                try {
                    $('#saved_message').animate({fontSize: '+3'}, 1000).animate({fontSize: '35'}, 1000);

                } catch (err) {
                    alert(err.message);
                }
            });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
