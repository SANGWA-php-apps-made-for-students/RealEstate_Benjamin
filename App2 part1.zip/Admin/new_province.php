<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>
<html>
    <head>
        <title>
            province</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head> 
    <body> 
        <div class="parts loc_p">
            <form action="new_location.php" method="post" enctype="multipart/form-data">
                <div class="parts eighty_centered no_paddin_shade_no_Border  margin_free smart_font">  province</div>
                <table class="new_data_table">
                    <tr><td>name :</td><td> <input type="text"     name="prov_txt_name" required   </td></tr>
                    <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                    <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_province" value="Save"/>  </td></tr>
                </table>

            </form></div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</hmtl>
