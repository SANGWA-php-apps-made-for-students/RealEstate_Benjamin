 
<?php

lack_image();

function lack_image() {
    require_once './dbConnection.php';
    $user = 55;
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "select    listing_id  from listing  where listing.listing_id not in (select listing from image) and listing.account=:user";
    $stmt = $db->prepare($sql);
    $stmt->execute(array(":user" => $user));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $image = $row['listingid'];
    echo 'image' . trim($image);
}
