<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
?>
<html>
    <head>
        <title>
            District
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    <div class="parts loc_p">
        <div class="parts  x_titles no_paddin_shade_no_Border  margin_free smart_font">
            District</div>
        <form action="new_location.php" method="post" enctype="multipart/form-data">
            <input type="text" class="textbox off" name="txt_province_id" id="txt_province_id">
            <span class="off" id="d"></span>
            <div class="parts  no_paddin_shade_no_Border">
                <?php save_district(); ?>
            </div>
            <table class="new_data_table">
                <tr><td>province :</td><td>
                        <?php
                        get_provincescombo();
                        ?>  </td></tr>
                <tr><td>name :</td><td> <input type="text"  class="parts"    name="txt_name" required  />  </td></tr>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_district" value="Save"/>  </td></tr>
            </table>
        </form>
    </div>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
</body>
</hmtl>
<?php

function save_district() {
    if (isset($_POST['send_district'])) {
        $name = $_POST['txt_name'];
        $province = $_POST['txt_province_id'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_district($name, $province);
        echo 'Saved successfully!';
    }
}

function get_provincescombo() {
    $bean = new multi_values();
    $bean->get_provinces_combo();
}
