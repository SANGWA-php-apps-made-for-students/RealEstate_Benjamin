<?php
require_once '../web_db/multi_values.php';
require_once './wizard_helper.php';
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>
<form action="new_wizard.php" method="post" enctype="multipart/form-data">
    <?php
    $mult = new multi_values();
    $cell_id = $mult->get_lastcell($_SESSION['userid']);
    $cell_name = (!empty($_SESSION['complete_updating'])) ? $mult->get_cell_by_listing($_SESSION['complete_updating']) : $mult->get_last_listing_location();
    $sector_id = $mult->get_sectorId_by_cell($cell_id);
    $sector_name = $mult->get_sector_by_cell($cell_id);
    $district_id = $mult->get_districtId_by_cell($cell_id);
    $district_name = $mult->get_district_by_cell($cell_id);
    $province_name = $mult->get_province_by_cell($cell_id);
    $province_id = $mult->get_provinceId_by_cell($cell_id);

    $long = $mult->get_long_by_cell($cell_id);
    $lat = $mult->get_lat_by_cell($cell_id);
//    $area = $mult->get_area_by_cell($cell_id);
    $address = $mult->get_address_by_cell($cell_id);
    $fillbg = new dialogs();
    ?>
    <script>
        // alert('location data do not exist in sessions ...');
    </script>
    <input type = "hidden"   class = "textbox "   placeholder = "Cell id"             name = "txt_cell_id"   id = "updateLoc_txt_cell_id"         value="<?php echo $cell_id; ?>">
    <input type = "hidden" class = "textbox " placeholder = "Cell name"             name = "txt_cell_name" id = "updateLoc_txt_cell_name"       value="<?php echo $cell_name; ?>">
    <input type = "hidden" class = "textbox " placeholder = "District id"           name = "txt_loc_lat"   id = "updateLoc_txt_district_id"     value="<?php echo $district_name; ?>">
    <input type = "hidden" class = "textbox " placeholder = "Sector id"             name = "txt_area"      id = "updateLoc_txt_sector_id"       value="<?php echo $sector_name; ?>">
    <input type = "hidden" class = "textbox " placeholder = "Province id"           name = "txt_loc_lng"   id = "updateLoc_txt_province_id"     value="<?php echo $province_name; ?>">
    <input type = "hidden" class = "textbox "   placeholder = "Long"                name = "txt_loc_lng"   id = "updateLoc_txt_loc_long"        value="<?php echo $long; ?>">
    <input type = "hidden" class = "textbox " placeholder = "lat"                   name = "txt_loc_lat"   id = "updateLoc_txt_loc_lat"         value="<?php echo $lat; ?>">
    <input type = "hidden" class = "textbox " placeholder = "area"                  name = "txt_area"      id = "updateLoc_txt_area"            value="<?php // echo $area;                                            ?>">
    <input type = "hidden" class = "textbox " placeholder = "Address"               name = "txt_loc_lng"   id = "updateLoc_txt_address"         value="<?php echo $address; ?>">
    <?php ?>
    <input type="hidden" class="textbox" placeholder="property type"      name="txt_property_type_id"  id="txt_property_type_id">
    <input type="hidden" class="textbox" placeholder="proprty cat"        name="txt_property_cat_id"   id="txt_property_cat_id">
    <input type="hidden" class="textbox" placeholder="province"           name="txt_province_id"       id="txt_province_id">
    <input type="hidden" class="textbox" placeholder="district"           name="txt_district_id"       id="txt_district_id">
    <input type="hidden" class="textbox" placeholder="loc lat"            name="txt_loc_lat"           id="txt_loc_lat"/>
    <input type="hidden" class="textbox" placeholder="loc lng"            name="txt_loc_lng"           id="txt_loc_lng"/>
    <input type="hidden" class="parts  " placeholder="property name"       name="txt_prop_name"  id="prop_name" />
    <input type="hidden" class="textbox" placeholder="Current step"       name="txt_current_step"      id="current_step" value="<?php echo $_SESSION['current_step']; ?>"/>
    <input type="hidden" class="textbox" placeholder="lisitng type" name="txt_listing_type" id="listing_type" />
    <div class="off" id="d">
    </div>

    <div class="parts eighty_centered  new_data_box smart_parts">
        <div class="parts   xx_titles no_paddin_shade_no_Border ">
            <?php
            if (isset($_POST['send_prop_loc'])) {
                if (!empty($_POST['sp_combo_cell'])) {
                    //save or update the location location
                    //save the location first
                    $location_cell = trim($_POST['sp_combo_cell']);
                    $mul = new multi_values();
                    $location_lat = $_POST['txt_loc_lat'];
                    $location_lng = $_POST['txt_loc_lng'];
                    $area = $_POST['txt_area'];
                    $address = $_POST['txt_address'];
                    require_once '../web_db/new_values.php';
                    require_once '../web_db/updates.php';
                    $obj = new new_values();
                    $update_obj = new updates();
                    if (!empty($_SESSION['complete_updating'])) {
                        $listing_id = $_SESSION['complete_updating'];
                        $update_obj->update_location_by_listing('yes', '1', $location_cell, $location_lat, $location_lng, $area, $address, $listing_id);
                        $update_obj->update_list_location_by_listing($listing_id);
                        unset($_SESSION['complete_updating']);
                        ?><script>//alert('updating a chosen listing, a particular');</script><?php
                    } else {
                        $procs = new Page_load();
                        if ($procs->process() == 'location') {
                            $obj->new_location('yes', get_property_id2(), $location_cell, $location_lat, $location_lng, $area, $address);
                            $update_obj->update_listing_location();
                        } else if ($procs->process() == 'image') {
                            $last_loc = trim($mult->get_lastlocation());
                            $update_obj->update_location('yes', '1', $location_cell, $location_lat, $location_lng, $area, $address, $last_loc);
                            $update_obj->update_listing_location();
//                            echo 'Appear:  location cell: ' . $location_cell . ' location lat: ' . $location_lat . ' location long: ' . $location_lng . '  area: ' . $area . ' address: ' . $address;
                        }
                    }
                    ?>
                    <script>
                        // window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
                        window.location.replace('http://localhost/Restate/Admin/redirect.php');
                    </script>
                    <?php
                } else {
                    ?>
                    <script>
                        alert('You have to specify all location addresses, including cell');
                    </script>
                    <?php
                }
            }
            ?>
        </div>
        <table   class="new_data_table " border="1">
            <tr>
                <td colspan="2">
                    <div class="parts no_paddin_shade_no_Border x_titles smart_font">Administrative location</div>
                </td>
            </tr>
            <tr>
            <tr>
                <td>Location:</td>
                <td>
                    <div class="parts full_center_two_h  no_paddin_shade_no_Border heit_free allow_drop">
                        <div class="parts no_paddin_shade_no_Border reverse_border link_cursor" id="loc_province"><p>
                                <?php get_provinces_Comboz() ?></p>
                            <span id="chosen_province"></span>
                        </div>
                        <div class="parts no_paddin_shade_no_Border reverse_border link_cursor" id="loc_district"><p>
                                <select id="sp_combo_distr" class="parts x_width_one_h">
                                    <option> -- District -- </option>
                                </select></p>
                            <span id="chosen_district"></span>
                        </div>
                        <div class="parts no_paddin_shade_no_Border reverse_border link_cursor " id="loc_sector"><p>
                                <select id="sp_combo_sectr" class="parts x_width_one_h">
                                    <option> -- Sector -- </option>
                                </select></p> <span id="chosen_sector"></span>
                        </div>
                        <div class="parts no_paddin_shade_no_Border reverse_border link_cursor" id="loc_cell"><p>
                                <select id="sp_combo_cell" name="sp_combo_cell" class="parts x_width_one_h">
                                    <option> -- Cell -- </option>
                                </select></p> <span id="chosen_cell"></span>
                        </div>
                        <div class="parts no_shade_noBorder link_cursor off" id="close_location">
                            Close
                        </div>
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border reverse_border" id="loc_res">
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td><div class="parts full_center_two_h no_paddin_shade_no_Border x_titles heit_free smart_font">Neighborhood</div>  </td><td>
            </tr>
            <tr>
                <td>Location</td>
                <td>
                    <input type="text"   name="txt_area" autocomplete="off" id="myInput"   onkeyup="myFunction()" required class="textbox" id="txt_new_listing_area" placeholder="Neighborhood name" value="<?php echo $mult->get_area_by_last_listing(); ?>"/>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                        <a id="show_location_link" class="off" href="#">Specify locations</a>
                        <?php
                        require_once './new_property_loc_search.php';
                        ?>
                    </div>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <div class="parts full_center_two_h no_shade_noBorder  reverse_border off heit_free" id="new_listing_area_res_box">
                        Results
                    </div>
                </td>
            </tr>
            <tr>
                <td>Address</td> <td>
                    <input class="txt_addressf" name="txt_address" type="text" autocomplete="off"  placeholder="Search for names.."  title="Type in a name" value="<?php echo $address; ?>"> 
                </td>
            </tr>
            <tr>
                <td></td>
                <td>

                </td>
            </tr>
            <tr>
                <td>
                    <input type="button" id="map_loc_link" value="Adjust map Location"/> <br/><br/>
                    <span id="chosen_lat_long">the long and lat</span>
                </td>  <td>
                    <div class="parts  full_center_two_h heit_free  no_paddin_shade_no_Border">
                        <div class="parts no_paddin_shade_no_Border  abs_full off" style="margin: 0px; overflow: hidden;"id="map_box">
                        </div>
                        <div class="parts fixed_box_5x abs_child off left_off_eighty " style=" position: fixed; z-index: 3;" id="map">
                        </div>
                        <input type="button" value="Confirm" style="position: fixed;" class="off" id="marker_loc">
                        <span id="label" class="parts  off label_loc" style="position: fixed;">pos</span>
                    </div>
                </td>
            </tr>
            <?php ?>
        </table>
    </div>
    <div class="parts eighty_centered off" >
        <?php
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
//                $obj->list_listing();
        ?>
    </div> <div class="parts eighty_centered smart_parts ">
        <input type="submit" class="confirm_buttons" name="send_prop_loc" id="btn_send_listing_loc" value="SAVE AND CONTINUE">
    </div>

    <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</form>

<script type = "text/javascript" >
    function initMap() {
        var myLatLng = {lat: -1.9706, lng: 30.1044};
//        var myLatLng = {lat: -1.942585, lng: 30.061405};
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: myLatLng
        });
        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: 'Location'
        });
    }
</script>
<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=
        AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
</script>

<?php

function get_provinces_Comboz() {
    $bean = new location_new();
    $bean->Load();
}

function get_district_boxe() {
    $bean = new location_new();
    $bean->get_districts_boxes();
}

function get_sector_boxe() {
    $bean = new multi_values();
    $bean->get_sectors_boxes();
}

function get_cells_boxe() {
    $bean = new multi_values();
    $bean->get_cells_boxes();
}

function get_province_combo() {
    $bean = new multi_values();
    $bean->get_provinces_combo2();
}

function get_sector_combo() {
    $bean = new multi_values();
    $bean->get_sectors_combo();
}

function get_property_id2() {
    $con = new my_connection();
    $sql = "select    property  from location   order by location_id desc limit 1";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['property'];
    return $userid;
}

function get_last_location2() {
    $con = new my_connection();
    $sql3 = "select  location.location_id from location order by location.location_id desc limit 1";
    $stmt = $con->getCon()->prepare($sql3);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $last_locationid = $row['location_id'];
    return $last_locationid;
}

//get last title
if (isset($_SESSION['listing_done'])) {
    $las_obj = new multi_values();
    $last_prop_category = $las_obj->get_last_listing_property_category();
}

function get_last_title() {
    $las_obj = new multi_values();
    return $last_title = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_title() : '';
}

function get_last_list_type() {
    $las_obj = new multi_values();
    return $last_list_type = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_listing_type() : '';
}

function get_last_purpose() {
    $las_obj = new multi_values();
    return $last_list_purpose = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_purpose() : '';
}

function get_last_prop_cat() {
    $las_obj = new multi_values();
    return $last_list_cat = isset($_SESSION['listing_done']) ? $las_obj->get_last_listing_property_category() : '';
}
