<?php
if (!isset($_SESSION)) {
    session_start();
}
require_once '../web_db/multi_values.php';
require_once '../web_db/new_values.php';
$obj = new new_values();
$obj_mult = new multi_values();
?><html>
    <head>
        <title>Property </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
        <form action="new_property.php" method="post" enctype="multipart/form-data">
            <?php
            require_once './Admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border new_data_box off">
                <div class="parts eighty_centered no_paddin_shade_no_Border">
                    <?php save_property(); ?>
                </div>
                <div class="parts xx_titles margin_free no_paddin_shade_no_Border">  property</div>
                <table class="new_data_table">
                    <tr><td>Name:</td><td> <input type="text"     name="txt_name" required class="textbox"   </td></tr>
                    <tr><td></td><td> <input type="submit"     name="send_property" value="Save"  class="confirm_buttons "   </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered no_shade_noBorder" >
                <?php
                $obj_mult->list_property();
                ?>

            </div>
        </div>  

</body>
</html>

<?php

function save_property() {
    if (isset($_POST['send_property'])) {
        $name = $_POST['txt_name'];
        if ($name != '') {
            $d = new new_values();
            $d->new_property($name);
            echo 'Saved successfully';
        }
    }
}
function get_prop_type_combo() {
    $data = new multi_values();
    $data->get_prop_type_combo();
}
