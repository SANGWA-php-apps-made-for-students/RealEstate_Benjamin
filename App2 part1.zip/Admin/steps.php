<div class="parts eighty_centered margin_free no_paddin_shade_no_Border">
    <a href="new_listing.php">
        <div class="parts two_fifty_left heit_free stepItem iconed" id="listing_step1">
            <div class="parts  step_icons" id="step_icon1"></div>
            <center>1 PROPERTY DESCRIPTION</center>
        </div>
    </a>
    <a href="new_price.php">
        <div class="parts two_fifty_left heit_free stepItem iconed" id="listing_step3"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon2"></div><center>2 PRICE</center></div>
    </a>
    <a href="new_property_location.php">
        <div class="parts two_fifty_left heit_free stepItem iconed" id="listing_step2"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon3"></div><center>3 LOCATION</center></div>
    </a>
    <a href="new_image.php">
        <div class="parts iconed two_fifty_left heit_free stepItem" id="listing_step4"><div class="parts no_paddin_shade_no_Border step_icons" id="step_icon4"></div><center>4 ATTACHMENT</center></div>
    </a>
</div>