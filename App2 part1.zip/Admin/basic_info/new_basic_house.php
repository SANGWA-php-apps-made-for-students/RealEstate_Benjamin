
<tr class="house_rows off">
    <td>Basic details (house):</td>
    <td>
        <table>
            <tr>
                <td>Bedrooms :<br/> <input type="text" autocomplete="off" class="only_numbers" id="txt_house_bedroom"  name="txt_house_bedroom"  style="width: 70px" value="<?php echo basic_house_bedrooms(); ?>" />  </td>
                <td>Bathrooms :<br/> <input type="text" autocomplete="off"  class="only_numbers" id="txt_house_bathroom"  name="txt_house_bathroom"   style="width: 70px;" value="<?php echo basic_house_bathrooms(); ?>" />  </td>
                <td>Total number of floors :<br/> <input type="text" autocomplete="off"  class="only_numbers" id="txt_house_total_number_floors"   name="txt_house_total_number_floors"  style="width: 70px;" value="<?php echo basic_total_number_floors(); ?>" />
                <td>Compound_size :<br/><input type="text"  autocomplete="off" class="only_numbers" id="txt_house_compound_size"   name="txt_house_compound_size"  style="width: 70px;" value="<?php echo basic_house_compound_size(); ?>" />
                <td>Living/floors area :<br/> <input type="text" autocomplete="off" class="only_numbers" id="txt_house_living_floors"   name="txt_house_living_floors"  style="width: 70px;" value="<?php echo basic_house_living_floor(); ?>" />  </td>
            </tr>
            <tr>
                <td>furnished :<br/>
                    <span id="house_def_furnished"></span>
                    <select  id="txt_house_furnished" name="txt_house_furnished" style="width: 80px;" >
                        <option></option>
                        <option>Furnished</option>
                        <option>Fully furnished</option>
                        <option>Not furnished</option>
                        <option>Semi furnished</option>
                    </select>
                </td>
                <td colspan="3">Available from<br/>
                    <input type="text" class="date_pick" placeholder="Date" id="txt_house_available_from" autocomplete="off"  name="txt_houae_available_from"  class="textbox" value="<?php echo basic_house_available_from(); ?>" />
                </td>
            </tr>
        </table>
    </td>
</tr>




