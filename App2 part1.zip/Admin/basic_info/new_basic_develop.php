<tr class="development_rows off">
    <td>Basic details (dev):</td>
    <td>
        <table>
            <tr>
                <td>Rooms :<br/> <input type="text"  class="only_numbers" id="txt_dev_bedroom"  name="txt_dev_bedroom"  style="width: 70px" />  </td>
                <td>Bathrooms :<br/> <input type="text"   class="only_numbers" id="txt_dev_bathroom"  name="txt_dev_bathroom"   style="width: 70px;" />  </td>
                <td>Total number of floors :<br/> <input type="text"  class="only_numbers" id="txt_dev_total_number_floors"   name="txt_dev_total_number_floors"  style="width: 70px;" />
                <td>Compound_size :<br/><input type="text"  class="only_numbers"   name="txt_dev_compound_size"  style="width: 70px;" />
                <td>Living/floors area :<br/> <input type="text" class="only_numbers" id="txt_dev_living_floors"    name="txt_dev_living_floors"  style="width: 70px;" />  </td>
            </tr>
            <tr>
                <td>furnished :<br/>
                    <span id="dev_dev_furnished"></span>
                    <select id="txt_dev_furnished" name="txt_dev_furnished" style="width: 80px;">
                        <option></option>
                        <option>Furnished</option>
                        <option>Fully furnished</option>
                        <option>Not furnished</option>
                        <option>Semi furnished</option>
                    </select>
                </td>
            </tr>
        </table>
    </td>
</tr>