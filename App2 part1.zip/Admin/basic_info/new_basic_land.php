<tr class="land_rows off">
    <td>Basic  details (land):</td>

    <td>Administrative location<br/><input type="text"     name="txt_administrative_location" class="textbox" id="txt_administrative_loc" value="<?php echo basic_administrative_location(); ?>" /></td>
</tr>
<tr class="land_rows off">
    <td> </td>
    <td>
        <table>
            <tr class="land_rows off">
                <td>Plot size<br/><input type="text" autocomplete="off" id="txt_plot_size" class="only_numbers"    name="txt_plot_size"  style="float: left;width: 70px;" value="<?php echo basic_land_plot_size(); ?>" />
                </td>
                <td>Plot number<br/>
                    <input type="text"  autocomplete="off"   name="txt_plot_number"  id="txt_plot_number" style="width: 90px;" value="<?php echo basic_land_plot_no(); ?>" /></td>
                </td>
                <td>measure<br/>
                    <select name="plot_measure"   id="plot_measure_combo"  style="width: 100px; float: right;">
                        <option></option>
                        <option>Meter square</option>
                        <option>ha</option>
                        <option>Other</option>
                    </select>
                </td>
                <td>Lot use<br/><input type="text" autocomplete="off" autocomplete="off"  id="txt_lot_use"  name="txt_lot_use"  style="width: 90px;" value="<?php echo basic_lot_use(); ?>" />
                </td>
            </tr>
        </table>
    </td>
<tr class="land_rows off" ><td>available_from :</td><td> <input type="text" autocomplete="off" id="txt_plot_available_from" placeholder="Date"  class="date_pick textbox"  name="txt_land_available_from" value="<?php echo basic_land_available_from(); ?>"   />  </td></tr>

<?php
require_once 'new_wizard.php';
require_once '../web_db/multi_values.php';
$obj = new multi_values();
$bean = new Page_load();

//
//function basic_land_plot_size() {
//    require_once '../web_db/multi_values.php';
//    $obj = new multi_values();
//    $bean = new Page_load();
//    if ($bean->process() != 'complete') {
//        if (!empty($_SESSION['listing_date'])) {
//            return $_SESSION['basic_land_plot_size'] = (!empty($_SESSION['basic_land_plot_size']))? : $obj->get_last_plotsize_land();
//        } else {
//            return '';
//        }
//    }
//}
//
//function basic_land_plot_no() {
//    require_once '../web_db/multi_values.php';
//    $obj = new multi_values();
//    $bean = new Page_load();
//    if ($bean->process() != 'complete') {
//        if (!empty($_SESSION['listing_date'])) {
//            return $_SESSION['basic_land_plot_no'] = (!empty($_SESSION['basic_land_plot_no']))? : $obj->get_last_plotno_land();
//        } else {
//            return '';
//        }
//    }
//}
//
//function basic_land_last_available_land() {
//    require_once '../web_db/multi_values.php';
//    $obj = new multi_values();
//    $bean = new Page_load();
//    if ($bean->process() != 'complete') {
//        if (!empty($_SESSION['listing_date'])) {
//            return $_SESSION['basic_land_available_from'] = (!empty($_SESSION['basic_land_available_from']))? : $obj->get_last_available_land();
//        } else {
//            return '';
//        }
//    }
//}
//
//function basic_lot_use() {
//    require_once '../web_db/multi_values.php';
//    $obj = new multi_values();
//    $bean = new Page_load();
//    if ($bean->process() != 'complete') {
//        if (!empty($_SESSION['listing_date'])) {
//            return $_SESSION['basic_lot_use'] = (!empty($_SESSION['basic_lot_use']))? : $obj->get_last_lotuse_land();
//        } else {
//            return '';
//        }
//    }
//}
