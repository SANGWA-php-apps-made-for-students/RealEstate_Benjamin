<tr class="aparts_rows off" ><td>Basic details (aprt):</td>
    <td>        <table>
            <tr >
                <td>Bedrooms:<br/>
                    <input type="text" autocomplete="off" id="txt_apart_bedrooms" placeholder="bed"                name="txt_aprt_bedrooms"  class="" value="<?php echo trim(bsc_aprt_bedroomz()); ?>" style="width: 70px;" />
                </td>
                <td>Bathrooms:<br/>
                    <input type="text" autocomplete="off" id="txt_apart_bathrooms" placeholder="bathroom"          name="txt_aprt_bathrooms"  class="only_numbers" style="width: 70px;" value="<?php echo basic_aprt_bathrooms(); ?>" />
                </td>
                <td>Total number of floors:<br/>
                    <input type="text" id="txt_total_number_floors" placeholder="tot no florz"                     name="txt_aprt_total_number_floors"  class="only_numbers" value="<?php echo basic_aprt_flor_no(); ?>" style="width: 70px;" />
                </td>
                <td>Total number of units<br/><input placeholder="tot units" type="text" id="txt_apart_floorNo"    name="txt_aprt_floor_number"  style="width: 70px;" value="<?php echo basic_aprt_tot_no(); ?>" /></td>
                <td>furnished<br/>
                    <div id="" class="parts no_paddin_shade_no_Border">
                    </div>
                    <select name="txt_aprt_furnished" id="apart_furnished" style="width: 70px;" >

                        <option></option>
                        <option>Yes</option>
                        <option>No</option>
                    </select>
                </td>
            </tr>
        </table>
    </td>
</tr> 