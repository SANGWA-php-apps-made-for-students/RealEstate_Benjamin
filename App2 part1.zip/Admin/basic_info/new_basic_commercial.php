<?php ?>
<tr class="commercial_rows off">
    <td>Basic details (cmrcl):</td>
    <td>
        <table>
            <tr>
                <td>Rooms :<br/> <input type="text"  class="" id="txt_comm_bedroom"                                            name="txt_comm_bedroom"  style="width: 70px"                        value="<?php echo basic_comm_bedrooms(); ?>" />  </td>
                <td>Bathrooms :<br/> <input type="text"   class="only_numbers" id="txt_comm_bathroom"                          name="txt_comm_bathroom"   style="width: 70px;"                     value="<?php echo basic_comm_bathrooms(); ?>" />  </td>
                <td>Total number of floors :<br/> <input type="text"  class="only_numbers" id="txt_comm_total_number_floors"   name="txt_comm_total_number_floors"  style="width: 70px;"           value="<?php echo basic_comm_total_noFlor(); ?>" />
                <td>Compound_size :<br/><input type="text"  class="only_numbers"  id="txt_comm_compound_size"                  name="txt_comm_compound_size"  style="width: 70px;"                 value="<?php echo basic_comm_compound_size(); ?>" />
                <td>Living/floors area :<br/> <input type="text" class="only_numbers"  id="txt_comm_living_floors"             name="txt_comm_living_floors"  style="width: 70px;"                 value="<?php echo basic_comm_living_flor(); ?>" />  </td>
            </tr>
            <tr>
                <td>furnished :<br/>
                    <span id="comm_def_furnished"></span>
                    <select id="txt_comm_furnished" name="txt_comm_furnished" style="width: 80px;">
                        <option></option>
                        <option>Furnished</option>
                        <option>Fully furnished</option>
                        <option>Not furnished</option>
                        <option>Semi furnished</option>
                    </select>
                </td>
            </tr>
        </table>
    </td>
</tr>




