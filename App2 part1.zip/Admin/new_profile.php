
<tr><td colspan="2"> <p>PERSONAL IDENTIFICATION</p>

        <table   class="new_data_table" style="margin-top: 0px;">
            <tr>
                <td>&nbsp; &nbsp;name :<br/> <input type="text"     name="txt_name" required class="parts" /> </td>
                <td>&nbsp;&nbsp; last_name :<br/> <input type="text"     name="txt_last_name" required class="parts" /></td>
                <td>&nbsp;&nbsp; Email :<br/> <input type="email"     name="txt_email" required class="parts"  /></td>
            </tr>
        </table>
    </td>
</tr>
<tr><td colspan="2">
        <p>TELEPHONE</p>
        <table   class="new_data_table" style="margin-top: 0px;">
            <tr>
                <td>&nbsp; &nbsp;Home phone :     <br/> <input type="text"     name="txt_home_phone" required class="parts"  /> </td>
                <td>&nbsp;&nbsp; Office phone :<br/> <input type="text"     name="txt_office_phone" required class= "parts" /></td>
                <td>&nbsp;&nbsp; Mobile phone :<br/>  <input type="text"     name="txt_mobile_phone" required class="parts" /></td>
            </tr>
        </table>
    </td>

</tr>

<tr><td colspan="2">
        <p>RESIDENCE </p>

        <table   class="new_data_table" style="margin-top: 0px;">
            <tr>
                <td>&nbsp; &nbsp;Address :     <br/><input type="text"     name="txt_address" required class="parts" /> </td>
                <td>&nbsp;&nbsp; City :<br/> <input type="text"     name="txt_city" required class="parts" /></td>
                <td>&nbsp;&nbsp; Country :<br/>
                    <select name="txt_country" class="parts  " style="width: 200px;">
                        <option>-- choose countries --</option>
                        <option>Afghanistan</option>
                        <option>Albania</option>
                        <option>Algeria</option>
                        <option>American Sam</option>
                        <option>Andorra</option>
                        <option>Angola</option>
                        <option>Anguilla</option>
                        <option>Antartica</option>
                        <option>Afghanistan</option>
                        <option>Argentina</option>
                        <option>Armenia</option>
                        <option>Aruba</option>
                        <option>Australia</option>
                        <option>Austria</option>
                        <option>Azerbaijan</option>
                        <option>Bahamas</option>
                        <option>Bahrain</option>
                        <option>Bangladesh</option>
                        <option>Barbados</option>
                        <option>Belarus</option>
                        <option>Belgium</option>
                        <option>Belize</option>
                        <option>Benin</option>
                        <option>Bermuda</option>
                        <option>Bhutan</option>
                        <option>Bolivia</option>
                        <option>Bosnia and H</option>
                        <option>Botswana</option>
                        <option>Bouvet Islan</option>
                        <option>Brazil</option>
                        <option>British Indi</option>
                        <option>Brunei Darus</option>
                        <option>Bulgaria</option>
                        <option>Burkina Faso</option>
                        <option>Burundi</option>
                        <option>Cambodia</option>
                        <option>Cameroon</option>
                        <option>Canada</option>
                        <option>Cape Verde</option>
                        <option>Cayman Islan</option>
                        <option>Central Afri</option>
                        <option>Chad</option>
                        <option>Chile</option>
                        <option>China</option>
                        <option>Christmas Is</option>
                        <option>Cocos Island</option>
                        <option>Colombia</option>
                        <option>Comoros</option>
                        <option>Congo</option>
                        <option>Congo</option>
                        <option>Cook Islands</option>
                        <option>Costa Rica</option>
                        <option>Cota D'Ivoir</option>
                        <option>Croatia</option>
                        <option>Cuba</option>
                        <option>Cyprus</option>
                        <option>Czech Republ</option>
                        <option>Denmark</option>
                        <option>Djibouti</option>
                        <option>Dominica</option>
                        <option>Dominican Re</option>
                        <option>East Timor</option>
                        <option>Ecuador</option>
                        <option>Egypt</option>
                        <option>El Salvador"</option>
                        <option>Equatorial G</option>
                        <option>Eritrea</option>
                        <option>Estonia</option>
                        <option>Ethiopia</option>
                        <option>Falkland Isl</option>
                        <option>Faroe Island</option>
                        <option>Fiji</option>
                        <option>Finland</option>
                        <option>France</option>
                        <option>France Metro</option>
                        <option>French Guian</option>
                        <option>French Polyn</option>
                        <option>French South</option>
                        <option>Gabon</option>
                        <option>Gambia</option>
                        <option>Georgia</option>
                        <option>Germany</option>
                        <option>Ghana</option>
                        <option>Gibraltar</option>
                        <option>Greece</option>
                        <option>Greenland</option>
                        <option>Grenada</option>
                        <option>Guadeloupe</option>
                        <option>Guam</option>
                        <option>Guatemala</option>
                        <option>Guinea</option>
                        <option>Guinea-Bissa</option>
                        <option>Guyana</option>
                        <option>Haiti</option>
                        <option>Haiti</option>
                        <option>Heard and Mc</option>
                        <option>Holy See</option>
                        <option>Honduras</option>
                        <option>Hong Kong</option>
                        <option>Hungary</option>
                        <option>Iceland</option>
                        <option>India</option>
                        <option>India</option>
                        <option>Indonesia</option>
                        <option>Iran</option>
                        <option>Iraq</option>
                        <option>Iraq</option>
                        <option>Ireland</option>
                        <option>Israel</option>
                        <option>Italy</option>
                        <option>Jamaica</option>
                        <option>Japan</option>
                        <option>Jordan</option>
                        <option>Kazakhstan</option>
                        <option>Kenya</option>
                        <option>Kiribati</option>
                        <option>Democratic P</option>
                        <option>Korea</option>
                        <option>Kuwait</option>
                        <option>Kuwait</option>
                        <option>Kyrgyzstan</option>
                        <option>Kyrgyzstan</option>
                        <option>Lao</option>
                        <option>Lao</option>
                        <option>Latvia</option>
                        <option>Lebanon</option>
                        <option>Lesotho</option>
                        <option>Lesotho</option>
                        <option>Liberia</option>
                        <option>Libyan Arab </option>
                        <option>Libyan Arab </option>
                        <option>Liechtenstei</option>
                        <option>Liechtenstei</option>
                        <option>Lithuania</option>
                        <option>Luxembourg</option>
                        <option>Luxembourg</option>
                        <option>Macau</option>
                        <option>Macedonia</option>
                        <option>Macedonia</option>
                        <option>Madagascar</option>
                        <option>Malawi</option>
                        <option>Malaysia</option>
                        <option>Maldives</option>
                        <option>Mali</option>
                        <option>Malta</option>
                        <option>Marshall Isl</option>
                        <option>Martinique</option>
                        <option>Martinique</option>
                        <option>Mauritania</option>
                        <option>Mauritania</option>
                        <option>Mauritius</option>
                        <option>Mayotte</option>
                        <option>Mexico</option>
                        <option>Micronesia</option>
                        <option>Moldova</option>
                        <option>Monaco</option>
                        <option>Mongolia</option>
                        <option>Montserrat</option>
                        <option>Montserrat</option>
                        <option>Morocco</option>
                        <option>Mozambique</option>
                        <option>Myanmar</option>
                        <option>Myanmar</option>
                        <option>Namibia</option>
                        <option>Nauru</option>
                        <option>Nepal</option>
                        <option>Netherlands"</option>
                        <option>Netherlands"</option>
                        <option>Netherlands </option>
                        <option>New Caledoni</option>
                        <option>New Zealand"</option>
                        <option>Nicaragua</option>
                        <option>Niger</option>
                        <option>Nigeria</option>
                        <option>Niue</option>
                        <option>Norfolk Isla</option>
                        <option>Northern Mar</option>
                        <option>Northern Mar</option>
                        <option>Norway</option>
                        <option>Norway</option>
                        <option>Oman</option>
                        <option>Oman</option>
                        <option>Pakistan</option>
                        <option>Palau</option>
                        <option>Panama</option>
                        <option>Panama</option>
                        <option>Papua New Gu</option>
                        <option>Paraguay</option>
                        <option>Peru</option>
                        <option>Philippines"</option>
                        <option>Pitcairn</option>
                        <option>Poland</option>
                        <option>Portugal</option>
                        <option>Puerto Rico"</option>
                        <option>Qatar</option>
                        <option>Qatar</option>
                        <option>Reunion</option>
                        <option>Romania</option>
                        <option>Russia</option>
                        <option>Rwanda</option>
                        <option>Rwanda</option>
                        <option>Saint Kitts </option>
                        <option>Saint LUCIA"</option>
                        <option>Saint Vincen</option>
                        <option>Samoa</option>
                        <option>San Marino</option>
                        <option>Sao Tome and</option>
                        <option>Saudi Arabia</option>
                        <option>Senegal</option>
                        <option>Seychelles</option>
                        <option>Sierra</option>
                        <option>Singapore</option>
                        <option>Slovakia</option>
                        <option>Slovenia</option>
                        <option>Solomon Isla</option>
                        <option>Somalia</option>
                        <option>South Africa</option>
                        <option>South Georgi</option>
                        <option>Span</option>
                        <option>SriLanka</option>
                        <option>St. Helena</option>
                        <option>St. Pierre a</option>
                        <option>Sudan</option>
                        <option>Suriname</option>
                        <option>Svalbard</option>
                        <option>Swaziland</option>
                        <option>Sweden</option>
                        <option>Switzerland"</option>
                        <option>Syria</option>
                        <option>Taiwan</option>
                        <option>Tajikistan</option>
                        <option>Tanzania</option>
                        <option>Thailand</option>
                        <option>Togo</option>
                        <option>Togo</option>
                        <option>Tokelau</option>
                        <option>Tonga</option>
                        <option>Trinidad and</option>
                        <option>Tunisia</option>
                        <option>Turkey</option>
                        <option>Turkmenistan</option>
                        <option>Turks and Ca</option>
                        <option>Tuvalu</option>
                        <option>Uganda</option>
                        <option>Ukraine</option>
                        <option>United Arab </option>
                        <option>United Arab </option>
                        <option>United Kingd</option>
                        <option>United State</option>
                        <option>United State</option>
                        <option>Uruguay</option>
                        <option>Uzbekistan</option>
                        <option>Vanuatu</option>
                        <option>Venezuela</option>
                        <option>Vietnam</option>
                        <option>Virgin Islan</option>
                        <option>Virgin Islan</option>
                        <option>Wallis and F</option>
                        <option>Western Saha</option>
                        <option>Yemen</option>
                        <option>Yugoslavia</option>
                        <option>Zambia</option>
                        <option>Zimbabwe</option>
                    </select></td>
            </tr>
        </table>
    </td>
</tr>

</td></tr>
<tr><td><p style="color: #000080; text-decoration: none">image:</p></td><td> <input type="file"     name="txt_image" required class="textbox" />  </td></tr>


<!--            <div class="parts eighty_centered" >

            </div>  -->

