<?php
session_start();
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_report_request.php" method="post">
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts abs_full   margin_free off" id="rpt_details_dialog">

            </div>
            <div class="parts abs_child skin2 eighty_centered off"  id="rpt_det_contents" style="position: fixed; height: 100%; overflow: scroll;">

            </div>


            <div class="parts eighty_centered">
                <div class="parts full_center_two_h no_paddin_shade_no_Border heit_free xx_titles">
                    Here are all the requests</div>
            </div>
            <div class="parts eighty_centered" id="requests_box">
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
//                $obj->list_property_request();
                ?>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                get_requests();
            });
            function get_requests() {
                setTimeout(function () {
                    $('#requests_box').load('Totals/All_incoming_requests.php');
                    get_requests();
                }, 1000);
            }
        </script>

    </body>
</html>
