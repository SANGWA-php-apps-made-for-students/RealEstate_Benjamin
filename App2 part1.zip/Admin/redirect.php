<?php

header('Location: new_wizard.php');
