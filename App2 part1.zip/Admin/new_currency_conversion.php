<?php
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_currency_conversion'])) {
    $currency_conversiondeleted = 'no';
    $from = $_POST['txt_from'];
    $to = $_POST['txt_to'];
    $rate = $_POST['txt_rate'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_currency_conversion($currency_conversiondeleted, $from, $to, $rate);
}
?>

<html>
    <head>
        <title>
            currency_conversion</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .sml{
                width: 100px;
            }
        </style>
    </head>
    <body>
        <form action="new_currency_conversion.php" method="post" enctype="multipart/form-data">
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">

            </div>
            <div class="parts eighty_centered off saved_dialog">
                currency_conversion saved successfully!</div>
            <div class="parts eighty_centered smart_font no_shade_noBorder">  Currency conversion</div>
            <div class="parts eighty_centered new_data_box ">

                <table class="new_data_table">
                    <tr><td>from :</td><td>
                            <input type="text" required  name="txt_from" class="sml">
                        </td>
                        <td>To</td>
                        <td>
                            <input required type="text"  name="txt_to" class="sml">

                        </td>
                        <td>Rate</td>
                        <td><input type="number"     name="txt_rate" required class="sml only_numbers" /></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>  <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_currency_conversion" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <?php
                $obj = new multi_values();
                $obj->list_currency_conversion();
                ?>
            </div>
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</hmtl>
<?php

