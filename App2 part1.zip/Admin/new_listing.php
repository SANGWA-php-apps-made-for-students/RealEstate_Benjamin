<?php
current_step();
require_once '../web_db/multi_values.php';
require_once './wizard_helper.php';
require_once '../web_db/whole_listing_by_id.php';
$chosen = new chosen_record();
//compare the last listing id with the last listing id from the apartment
?>
<html>
    <head>
        <style>
            #update_link a{
                color: #fff;
                text-decoration: none;
                text-align: center;
                font-family: arial;
            }
        </style>
        <title>
            Listing
        </title>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <form action="new_wizard.php" method="post" enctype="multipart/form-data">
        <input type = "hidden" class = "textbox left_off_eighty " placeholder = "lisitng type"                    name = "txt_listing_type"               id = "listing_type"  />     <!-- This listing type  is used to save new listing -->
        <input type = "hidden" class = "textbox left_off_eighty " placeholder = "(to update )lisitng type"        name = "update_listing_type"            id = "txt_update_listing_type"              value="<?php echo get_last_lst_type(); ?>"/> <!-- this listing type is used when updating . -->
        <input type = "hidden" class = "textbox left_off_eighty"  placeholder = "property type"                   name = "txt_property_type_id"           id = "txt_property_type_id"                 value="<?php echo get_last_prop_type(); ?>">
        <input type = "hidden" class = "textbox left_off_eighty"  placeholder = "property type name"              name = "txt_property_type_name"         id = "txt_property_type_name"               value="<?php echo get_prop_type_by_listing(); ?>">
        <input type = "hidden" class = "textbox "                 placeholder = "proprty cat"                     name = "txt_property_cat_id"            id = "txt_property_cat_id">
        <input type = "hidden" class = "textbox "                 placeholder = "update proprty cat"              name = "update_txt_property_cat_id"     id = "update_txt_property_cat_id"           value="<?php echo get_prop_cat(); ?>" >
        <input type = "hidden" class = "textbox " placeholder = "update proprty cat"                              name = "update_txt_aprt_furnished"      id = "update_txt_aprt_furnished"            value="<?php echo basic_aprt_furnished(); ?>" >
        <input type = "hidden" class = "parts   off " style = "margin-left: 300px;" placeholder = "property name" name = "txt_prop_name"                  id = "prop_name" />
        <input type = "hidden" class = "textbox off" placeholder = "Current step"                                 name = "txt_current_step"               id = "current_step"                         value="<?php echo $_SESSION['current_step']; ?>"/>
        <input type = "hidden" class = "textbox " placeholder = "Last features"                                     name = "last_feat"                      id = "last_feat"                          value="<?php echo last_features(); ?>"/>
        <input type = "hidden" class = "textbox off" placeholder = "Editing mode"                                 name = "Editing_mode"                   id = "Editing_mode" />
        <input type = "hidden" class = "textbox" placeholder = "Features chosen "                                 name = "feat_chosen"                    id = "feat_chosen" />
        <input type = "hidden" class = "textbox off" placeholder = "working_listing"                              name = "working_listing"                id = "working_listing" />
        <input type = "hidden" class = "textbox" placeholder = "working_listing"                                  name = "house_or_land"                  id = "house_or_land" />
        <input type = "hidden"   class = "textbox" placeholder = "Updating specific"                                name = "txt_updasting-specific"       id = "updating_specific"                  value="<?php echo (isset($_SESSION['complete_updating']) ) ? $_SESSION['complete_updating'] : ''; ?>"/>

        <!--Combo boxes for basic info-->
        <input type="hidden" id="basic_house_frunished" value="<?php echo basic_house_furnished(); ?>" /></br>
        <input type="hidden" id="basic_commercial_frunished" value="<?php echo basic_comm_furnished(); ?>" /></br>
        <?php
        $obj = new multi_values();
        $last_descriptioon = $obj->get_last_description();


        if (!empty($_SESSION['listing_date'])) {// this means that the user is currently saving the ilisting,
            // or has saved one of the steps of the wizatrd and the session os still alive( maybe has not closed the browser yet)
            ?>
            <script>
                //   alert('data exist in sessions ...');
            </script>
            <?php
        } else {
            $_SESSION['data_found'] = 'no';
            ?>
            <script>
                //   alert('data do not exist in sessions ...');
            </script>
            <?php
        }
        if (isset($_POST['send_listing'])) {
            if (!empty($_SESSION['complete_updating'])) {
                require_once '../web_db/whole_listing_by_id.php';
                $chosenid = new chosen_record();
                $id = $_SESSION['complete_updating'];
                $wiz_helper = new wizard_helper();
                $wiz_helper->update_existing_listing($id);
                unset($_SESSION['complete_updating']);
                ?>  <script> //    alert('only updating specific ...');</script><?php
            } else {
                $mul = new multi_values();
                $last_id = $mul->get_lastlisting($_SESSION['userid']);
                $editing_mode = $_POST['Editing_mode'];
                if (!empty($editing_mode)) {
                    $wiz_helper2 = new wizard_helper();
                    $wiz_helper2->update_existing_listing($last_id);
                    ?>
                    <script>//alert('only update ...');</script>
                    <?php
                } else {
                    $wiz_helper2 = new wizard_helper();
                    $wiz_helper2->save_new_listing();
                    ?>
                    <script>                      //  alert('new data ...');                    </script>
                    <?php
                }
            }
        }
        ?>
        <div class = "off" id = "d">
            <?php
            feature_by_session();
            ?>
        </div>
        <div class = "parts eighty_centered  new_data_box smart_parts">
            <div class = "parts   xx_titles no_paddin_shade_no_Border smart_font"id = "property_desc_title"> Listing
            </div>
            <table class = "new_data_table">
                <tr>
                    <td><span id = "listing_type_chosen"></span>Property type:</td>
                    <td> <?php include './new_listing_type.php'; ?></td>
                </tr>
                <tr><td>Property Category :</td><td> <?php get_property_type_combo(); ?></td></tr>
                <tr>
                    <td>Property sub category</td>
                    <td>
                        <?php
                        //just call a method that does everything here ...
                        $obj = new multi_values();
                        $obj->prop_cat_in_combo();
                        ?>
                    </td>
                </tr>
                <tr><td>Property Title :</td>
                    <td><input required  type="text" autocomplete="off" name="txt_title" placeholder="Property title" id="txt_title" class="textbox" value="<?php echo last_title(); ?> " />   </td></tr>
                <tr><td>Description :</td><td><textarea   style="height: 100px;" name="txt_desc" placeholder="Property description" id="" class="tinymce" >
                            <?php
                            echo last_description();
                            ?>
                        </textarea>
                    </td>
                </tr>
                <?php

                // <editor-fold defaultstate="collapsed" desc="----------last fields fnxs------------">
// <editor-fold defaultstate="collapsed" desc="----APARTM----">
                function bsc_aprt_bedroomz() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
//                        return $chosenid->get_chosen_bedroom_apartment($id);
                        return $id;
                    } else {
                        $bean = new Page_load();
                        $obj = new multi_values();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_bedroom_apartment();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_aprt_bathrooms() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_bedroom_apartment($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_bathrooms_apartment();
                        }
                    }
                }

                function basic_aprt_flor_no() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_floor_number_apartment($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_floor_number_apartment();
                        }
                    }
                }

                function basic_aprt_tot_no() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_total_floor_nbr_apartment($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_total_floor_nbr_apartment();
                        }
                    }
                }

                function basic_aprt_furnished() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_furnished_apartment($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_furnished_apartment();
                        }
                    }
                }

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="----COMM-----------">

                function basic_comm_bedrooms() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_basic_commercial_bedroom($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_comm_bedrooms'] = (!empty($_SESSION['basic_comm_bedrooms'])) ? $_SESSION['basic_comm_bedrooms'] : $obj->get_last_basic_commercial_bedroom();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_comm_bathrooms() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_basic_commercial_bathroom($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_comm_bathrooms'] = (!empty($_SESSION['basic_comm_bathrooms'])) ? $_SESSION['basic_comm_bathrooms'] : $obj->get_last_basic_commercial_bathroom();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_comm_total_noFlor() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_basic_commercial_totalnumber_flors($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_comm_total_noFlor'] = (!empty($_SESSION['basic_comm_total_noFlor'])) ? $_SESSION['basic_comm_total_noFlor'] : $obj->get_last_basic_commercial_totalnumber_flors();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_comm_compound_size() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_basic_commercial_compound_size($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_comm_compound_size'] = (!empty($_SESSION['basic_comm_compound_size'])) ? $_SESSION['basic_comm_compound_size'] : $obj->get_last_basic_commercial_compound_size();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_comm_living_flor() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_basic_commercial_living_flors($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_comm_living_flor'] = (!empty($_SESSION['basic_comm_living_flor'])) ? $_SESSION['basic_comm_living_flor'] : $obj->get_last_basic_commercial_living_flors();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_comm_furnished() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_basic_commercial_furnished($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_basic_commercial_furnished();
                        } else {
                            return '';
                        }
                    }
                }

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="------HOUSE-----">
                function basic_house_available_from() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_available_house($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_available_house();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_house_bedrooms() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_bedroom_house($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_house_bedrooms'] = (!empty($_SESSION['basic_house_bedrooms'])) ? $_SESSION['basic_house_bedrooms'] : $obj->get_last_bedroom_house();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_house_bathrooms() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_bathroom_house($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_house_bathrooms'] = (!empty($_SESSION['basic_house_bathrooms'])) ? $_SESSION['basic_house_bathrooms'] : $obj->get_last_bathroom_house();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_house_compound_size() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_compound_size_house($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_house_compound_size'] = (!empty($_SESSION['basic_house_compound_size'])) ? $_SESSION['basic_house_compound_size'] : $obj->get_last_compound_size_house();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_house_living_floor() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_living_floors_house($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_house_living_floor'] = (!empty($_SESSION['basic_house_living_floor'])) ? $_SESSION['basic_house_living_floor'] : $obj->get_last_living_floors_house();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_total_number_floors() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_total_floor_nbr_apartment($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_total_number_floors'] = (!empty($_SESSION['basic_total_number_floors'])) ? $_SESSION['basic_total_number_floors'] : $obj->get_last_total_number_floors_house();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_house_furnished() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_furnished_house($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $obj->get_last_furnished_house();
                        } else {
                            return '';
                        }
                    }
                }

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="-----LAND------">
                function basic_administrative_location() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_admin_loc_land($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $res = $obj->get_last_admin_loc_land();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_land_plot_no() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_plotno_land($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_land_plot_no'] = (!empty($_SESSION['basic_land_plot_no'])) ? $_SESSION['basic_land_plot_no'] : $obj->get_last_plotno_land();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_land_plot_size() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_plotsize_land($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {

                            return $_SESSION['basic_land_plot_size'] = (!empty($_SESSION['basic_land_plot_size'])) ? $_SESSION['basic_land_plot_size'] : $obj->get_last_plotsize_land();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_lot_use() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_lotuse_land($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_lot_use'] = (!empty($_SESSION['basic_lot_use'])) ? $_SESSION['basic_lot_use'] : $obj->get_last_lotuse_land();
                        } else {
                            return '';
                        }
                    }
                }

                function basic_land_available_from() {
                    if (!empty($_SESSION['complete_updating'])) {
                        require_once '../web_db/whole_listing_by_id.php';
                        $chosenid = new chosen_record();
                        $id = $_SESSION['complete_updating'];
                        return $chosenid->get_chosen_available_land($id);
                    } else {
                        $obj = new multi_values();
                        $bean = new Page_load();
                        if ($bean->process() != 'complete') {
                            return $_SESSION['basic_land_available_from'] = (!empty($_SESSION['basic_land_available_from'])) ? $_SESSION['basic_land_available_from'] : $obj->get_last_available_land();
                        } else {
                            return '';
                        }
                    }
                }

// </editor-fold>
// </editor-fold>
                require_once './basic_info/new_basic_apartment.php';
                require_once './basic_info/new_basic_house.php';
                require_once './basic_info/new_basic_land.php';
                require_once './basic_info/new_basic_commercial.php';
                require_once './basic_info/new_basic_develop.php';
                ?>
            </table>
            <div class="parts full_center_two_h no_paddin_shade_no_Border x_titles heit_free off smart_font" id="feature_label">Features</div>
            <div class="parts full_center_two_h heit_free no_shade_noBorder smart_parts" id="features_box">
            </div>
        </div>
        <div class="parts eighty_centered smart_parts">
            <input type="submit" class="confirm_buttons" name="send_listing" id="btn_send_listing" value="SAVE AND CONTINUE">
        </div>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </form>
    <script src="../web_scripts/richText/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="../web_scripts/richText/tinymce/init-tinymce.js" type="text/javascript"></script>
    <script>
                        $(document).ready(function () {
                            get_listing_type_combo();
                            $('.combo_roperty_type').unbind('change').change(function () {
                                alert('the property type is now selected1');
                                var prop_type_cat = $('.combo_property_type option:selected').text().trim();
                                $.post('handler.php', {prop_type_cat: prop_type_cat}, function (data) {

                                }).complete(function () {
                                });
                            });
                        });
                        function get_listing_type_combo() {
                            $('.list_type_combo').unbind('change').change(function () {
                                var lst_type = $(this).val().trim();
                                $('#listing_type').val(lst_type);
                            });
                        }

    </script>
</hmtl>
<?php

// <editor-fold defaultstate="collapsed" desc="-------------different fncts-----------------">

function get_property_type_combo() {
    $bean = new multi_values();
    $bean->get_prop_type_combo();
}

function get_last_lst_type() {
    if (!empty($_SESSION['complete_updating'])) {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = $_SESSION['complete_updating'];
        return $chosenid->get_chosen_listing_type($id);
    } else {
        $bean = new multi_values();
        return $last_lst_type = $bean->get_last_listing_type();
    }
}

function get_last_prop_type() {
    if (!empty($_SESSION['complete_updating'])) {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = $_SESSION['complete_updating'];
        return $chosenid->get_chosen_listing_prop_type_by_listing_id($id);
    } else {
        $bean = new multi_values();
        return $bean->get_last_listing_prop_type_by_listing_id();
    }
}

function get_provinces_boxes() {
    $bean = new multi_values();
    $bean->get_provinces_boxes();
}

function get_district_boxes() {
    $bean = new multi_values();
    $bean->get_districts_boxes();
}

function get_sector_boxes() {
    $bean = new multi_values();
    $bean->get_sectors_boxes();
}

function get_cells_boxes() {
    $bean = new multi_values();
    $bean->get_cells_boxes();
}

function get_provinces_combo() {
    $bean = new multi_values();
    $bean->get_provinces_combo2();
}

function get_sectors_combo() {
    $bean = new multi_values();
    $bean->get_sectors_combo();
}

function map() {
    include './my_map.php';
}

function get_property_id() {
    $con = new my_connection();
    $prop_name = $_POST['txt_prop_name'];
    $property_id = '';
    $sql = "select    property.property_id from property_type join property on property_type.property=property.property_id where property_type.property_type_id in(select property_type.property from property_type where name=:name);";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":name" => $prop_name));
    while ($row = $stmt->fetch()) {
        $property_id = $row['property_id'];
    }
    return $property_id;
}

function get_last_location() {
    $con = new my_connection();
    $sql3 = "select  location.location_id from location order by location.location_id desc limit 1";
    $stmt = $con->getCon()->prepare($sql3);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $last_locationid = $row['location_id'];
    return $last_locationid;
}

class More_onListing {

    function get_propertyCat_by_proerty_types($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select     property_category.name from property_category join property_type on property_type.property_type_id=property_category.type where property_type.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts  full_center_two_h margin_free heit_free no_paddin_shade_no_Border res_item">' . $row['name'] . '</div>';
        }
    }

}

function current_step() {
    $_SESSION['current_step'] = 1;
}

// </editor-fold>

function get_prop_cat() {
    if (!empty($_SESSION['complete_updating'])) {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = $_SESSION['complete_updating'];
        return $chosenid->get_chosen_listing_prop_cat_noDiv($id);
    } else {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $res = $obj->get_last_listing_prop_cat_noDiv(); //this is just the id
        return $res;
    }
}

function feature_by_session() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->features_last_listing($_SESSION['userid']);
    return $res;
}

//fields refill

function get_my_type() {
//this function is used on the price page to verify if the listing type id rent or sale.
    if (!empty($_SESSION['listing_date'])) {
        if ($_SESSION['listing_type'] == '1') {
            echo 'Property for rent';
        } else {
            echo 'Property for sale';
        }
    } else {
        $obj = new multi_values();
        $last_lst_type = $obj->get_last_listing_type();
        if ($last_lst_type == '1') {
            echo 'Property for rent';
        } else {
            echo 'Property for sale';
        }
    }
}

function last_description() {
    if (!empty($_SESSION['complete_updating'])) {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = $_SESSION['complete_updating'];
        return $chosenid->get_chosen_description($id);
    } else {
        require_once './new_wizard.php';
        $pg_obj = new Page_load();
        if ($pg_obj->process() != 'complete') {
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            return $obj->get_last_description();
        } else {
            return '';
        }
    }
}

function last_title() {
    if (!empty($_SESSION['complete_updating'])) {
        require_once '../web_db/whole_listing_by_id.php';
        $chosenid = new chosen_record();
        $id = trim($_SESSION['complete_updating']);
        return trim($chosenid->get_chosen_listing_title($id));
    } else {
        require_once './new_wizard.php';
        $pg_obj = new Page_load();
        if ($pg_obj->process() != 'complete') {
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            return trim($obj->get_last_listing_title());
        } else {
            return '';
        }
    }
}

function last_features() {//this is to get the last feature  from listing_features table (in order to verify the existence of the feature on load)
    require_once '../web_db/Wiz_unirecords.php';
    $obj = new multi_values();
    $bean = new Page_load2();
    if (isset($_SESSION['complete_updating'])) {
        return ($obj->get_if_feat_byListing($_SESSION['complete_updating'])) ? $obj->get_if_feat_byListing($_SESSION['complete_updating']) : '';
    } else if ($bean->process() != 'complete') {
        return $obj->get_last_list_feat();
    } else {
        return '';
    }
}

function get_prop_type_by_listing() {//this is the property type name by the session (shich is the chosen listing to update (from report))
    if (isset($_SESSION['complete_updating'])) {
        $listing = $_SESSION['complete_updating'];
        $mul = new multi_values();
        return $res = $mul->get_property_type_name_by_lsiting($listing);
    } else {
        return '';
    }
}

function what_listingid() {
    if (isset($_SESSION['complete_updating'])) {
        return (!empty($_SESSION['complete_updating']))? : $_SESSION['complete_updating'];
    } else {
        
    }
}

//$my_type = (isset($_SESSION) && );
$my_category = 0;
$my_title = 0;
$my_description = 0;





