<div class="parts  side_menu dull left_off_eighty off" id="dull">
    <a class="menuItem" href="new_account.php">Users account</a>
    <a class="menuItem" href="new_account_category.php">users category</a>
    <a class="menuItem" href="new_features.php">Features</a>
    <a class="menuItem" href="new_basic_info.php">Basic information</a>
    
    <!--<a class="menuItem" href="new_image.php">Manage images</a>-->
    
    <a class="menuItem" href="new_listing.php">Listings</a>
<!--    <a class="menuItem" href="new_listing_type.php">Listing types</a>-->
    <a class="menuItem" href="new_location.php">Locations /Area</a>
    <a class="menuItem" href="new_price.php">Cash flow</a>
    <!--<a class="menuItem" href="new_profile.php">Profiles</a>-->
    <a class="menuItem" href="new_property.php">properties</a>
    <a class="menuItem" href="new_property_type.php">property type</a>
    <a class="menuItem" href="new_property_category.php"> Property categories</a>
    <a class="menuItem" href="new_property_subcategory.php"> Sub categories</a>
    <a class="menuItem" href="new_property_visitor.php">inspectors </a>
    <br/>
    <br/>
    <a class="menuItem" href="new_property_visitor.php">Approve area names </a>
    <a class="menuItem" href="new_property_visitor.php">Listing Settings(Unseen) </a>
    <a class="menuItem" href="new_property_visitor.php">inspectors </a>
    <a class="menuItem" href="new_property_visitor.php">Assign roles </a>
    
    <a class="menuItem" href="new_property_visitor.php">Money / Finance</a>
    <a class="menuItem" href="new_property_visitor.php">Gallery</a>
    
</div>