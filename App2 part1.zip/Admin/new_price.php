<?php
require_once './dbConnection.php';
$con = new my_connection();
$sql2 = "select  listing.listing_id from listing order by  listing.listing_id desc limit 1";
$stmt2 = $con->getCon()->prepare($sql2);
$stmt2->execute();
$row = $stmt2->fetch(PDO::FETCH_ASSOC);
$listing_id = $row['listing_id'];
$last_listingid = $listing_id;
$property = $listing_id;
if (!isset($_SESSION['listing_done'])) {
    //header('location: new_listing.php');
}
if (isset($_POST['send_price'])) {
    require_once '../web_db/whole_listing_by_id.php';
    $obj_nmul = new multi_values();
    if (!empty($_SESSION['complete_updating'])) {
        $chosenid = new chosen_record();
        $id = $_SESSION['complete_updating']; //thi is the chosen listing id , not the last listing
        $price_id = $obj_nmul->get_price_by_lsting($id); // here we get the price id bcs we updaet the price by its id
        update_price($price_id);
        unset($_SESSION['complete_updating']);
        ?>  <script>    //  alert('only updating specific ...');</script><?php
    } else {
        $editing_mode = trim($_POST['Editing_mode_price']);
        $last_price = $obj_nmul->get_lastprice();
        if (process() != 'price') {
            update_price($last_price);
            ?>        <script> //alert('this is updating new_price.php ...');</script><?php
        } else {
            save_new_price();
            ?>        <script> alert('this is saving ...');</script><?php
        }
    }
}
?> 
<?php
require_once '../web_db/multi_values.php';
$obj = new multi_values();
$last_price_amount = $obj->get_last_price_amount($_SESSION['userid']);
$get_last_price_currency = $obj->get_last_price_currency($_SESSION['userid']);
$other_info = $obj->get_last_price_min_advance($_SESSION['userid']);

$last_lst_id = $obj->get_lastlisting($_SESSION['userid']);
$last_price_amount_per_day = $obj->get_last_price_amount_per_day();
$get_last_price_commission = $obj->get_last_price_commission($_SESSION['userid']);
$get_last_price_utilities = $obj->get_last_price_price_day($_SESSION['userid']);
$last_price_perSquare_meter = $obj->get_last_price_perSquare_meter($_SESSION['userid']);
//store in sessions
$_SESSION['amount'] = $last_price_amount;
$_SESSION['currency'] = $get_last_price_currency;
$_SESSION['other_info'] = $other_info;
$_SESSION['last_listing'] = $last_lst_id;
$_SESSION['amount_per_day'] = $last_price_amount_per_day;
$_SESSION['property'] = $property;
$_SESSION['commission'] = $get_last_price_commission;
$_SESSION['last_price_perSquare_meter'] = $last_price_perSquare_meter;
?>
<form action="new_wizard.php" method="post" enctype="multipart/form-data">
    <input type="hidden" class="textbox_price off" placeholder="Current step" name="txt_current_step"id="current_step" value=""/>
    <input type="hidden" class="textbox_price off" id="txt_condition_id" />
    <input type="hidden" class="textbox_price off" id="txt_deposit_required" />
    <input type="hidden" class="textbox_price" name="txt_utilities" id="txt_utilities" />
    <input type = "hidden" class = "textbox " placeholder = "price Editing mode" name = "Editing_mode_price" id ="Editing_mode_price" />
    <!--currency-->
    <input type = "hidden" class = "textbox " placeholder = "price Editing mode" name = "curr_month" id ="curr_month" value="<?php echo get_month_curr(); ?>" />
    <input type = "hidden" class = "textbox " placeholder = "price Editing mode" name = "curr_day" id ="curr_day" value="<?php echo get_day_curr(); ?>" />
    <!-- End of currency (checkboxes of the currency months and day)-->
    <input type = "hidden" class = "textbox " placeholder = "check utils exists " name = "util_exist" id ="util_exist" value="<?php echo get_my_utils(); ?>"/>
    <div id="d_" class="off">    </div>
    <div class="parts off" id="checked_utils">
        <?php
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        if (!empty($_SESSION['complete_updating'])) {
            $res = $obj->get_price_utililites_by_listing($_SESSION['complete_updating']);
        } else {
            $res = $obj->utililites_last_price();
        }
        ?>
    </div>
    <div class="parts eighty_centered off ">
        price saved successfully!
    </div>
    <div class="parts eighty_centered no_paddin_shade_no_Border">
    </div>
    <div class="parts eighty_centered  new_data_box smart_parts">
        <div class="parts fifty_percent_two_h heit_free no_paddin_shade_no_Border ">
            <table border="3" class="new_data_table">
                <tr>  
                    <td colspan="2">
                        <div class="parts two_fifty_left heit_free no_paddin_shade_no_Border xx_titles smart_font">
                            Price per month
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Amount</td><td> <input type="text" autocomplete="off" id="txt_amount" value="<?php echo $last_price_amount_per_day; ?>"   name="txt_amount" required class="textbox_price only_numbers" /> </td>
                </tr>
                <tr>
                    <td>Currency</td>
                    <td> <select name="txt_month_currency" class="textbox_price" id="txt_month_currency" ><option></option>
                            <option  name="txt_currency" >
                                USD
                            </option>
                            <option  name="txt_currency" >
                                Rwf
                            </option>
                            <option  name="txt_currency" >
                                Euro
                            </option>
                        </select>
                        <table>

                        </table>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td> <input type="text" class="textbox_price off only_numbers" id="price_cond_textfield" placeholder="Specify the condition" name="txt_other_condition" style="width: 200px;" /></td>
                </tr>
                <tr>
                    <td>Other information:</td><td> <input type="text" class="textbox_price" id="txt_minimum_advance" value="<?php echo $_SESSION['other_info']; ?>" name="txt_minimum_advance" /></td>
                </tr>
                <tr><td></td>
                    <td>
                        <input type="text" name="txt_utilities_other"  class="textbox_price off" id="txt_utilities" placeholder="Specify other utilities">
                    </td>
                </tr>
            </table>
        </div>
        <div class="parts fifty_percent_two_h no_paddin_shade_no_Border heit_free ">
            <table class="new_data_table">
                <td colspan="2">
                    <div class="parts two_fifty_left heit_free no_paddin_shade_no_Border xx_titles smart_font">
                        Price per day
                    </div>
                </td>
                <tr id="hide_amount_day">
                    <td>Amount per day</td>
                    <td><input type="text"  id="txt_amount_per_day"   name="txt_amount_per_day" autocomplete="off" value="<?php echo $last_price_amount_per_day; ?>" class="textbox_price" />

                    </td>
                </tr>

                <tr id="currency_amount">
                    <td>
                        Currency  
                    </td><td>
                        <select id="amount_day_select" style="width: 250px;">
                            <option></option>
                            <option  name="txt_currency" >
                                USD
                            </option>
                            <option  name="txt_currency" >
                                Rwf
                            </option>
                            <option  name="txt_currency" >
                                Euro
                            </option>
                        </select>
                    </td>
                </tr>
                <tr class="hidable_row_prc_sqr_meter">
                    <td>Price per square meter</td>
                    <td> <input type="text" autocomplete="off" id="txt_price_square_meter_per_day"    name="txt_price_square_meter_per_day"  class="textbox_price" value="<?php echo $_SESSION['last_price_perSquare_meter']; ?>"  />

                    </td>
                </tr>
                <tr class="hidable_row_prc_sqr_meter">
                    <td>
                        Currency:
                    </td><td>
                        <select name="txt_curr_day" id="perSqaure_select" style="width: 250px;">
                            <option></option>
                            <option  name="txt_currency" >
                                USD
                            </option>
                            <option  name="txt_currency" >
                                Rwf
                            </option>
                            <option  name="txt_currency" >
                                Euro
                            </option>
                        </select>
                        <table>

                        </table>
                    </td>
                </tr>
                <tr class="off">
                    <td>Advance</td>
                    <td> <input type="text"  id="txt_minimum_advance_per_day"   name="txt_minimum_advance_per_day"  class="textbox_price" /></td>
                </tr>
                <tr class="off">
                    <td>deposit required: </td>
                    <td><input type="text"  id=""   name="txt_deposit_required_per_day"  class="textbox_price" /></td>
                </tr>
                <tr>
                    <td>Commission: </td><td><input type="text" class="textbox_price" id="txt_commission" name="txt_commission" value="<?php echo $_SESSION['commission']; ?>"/> </td>
                </tr>
                <tr class="off">
                    <td>commission: </td>
                    <td><input type="text"  id="txt_commission_per_day"   name="txt_commission_per_day"  class="textbox_price" value="<?php echo $_SESSION['commission']; ?>" /></td>
                </tr>
                <tr class="off">
                    <td>utilities_extra_per_day</td>
                    <td><input type="text"  id="txt_utilities_extra_per_day"     name="txt_utilities_extra_per_day" placeholder="utilisties (per day)"  class="textbox_price" /><br/>
                    </td>
                </tr>
            </table>
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border reverse_border" id="util_box">
            <?php
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            $obj->get_utilities_checkbox();
            ?>
        </div>
    </div>
    <div class="parts eighty_centered  smart_parts">
        <input type="submit" class="confirm_buttons" style="margin-top: 50px;" name="send_price" id="send_features" value="SAVE AND CONTINUE"/>
    </div>
    <div class="parts eighty_centered no_shade_noBorder">
        <?php
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
//                $obj->list_price();
        ?>
    </div>
    <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</form>  
<?php

function get_features_checkbox() {
    require_once '../Admin/dbConnection.php';
    $con = new my_connection();
    $db = $con->getCon();
    $sql = " select   property_category.name from property_category join property_type on property_type.property_type_id=property_category.type where property_type.name='house'";
    foreach ($db->query($sql) as $row) {
        echo "<label for=\"feat\"> <input class=\"feat\" class=\"checkboxes\" name=\"feat\" type=\"checkbox\" value=" . $row['name'] . ">" . $row['name'] . "</label>";
    }
}

function save_new_price() {
    $amount = $_POST['txt_amount'];
    $currency = $_POST['txt_month_currency']; //  monthly currency 
    //$combo = $_POST['condition_combo'];
    $condition = 'omitted';
    $commission = $_POST['txt_commission'];
    $deposit_required = 'no';
    $utilities_extra = 'changed';
    $curr_month = $_POST['txt_month_currency'];
    $curr_day = $_POST['txt_curr_day'];

    $amount_per_day = $_POST['txt_amount_per_day'];
    $price_square_meter_per_day = (empty($_POST['txt_price_square_meter_per_day'])) ? 0 : $_POST['txt_price_square_meter_per_day'];
    $minimum_advance_per_day = $_POST['txt_minimum_advance_per_day'];
    $deposit_required_per_day = $_POST['txt_deposit_required_per_day'];
    $commission_per_day = $_POST['txt_commission_per_day'];
    $utilities_extra_per_day = $_POST['txt_utilities_extra_per_day'];

    require_once '../web_db/multi_values.php';
    $obj_nmul = new multi_values();
    $last_listing = $obj_nmul->get_lastlisting($_SESSION['userid']);
    $property = $last_listing;

    $Minimum_advance = $_POST['txt_minimum_advance'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj2 = new new_values();
    $obj->new_price($amount, $curr_day, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $last_listing, $amount_per_day, $price_square_meter_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $curr_month, $curr_day);
    if (!empty($_POST['txt_utilities']) || !empty($_POST['util_exist'])) {
        $mul_obj = new multi_values();
        $last_priceid = $mul_obj->get_lastprice();
        $utilities = $_POST['utilities'];
        foreach ($utilities as $feat) {
            $obj2->new_price_utilities(trim($last_priceid), trim($feat));
        }
    }
    $_SESSION['changes'] = 'price';
    ?>
    <script>
        //window.location.replace('http://www.codeguru-pro.net/Esercos/Admin/redirect.php');
        window.location.replace('redirect.php');
    </script>
    <?php
}

function update_price($price_id) {
    require_once '../web_db/updates.php';
//    require_once './dbConnection.php';
    $amount = $_POST['txt_amount'];
    $currency = $_POST['txt_month_currency'];
    //  combo = $_POST['condition_combo'];
    $condition = 'omitted';
    $commission = $_POST['txt_commission'];
    $deposit_required = 'no';
    $utilities_extra = 'changed';
    $amount_per_day = $_POST['txt_amount_per_day'];
    $price_square_meter_per_day = $_POST['txt_price_square_meter_per_day'];
    $minimum_advance_per_day = $_POST['txt_minimum_advance_per_day'];
    $deposit_required_per_day = $_POST['txt_deposit_required_per_day'];
    $commission_per_day = $_POST['txt_commission_per_day'];
    $utilities_extra_per_day = $_POST['txt_utilities_extra_per_day'];
    require_once '../web_db/multi_values.php';
    require_once '../web_db/new_values.php';
    require_once '../web_db/deletions.php';
    $obj_nmul = new multi_values();
    $del = new deletions();
    $new_var = new new_values();

    $last_listing = $obj_nmul->get_lastlisting();

    $property = $last_listing;
    $Minimum_advance = $_POST['txt_minimum_advance'];
    $obj_update = new updates();
    $curr_month = $_POST['txt_month_currency'];
    $curr_day = $_POST['txt_curr_day'];
    $obj_update->update_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $last_listing, $amount_per_day, $price_square_meter_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $curr_month, $curr_day, $price_id);
    if (!empty($_POST['txt_utilities']) || !empty($_POST['util_exist'])) {
        $del->deleteFrom_price_utilities($price_id);
        $utilities = $_POST['utilities'];
        foreach ($utilities as $util) {
            $new_var->new_price_utilities(trim($price_id), trim($util));
        }
    }
    ?>
    <script>
        window.location.replace('http://localhost/Restate/Admin/redirect.php');
    </script>
    <?php
}

function get_month_curr() {
    $obj = new multi_values();
    $bean = new Page_load();
    if ($bean->process() != 'complete') {
        return $obj->get_last_price_cur_month();
    } else if (isset($_SESSION['complete_updating'])) {
        return $obj->get_last_price_cur_month_by_listing($_SESSION['complete_updating']);
    }
}

function get_day_curr() {
    $obj = new multi_values();
    $bean = new Page_load();
    if ($bean->process() != 'complete') {
        return $obj->get_last_price_curr_day();
    } else if (!empty($_SESSION['complete_updating'])) {
        return $obj->get_last_price_curr_day_bylisting($_SESSION['complete_updating']);
    }
}

function get_my_utils() {
    $obj = new multi_values();
    $bean = new Page_load();
    if ($bean->process() != 'complete') {
        return $obj->get_last_price_utilz();
    }
}

function process() {
    try {
        if (!empty(lack_price()) || lack_price() != 0) {
            return 'price';
        } else if (!empty(lack_location()) || lack_location() != 0) {
            return 'location';
        } else if (!empty(lack_image()) || lack_image() != 0) {
            return 'image';
        } else {
            return 'complete';
        }
    } catch (PDOException $e) {
        echo $e->getCode();
    }
}

function lack_price() {
    require_once './dbConnection.php';
    $database = new my_connection();
    $db = $database->getCon();
    $sql2 = " select   min(listing_id) as listing from listing  where listing.listing_id not in (select listing from price where listing <>'null')";
    $stmt2 = $db->prepare($sql2);
    $stmt2->execute();
    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
    $price = $row2['listing'];
    return trim($price);
}

function lack_location() {
    require_once './dbConnection.php';
    $database = new my_connection();
    $db = $database->getCon();
    $sql3 = " select count(location) as tot from listing where  location = 0";
    $stmt3 = $db->prepare($sql3);
    $stmt3->execute();
    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
    $loc = $row3['tot'];
    return trim($loc);
}

function lack_image() {
    require_once './dbConnection.php';
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "select   min(listing_id) as listingid  from listing  where listing.listing_id not in (select listing from image)";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $image = $row['listingid'];
    return trim($image);
}

function montly_fields() {
    ?>

    <?php
}
