<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_account_category'])) {
    $name = $_POST['txt_name'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_account_category($name);
}
?>
<html>
    <head>
        <title>
            account_category</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body>
        <form action="new_account_category.php" method="post" enctype="multipart/form-data">
            <?php
            include 'Admin_header.php';
            ?> 

            <div class="parts eighty_centered no_shade_noBorder">
            </div>
            <div class="parts eighty_centered no_shade_noBorder margin_free smart_font">  Account_category</div>
            <div class="parts eighty_centered  new_data_box">
                <div class="parts">
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_account_category();
                    ?>

                </div>
                <div class="parts">
                    <table class="new_data_table top_off_x">
                        <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox"   </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_account_category" value="Save"/>  </td></tr>
                    </table>
                </div>

            </div>


            <div class="parts eighty_centered footer">
                Copyrights <?php echo date("Y") ?>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</hmtl>
