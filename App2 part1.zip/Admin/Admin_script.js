$(document).ready(function () {
    try {
        Refresh();
        get_off_step_one();

//        slide_rep_box();
        from_left();
        from_right();
        from_bottom();
    } catch (err) {
        alert(err.message);
    }
});
function Refresh() {
    try {
        setTimeout(function () {
            $('#c_users').load('Totals/All_user.php');
            $('#c_users_cat').load('Totals/All_users_cat.php');
            $('#c_admins').load('Totals/All_admin.php');
            $('#c_prop_types').load('Totals/All_user.php');
            $('#c_agents').load('Totals/All_agents.php');
            $('#c_managers').load('Totals/All_managers.php');
            $('#c_prop_cat').load('Totals/All_prop_cat.php');
            $('#c_listings').load('Totals/All_listings.php');
            $('#c_listings_no_image').load('Totals/All_listing_no_Image.php');
            $('#c_listings_no_prices').load('Totals/All_listing_no_price.php');
            $('#c_requests').load('Totals/All_requests.php');
            Refresh();
        }, 4000);
    } catch (err) {
        alert(err.message);
    }
}

function Get_all_agents() {
    var count_agents = "data";
    $.post('handler.php', {count_users: count_agents}, function (data) {
        $('#c_agents').html(data);
    });
}
function Get_all_agents() {
    var count_agents = 'data';
    $.post('handler.php', {count_users: count_agents}, function (data) {
        $('#c_agents').html(data);
    });
}

function get_off_step_one() {

//    var y = '';
//    $('#btn_send_listing').click(function () {
//        var selecteditems = [];
//        $("#features_box").find("input:checked").each(function (i, ob) {
//            selecteditems.push($(ob).val());
//        });
//        for (var i = 0; i < selecteditems.length; i++) {
//            var feature_item = selecteditems[i];
//            $.post('../Admin/handler.php', {feature_item: feature_item}, function (data) {
////                $('#my_cat_res').show().html(data);
//                $('#lbl2').text(data);
//                alert(data);
//            });
//        }
//        return false;
//
//    });

}
function get_user_logged_out() {
    $('.logout').click(function () {
        alert('logging out');
        return false;
    });
}

function from_left() {
     $('.c_users_cat,.c_users,.c_admins').show("drop", {direction: "left"}, 1000);
}
function from_right() {
    $('.c_managers,.c_agents,.c_prop_types').show("drop", {direction: "right"}, 1000);
}

function from_bottom() {
      $('.c_prop_cat,.c_listings,.c_listings_no_image,.c_requests').show("drop", {direction: "bottom"}, 1000);
}
    
function slide_rep_box() {
    //rep box means report box 
    $(".fixed_box_xxx").show("drop", {direction: "down"}, 600);
}

