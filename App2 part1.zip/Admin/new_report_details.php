<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Here we go with report details
        </h1>
        <?php
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        $stmt = $db->prepare("DELETE FROM listing WHERE listing_id=:id");
        $id = 100;
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        $stmt->execute();
        $affected_rows = $stmt->rowCount();
        ?>

    </body>
</html>
