<?php
session_start();
require_once '../web_db/multi_values.php';
if (isset($_POST['send_location'])) {
    $name = $_POST['txt_name'];
    $appear = $_POST['txt_appear'];
    $property = $_POST['txt_property'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_location($name, $appear, $property);
}
if (isset($_POST['send_sector'])) {
    $sect_name = $_POST['sector_txt_name'];
    $prov_id = $_POST['txt_province_id'];
    if ($sect_name != '' && $prov_id != '') {
        require_once '../web_db/new_values.php';
        $newdata = new new_values();
        $newdata->new_sector($sect_name, $prov_id);
        echo 'save successfully';
    } else {
        echo'All the fields must be initialized';
    }
}
if (isset($_POST['send_province'])) {
    $name = $_POST['prov_txt_name'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_province($name);
}
require_once '../web_db/multi_values.php';
include './Admin_header.php';
?>
<html>
    <head>
        <title>Locations</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .loc_body .loc_p{
                min-height: 300px;
                min-width: 250px;
            }
            .loc_body .xx_titles{
                font-weight: bolder;
                color: #faf300;
                font-size: 20px;
                text-shadow: 2px 2px 4px #7f00fa;

            }
        </style>
    </head>
    <body class="loc_body">
        <div class="parts xx_titles no_paddin_shade_no_Border eighty_centered">
            <div class="parts xx_titles no_paddin_shade_no_Border">
                Add more locations
            </div></div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border loc_textboxes margin_free">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border"> 
                <div class="parts link_cursor tab_buttons" id="tab1">Add data</div>
                <div class="parts link_cursor tab_buttons" id="tab2">View & edit</div>
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border tab_content" id="tab1_content">
                <?php
                include './new_province.php';
                include './new_district.php';
                include './new_sector.php';
                include './new_cell.php';
                ?>
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border off tab_content" id="tab2_content">
                <div class="parts" style="width: 350px;">
                    <div class="parts xx_titles no_paddin_shade_no_Border">List of Sector (<?php
                        $obj = new multi_values();
                        echo $obj->All_sector();
                        ?>)</div>
                    <?php
                    $first = $obj->get_first_sector();
                    $obj->list_sector($first);
                    ?>
                </div>
                <div class="parts">
                    <div class="parts xx_titles  no_paddin_shade_no_Border">List of Cells (<?php echo $obj->All_cell(); ?>)</div>

                    <?php
                    $first2 = $obj->get_first_cell();
                    $obj->list_cell($first2);
                    ?>
                </div>
            </div>  
        </div>
        <!--            <div class="parts eighty_centered" >
        <?php ?>
        </div>-->
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>

    </body>
</html>
<?php

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'location') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_cell_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
