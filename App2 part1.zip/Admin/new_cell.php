<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_cell'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'location') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $cell_id = $_SESSION['id_upd'];
            $name = $_POST['txt_name'];
            $sector = $_POST['txt_sector_id'];
            $upd_obj->update_cell($name, $sector, $cell_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $name = $_POST['txt_name'];
        $sectorid = $_POST['txt_sector_id'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_cell($name, $sectorid);
    }
}
require_once '../web_db/multi_values.php';
?>
<html>
    <head>
        <title>
            cell</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_location.php" method="post" enctype="multipart/form-data">
            <div class="parts loc_p">
                <input type="text" class="textbox off" name="txt_sector_id" id="txt_sector_id">
                <span class="off" id="d"></span>
                <div class="parts eighty_centered xx_titles margin_free no_shade_noBorder new_data_box smart_font">  cell</div>
                <table class="new_data_table">
                    <tr><td>Sector :</td><td>
                            <?php
                            get_sector_combo();
                            ?>
                        </td></tr>
                    <tr><td>name :</td><td> <input type="text"     name="txt_name" required value="<?php echo chosen_name_upd(); ?>" /> </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_left heit_free" name="send_cell" value="Save"/>  </td></tr>
                </table>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_sector_combo() {
    $bean = new multi_values();
    $bean->get_sectors_combo();
}
