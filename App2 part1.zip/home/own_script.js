$(window).load(function () {
    choose_req_option();
});

