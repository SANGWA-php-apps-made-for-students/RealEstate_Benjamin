<!--Slider-->
<div class="rev_slider_wrapper">
    <div id="rev_overlaped" class="rev_slider"  data-version="5.0">
        <ul>
            <!-- SLIDE -->
            <li data-transition="fade">
                <img src="images/home1-banner1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" class="rev-slidebg">
            </li>
            <li data-transition="fade">
                <img src="images/home1-banner2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" class="rev-slidebg">
            </li>
            <li data-transition="fade">
                <img src="images/home1-banner3.jpg" alt="" data-bgposition="center center" data-bgfit="cover" class="rev-slidebg">
            </li>
            <div class="tp-static-layers" 
                 style="color: #fff;
                 font-size: 20px;
                 /*margin: 33% 5%;*/
                 min-height: 100px;
                 background-color: #3861aa;
                 width: 50%;
                 position: absolute;
                 opacity: 0.1;
                 top: 0px;
                 border: 1px solid #fff;">
            </div>
            <div id="show_det_btn"  class="tp-static-layers" 
                 style="color: #fff;
                 font-size: 20px;
                 margin: 23% 25%;
                 min-height: 50px;
                 width: 200px;
                 position: absolute;
                 top: 0px;
                 border-radius: 35px;
                 padding: 10px;
                 box-sizing: border-box;
                 text-align: center;
                 cursor: pointer;
                 border: 1px solid #fff;">Show details</div>
            <div class="tp-static-layers" 
                 style="color: #fff;
                 font-size: 20px;
                 margin: 33% 5%;
                 min-height: 70px;
                 width: 50%;
                 position: absolute;
                 top: 0px;
                 padding: 10px;">
                <div style="display: block; font-size: 20px;">
                    Park Avenue Apartment
                </div>
                <!--                <div style="display: block; font-size: 17px;">
                                    Start
                                </div>-->
                <div style="font-size: 17px;float: left; width: 100%; display: block;  ">
                    <div style="width: 30%; float: left;  ">Price: 345$.00</div>
                    <div style="width: 70%; float: left; text-align: left;">3 Bedrooms&nbsp; 4 bathrooms</div>

                </div>
            </div>
            <div class="tp-static-layers">
                <div class="tp-caption tp-static-layer"
                     id="slide-37-layer-2"
                     data-x="['left','left','left','left']" data-hoffset="['50','50','50','50']"
                     data-y="['bottom','bottom','bottom','bottom']" data-voffset="['230','180','150','100']"
                     data-whitespace="nowrap"
                     data-visibility="['on','on','on','on']"
                     data-fontsize="['48','48','28','28']"
                     data-start="500"
                     data-responsive_offset="on"
                     data-basealign="slide"
                     data-startslide="0"
                     data-endslide="5"
                     style="z-index: 5;">
                    <!--<h1><span class="t_white">We Can Find just Right <br>Property for You.</span></h1>-->  
                </div>
                <div class="tp-caption tp-static-layer"
                     id="slide-37-layer-2"
                     data-x="['left','left','left','left']" data-hoffset="['50','50','50','50']"
                     data-y="['bottom','bottom','bottom','bottom']" data-voffset="['150','100','120','120']"
                     data-whitespace="nowrap"
                     data-visibility="['on','on','on','on']"
                     data-start="500"
                     data-basealign="slide"
                     data-startslide="0"
                     data-endslide="5"
                     style="z-index: 5; display: none;">
                    <p class="medo">We Deal with Different kinds of Properties No matter if you need a House,
                        an Apartment or Commercial house. You’ll find suitable options on time.
                    </p>
                </div>
                <div  class="tp-caption tp-static-layer"
                      id="slide-37-layer-2"
                      data-x="['left','left','left','left']" data-hoffset="['50','50','50','50']"
                      data-y="['bottom','bottom','bottom','bottom']" data-voffset="['60','60','60','60']"
                      data-whitespace="nowrap"
                      data-visibility="['on','on','on','on']"
                      data-start="500"
                      data-basealign="slide"
                      data-startslide="0"
                      data-endslide="5"
                      style="z-index: 5; display: none;"><a href="listing1.html" class="btn-white border_radius uppercase">view Properties</a>
                </div>
            </div>
        </ul>
    </div>
</div>
<!--Slider ends-->
<script>
    $('#show_det_btn').mouseover(function () {
        $(this).css('background-color', '#3861aa');
    });
</script>
<style>
    .ff{
        color: #3d5f9d;
    }
</style>