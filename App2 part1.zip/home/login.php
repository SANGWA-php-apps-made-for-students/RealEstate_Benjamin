<?php
session_start();

require_once './top_bar.php';
require_once './menu.php';
//require_once './new_homepage/slider.php';
?>
<html>
    <head>
        <title>Login</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos | Login</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="icon" href="images/icon.png">
        <style>
            #txt_username,#txt_password{
                color: #0d1611;
            }
        </style>
    </head>
    <body>
        <!--Loader-->
        <div class="loader">
            <div class="span">
                <div class="location_indicator"></div>
            </div>
        </div>
        <!--Loader-->
        <!-- Page Banner Start-->
        <section class="page-banner padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1 class="text-uppercase">Login</h1>
                        <p>Esercos Services brought to you with care</p>
                        <ol class="breadcrumb text-center">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Pages</a></li>
                            <li class="active">Login</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <!-- Login -->
        <section id="login" class="padding">
            <div class="container">
                <h3 class="hidden">hidden</h3>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="profile-login">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Login</a></li>
                                <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Register</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content padding_half">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                                    <div class="agent-p-form">
                                        <form action="login.php" method="post" class="callus clearfix">
                                            <div style="width: 100%; float: left;"><?php login(); ?></div>
                                            <div class="single-query form-group col-sm-12">
                                                <input id="txt_username" type="email" required autocomplete="off" class="keyword-input" name="username" placeholder="username">
                                            </div>
                                            <div class="single-query form-group  col-sm-12">
                                                <input id="txt_password" type="password" required autocomplete="off" class="keyword-input" name="password" placeholder="Password">
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="col-sm-6">
                                                        <div class="search-form-group white form-group text-left">
                                                            <div class="check-box-2"><i><input type="checkbox" name="check-box"></i></div>
                                                            <span>Remember Me</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6 text-right">
                                                        <a href="#" class="lost-pass">Lost your password?</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <input type="submit" name="send_login" value="submit now" class="btn-slide border_radius">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="profile">
                                    <div class="agent-p-form">
                                        <form action="login.php" method="post" class="callus clearfix">
                                            <div class="single-query col-sm-12 form-group">
                                                <input name="txt_name" type="text" class="keyword-input" autocomplete="off"  placeholder="Name" required>
                                            </div>
                                            <div class="single-query col-sm-12 form-group">
                                                <input name="txt_phone" id="phone_number" type="text" class="keyword-input only_numbers" autocomplete="off"  placeholder="Phone" required>
                                            </div>
                                            <div class="single-query col-sm-12 form-group">
                                                <input name="txt_email" type="text" class="keyword-input" placeholder="Email Address">
                                            </div>
                                            <div class="single-query col-sm-12 form-group">
                                                <input name="txt_password" type="password" class="keyword-input" placeholder="Password">
                                            </div>
                                            <div class="search-form-group white col-sm-12 form-group text-left" style="display: none;">
                                                <div class="check-box-2"><i><input type="checkbox" name="check-box"></i></div>
                                                <span>Receive Newsletter</span>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                                <div class="query-submit-button">
                                                    <input name="send_registration" type="submit" value="Creat an Account" class="btn-slide">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Login end -->
        <?php require_once './other_footer.php'; ?>
        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
        <script>
            $('#phone_number').keydown(function (e) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                        // Allow: Ctrl+A, Command+A
                                (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                                // Allow: home, end, left, right, down, up
                                        (e.keyCode >= 35 && e.keyCode <= 40)) {
                            // let it happen, don't do anything
                            return;
                        }
                        // Ensure that it is a number and stop the keypress
                        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                            e.preventDefault();
                        }
                    });
        </script>
    </body>
</html>
<?php
register();

function register() {
    if (isset($_POST['send_registration'])) {
        $name = $_POST['txt_name'];
        $phone = $_POST['txt_phone'];
        $email = $_POST['txt_email'];
        $password = $_POST['txt_password'];
        $category = 1; //this is the category of 8 shall correct the methodology by searching by the name of the catefory (pub_user)
        $con = new conn_login();
// <editor-fold defaultstate="collapsed" desc="----create user profile (profile=> account)">
//
// New profile
        try {
            $db = $con->log_con();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :name,  :last_name,  :email,   :office_phone,  :mobile_phone,  :address,  :city,  :country,  :image)");
            $stm->execute(array(':profile_id' => 0, ':name' => $name, ':last_name' => '', ':email' => $email, ':office_phone' => '', ':mobile_phone' => $phone, ':address' => '', ':city' => '', ':country' => '', ':image' => 0));
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
//
//
//
// 
// 
// 
// last profile and account
        $last_prof_sql = "select    profile.profile_id from profile order by profile_id desc";
        $last_prof_stmt = $db->prepare($last_prof_sql);
        $last_prof_stmt->execute();
        $row = $last_prof_stmt->fetch(PDO::FETCH_ASSOC);
        $last_prof_id = $row['profile_id'];
// Account
// 
// 
// 
        new_account($email, $password, $category, 'no', 'no', date('y-m-d'), $last_prof_id);
        // add sessions
        $_SESSION['names'] = $_POST['txt_name'];

        $last_acc_sql = "select    account.account_id from account order by account_id desc limit 1";
        $last_acc_stmt = $db->prepare($last_prof_sql);
        $last_acc_stmt->execute();
        $row = $last_acc_stmt->fetch(PDO::FETCH_ASSOC);
        $last_acc_id = $row['account_id'];
        $_SESSION['userid'] = $last_acc_id;

// </editor-fold>
        ?><script>
                    window.location.replace('www.codeguru-pro.net/Admin/admin_dashboard.php');
        </script><?php
    }
}

function new_account($username, $password, $account_category, $online, $deleted, $date_created, $profile) {
    $con = new conn_login();
    $db = $con->log_con();
    $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category,  :online,  :deleted,  :date_created,  :profile)");
    $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category, ':online' => $online, ':deleted' => $deleted, ':date_created' => $date_created, ':profile' => $profile));
}

function login() {
    if (isset($_POST['send_login'])) {
        $obj = new more_db_op();
        //        require_once './web_db/updates.php';
        //        $obj_update = new updates();
        $username = $_POST['username'];
        $password = $_POST['password'];
        $cat = $obj->get_user_category($username, $password);
        if (!empty($cat)) {
            $_SESSION['names'] = $obj->get_name_logged_in($username, $password);
            $_SESSION['userid'] = $obj->get_id_logged_in($username, $password);
            $_SESSION['cat'] = $obj->get_user_category($username, $password);
            $_SESSION['login_token'] = $_SESSION['userid'];
            $_SESSION['agency'] = (!empty($obj->check_agencyname_by_account($username, $password))) ? $obj->check_agencyname_by_account($username, $password) : '';
            $_SESSION['agency_name'] = (!empty($obj->get_agency_name($username, $password))) ? $obj->get_agency_name($username, $password) : '';
            // update that the user is online
            // $obj_update->get_user_online($_SESSION['userid']);

            if ($cat != 'pub_user') {//he is sector
                ?><script> window.location.replace('../Admin/admin_dashboard.php');</script><?php
            } else {
                ?><script> window.location.replace('pubUser_loggedin.php');</script><?php
            }

            /* else if ($cat == 'manager') {// he is district
              ?><script> window.location.replace('../AdminDash/index.php');</script><?php
              } else if ($cat == 'agent') {// he is minagri
              ?><script> window.location.replace('location: Minagri/MinagriDashboard.php');</script><?php
              } else {
              ?><script> window.location.replace('index.php');</script>
              <?php
              }
             */
        } else {
            echo '<div class="red_message">Username or password invalid</div>';
        }
    }
}

class more_db_op {

    function get_user_category($username, $password) {
        try {
            $con = new conn_login();
            $cat = '';
            $sql = "select     account_category.name from  account_category join account on account_category.account_category_id=account.account_category where  account.username=:username and  account.password =:password";
            $stmt = $con->log_con()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['name'];
            return $cat;
        } catch (PDOException $e) {
            echo 'Error getting the user category: ' . $e;
        }
    }

    function get_name_logged_in($username, $password) {
        try {
            $con = new conn_login();
            $ex = $con->log_con();
            $cat = '';
            $ex->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select   profile.name, profile.last_name from profile join account on account.profile=profile.profile_id where   account.username=:username and   account.password=:password";
            $stmt = $con->log_con()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['name'] . ' ' . $row['last_name'];
            return $cat;
        } catch (PDOException $ex) {
            echo 'the error while getting the name of the user: ' . $ex->getMessage();
        }
    }

    function get_userid_by_Acc_cat($name) {
        $con = new conn_login();
        $sql = "select    account.account_id from  account join account_category on account_category.account_category_id=account.account_category where   name = :name";
        $stmt = $con->log_con()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_id_logged_in($username, $password) {
        try {

            $con = new conn_login();
            $sql = "select    account.account_id from account where  account.username=:username and  account.password =:password";
            $stmt = $con->log_con()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_id'];
            return $userid;
        } catch (PDOException $ex) {
            echo 'The error while getting the id of the user' . $ex;
        }
    }

    function check_agencyname_by_account($username, $password) {
        $con = new conn_login();
        $sql = "select agency.agency_name from agency   join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id   
                where username=:username and account.password=:password";
        $stmt = $con->log_con()->prepare($sql);
        $stmt->execute(array(":username" => $username, ":password" => $password));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $agency = $row['agency_name'];
        return ($agency == 'esercos') ? 'yes' : 'no';
    }

    function get_agency_name($username, $password) {
        $con = new conn_login();
        $sql = "select agency.agency_name from agency   join agent on agent.agency = agency.agency_id 
                join account on agent.account = account.account_id   
                where username=:username and account.password=:password";
        $stmt = $con->log_con()->prepare($sql);
        $stmt->execute(array(":username" => $username, ":password" => $password));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $agency_name = $row['agency_name'];
        return $agency_name;
    }

}

class conn_login {

    function log_con() {
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}
