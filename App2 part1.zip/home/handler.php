<?php

session_start();
if (isset($_POST['listing_details'])) {
    $_SESSION['listing_details'] = $_POST['listing_details'];
    $_SESSION['prop_title'] = $_POST['prop_title'];
    $_SESSION['district'] = $_POST['district'];
}
if (isset($_POST['phone_req'])) {

    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_agency_phone('esercos');
    return $res;
}
if (isset($_POST['type_name'])) {
    $_SESSION['search_prop_type'] = $_POST['type_name'];
}