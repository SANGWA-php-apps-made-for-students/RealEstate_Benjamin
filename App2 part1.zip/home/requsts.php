<?php
require_once './top_bar.php';
require_once('../web_db/request_con.php');
require_once './menu.php';
?>
<html>
    <head>
        <title>Requests</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href="styles.css" rel="stylesheet" type="text/css"/>
        <link rel="icon" href="images/icon.png">
        <style>
            .txt_box{
                border: 1px solid #333333;
            }
        </style>
    </head>
    <body>
        <section id="property" class="padding listing1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-1 col-md-2"></div>
                    <div class="col-sm-10 col-md-8">
                        <h2 class="text-uppercase bottom40">Request for a Property</h2>
                        <div class="parts full_width border_off">
                            <div class="parts round_radio tab_buttons tab_butn1 off"> </div>
                            <div class="parts border_off off">Send an email</div>
                            <div class="parts round_radio tab_buttons tab_butn2"></div>
                            <div class="parts border_off">Call an agent</div>
                            <div class="parts round_radio tab_buttons tab_butn3"></div>
                            <div class="parts border_off">Send email</div>
                        </div>
                        <div class="parts full_width tab_content tab_content1 border_off">
                            <form class="callus clearfix border_radius submit_property" action="requsts.php" method="post">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="single-query form-group bottom20">
                                            <label>Email</label>
                                            <input type="email" name="e_email" class="txt_box keyword-input" required="" autocomplete="off" placeholder="Enter your email">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="single-query form-group bottom20">
                                            <label>Your message</label>
                                            <textarea required name="e_msg" class="col-sm-12 keyword-input "></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-4 margin_free" style="margin-top: 0px;" >
                                        <button type="submit" name="send_email" class="btn-blue border_radius margin40" style="margin-top: 30px;">submit request</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="parts full_width tab_content tab_content2 border_off off">
                            <form class="callus clearfix border_radius submit_property" >
                                <div class="row ">
                                    <div class="col-sm-12">
                                        <div class="single-query form-group bottom20">
                                            <label>Enter your phone number </label>
                                            <input type="text" name="p_phone" id="p_phone" class="txt_box keyword-input" required="" autocomplete="off" placeholder="+250 Enter your phone">
                                        </div>
                                    </div>

                                </div>
                            </form><div class="col-md-4" style="float: right; margin-top: 0px;">
                                <button id="send_phone"   class="btn-blue border_radius margin40">Get phone number</button>
                            </div>
                        </div>
                        <div class="parts full_width tab_content tab_content3 border_off off">
                            <form class="callus clearfix border_radius submit_property" action="requsts.php" method="post">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="single-query form-group bottom20">
                                            <label>Email</label>
                                            <input type="text" name="c_email" class="txt_box keyword-input" required="" autocomplete="off" placeholder="Enter your email">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="single-query form-group bottom20">
                                            <label>Phone</label>
                                            <input type="text" name="c_phone" class="keyword-input" required="" autocomplete="off" placeholder="Enter your phone number">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="single-query form-group bottom20">
                                            <label>Your message</label>
                                            <textarea required name="c_msg" class="col-sm-12 keyword-input "></textarea>
                                        </div>
                                    </div>

                                    <div class="col-md-16" style="float: right;margin-right: 10px;">
                                        <button type="submit" name="send_request" class="btn-blue border_radius margin40">submit request</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-sm-1 col-md-2"></div>
                    <div class="col-sm-4">
                    </div>
                </div>
            </div>
        </section>
        <script src="js/jquery-2.1.4.js"></script>

        <script>
            $(document).ready(function () {
                //done when someone choose an option of request
                //defaults
                $('.tab_butn1').css('background-color', '#52e000');
                $('.round_radio').click(function () {
                    $('.round_radio').css('background-color', '#e0d756');
                    $(this).css('background-color', '#52e000');
                });
                $('.tab_butn1').click(function () {
                    $('.tab_content').hide();
                    $('.tab_content1').show();
                });
                $('.tab_butn2').click(function () {
                    $('.tab_content').hide();
                    $('.tab_content2').show();
                });
                $('.tab_butn3').click(function () {
                    $('.tab_content').hide();
                    $('.tab_content3').show();
                });
                call_agent();
            });

            function call_agent() {
                $('#send_phone').unbind('click').click(function () {
                    var phone_req = $('#p_phone').val();
                    var res = '';

                    $.post('handler.php', {phone_req: phone_req}, function (data) {
                        alert('the returned: ' + data);
                    }).complete(function () {

                    });
                });
            }
        </script>
    </body>
</html>
<?php
require_once '../web_db/multi_values.php';
require_once '../web_db/new_values.php';
require_once '../web_db/updates.php';
$mul_obj = new multi_values();
$upd_obj = new updates();
$add_obj = new new_values();
if (isset($_POST['send_request'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'message') {
            $upd_obj = new updates();
            $message_id = $_SESSION['id_upd'];
            $account = trim($_POST['txt_account_id']);
            $date = date('y-m-d');
            $type = get_msgtypeid_by_name('request');
            $message = $_POST['c_msg'];
            $upd_obj->update_message($account, $date, $type, $message, $message_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $date = date('y-m-d');
        $type = get_msgtypeid_by_name('request');
        $message = $_POST['c_msg'];
        //save the profile to get his phone and email
        $mobile_phone = $_POST['c_phone'];
        $email = $_POST['c_email'];

        $add_obj->new_profile('', '', $email, '', '', $mobile_phone, '', '', '', 0);
        $last_profile = $mul_obj->get_last_profile_id();
        $cat = 8; //this is the user =>pub user, shall change for auto track
        //save the account
        $add_obj->new_account('', '', $cat, 'no', 'no', date('y-m-d'), $last_profile);
        $last_acc = $mul_obj->get_last_acc_id();
        $add_obj->new_message($last_acc, date('y-m-d'), $type, $message);
        ?><script>alert('Request submited');</script><?php
    }
}
if (isset($_POST['send_call'])) {
    $phone = $_POST['p_phone'];
    $add_obj->new_profile('', '', $email, '', '', $mobile_phone, '', '', '', 0);

    echo $phone;
}

if (isset($_POST['send_email'])) {
    $email = $_POST['e_email'];
    $msg = $_POST['e_msg'];
// <editor-fold defaultstate="collapsed" desc="---this is sending email">
//    $msg = "First line of text\nSecond line of text";
//    $msg = wordwrap($msg, 70);
    // send email
    mail("sangwa45@yahoo.com", "My subject", $msg);

// </editor-fold>

    echo $email . '  ' . $msg;
}

function get_msgtypeid_by_name($name) {
    $con = new request_con();
    $sql = "select    msg_type_id  from msg_type   where  msg_type.name = :name ";
    $stmt = $con->req_con()->prepare($sql);
    $stmt->execute(array(":name" => $name));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['msg_type_id'];
    return $userid;
}
