<!--Footer-->
<footer class="padding_top footer2">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="footer_panel bottom30">
                    <a href="javascript:void(0)" class="logo bottom30">
                        <img width="100" height="50"  src="images/logo_white.png" alt="logo"></a>
                    <p class="bottom15">
                        We are ambitious company. We provide local community and worldwide with Civil 
                        Engineering Consultancy and Real Estate Services.
                    </p>
                    <p class="bottom15">If you are interested in castle do not wait and <a href="javascript:void(0)">LEAVE US YOUR EMAIL!</a></p>
                    <ul class="social_share">
                        <li><a href="javascript:void(0)" class="facebook"><i class="icon-facebook-1"></i></a></li>
                        <li><a href="javascript:void(0)" class="twitter"><i class="icon-twitter-1"></i></a></li>
                        <li><a href="javascript:void(0)" class="google"><i class="icon-google4"></i></a></li>
                        <li><a href="javascript:void(0)" class="linkden"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="javascript:void(0)" class="vimo"><i class="icon-vimeo3"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer_panel bottom30">
                    <h4 class="bottom30">Search by Area</h4>
                    <ul class="area_search">
                        <li><a href="javascript:void(0)"><i class="icon-icons74"></i>Nyarutarama, Kigali</a></li>
                        <li class="active"><a href="javascript:void(0)"><i class="icon-icons74"></i>Gacuriro, Kigali</a></li>
                        <li><a href="javascript:void(0)"> <i class="icon-icons74"></i>Kacyiru, Kigali</a></li>
                        <li><a href="javascript:void(0)"><i class="icon-icons74"></i>Kibagabaga, Kigali</a></li>
                        <li><a href="javascript:void(0)"><i class="icon-icons74"></i>Gisozi , Kigali</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer_panel bottom30">
                    <h4 class="bottom30">Latest News</h4>
                    <div class="media">
                        <a class="media-object"><img src="images/footer-news1.png" alt="news"></a>
                        <div class="media-body">
                            <a href="#.">Nearest mall in high tech Goes your villa</a>
                            <span><i class="icon-clock4"></i>Feb 22, 2017</span>
                        </div>
                    </div>
                    <div class="media">
                        <a class="media-object"><img src="images/footer-news1.png" alt="news"></a>
                        <div class="media-body">
                            <a href="#.">Nearest mall in high tech Goes your villa</a>
                            <span><i class="icon-clock4"></i>Feb 22, 2017</span>
                        </div>
                    </div>
                    <div class="media">
                        <a class="media-object"><img src="images/footer-news1.png" alt="news"></a>
                        <div class="media-body">
                            <a href="#.">Nearest mall in high tech Goes your villa</a>
                            <span><i class="icon-clock4"></i>Feb 22, 2017</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer_panel bottom30">
                    <h4 class="bottom30">Get in Touch</h4>
                    <ul class="getin_touch">

                        <li><a href="javascript:void(0)"><i class="icon-icons142"></i>esercosltd@gmail.com</a></li>
                        <li><a href="javascript:void(0)"><i class="icon-browser2"></i>www.reba.com</a></li>
                        <li><i class="icon-icons74"></i>Copyrights &copy; 2018 - <?php echo date('Y'); ?> <span>Esercos</span> Rwanda</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--CopyRight-->
<div class="copyright index2">
    <div class="copyright_inner">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <p>Copyright &copy; <?php echo date('Y'); ?> <span>Esorcos</span>. All rights reserved.</p>
                </div>
                <div class="col-md-5 text-right">
                    <p>Designed by <a href="javascript:void(0)">Codeguru Ltd</a></p>
                </div>
            </div>
        </div>
    </div>
</div>