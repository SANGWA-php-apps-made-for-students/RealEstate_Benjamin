<!--Partners-->
<section id="logos">
    <div class="container partner2 padding">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h2 class="uppercase">Our Partners</h2>
                <p class="heading_space">Aliquam nec viverra erat. Aenean elit tellus mattis quis maximus.</p>
            </div>
        </div>
        <div class="row">
            <div id="partners" class="owl-carousel">
                <div class="item">
                    <img src="images/logo1.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo2.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo3.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo4.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo5.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo1.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo2.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo3.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo4.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo5.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo1.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo2.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo3.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo4.png" alt="Featured Partner">
                </div>
                <div class="item">
                    <img src="images/logo5.png" alt="Featured Partner">
                </div>
            </div>
        </div>
    </div>
</section>
<!--Partners Ends-->