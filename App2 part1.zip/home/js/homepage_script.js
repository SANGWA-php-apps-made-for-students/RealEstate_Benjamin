$(document).ready(function () {
    get_listing_details();
  
});
function get_listing_details() {
    $('.data_item').on('click', function () {
        var listing_details = $(this).data('listing_id');
        var prop_title = $(this).data('prop_title');
        var district = $(this).data('prop_district');
       
        $.post('handler.php', {listing_details: listing_details,
            prop_title: prop_title,
            district: district}, function (data) {
        }).complete(function () {
            window.location.replace('prop_details');
        });

        return false;
    });


}


