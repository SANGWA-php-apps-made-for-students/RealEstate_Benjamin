<?php
require_once '../web_db/connection.php';
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos | Contact</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="icon" href="images/icon.png">
    </head>
    <body>
        <!--Loader-->
        <div class="loader" style="display: none;">
            <div class="span">
                <div class="location_indicator"></div>
            </div>
        </div>
        <!--Loader-->
        <?php
        require_once './top_bar.php';
        require_once './menu.php';
        ?>
        <!--Contact-->
        <section id="contact-us">
            <div class="contact" >
                <div id="my_map" style="width: 60%; position: relative; height: 500px;margin-left: 20px; margin-top: 130px; margin-bottom: 400px;">
                    <div style="float: left; position: absolute; right: 20px; top: 20px;
                         background-color: #fff; width: 90%;height: 80%;
                         padding: 20px; border:1px solid #173145; box-sizing: border-box; bottom: 500px;">

                    </div>
                </div>
                <div class="container" >
                    <div class="row">
                        <div class="col-md-4 hidden-xs">
                        </div>
                        <div class="col-md-4 hidden-xs">
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12  contact-text">
                            <div class="agent-p-contact"  >
                                <div class="our-agent-box bottom30">
                                    <h2>get in touch</h2>
                                </div>
                                <div class="agetn-contact-2 bottom30">
                                    <p><i class=" icon-icons142"></i> esercosltd@gmail.com</p>
                                    <p><i class="icon-browser2"></i>www.reba.com</p>
                                    <p><i class="icon-icons74"></i>  Kigali city center, KN av 4, 2<sup>nd</sup> floor    </p>
                                </div>
                                <ul class="social_share bottom20">
                                    <li><a href="javascript:void(0)" class="facebook"><i class="icon-facebook-1"></i></a></li>
                                    <li><a href="javascript:void(0)" class="twitter"><i class="icon-twitter-1"></i></a></li>
                                    <li><a href="javascript:void(0)" class="google"><i class="icon-google4"></i></a></li>
                                    <li><a href="javascript:void(0)" class="linkden"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="javascript:void(0)" class="vimo"><i class="icon-vimeo3"></i></a></li>
                                </ul>
                            </div>
                            <div class="agent-p-form">
                                <div class="our-agent-box bottom30">
                                    <h2>Send us a message</h2>
                                </div>
                                <div class="row">
                                    <form action="contact_us.php" method="post" class="callus">
                                        <div class="col-md-12">
                                            <div class="single-query form-group">
                                                <input type="text" name="txt_name" placeholder="Your Name" class="keyword-input">
                                            </div>
                                            <div class="single-query form-group">
                                                <input type="text" name="txt_phone" placeholder="Phone Number" class="keyword-input">
                                            </div>
                                            <div class="single-query form-group">
                                                <input type="text" name="txt_email" placeholder="Email Adress" class="keyword-input">
                                            </div>
                                            <div class="single-query form-group">
                                                <textarea          name="txt_msg"   placeholder="Messege" class="form-control"></textarea>
                                            </div>
                                            <input type="submit" name="send_message" value="send message" class="btn-blue">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact End -->
        <?php require_once './other_footer.php'; ?>
        <script type = "text/javascript">
            function initMap() {
                var myLatLng = {lat: -1.9423122, lng: 30.061094799999978};
                var map = new google.maps.Map(document.getElementById('my_map'), {
                    zoom: 17,
                    center: myLatLng
                });
                var marker = new google.maps.Marker({
                    position: myLatLng,
                    map: map,
                    title: 'Esercos Headquarters'
                });
            }
        </script>
        <script async defer   src="https://maps.googleapis.com/maps/api/js?key=
                AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
        </script>
        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <!--Revolution Slider-->
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/neary-by-place.js"></script>
<!--        <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>-->
        <script src="js/gmaps.js.js"></script>
        <!--<script src="js/contact.js"></script>-->
        <script src="js/google-map.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
    </body>
</html>
<?php
if (isset($_POST['send_message'])) {

    $name = $_POST['txt_name'];
    $phone = $_POST['txt_phone'];
    $email = $_POST['txt_email'];
    $message = $_POST['txt_msg'];
    $database = new my_connection();
    $date = date('y-m-d');
    $db = $database->getCon();
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stm = $db->prepare("insert into message values(:message_id, :account,  :date,  :type,  :message)");
    $stm->execute(array(':message_id' => 0, ':account' => 0, ':date' => $date, ':type' => 3, ':message' => $message));
    ?><script>alert('The message was sent successfully');</script><?php
}