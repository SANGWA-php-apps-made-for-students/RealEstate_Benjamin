<!--Top bar-->
<div class="topbar ahabanza">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <p>Smart Service With Professinalism, Competence & Integrity.</p>
            </div>
            <div class="col-md-7 text-right">
                <ul class="breadcrumb_top text-right">
                    <li><a href="requsts"><i class="icon-icons215"></i>Request Property</a></li>
                    <li><a href="submission"><i class="icon-icons215"></i>Submit Property</a></li>
                    <!--<li><a href="submit_property.html"><i class="icon-icons215"></i>Submit Property</a></li>-->
                    <?php if (isset($_SESSION['cat'])) { ?>    <li> 
                            <a href="#"><i class="icon-icons215"></i>
                                <?php echo $_SESSION['names']; ?>


                            </a></li> <?php } ?>
      <!--  <li><a href="profile.php"><i class="icon-icons230"></i>Profile</a></li>-->
                    <li><a href="login"><i class="icon-icons179"></i>Login / Register</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--Top bar ends-->