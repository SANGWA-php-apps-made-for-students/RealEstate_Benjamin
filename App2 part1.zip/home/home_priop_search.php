 
<div class="parts no_paddin_shade_no_Border off" id="loc_pane" style="
     background-color: #fff; max-height: 150px; overflow-y: hidden;">
    <table class="dataList_table off" id="myTable">
        <tr><td class="loc_sear_rows"><span>House </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House for rent</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House for sale</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House in town</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House out of city</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House in remote area</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House with a garage </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  with parking </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  with closets </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  on road side </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  with car parking </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  with parking </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  with conference space </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House  with meeting hall </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Apartment close to city</span></td></tr>
        <tr><td class="loc_sear_rows"><span>Apartment in Kigali</span></td></tr>
        <tr><td class="loc_sear_rows"><span>Good Apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Good looking </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Nice Apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Big house  </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Big house for family </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Self contained house </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Bangalow </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Family house </span></td></tr>
        <tr><td class="loc_sear_rows"><span>1 room apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>2 rooms apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>3 rooms apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>3 or above rooms apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>5 or above rooms apartment </span></td></tr>
        <tr><td class="loc_sear_rows"><span>cheap house </span></td></tr>
        <tr><td class="loc_sear_rows"><span>House which is not expensive </span></td></tr>
        <tr><td class="loc_sear_rows"><span>Commercial house</span></td></tr>
        <tr><td class="loc_sear_rows"><span>Residence house</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House for residence</span></td></tr>

        <tr><td class="loc_sear_rows"><span>House / Apartments from Nyarutarama</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments from Gisozi residence</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments from Gacuriro</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments from Kicukiro</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments from Kagarama</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments for residence</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments for residence</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments for residence</span></td></tr>
        <tr><td class="loc_sear_rows"><span>House / Apartments for residence</span></td></tr>
    </table> 
</div>

<script>
    function myFunction() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[0];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
</script>
