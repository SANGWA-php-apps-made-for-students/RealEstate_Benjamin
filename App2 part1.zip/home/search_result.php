<?php
session_start();
?><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="icon"                       href="images/icon.png">

    </head>
    <body>
        <?php
        require_once 'top_bar.php';
        require_once 'menu.php';

        $keyword = $_POST['keyword'];
        $location = $_POST['Location'];
        $max_price = $_POST['max_price'];
        $currency = $_POST['currency'];

//        $keyword = 'apartment';
//        $location = 'nyarutarama';
//        $max_price = '500000';
//        $currency = 'usd';
        ?>
        <section id="property" class="padding_top padding_bottom_half">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 listing1 property-details">
                        <h2 class="text-uppercase"> </h2>
                        <div id="property-gallery" class="cbp listing1">
                            <?php
                            try {
                                require_once('../web_db/connection.php');
                                $con = new my_connection();
                                $db = $con->getCon();
                                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                $sql = " select distinct listing.listing_id, price.price_id,  price.amount,  price.currency,
                                price.property,  price.Minimum_advance,  price.deposit_required,
                                price.commission,  price.utilities_extra,  price.listing,
                                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                                ,  location.area,location,address
                                from listing
                                left  join price on price.listing = listing.listing_id
                                left  join image on image.listing = listing.listing_id
                                left  join location on listing.location = location.location_id
                                left  join cell on location.cell = cell.cell_id
                                left  join sector on cell.sector = sector.sector_id
                                left  join district on sector.district = district.district_id
                                left  join province on district.province = province.province_id
                                left join basic_apartment on basic_apartment.listing = listing.listing_id
                                left join basic_land on basic_land.listing = listing.listing_id
                                join account on listing.account = account.account_id
                                join listing_type on listing.listing_type = listing_type.listing_type_id
                                left join property on listing.property = property.property_id
                                left join property_category on listing.property_category = property_category.property_category_id
                                join property_type on property_category.property_type = property_type.property_type_id 
                                where  listing.active='yes'  and price.amount<=:price or property_type.name=:prop_type  or location.area=:area 
                                group by listing.listing_id";
                                $stmt = $db->prepare($sql);
                                $stmt->execute(array(":price" => $max_price, ":prop_type" => $keyword, ":area" => $location));
                                if ($stmt->rowCount() > 0) {

                                    while ($row = $stmt->fetch()) {
                                        echo ' 
                                            <div class="cbp-item latest sale" >
                                    <div class="property_item data_item" data-prop_title=' . $row['title'] . ''
                                        . ' data-listing_id=' . $row['listing_id'] .
                                        ' data-prop_district=' . $row['district'] . '>
                                    <div class="image">
                                        <a href="#"><img src="../web_images/property/' . $row['path'] . '" alt="latest property" class="img-responsive" style="width: 360px; height: 235px;"></a>
                                        <div class="price clearfix">
                                        <div style="background-color: #000; position: absolute; bottom: 0px; height: 60px; width: 100%;opacity: 0.5;">
                                        </div>
                                        <div style=" position: absolute; bottom: 0px; min-height: 60px; width: 100%; color: #fff; padding: 4px;">
                                            <div style="float: left;width: 100%; text-transform: UPPERCASE;">' . $row['title'] . '</div>
                                            <div style="display: block; width: 210px;  height:20px;overflow: hidden; ">@ ' . $row['district'] . ', ' . $row['address'] . ', ' . $row['area'] . '</div>
                                            <div style="float: left; color: #fff; width: 86px;  margin-right: 3px;overflow: hidden;">';
                                        echo bedrooms($row['listing_id']);
                                        echo ' bedrooms</div>&nbsp
                                            <div style="float: left; color: #fff; width: 86px;">';
                                        echo bathroms($row['listing_id']);
                                        echo ' bathrooms</div>
                                        </div>
                                            <span class="tag pull-right"> $' . $row['amount'];
                                        echo ' ' . Per_month($row['listing_id']);
                                        echo '</span>                </div>
                                        <span class = "tag_t">' . sale_rent($row['listing_id']) . '</span>
                                        <span class = "tag_l">' . $row['listing_date'] . '</span>
                            </div>
                            <div class = "proerty_content" >

                            <div class = "favroute clearfix">

                            <ul class = "pull-right" style=" display: none";>
                            <li><a href = "javascript:void(0)"><i class = "icon-like"></i></a></li>
                            <li><a href = "#seventy" class = "share_expender" data-toggle = "collapse"><i class = "icon-share3"></i></a>
                            </li>
                            </ul>
                            </div>
                            <div class = "toggle_share collapse" id = "seventy">
                            </div>
                            </div>
                            </div>
                            </div>';
                                    }
                                } else {
                                    echo '<h3>No result found';
                                }
                            } catch (PDOException $e) {
                                echo $e->getMessage();
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.actions.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
        <script src="js/homepage_script.js" type="text/javascript"></script>
    </body>
</html>
<?php

function sale_rent($listing) {
    $con = new my_connection();
    $sql = "select listing.listing_type from listing 
            where  listing.listing_id = :listing_id ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing_id" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['listing_type'];
    return ($userid == 1) ? 'For rent' : 'For Sale';
}

function get_prop_type_by_lstng_id($list_id) {//this method the chosen listing id is inside of it
    $con = new my_connection();
    $sql = "select    property_type.property_type_id  from property_type
            join property_category on property_category.property_type = property_type.property_type_id
            join listing on listing.property_category = property_category.property_category_id
            where  listing.listing_id = :listing_id ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing_id" => $list_id));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['property_type_id'];
    return $userid;
}

function get_days_ago($date) {
    $year = date('Y', strtotime($date));
    $t = $date;
    $listing_day = date("D", strtotime($t));
    $listing_date = date("d", strtotime($t));
    if ($year == date('Y')) {//this year
        if (We_this_week() && ($listing_day == 'Sat' || $listing_day == 'Fri' || $listing_day = 'Thu' || $listing_day == 'Wed' || $listing_day == 'Mon' || $listing_day == 'Tue' || $listing_day == 'Sun') && ( $listing_date > today_date())) {//Last week
            return 'Last week';
        } else if (day() == $listing_day) {//Today
            return 'Today';
        } else if (day() == 'Thu') {
            
        } else if (day() == 'Fri') {
            
        } else if (day() == 'Sat') {
            
        } else if (day() == 'Sun') {
            
        }
    } else {
        
    }
}

function We_this_week() {
    if (day() == 'Tue' || day() == 'Mon' || day() == 'Wed' || day() == 'Thu' || day() == 'Fri' || day() == 'Sat') {
        return true;
    }
}

function day() {//this is to get today (Monday, Tuesday, etc)
    $t = date('d-m-Y');
    return date("D", strtotime($t));
}

function today_date() {
    return date('d');
}

function n_floows($listing_id) {
    if (get_prop_type_by_lstng_id($listing_id) == 8) {//this is the apartment
        echo apart_bedrooms_By_isting($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 9) {// this is the commercial
        echo comm_bedroom_by_listing($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 10) {//this is the house
        echo house_bedroom_bylisting($listing_id);
    }
}

function bedrooms($listing_id) {//this will retiuve the  bedrooms no matter what the property type it os
    if (get_prop_type_by_lstng_id($listing_id) == 8) {//this is the apartment
        return apart_bedrooms_By_isting($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 9) {// this is the commercial
        return comm_bedroom_by_listing($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 10) {//this is the house
        return house_bedroom_bylisting($listing_id);
    }
}

function bathroms($listing_id) {
    if (get_prop_type_by_lstng_id($listing_id) == 8) {//this is the apartment
        echo apart_bathrooms_By_isting($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 9) {// this is the commercial
        echo comm_bathrooms_by_listing($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 10) {//this is the house
        echo house_bathrooms_bylisting($listing_id);
    }
}

function nFloors($listing_id) {
    if (get_prop_type_by_lstng_id($listing_id) == 8) {//this is the apartment
        echo apart_nFloors_By_isting($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 9) {// this is the commercial
        echo comm_nFloors_by_listing($listing_id);
    } else if (get_prop_type_by_lstng_id($listing_id) == 10) {//this is the house
        echo house_nFloors_bylisting($listing_id);
    }
}

function Per_month($listing_id) {
    if (per_month_sale($listing_id) == 1) {//it means that the listing is for rent
        return 'per month';
    } else {//it means that the listng is for sale
        return '';
    }
}

function per_month_sale($listing_id) {//this function return the condition if the prooper
    $con = new my_connection();
    $sql = "select listing.listing_type from listing where listing.listing_id =:listingid ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array("listingid" => $listing_id));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['listing_type'];
    return $userid;
}

// <editor-fold defaultstate="collapsed" desc="--------bedrooms single callables ------">
function apart_bedrooms_By_isting($listing) {
    $db = new my_connection();
    $sql = "select   basic_apartment.bedrooms  from basic_apartment where basic_apartment.listing=:listing";
    $stmt = $db->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bedrooms'];
    echo $userid;
}

function comm_bedroom_by_listing($listing) {
    $con = new my_connection();
    $sql = "select    bedroom  from basic_commercial where basic_commercial.listing=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bedroom'];
    echo $userid;
}

function house_bedroom_bylisting($listing) {
    $con = new my_connection();
    $sql = "select    bedroom  from basic_house  where basic_house.listing=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bedroom'];
    echo $userid;
}

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="-------bathroomas single callables -------">

function apart_bathrooms_By_isting($listing) {
    $db = new my_connection();
    $sql = "select   basic_apartment.bathrooms from basic_apartment where basic_apartment.listing_id=:listing";
    $stmt = $db->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bathrooms'];
    return $userid;
}

function comm_bathrooms_by_listing($listing) {
    $con = new my_connection();
    $sql = "select    bathroom  from basic_commercial where basic_commercial.listing=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bathroom'];
    return $userid;
}

function house_bathrooms_bylisting($listing) {
    $con = new my_connection();
    $sql = "select    bathroom  from basic_house where basic_house.listing=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bathroom'];
    return $userid;
}

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="---- number floors single callables -------">
function apart_nFloors_By_isting($listing) {
    $db = new my_connection();
    $sql = "select   basic_apartment.total_number_floors  from basic_apartment where basic_apartment.listing=:listing";
    $stmt = $db->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['total_number_floors'];
    return $userid;
}

function comm_nFloors_by_listing($listing) {
    $con = new my_connection();
    $sql = "select    total_number_floors  from basic_commercial where basic_commercial.listing=:listing  ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['total_number_floors'];
    return $userid;
}

function house_nFloors_bylisting($listing) {
    $con = new my_connection();
    $sql = "select    bathroom  from basic_house where basic_house.listing=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['bathroom'];
    return $userid;
}

// </editor-fold>

