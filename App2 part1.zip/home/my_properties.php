<?php
require_once 'top_bar.php';
require_once 'menu.php';
//require_once './new_homepage/slider.php';
?>
<html>
    <head>
        <title>My properties</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="icon" href="images/icon.png">
    </head>
    <body>

        <!-- My - Property Start -->
        <section id="agent-2-peperty" class="my-pro padding">
            <div class="container">

                <div class="row bottom30">
                    <div class="col-md-12 text-center">
                        <h2 class="text-uppercase">My Properties</h2>
                    </div>
                </div>
            </div>
            <div class="container  list-t-border">
                <div class="row bg-hover">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover bg-color-gray">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover bg-color-gray">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover bg-color-gray">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-hover bg-color-gray">
                    <div class="my-pro-list">
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <img src="images/my-p-list.png" alt="image"/>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="feature-p-text">
                                <h4>Historic Town House</h4>
                                <p>Action Area I, Newtown, New Town, West Bengal, India</p>
                                <span><b>Status:</b>  For Sale</span><br>
                                <div class="button-my-pro-list">
                                    <a href="#.">$128,600</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                            <div class="select-pro-list">
                                <a href="#"><i class="icon-pen2"></i></a>
                                <a href="#"><i class="icon-cross"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row padding_top">
                    <div class="col-md-12">
                        <ul class="pager">
                            <li><a href="#">1</a></li>
                            <li class="active"><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- My - Property end -->



        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
    </body>
</html>
