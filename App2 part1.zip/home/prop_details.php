<?php
session_start();
require_once 'whole_listing_by_id.php';
require_once './whole_price_by_id.php';

$obj = new chosen_record();
$obj_price = new Price_by_listing();
$obj_basc = new basic_info_by_listing();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos | Property Detail</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="icon" href="images/icon.png">
        <style>
            .pro-img{

            }
        </style>
    </head>
    <body>
        <!--Loader-->
        <!--        <div class="loader">
                    <div class="span">
                        <div class="location_indicator"></div>
                    </div>
                </div>-->
        <!--Loader-->
        <?php
        require_once 'top_bar.php';
        require_once 'menu.php';
        ?>
        <!-- Page Banner Start-->
        <section class="page-banner padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1 class="text-uppercase">Property Details - <?php echo (isset($_SESSION['listing_details'])) ? $_SESSION['listing_details'] : 'not found'; ?></h1>
                        <p>Your needs are our duty </p>
                        <ol class="breadcrumb text-center">
                            <li><a href="index.php">Home</a></li>

                            <li class="active">Property Details - <?php echo (!empty($_SESSION['listing_details'])) ? $_SESSION['listing_details'] : 'not found'; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <!-- Page Banner End -->

        <!-- Property Detail Start -->
        <section id="property" class="padding_top padding_bottom_half">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 listing1 property-details">
                        <h2 class="text-uppercase"><?php echo $obj->get_chosen_listing_title($_SESSION['listing_details']); ?></h2>
                        <p class="bottom30"> <?php echo (isset($_SESSION['district'])) ? $_SESSION['district'] : ''; ?>, UK</p>
                        <div id="property-d-1" class="owl-carousel">
                            <?php echo (isset($_SESSION['listing_details'])) ? get_details($_SESSION['listing_details']) : '' ?>
                        </div>
                        <div id="property-d-1-2" class="owl-carousel">
                            <?php show_thumbnails($_SESSION['listing_details']) ?>
                        </div>
                        <div class="property_meta bg-black bottom40">

                        </div>
                        <h2 class="text-uppercase">Property Description</h2>
                        <?php echo get_chosen_description($_SESSION['listing_details']) ?>
                        <h2 class="text-uppercase bottom20">Quick Summary</h2>
                        <div class = "row property-d-table bottom40">
                            <div class = "col-md-6 col-sm-6 col-xs-12">
                                <table class = "table table-striped table-responsive">
                                    <tbody>
                                        <tr>
                                            <td><b>Property Id</b></td>
                                            <td class = "text-right"><?php echo $_SESSION['listing_details']; ?></td>
                                        </tr>
                                        <tr>
                                            <td><b>Price</b> </td>
                                            <td class = "text-right"> <?php echo $obj_price->get_amount($_SESSION['listing_details']) ?> / month</td>
                                        </tr>
                                        <tr>
                                            <td><b>Property Size</b></td>
                                            <td class = "text-right">5, 500 ft2</td>
                                        </tr>
                                        <tr>
                                            <td><b>Bedrooms</b></td>
                                            <td class = "text-right"><?php echo $obj_basc->bedrooms($_SESSION['listing_details']); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b>Bathrooms</b></td>
                                            <td class = "text-right">3</td>
                                        </tr>
                                        <tr>
                                            <td><b>Available From</b></td>
                                            <td class = "text-right"><?php echo $obj_basc->available_from($_SESSION['listing_details']) ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class = "col-md-6 col-sm-6 col-xs-12">
                                <table class = "table table-striped table-responsive">
                                    <tbody>
                                        <tr>
                                            <td><b>Status</b></td>
                                            <td class = "text-right"><?php echo Rent_or_Sale($_SESSION['listing_details']); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b>Category</b></td>
                                            <td class = "text-right"><?php echo $obj->get_chosen_listing_prop_typeName_by_listing_id($_SESSION['listing_details']); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b>Garages</b></td>
                                            <td class = "text-right">1</td>
                                        </tr>
                                        <tr>
                                            <td><b>Cross Streets</b></td>
                                            <td class = "text-right">Nordoff</td>
                                        </tr>
                                        <tr>
                                            <td><b>Floors</b></td>
                                            <td class = "text-right">Carpet - Ceramic Tile</td>
                                        </tr>
                                        <tr>
                                            <td><b>Plumbing</b></td>
                                            <td class = "text-right">Full Copper Plumbing</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <h2 class="text-uppercase bottom20">Features</h2>
                        <div class="row bottom40">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <ul class="pro-list">
                                    <?php get_features_by_listing($_SESSION['listing_details']); ?>
                                </ul>
                            </div>
                        </div>

                        <?php if (!empty(get_map_or_not())) { ?>
                            <h2 class="text-uppercase bottom20" >Property Map</h2>
                            <div class="row bottom40" id="map">
                                <div class="col-md-12 bottom20">
                                    <div class="property-list-map" style=" height: 300px;">
                                        <div  class="multiple-location-map" style="   width:100%;height:380px;"></div>
                                    </div>
                                </div>
                                <div class="social-networks">
                                    <div class="social-icons-2">
                                        <span class="share-it">Share this Property</span>
                                        <span><a href="#."><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></span>
                                        <span><a href="#."><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</a></span>
                                        <span><a href="#."><i class="fa fa-google-plus" aria-hidden="true"></i> Google +</a></span>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="row hidden">
                            <div class="col-sm-10">
                                <h2 class="text-uppercase top20">Similar Properties</h2>
                                <p class="bottom30">We have Properties in these Areas View a list of Featured Properties.</p>
                            </div>
                            <div class="col-sm-12"><div id="two-col-slider" class="owl-carousel">
                                    <div class="item">
                                        <div class="property_item heading_space" style="border: 1px solid #004c87;">
                                            <div class="image">
                                                <a href="#."><img src="images/listing1.jpg" alt="latest property" class="img-responsive"></a>
                                                <div class="price clearfix">
                                                    <span class="tag pull-right">$8,600 Per Month</span>
                                                </div>
                                                <span class="tag_t">For Sale</span>
                                                <span class="tag_l">Featured</span>
                                            </div>
                                            <div class="proerty_content">
                                                <div class="proerty_text">
                                                    <h3 class="captlize"><a href="#.">Historic Town House</a></h3>
                                                    <p>45 Regent Street, London, UK</p>
                                                </div>
                                                <div class="property_meta transparent">
                                                    <span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span>
                                                    <span><i class="icon-bed"></i>2 Office Rooms</span>
                                                    <span><i class="icon-safety-shower"></i>1 Bathroom</span>
                                                </div>
                                                <div class="property_meta transparent bottom30">
                                                    <span><i class="icon-old-television"></i>TV Lounge</span>
                                                    <span><i class="icon-garage"></i>1 Garage</span>
                                                    <span></span>
                                                </div>
                                                <div class="favroute clearfix">
                                                    <p class="pull-md-left"><i class="icon-calendar2"></i>&nbsp;5 Days ago </p>
                                                    <ul class="pull-right">
                                                        <li><a href="#."><i class="icon-like"></i></a></li>
                                                        <li><a href="#five" class="share_expender" data-toggle="collapse"><i class="icon-share3"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="toggle_share collapse" id="five">
                                                    <ul>
                                                        <li><a href="#." class="facebook"><i class="icon-facebook-1"></i> Facebook</a></li>
                                                        <li><a href="#." class="twitter"><i class="icon-twitter-1"></i> Twitter</a></li>
                                                        <li><a href="#." class="vimo"><i class="icon-vimeo3"></i> Vimeo</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="property_item heading_space">
                                            <div class="image">
                                                <a href="#."><img src="images/listing1.jpg" alt="latest property" class="img-responsive"></a>
                                                <div class="price clearfix">
                                                    <span class="tag pull-right">$8,600 Per Month</span>
                                                </div>
                                                <span class="tag_t">For Sale</span>
                                                <span class="tag_l">Featured</span>
                                            </div>
                                            <div class="proerty_content">
                                                <div class="proerty_text">
                                                    <h3 class="captlize"><a href="#.">Historic Town House</a></h3>
                                                    <p>45 Regent Street, London, UK</p>
                                                </div>
                                                <div class="property_meta transparent">
                                                    <span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span>
                                                    <span><i class="icon-bed"></i>2 Office Rooms</span>
                                                    <span><i class="icon-safety-shower"></i>1 Bathroom</span>
                                                </div>
                                                <div class="property_meta transparent bottom30">
                                                    <span><i class="icon-old-television"></i>TV Lounge</span>
                                                    <span><i class="icon-garage"></i>1 Garage</span>
                                                    <span></span>
                                                </div>
                                                <div class="favroute clearfix">
                                                    <p class="pull-md-left"><i class="icon-calendar2"></i>&nbsp;5 Days ago </p>
                                                    <ul class="pull-right">
                                                        <li><a href="#."><i class="icon-like"></i></a></li>
                                                        <li><a href="#four" class="share_expender" data-toggle="collapse"><i class="icon-share3"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="toggle_share collapse" id="four">
                                                    <ul>
                                                        <li><a href="#." class="facebook"><i class="icon-facebook-1"></i> Facebook</a></li>
                                                        <li><a href="#." class="twitter"><i class="icon-twitter-1"></i> Twitter</a></li>
                                                        <li><a href="#." class="vimo"><i class="icon-vimeo3"></i> Vimeo</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="property_item heading_space">
                                            <div class="image">
                                                <a href="#."><img src="images/listing1.jpg" alt="latest property" class="img-responsive"></a>
                                                <div class="price clearfix">
                                                    <span class="tag pull-right">$8,600 Per Month</span>
                                                </div>
                                                <span class="tag_t">For Sale</span>
                                                <span class="tag_l">Featured</span>
                                            </div>
                                            <div class="proerty_content">
                                                <div class="proerty_text">
                                                    <h3 class="captlize"><a href="#.">Historic Town House</a></h3>
                                                    <p>45 Regent Street, London, UK</p>
                                                </div>
                                                <div class="property_meta transparent">
                                                    <span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span>
                                                    <span><i class="icon-bed"></i>2 Office Rooms</span>
                                                    <span><i class="icon-safety-shower"></i>1 Bathroom</span>
                                                </div>
                                                <div class="property_meta transparent bottom30">
                                                    <span><i class="icon-old-television"></i>TV Lounge</span>
                                                    <span><i class="icon-garage"></i>1 Garage</span>
                                                    <span></span>
                                                </div>
                                                <div class="favroute clearfix">
                                                    <p class="pull-md-left"><i class="icon-calendar2"></i>&nbsp;5 Days ago </p>
                                                    <ul class="pull-right">
                                                        <li><a href="#."><i class="icon-like"></i></a></li>
                                                        <li><a href="#six" class="share_expender" data-toggle="collapse"><i class="icon-share3"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="toggle_share collapse" id="six">
                                                    <ul>
                                                        <li><a href="#." class="facebook"><i class="icon-facebook-1"></i> Facebook</a></li>
                                                        <li><a href="#." class="twitter"><i class="icon-twitter-1"></i> Twitter</a></li>
                                                        <li><a href="#." class="vimo"><i class="icon-vimeo3"></i> Vimeo</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="property_item heading_space">
                                            <div class="image">
                                                <a href="#."><img src="images/listing1.jpg" alt="latest property" class="img-responsive"></a>
                                                <div class="price clearfix">
                                                    <span class="tag pull-right">$8,600 Per Month</span>
                                                </div>
                                                <span class="tag_t">For Sale</span>
                                                <span class="tag_l">Featured</span>
                                            </div>
                                            <div class="proerty_content">
                                                <div class="proerty_text">
                                                    <h3 class="captlize"><a href="#.">Historic Town House</a></h3>
                                                    <p>45 Regent Street, London, UK</p>
                                                </div>
                                                <div class="property_meta transparent">
                                                    <span><i class="icon-select-an-objecto-tool"></i>4800 sq ft</span>
                                                    <span><i class="icon-bed"></i>2 Office Rooms</span>
                                                    <span><i class="icon-safety-shower"></i>1 Bathroom</span>
                                                </div>
                                                <div class="property_meta transparent bottom30">
                                                    <span><i class="icon-old-television"></i>TV Lounge</span>
                                                    <span><i class="icon-garage"></i>1 Garage</span>
                                                    <span></span>
                                                </div>
                                                <div class="favroute clearfix">
                                                    <p class="pull-md-left"><i class="icon-calendar2"></i>&nbsp;5 Days ago </p>
                                                    <ul class="pull-right">
                                                        <li><a href="#."><i class="icon-like"></i></a></li>
                                                        <li><a href="#three" class="share_expender" data-toggle="collapse"><i class="icon-share3"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="toggle_share collapse" id="three">
                                                    <ul>
                                                        <li><a href="#." class="facebook"><i class="icon-facebook-1"></i> Facebook</a></li>
                                                        <li><a href="#." class="twitter"><i class="icon-twitter-1"></i> Twitter</a></li>
                                                        <li><a href="#." class="vimo"><i class="icon-vimeo3"></i> Vimeo</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-12 text-center heading_space hidden">
                            <ul class="pager">
                                <li><a href="#.">1</a></li>
                                <li class="active"><a href="#.">2</a></li>
                                <li><a href="#.">3</a></li>
                            </ul>
                        </div>
                    </div>
                    <aside class="col-md-4 col-xs-12">
                        <div class="property-query-area clearfix">
                            <div class="col-md-12">
                                <h3 class="text-uppercase bottom20 top15">Contact agent</h3>
                            </div>
                            <form class="callus" method="post" action="prop_details.php">
                                <div class="single-query form-group col-sm-12">
                                    <input type="text" name="txt_name" class="keyword-input" placeholder="Name">
                                </div>
                                <div class="single-query form-group col-sm-12">
                                    <input type="text" name="txt_phone" class="keyword-input" placeholder="Phone">
                                </div>
                                <div class="single-query form-group col-sm-12">
                                    <input type="text" name="txt_email" class="keyword-input" placeholder="Email">
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <textarea class="form-control" name="txt_msg" placeholder="Message"></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12 form-group">
                                    <button type="submit" name="send_comment" class="btn-blue border_radius">Submit</button>
                                </div>
                            </form>

                            <div class="search-propertie-filters collapse">
                                <div class="container-2">
                                    <div class="row">
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="search-form-group white">
                                                <input type="checkbox" name="check-box" />
                                                <span>Rap music</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row bottom20" style="float:left; margin-left: 5px;">
                            <h3 class="text-uppercase bottom20 top15">Featured</h3>
                            <?php echo featured_listing(); ?>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <h3 class="margin40 bottom20">Featured Properties</h3>
                            </div>
                            <div class="col-md-12">
                                <div id="agent-2-slider" class="owl-carousel">
                                    <div class="item">
                                        <div class="property_item heading_space">
                                            <div class="image">
                                                <a href="#."><img src="images/slider-list2.jpg" alt="listin" class="img-responsive"></a>
                                                <div class="feature"><span class="tag-2">For Rent</span></div>
                                                <div class="price clearfix"><span class="tag pull-right">$8,600 Per Month - <small>Family Home</small></span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="property_item heading_space">
                                            <div class="image">
                                                <a href="#."><img src="images/slider-list2.jpg" alt="listin" class="img-responsive"></a>
                                                <div class="feature"><span class="tag-2">For Rent</span></div>
                                                <div class="price clearfix"><span class="tag pull-right">$8,600 Per Month - <small>Family Home</small></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </section>
        <!-- Property Detail End -->

        <!--CopyRight-->
        <?php require_once './other_footer.php'; ?>
        <script type = "text/javascript">
            function initMap() {
            var lat =<?php echo get_lat_by_listing(); ?>;
            var lng =<?php echo get_longtd_by_listing(); ?>;
            var myLatLng = {lat, lng};
            var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,
                    center: myLatLng
            });
            var marker = new google.maps.Marker({
            position: myLatLng,
                    map: map,
                    title: 'Esercos Headquarters'
            });
            }

        </script>
        <script async defer   src="https://maps.googleapis.com/maps/api/js?key=
                AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
        </script>
        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/neary-by-place.js"></script>
        <script src="js/maps.search.js"></script>
        <script src="js/google-map.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
    </body>
</html>

<?php

function featured_listing() {//this retrieves general featured
    $con = new my_connection();
    $sql = " select  distinct listing.listing_id, price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                ,listing.active from listing
                left  join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                left join property on listing.property = property.property_id
                left join property_category on listing.property_category = property_category.property_category_id
                where  listing.listing_id not in (select listing from featured where featured_cat<> '5' and featured_cat<>'6')   group by listing.listing_id";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute();
    while ($row = $stmt->fetch()) {
        echo'
        <div class="row bottom20" style=" border-bottom: 2px solid #a2a5a8;min-height: 95px;    ">
            <div class="col-md-4 col-sm-4 col-xs-6 p-image">
                <img src="../web_images/property/' . $row['path'] . '" alt="image"/>
            </div>
            <div class="col-md-8 col-sm-8 col-xs-6" >
                <div class="feature-p-text" >
                    <h4>' . $row['title'] . '</h4>
                    <p class="bottom15">' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '</p>
                    <a href="#.">' . $row['amount'] . '</a>
                </div>
            </div>
        </div> ';
    }
}

function get_map_or_not() {
    $db = new my_connection();
    $sql = " select location.lat
            from location
            join listing on listing.location = location.location_id 
            where  listing.listing_id=:listing";
    $stmt = $db->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $_SESSION['listing_details']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $lat = trim($row['lat']);
    return ($lat != '') ? $lat : '';
}

function get_details($Listing) {
    $con = new my_connection();
    $sql = " select  distinct 	image.path from listing   join image on image.listing = listing.listing_id       where listing.listing_id=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $Listing));
    while ($row = $stmt->fetch()) {
        ?>  <?php
        echo '<div class="pro-img" >
                                <figure class="wpf-demo-gallery">
                                    <div class="item"><img src = "../web_images/property/' . $row['path'] . '" alt = "image"/></div>
                                    <figcaption class="view-caption">
                                        <a data-fancybox-group="gallery" class="fancybox" href="images/property-d-1-1.jpg" ><i class="icon-focus"></i>Big</a>
                                    </figcaption>
                                </figure>
                            </div>';
    }
}

function show_thumbnails($Listing) {
    $res = '';
//    require_once '../web_db/connection.php';
    $con = new my_connection();
    $sql = " select  distinct 	image.path from listing   join image on image.listing = listing.listing_id       where listing.listing_id=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $Listing));
    while ($row = $stmt->fetch()) {
        ?>  <?php
        echo '<div class="item" ><img src="../web_images/property/' . $row['path'] . '" alt="image"/></div>';
    }
}

function get_chosen_description($list_id) {
    $db = new my_connection();
    $sql = "select description from listing    where  listing.listing_id = :listing_id ";
    $stmt = $db->getCon()->prepare($sql);
    $stmt->execute(array(":listing_id" => $list_id));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['description'];
    return $userid;
}

function get_prop_type_by_lstng_id($list_id) {//this the listing type even thought the method os not well named
    $con = new my_connection();
    $sql = "select listing_type from listing where listing_id = :listing_id ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing_id" => $list_id));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['listing_type'];
    return $userid;
}

function Rent_or_Sale($listing_id) {
    if (get_prop_type_by_lstng_id($listing_id) == 1) {
        return 'Rent';
    } else if (get_prop_type_by_lstng_id($listing_id) == 2) {
        return 'Sale';
    }
}

function feature_by_session() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->features_last_listing();
    return $res;
}

function get_features_by_listing($listing) {
    ?><script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script><?php
    $res = '';
    $con = new my_connection();
    $sql = "select listing_features.features,  features.name from listing_features
                        join features on listing_features.features = features.features_id where listing_features.listing=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $listing));

    while ($row = $stmt->fetch()) {
        echo ' <li>' . $row['name'] . '</li>';
    }
}

save_web_visit();

function save_web_visit() {
    if (isset($_SESSION['listing_details'])) {
        if (!empty(get_if_visited_before())) {//if visited before
            $last_c = get_last_count();
            update_web_visits(date('y-m-d'), $last_c + 1, $_SESSION['listing_details'], $_SESSION['listing_details']);
        } else {
            echo 'Saved';
            new_web_visits(date('y-m-d'), 1, $_SESSION['listing_details']);
        }
    }
}

function get_last_count() {
    $con = new my_connection();
    $sql = "select visit_count from web_visits
        where listing=:listing  ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $_SESSION['listing_details']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $first_rec = $row['visit_count'];
    return $first_rec;
}

function get_if_visited_before() {
    $con = new my_connection();
    $sql = "select listing from web_visits
        where listing=:listing  ";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $_SESSION['listing_details']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $first_rec = $row['listing'];
    return $first_rec;
}

function get_lat_by_listing() {
    $con = new my_connection();
    $sql = "select location.lat
            from location
            join listing on listing.location = location.location_id 
            where  listing.listing_id=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $_SESSION['listing_details']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $first_rec = $row['lat'];
    return $first_rec;
}

function get_longtd_by_listing() {
    $con = new my_connection();
    $sql = "select location.longtd
            from location
            join listing on listing.location = location.location_id 
            where  listing.listing_id=:listing";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listing" => $_SESSION['listing_details']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $first_rec = $row['longtd'];
    return $first_rec;
}

function new_web_visits($date, $visit_count, $listing) {
    try {
        $database = new my_connection();
        $db = $database->getCon();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into web_visits values(:web_visits_id, :date,  :visit_count,:listing)");
        $stm->execute(array(':web_visits_id' => 0, ':date' => $date, ':visit_count' => $visit_count, ":listing" => $listing));
    } catch (PDOException $e) {
        echo 'Error .. ' . $e->getMessage();
    }
}

function update_web_visits($date, $visit_count, $listing, $web_visits_id) {
    $database = new my_connection();
    $db = $database->getCon();
    $stmt = $db->prepare("UPDATE web_visits set date= ?, visit_count= ?, listing= ? WHERE listing=?");
    $stmt->execute(array($date, $visit_count, $listing, $web_visits_id));
}

function new_comment($commentdeleted, $message, $account, $date, $listing) {
    try {
        $database = new my_connection();
        $db = $database->getCon();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into comment values(:comment_id, :commentdeleted,  :message,  :account,  :date,  :listing)");
        $stm->execute(array(':comment_id' => 0, ':commentdeleted' => $commentdeleted, ':message' => $message, ':account' => $account, ':date' => $date, ':listing' => $listing));
    } catch (PDOException $e) {
        echo 'Error .. ' . $e;
    }
}

function new_comment_replies($comment_repliesdeleted, $message, $date, $account, $comment) {
    try {
        $database = new my_connection();
        $db = $database->getCon();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into comment_replies values(:comment_replies_id, :comment_repliesdeleted,  :message,  :date,  :account,  :comment)");
        $stm->execute(array(':comment_replies_id' => 0, ':comment_repliesdeleted' => $comment_repliesdeleted, ':message' => $message, ':date' => $date, ':account' => $account, ':comment' => $comment));
    } catch (PDOException $e) {
        echo 'Error .. ' . $e;
    }
}

send_comment();

function send_comment() {
    if (isset($_POST['send_comment'])) {
        $txt_name = $_POST['txt_name'];
        $txt_email = $_POST['txt_email'];
        $msg = $_POST['txt_msg'];
        $phone = $_POST['txt_phone'];
        $commentdeleted = 'no';
        $account = 0;
        $date = date("y-m-d");
        $listing = $_SESSION['listing_details'];
        if (!empty(email_exists($txt_email))) {//here we search through the account table
            ?><script>alert('There is an account already with this email, please login');</script><?php
        } else if (empty($_SESSION['cat'])) {//if he has not logged in
            $_SESSION['name'] = $txt_name;
            $_SESSION['email'] = $txt_email;
            $_SESSION['msg'] = $msg;
            $_SESSION['phone'] = $phone;
            $_SESSION['account'] = $account;
            ?><script>
                    window.location.replace('login_first.php');
            </script><?php
        } else {
            try {
                $account = $_SESSION['userid'];
                new_comment($commentdeleted, $msg, $account, $date, $listing);
            } catch (PDOException $e) {
                echo 'Error .. ' . $e->getMessage();
            }
        }
    }
}

function email_exists($email) {
    try {
        $con = new my_connection();
        $sql = "select    account.username from account where  account.username=:username";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $email);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $found = $row['username'];
        return $found;
    } catch (PDOException $ex) {
        echo 'The error while getting the id of the user' . $ex;
    }
}
