+<?php
session_start();
unset($_SESSION['listing_details']);
require_once('../web_db/connection.php');
$con = new my_connection();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="icon" href="images/icon.png">
        <style>
            .tp_overlay{
                /*background-color: #330033;*/
                top: 121px;
                z-index: 980;
                padding: 0px;
            }
            .custom_overlay, .my_textbox{
                float: left;
            }
            .custom_overlay{
                width: 80%;
                /*margin: 140px 10%;*/
            }
            .my_textbox{
                margin-top: 15px;
                float: left;
                width: 30%;
                margin-left: 10px;
            }
            .my_textbox:first-of-type{
                margin-left: 0px;
            }
            .my_button_2{/*sorry this is just the textbox*/
                margin-left: 10px;
            }
            .my_button_3{/*sorry this is just the textbox*/
                float: right;
            }
            .my_textbox input[type="text"]{
                width: 100%;
                height:44px; 
                border:1px solid #d5dadf;  
                border-radius:4px;
                padding:6px 12px;
                color: #999999;
            }
            .my_button:first-of-type{
                margin-top: 200px;
            }
            .my_button{
                float: right;
                margin-top: 20px;
                background-color: #fff;
                /*margin-left: 35%;*/
                height: 44px;
                border-radius: 4px; 
                margin-top: 60px;
            }
            .my_button input[type="submit"]{
                background-color: #FFFF0D;
                float: right;
                margin-right: 0px;
            }
            .full_textbox{
                width: 100%;
            }
            .txt_full{
                width: 100%;
                border:1px solid #d5dadf;
                height:44px;
                border-radius:4px;
                background:#fff;
                padding:6px 12px;
                font-size:14px;
                color: #999999;
            }
            #first_txt{
                /*yea eventhough alll of the three textboxs float left to 10px this is one will not be because it is the first*/
                margin-left: 0px;
            }
        </style>
    </head>
    <body>
        <!--Loader-->
        <div class="loader">
            <div class="span">
                <div class="location_indicator"></div>
            </div>
        </div>
        <!--Loader-->
        <?php
        require_once 'top_bar.php';
        require_once 'menu.php';
        require_once 'slider.php';
        require_once 'overlay.php';
        require_once './gallery.php';
        // require_once 'deals.php';
        // require_once 'parallax.php';
        // require_once 'testimonials.php';
        // require_once 'partners.php';
        require_once './footer.php';
        ?>
        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.actions.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
        <script src="js/homepage_script.js" type="text/javascript"></script>


    </body>
</html>
