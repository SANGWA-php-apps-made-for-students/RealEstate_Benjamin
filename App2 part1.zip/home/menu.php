<?php ?>
<script>
    $(document).ready(function () {
        search_by_propType();
    });

    function search_by_propType() {
        $('.by_category').click(function () {
            var type_name = $(this).data('cat');
            var cont = 'c';
            $.post('handler.php', {type_name: type_name}, function (data) {

            }).complete(function () {
                window.location.replace('listing_by_prpType.php');
            });
        });
    }
</script>
<nav class="navbar navbar-default navbar-sticky bootsnav" style="margin-top: 0px;" >
    <div class="container">
        <div class="attr-nav">
            <ul class="social_share clearfix">
                <li><a href="#." class="facebook"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#." class="twitter"> <i class="fa fa-twitter"></i></a></li>
                <li><a class="google" href="#.">  <i class="icon-google4"></i></a></li>
            </ul>
        </div>
        <!-- Start Header Navigation -->
        <div class="navbar-header" >
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand sticky_logo" href="index.php"><img src="images/logo.png" width="100" height="50" class="logo" alt=""></a>
        </div>
        <!-- End Header Navigation -->
        <div class="collapse navbar-collapse" id="navbar-menu" style="float: left; margin-left: 50px; margin-top: 10px;">
            <ul class="nav navbar-nav" data-in="fadeIn" data-out="fadeOut">
                <li class="dropdown active">
                    <a href="index" class="dropdown-toggle" data-toggle="dropdown">Home </a>
                </li>
                <li class="dropdown megamenu-fw">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Sales</a>
                    <ul class="dropdown-menu megamenu-content" role="menu">
                        <li>
                            <div class="row">
                                <div class="col-menu col-md-3">
                                    <h5 class="title">PROPERTIES CATEGORIES </h5>
                                    <div class="content">
                                        <ul class="menu-col">
                                            <li><a class="by_category" data-cat="Apartment" href="#">Apartments</a></li>
                                            <li><a class="by_category" data-cat="Commercial" href="#">Commercial</a></li>
                                            <li><a class="by_category" data-cat="Land" href="#">Land</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-menu col-md-9">
                                    <h5 class="title bottom20">PROPERTIES FOR SALE</h5>
                                    <div class="row">
                                        <div id="nav_slider" class="owl-carousel">
                                            <?php
                                            get_sumarized_list_by_list_type(2);
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class = "dropdown megamenu-fw">
                    <a href = "#" class = "dropdown-toggle" data-toggle = "dropdown">Rentals</a>
                    <ul class = "dropdown-menu megamenu-content" role = "menu">
                        <li>
                            <div class = "row">
                                <div class = "col-menu col-md-3">
                                    <h5 class = "title">PROPERTIES CATEGORIES</h5>
                                    <div class = "content">
                                        <ul class = "menu-col">
                                            <li><a href = "listing1.html">Apartments</a></li>
                                            <li><a href = "index7.html">Commercial</a></li>
                                            <li><a href = "listing2.html">Land</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class = "col-menu col-md-9">
                                    <h5 class = "title bottom20">PROPERTIES FOR RENT</h5>
                                    <div class = "row">
                                        <div id = "nav_slider" class = "owl-carousel">
                                            <?php get_sumarized_list_by_list_type(1); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class = "dropdown active">
                    <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">Services </a>
                    <ul class = "dropdown-menu">
                        <li><a href = "index.html">Property management</a></li>
                        <li><a href = "index2.html">Property Evaluation</a></li>

                        <li> <a href = "fullscreen.html">Home Fullscreen<span>new</span></a></li>
                    </ul>
                </li>

                <li class = "dropdown active" style = "display: none;">
                    <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">Features </a>
                    <ul class = "dropdown-menu">
                        <li class = "dropdown">
                            <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">News</a>
                            <ul class = "dropdown-menu">
                                <li><a href = "news.html">Accessibility</a></li>
                                <li><a href = "news2.html">Neighborhood</a></li>
                                <li><a href = "news3.html">Appliances</a></li>
                                <li><a href = "news3.html">Extra</a></li>
                                <li><a href = "news3.html">Appliances</a></li>
                            </ul>
                        </li>
                        <li class = "dropdown">
                            <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">Property Agents</a>
                            <ul class = "dropdown-menu">
                                <li><a href = "agent1.html">Agent Style1</a></li>
                                <li><a href = "agent2.html">Agent Style2</a></li>
                                <li><a href = "agent3.html">Agent Style3</a></li>
                                <li><a href = "agent4.htm4">Agent Style4</a></li>
                                <li><a href = "agent5.htm5">Agent Style5</a></li>
                            </ul>
                        </li>
                        <li class = "dropdown">
                            <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">Agent Profile Styles</a>
                            <ul class = "dropdown-menu">
                                <li><a href = "agent_profile.html">Agent Profile 1</a></li>
                                <li><a href = "agent_profile2.html">Agent Profile 2</a></li>
                            </ul>
                        </li>
                        <li class = "dropdown">
                            <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">Testimonials</a>
                            <ul class = "dropdown-menu">
                                <li><a href = "testimonial.html">Style 1</a></li>
                                <li><a href = "testimonial2.html">Style 2</a></li>
                            </ul>
                        </li>
                        <li class = "dropdown">
                            <a href = "#." class = "dropdown-toggle" data-toggle = "dropdown">FAQ's</a>
                            <ul class="dropdown-menu">
                                <li><a href="faq.html">Style 1</a></li>
                                <li><a href="faq2.html">Style 2</a></li>
                            </ul>
                        </li>
                        <li><a href="favorite_properties.html">Favorite Properties</a></li>
                        <li class="dropdown">
                            <a href="#." class="dropdown-toggle" data-toggle="dropdown">404 Error</a>
                            <ul class="dropdown-menu">
                                <li><a href="404.html">404 Error 1</a></li>
                                <li><a href="404-2.html">404 Error 2</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="dropdown active">
                    <a href="contact_us.php" class="dropdown-toggle" data-toggle="dropdown">Contact us </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php

function get_sumarized_list_by_list_type($type) {
    $m_con = new menu_con();
    $sql = "select  distinct listing.listing_id, price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                ,listing.active, location.area,location,address from listing
                left  join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                left join property on listing.property = property.property_id
                left join property_category on listing.property_category = property_category.property_category_id
                join featured on featured.listing = listing.listing_id 
                where listing_type=:type   group by listing.listing_id    ";

    $stmt = $m_con->con_menu()->prepare($sql);
    $stmt->execute(array(":type" => $type));
    while ($row = $stmt->fetch()) {

        echo ' <div class = "item">
              <div class = "image bottom15">
          <img src = "../web_images/property/' . $row['path'] . '" alt = "Featured Property">
           <span class = "nav_tag yellow text-uppercase">for rent</span>
            </div>
             <h4><a href = "property_detail1.html">' . $row['title'] . '     </a></h4>
              <p>' . $row['district'] . ', ' . $row['address'] . ', ' . $row['area'] . '</p>
              </div>';
    }
}

class menu_con {

    function con_menu() {
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}
