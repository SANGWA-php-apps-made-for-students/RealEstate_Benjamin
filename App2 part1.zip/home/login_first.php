<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Esercos | Property Detail</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/reality-icon.css">
        <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
        <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
        <link rel="stylesheet" type="text/css" href="css/settings.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link rel="icon" href="images/icon.png">
        <style>
            .pro-img{

            }
        </style>
    </head>
    <body>
        <?php
        require_once 'top_bar.php';
        require_once 'menu.php';
        ?>
        <div class="container">
            <div class="row">
                <div class="property-query-area clearfix col-sm-6">
                    <div class="row bottom40">
                        <h4 class="text-uppercase bottom20 top15">You have entered</h4>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <ul class="pro-list">
                                <li><?php echo $_SESSION['name']; ?></li>  
                                <li><?php echo $_SESSION['email']; ?></li>
                                <li><?php echo $_SESSION['msg']; ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <h3 class="text-uppercase bottom20 top15">Make your password</h3>
                        <h6>You can use your email and that password to login to see more about favorite propertues.</h6>
                    </div>
                    <form class="callus" method="post" action="login_first.php">
                        <div class="single-query form-group col-sm-6">
                            <input type="password" name="psw1"  class="keyword-input" placeholder="Password">
                        </div>
                        <div class="single-query form-group col-sm-6">
                            <input type="password" name="psw2" class="keyword-input" placeholder="Confirm Password">
                        </div>
                        <div class="col-sm-12 form-group">
                            <button type="submit" name="send_comment_acc" class="btn-blue border_radius">Submit</button>
                        </div>
                    </form>
                    <div class="search-propertie-filters collapse">
                        <div class="container-2">
                            <div class="row">
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-6">
                                    <div class="search-form-group white">
                                        <input type="checkbox" name="check-box" />
                                        <span>Rap music</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php require_once './other_footer.php'; ?>
        <script src="js/jquery-2.1.4.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootsnav.js"></script>
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/jquery-countTo.js"></script>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/range-Slider.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.cubeportfolio.min.js"></script>
        <script src="js/selectbox-0.2.min.js"></script>
        <script src="js/zelect.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/revolution.extension.layeranimation.min.js"></script>
        <script src="js/revolution.extension.navigation.min.js"></script>
        <script src="js/revolution.extension.parallax.min.js"></script>
        <script src="js/revolution.extension.slideanims.min.js"></script>
        <script src="js/revolution.extension.video.min.js"></script>
        <script src="js/neary-by-place.js"></script>
        <script src="js/maps.search.js"></script>
        <script src="js/google-map.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/functions.js"></script>
    </body>
</html>
<?php
if (isset($_POST['send_comment_acc'])) {
    $psw1 = trim($_POST['psw1']);
    $psw2 = trim($_POST['psw2']);
    if (strcmp($psw1, $psw2) == 0) {
        require_once '../web_db/multi_values.php';
        require_once '../web_db/new_values.php';
        $obj = new multi_values();
        $new_o = new new_values();
        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        $phone = $_SESSION['phone'];
        $msg = $_SESSION['msg'];
        $date = date('y-m-d');
        $listing = $_SESSION['listing_details'];
        $last_acc = $obj->get_last_acc_id();
        // <editor-fold defaultstate="collapsed" desc="---save profile with email and name save account, comment by acc">
        // 
        // acc
        $new_o->new_profile($name, '', $email, '', $phone, '', '', '', 0);
        //
        //
        //
        //
        //
        $last_profile = $obj->get_last_profile_id();
        $new_o->new_account($email, $psw1, 8, 'no', 'no', $date, $last_profile);
        // 
        // 
        //
        //
        //last acc and s
        $account = $obj->get_last_acc_id();
        $new_o->new_comment('no', $msg, $account, $date, $listing);
        // 
        // 
        ?><script>window.location.replace('index.php');</script><?php
// </editor-fold>
    } else {
        ?><script>alert('Passwords dont match .');</script><?php
    }
}