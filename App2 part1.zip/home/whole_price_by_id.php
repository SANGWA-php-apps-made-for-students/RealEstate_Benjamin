<?php

class Price_by_listing {

    function get_amount($listing) {
        $con = new my_connection();
        $sql = "select price.amount from price	 join listing on price.listing = listing.listing_id where listing.listing_id=:listingid";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array("listingid" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['amount'];
        return $userid;
    }

}
