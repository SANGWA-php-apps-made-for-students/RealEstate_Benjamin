<div class="tp_overlay"  >
    <form action="search_result.php" method="post" >
        <div class="custom_overlay" >
            <div class="container" style="margin-top: 80px; width: 400px;">
                <div class="clearfix" style="marg">
                    <div id="filters-property" class="cbp-l-filters-button text-center">
                        <div data-filter=".sale" class="cbp-filter-item" style="color: #fff;">SALE</div>
                        <div data-filter=".rent" class="cbp-filter-item" style="color: #fff;">RENT</div>
                    </div>
                </div>
            </div>
            <div class="full_textbox">
                <input class="txt_full" id="myInput" onkeyup="myFunction()" autocomplete="off" required type="text" placeholder="example: office, apartment, commercial" name="keyword">
                <div class="parts">
                    <?php require_once './home_priop_search.php'; ?>
                </div>
            </div>
            <div class="my_textbox three_percent" id="first_txt">
                <input type="text"  required name="Location" placeholder="Location"/>
            </div>
            <div class="my_textbox my_button_2 three_percent">
                <input type="text" required name="max_price" placeholder="Max price"/>
            </div>
            <div class="my_textbox my_button_3 three_percent">
                <select class="my_droplist" required   name="currency" placeholder="Currency " style="padding: 10px; border-radius: 5px; min-width: 130px;  float: right;">
                    <option></option>
                    <option>USD</option>
                    <option>Frw</option>
                    <option>Euro</option>
                </select>
            </div>
            <div class="my_button center_button search_btn">
                <input type="submit" name="send_search" class="border_radius btn-yellow text-uppercase"  value="Search" />
            </div>
            <!--        <div class="my_button ">
                        <input type="submit" name="send_seatrch" class="border_radius btn-yellow text-uppercase"  value="View more" />
                    </div>-->

        </div>
    </form>
</div>  
<script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
<script>
                    $(document).ready(function () {
                        $('#myTable span').mouseover(function () {
                            $('span').removeClass('hover_cursor');
                            $(this).addClass('hover_cursor');
                        });
                        $('#myTable span').click(function () {
                            $('#myInput').val($(this).html());
                            $('#myTable, #loc_pane').hide();
                        });
                        $('#myInput').keyup(function () {
                            var item = $(this).val();
                            $('span').removeClass('hover_cursor');
                            if (item !== '') {
                                $('#myTable, #loc_pane').show();
                            } else if (item == '') {
                                $('#myTable, #loc_pane').hide();
                            }

                        });
                    });
</script>
<style>
    #myInput{
        color: #000;
    }
    .hover_cursor{
        cursor: pointer;
        background-color: #0052ff;
        color: #fff;
    }
    #loc_pane{
        padding: 10px;
        box-sizing: border-box;
    }
    .off{
        display: none;
    }
    span{
        width: 100%;
    }
</style>