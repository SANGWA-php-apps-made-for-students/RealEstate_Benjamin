<script>
    window.location.replace('home/index.php');
</script>