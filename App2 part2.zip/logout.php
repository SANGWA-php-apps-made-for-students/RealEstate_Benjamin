<?php

session_start();
unset($_SESSION['login_token']);

unset($_SESSION['listing_date']);
unset($_SESSION['account']);
unset($_SESSION['listing_type']);
unset($_SESSION['title']);
unset($_SESSION['description']);
unset($_SESSION['purpose']);
unset($_SESSION['property_category']);
unset($_SESSION['property_type']);

session_destroy();
header('location:index.php');

