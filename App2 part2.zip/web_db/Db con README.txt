THE CONNECTION STRING IS LOCATED IN THE FOLLOWING FILES:

1. app/web_db/connection.php
2. app/admin/dbConnection.php
3. app/web_db/request_con.php   => bottom part
4. app/home/menu.php      => bottom part
5. app/home/login.php     => bottom part


WIZARD FILES
--------------
=>new_wizard.php

 =>html_fields.php (new data-update data)

   new_listing.php (new data-update data)
   new_price.php (new data-update data)
   new_property_location.php
   new_image.php(new data-update data)

report
---------
new_report.php


