<?php
require_once '../Admin/dbConnection.php';
$con = new my_connection();

class multi_values {

    function list_account() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select * from account";
        ?>
        <table class="dataList_table" id="sp_table">
            <thead>
                <tr>
                    <td> ID </td>
                    <td> username </td>
                    <td> password </td>
                    <td> account_category </td>
                    <td> online </td>
                    <td> deleted </td>
                    <td> date_created </td>
                </tr>
            </thead>
            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <?php echo $row['password']; ?>
                    </td>
                    <td>
                        <?php echo $row['account_category']; ?>
                    </td>
                    <td>
                        <?php echo $row['is_online']; ?>
                    </td>
                    <td>
                        <?php echo $row['deleted']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_created']; ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php
    }

    function list_account_category() {

        $con = new my_connection();
        $sql = "select * from account_category";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>

                    <td> name </td>
                </tr>
            </thead>
            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_profile() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select * from profile";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td>profile ID</td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> email </td>
                    <td> home_phone </td>
                    <td> office_phone </td>
                    <td> mobile_phone </td>
                    <td> address </td>
                    <td> city </td>
                    <td> country </td>
                    <td> image </td>


                </tr></thead>
            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['email']; ?>
                    </td>
                    <td>
                        <?php echo $row['home_phone']; ?>
                    </td>
                    <td>
                        <?php echo $row['office_phone']; ?>
                    </td>
                    <td>
                        <?php echo $row['mobile_phone']; ?>
                    </td>
                    <td>
                        <?php echo $row['address']; ?>
                    </td>
                    <td>
                        <?php echo $row['city']; ?>
                    </td>
                    <td>
                        <?php echo $row['country']; ?>
                    </td>
                    <td>
                        <?php echo $row['image']; ?>
                    </td>
                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_property() {
        $con = new my_connection();
        $db = $con->getCon();
        $sql = "select * from property";
        ?>
        <?php
        foreach ($con->getCon()->query($sql) as $row) {
            echo '<div class="parts two_fifty_left " >' . $row['name'] . '</div>';
        }
    }

    function list_property_category() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select * from property_category";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> name </td>

                </tr></thead>
            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>

                    <td>
                        <?php echo $row['property_category_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_property_category_vs_property() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select  property_category.property_category_id, property_category.name, property_type.name as type  from property_type join property_category on property_category.property_type=property_type.property_type_id";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> Category </td>
                    <td> Type </td>
                </tr></thead>
            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['property_category_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['type']; ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_property_subcategory() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select * from property_subcategory";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> property_subcategory </td>

                </tr></thead>

            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>

                    <td>
                        <?php echo $row['property_subcategory_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['property_subcategory']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_features() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    features.features_id,  features.name as feat,features_cat.cat_name as feat_cat,  property_type.name
                from property_type
                join features on property_type.property_type_id = features.property_type
                join features_cat on features_cat.features_cat_id=features.category
                order by features.features_id asc";
        ?>
        <table class="dataList_table">
            <thead><tr><td> features_id </td><td> Feature </td>
                    <td> name </td> <td> Category </td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?>
                <tr>
                    <td>        <?php echo $row['features_id']; ?> </td>
                    <td>        <?php echo $row['feat']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['feat_cat']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_listing() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select listing.listing_id,   profile.name as prof_name,  profile.last_name,
                property_category.name as cat,  listing.listing_date,
                listing.listing_type,  property.name as house,  listing.title,
                listing.purpose, location.area
                from listing
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                join property on listing.property = property.property_id
                join property_category on listing.property_category = property_category.property_category_id
                join location on listing.location = location.location_id  join profile on account.profile = profile.profile_id
                 join property on location.property = property.property_id ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> listing_id </td>
                    <td> In charge(name) </td>
                    <td> In charge(last name) </td>
                    <td> Category name </td>
                    <td> listing_date </td>

                    <td> listing_type </td><td> property </td><td> title </td><td> purpose </td><td> location </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>
                    <td>        <?php echo $row['listing_id']; ?> </td>
                    <td>        <?php echo $row['prof_name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['cat']; ?> </td>
                    <td>        <?php echo $row['listing_date']; ?> </td>
                    <td>        <?php echo $row['listing_type']; ?> </td>
                    <td>        <?php echo $row['house']; ?> </td>
                    <td>        <?php echo $row['title']; ?> </td>
                    <td>        <?php echo $row['purpose']; ?> </td>
                    <td>        <?php echo $row['area']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_listing_type() {//these listing types are listed as checkboxes
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select listing_type.listing_type_id, listing_type.name from listing_type";
        ?>
        <select class="textbox list_type_combo"><option></option>
            <?php
            foreach ($con->getCon()->query($sql) as $row) {
                echo "<option value=" . $row['listing_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    //get the last listing fields
    function get_last_listing_account() {
        $db = new my_connection();
        $sql = "select  listing.account
        from listing order by listing.listing_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account'];
        return $userid;
    }

    function get_last_listing_listing_type() {

        $db = new my_connection();
        $sql = "select    listing.listing_type
        from listing order by listing.listing_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing_type'];
        return $userid;
    }

    function get_last_listing_property() {

        $db = new my_connection();
        $sql = "select   listing.property
        from listing order by listing.listing_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property'];
        return $userid;
    }

    function get_last_listing_title() {

        $db = new my_connection();
        $sql = "select   listing.title
        from listing order by listing.listing_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['title'];
        return $userid;
    }

    function get_last_listing_purpose() {

        $db = new my_connection();
        $sql = "select       listing.purpose
        from listing order by listing.listing_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['purpose'];
        return $userid;
    }

    function get_last_listing_property_category() {

        $db = new my_connection();
        $sql = "select    listing.property_category
        from listing order by listing.listing_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property_category'];
        return $userid;
    }

    function get_last_listing_address() {

        $db = new my_connection();
        $sql = "select location.address  from location order by location.location_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['address'];
        return $userid;
    }

    //End of last listing fields

    function list_image() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select image.deleted,image.appear,   image.listing,  listing.listing_date,  listing.title,  listing.purpose,  listing.account,  listing.listing_type,  image.path
            from listing
                    join image on image.listing=listing.listing_id";
        ?>

        <?php
        foreach ($con->getCon()->query($sql) as $row) {

            echo'<div class="parts two_fifty_left heit_free no_paddin_shade_no_Border   ">
             <div class="parts margin_free full_center_two_h heit_free ">' . '';
            echo "<img class=\"parts no_paddin_shade_no_Border\" src=../web_images/property/" . $row['path'] . " width=\"220\"; height=\"200\"/>";
            echo '<div class="parts no_paddin_shade_no_Border margin_free full_center_two_h heit_free ">' . $row['listing_date'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border margin_free full_center_two_h heit_free ">' . $row['title'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border margin_free full_center_two_h heit_free ">' . $row['appear'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border margin_free full_center_two_h heit_free ">  <div class="parts abs_child"><a href="#">delete</a></div>   &nbsp;
                        <a href="#">Rename</a> <a href="#">View Big image</a></div>';
            echo '
                </div>
        </div>';
        }
    }

    function list_location() {
        $con = new my_connection();
        $sql = "select * from location";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> name </td>
                    <td> appear </td>
                    <td> property </td>

                </tr></thead>

            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['location_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['appear']; ?>
                    </td>
                    <td>
                        <?php echo $row['property']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_price() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location
                    from listing
                     join price on price.listing = listing.listing_id
                       join location on listing.location = location.location_id
                        join account on listing.account = account.account_id
                        join listing_type on listing.listing_type = listing_type.listing_type_id
                        join property on listing.property = property.property_id
                        join property_category on listing.property_category = property_category.property_category_id
                   ";
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts two_fifty_left heit_free">';
            echo '<div class="parts"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts">Price id:   ' . $row['price_id'] . '    </div>';
            echo '<div class="parts"> Amount:  ' . $row['amount'] . '     </div>';
            echo '<div class="parts"> Currency:  ' . $row['currency'] . '     </div>';
            echo '<div class="parts"> property:  ' . $row['property'] . '     </div>';
            echo '<div class="parts"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts"> Utilities:  ' . $row['utilities_extra'] . '</div>';

            echo '<div class="parts"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts"> Title:  ' . $row['title'] . ' </div>';
            echo '<div class="parts"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts"> Property category  ' . $row['property_category'] . '</div>';
            echo '<div class="parts"> Location:  ' . $row['location'] . '  </div>';
            echo '</div>';
        }
    }

    function list_property_visitor() {
        require_once 'dbConnection.php';
        $con = new my_connection();
        $sql = "select * from property_visitor";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> property </td>

                </tr></thead>
            <?php foreach ($con->getCon()->query($sql) as $row) { ?><tr>

                    <td>
                        <?php echo $row['property']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_basic_info() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select  basic_info.basic_info_id,  basic_info.name as basics,  property_type.name
                from basic_info
                join property_type on basic_info.property_type = property_type.property_type_id
                 ";
        ?>
        <table class="dataList_table"style="margin-top: 0px;">
            <thead><tr><td> basic_info_id </td><td> name </td><td> name </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>
                    <td>        <?php echo $row['basic_info_id']; ?> </td>
                    <td>        <?php echo $row['basics']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_property_type() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from property_type";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> name </td>
                    <td> property </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['property']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_province() {
        $con = new my_connection();
        $sql = "select * from province";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($con->getCon($sql)as $row) { ?><tr>

                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_district() {
        $db = new my_connection();
        $sql = "select * from district";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> name </td>
                    <td> province </td>

                </tr></thead>
            <?php foreach ($db->getCon($sql) as $row) { ?><tr>

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['province']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_property_request() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from property_request  where received='no' ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> property request id</td>
                    <td> names </td>
                    <td> telephone </td>
                    <td> listing </td>
                    <td> Option</td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['property_request_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['names']; ?>
                    </td>
                    <td>
                        <?php echo $row['telephone']; ?>
                    </td>
                    <td>
                        <?php echo $row['listing']; ?>
                    </td>


                    <td>
                        <a class="request_link" href="#" value="<?php echo $row['listing']; ?>">
                            View
                        </a>

                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_features_cat() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from features_cat where features_cat.features_catdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead>
                <tr>
                    <td> features_cat </td>
                    <td> cat_name </td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr>
                    <td>
                        <?php echo $row['features_cat_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['cat_name']; ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_currency_conversion() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from currency_conversion where currency_conversion.currency_conversiondeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>

                    <td> from </td>
                    <td> to </td>
                    <td> rate </td>
                    <td> Delete </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>

                    <td>
                        <?php echo $row['currency_conversion_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['from']; ?>
                    </td>
                    <td>
                        <?php echo $row['to']; ?>
                    </td>
                    <td>
                        <?php echo $row['rate']; ?>
                    </td>
                    <td>
                        <a href="#" class="delete_link_currency_conversion" style="color: #000080;" value="
                           <?php echo $row['currency_conversion_id']; ?>">Delete</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function All_accounts() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_account_cat() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    account_category.name from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_admin() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    account_category.name from account_category where account_category.name='admin'";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_managers() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    account_category.name from account_category where account_category.name='Manager'";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_agents() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    account_category.name from account_category where account_category.name='Manager'";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_prop_types() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_type.name from property_type";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function All_prop_cat() {
        $c = 0;
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_category.name from property_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    /* uni and more */

    function get_lastbasic_apartment() {
        $db = new my_connection();
        $sql = "select   basic_apartment.basic_apartment_id from basic_apartment order by basic_apartment.basic_apartment_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_apartment_id'];
        return $userid;
    }

    function get_lastbasic_commercial() {
        $db = new my_connection();
        $sql = "select   basic_commercial.basic_commercial_id from basic_commercial order by basic_commercial.basic_commercial_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_commercial_id'];
        return $userid;
    }

    function get_lastbasic_house() {

        $db = new my_connection();
        $sql = "select   basic_house.basic_house_id from basic_house order by basic_house.basic_house_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_house_id'];
        return $userid;
    }

    function get_lastbasic_land() {

        $db = new my_connection();
        $sql = "select   basic_land.basic_land_id from basic_land order by basic_land.basic_land_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_land_id'];
        return $userid;
    }

    function get_user_category($username, $password) {
        require_once 'Admin/dbConnection.php';
        $con = new my_connection();
        $cat = '';
        $sql = "select     account_category.name from  account join account_category on account_category.account_category_id=account.account_category where  account.username=:username and  account.password =:password";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cat = $row['name'];
        return $cat;
    }

    function get_name_logged_in($username, $password) {
        require_once 'Admin/dbConnection.php';
        $con = new my_connection();
        $cat = '';
        $sql = "select   profile.name from profile join account on account.profile=profile.profile_id where   account.username=:username and   account.password=:password";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cat = $row['name'];
        return $cat;
    }

    function get_userid_by_Acc_cat($name) {
        $userid = 0;
        require_once '../Admin/dbConnection.php';
        $con = new my_connection();
        $sql = "select     account_category_id from  account_category    where   name = :name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        return $userid;
    }

    function get_features_combo() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    features.name from features";
        ?>
        <select class="textbox">
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['features.features_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_user_category_combo() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox combo_user_cat"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_prop_type_combo() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_type.property_type_id , property_type.name from property_type ";
        ?>
        <select  name="cbo_property_name" class="textbox gen_cat combo_property_type x_width_two_h pt"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_type_id'] . ">" . trim($row['name']) . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_prop_type_combo_to_update() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_type.property_type_id , property_type.name from property_type ";
        ?>
        <select  name="cbo_property_name" class="textbox  combo_property_type_toUpdate x_width_two_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_combo() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property.property_id,  property.name from property";
        ?>
        <select class="textbox combo_property"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_property_cat_combo() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    property_category.name from property_category";
        ?>
        <select class="textbox combo_property_cat"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['property_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_provinces_combo() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select   province.province_id,province.name from province";
        ?>
        <select class="parts  combo_province x_width_one_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_provinces_combo2() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select   province.province_id,province.name from province";
        ?>
        <select class="parts  combo_province2 x_width_one_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_districts_combo() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select  district.district_id ,  district.name from district";
        ?>
        <select class="parts  combo_district x_width_one_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_sectors_combo() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    sector.sector_id,  sector.name from sector";
        ?>
        <select class="parts combo_sectors x_width_one_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_cells_combo() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select  cell.cell_id   ,  cell.name from cell";
        ?>
        <select class="parts combo_property_cat x_width_one_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_id_logged_in($username, $password) {
        $userid = 0;
        require_once 'Admin/dbConnection.php';
        $con = new my_connection();
        $sql = "select    account.account_id from account where  account.username=:username and  account.password =:password";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_id_property($name) {
        $userid = 0;
        require_once '../Admin/dbConnection.php';
        $con = new my_connection();
        $sql = "select     property.property_id from property where property.name=:property_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':property_id', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property_id'];
        return $userid;
    }

    function get_id_property_type($name) {
        $userid = 0;
        require_once '../Admin/dbConnection.php';
        $con = new my_connection();
        $sql = " select    property_type.property_type_id  from property_type where property_type.name =:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property_type_id'];
        return $userid;
    }

    function get_last_profile_id() {
        $userid = 0;
        require_once '../Admin/dbConnection.php';
        $con = new my_connection();
        $sql = "select    profile.profile_id from profile order by profile_id desc";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_last_image_id() {
        $userid = 0;

        $con = new my_connection();
        $sql = "select      image.image_id as id from image order by image_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['id'];
        return $userid;
    }

    function get_last_acc_id() {
        $con = new my_connection();
        $sql = "select    account.account_id  from account order by account_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_propertyCat_by_proerty_types($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select property_category.property_category_id,   property_category.name from property_category join property_type on property_type.property_type_id=property_category.property_type where property_type.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts   res_item pro_cat_data_item"><span class="off">' . $row['property_category_id'] . '</span>' . $row['name'] . '</div>';
        }
    }

    function get_propertyCat_by_proerty_type_id($id) {
        $res = '';
        $con = new my_connection();
        $sql = "select property_category.property_category_id,   property_category.name from property_category join property_type on property_type.property_type_id=property_category.property_type where property_type.property_type_id=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $id));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts   res_item pro_cat_data_item"><span class="off">' . $row['property_category_id'] . '</span>' . $row['name'] . '</div>';
        }
    }

    function get_propertyCat_id_by_prop_cat_Name($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select      property_category.property_category_id from  property_category where  property_category.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="res_item">' . $row['property_category_id'] . '</div>';
        }
    }

    function get_property_cat_name_by_property_cat_id($id) {
        $con = new my_connection();
        $sql = "select  property_category_id,  name  from property_category   where  property_category.property_category_id = :prop_cat ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":prop_cat" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
//        return '<div class="partsres_item pro_cat_data_item"><span class="off">' . $row['property_category_id'] . '</span>' . $row['name'] . '</div>';
        return $userid;
    }

    function prop_cat_in_combo() {
        //this is the one that displays the data on load in the ccmbo box. On Listing page.

        $last_pro_type = $this->get_last_listing_prop_type_by_listing_id();
//        $prop_type_by_propCat=$this->get_prop

        $con = new my_connection();
        $sql = "select property_category.property_category_id,  property_category.name from property_category "
                . "  join property_type on property_category.property_type = property_type.property_type_id  "
                . " where property_type.property_type_id=:prop";
        $stmt = $con->getCon()->prepare($sql);
        ?>
        <select class = "textbox last_prop_cat_combo" id = "combo_tofill">
            <option> -- Select the option -- </option>
            <?php
            $stmt->execute(array(":prop" => $last_pro_type));
            while ($row = $stmt->fetch()) {
                echo "<option value=" . $row['property_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select><?php
    }

    function get_features_checkbox($name) {
        ?><script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script><?php
        $res = '';
        $con = new my_connection();
        $sql = "select distinct  features_cat.cat_name as cat from features_cat"
                . " join features on features.category = features_cat.features_cat_id"
                . "  join property_type on property_type.property_type_id = features.property_type "
                . " where property_type.property_type_id=:name "
                . " order by features_cat.cat_name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        ?><?php
        $c = 0;
        ?>
        <?php
        while ($row = $stmt->fetch()) {
            $cat = $row['cat'];
            $sql2 = "   select distinct features.features_id, features.name  from features "
                    . " join features_cat on features_cat.features_cat_id=features.category "
                    . " where features_cat.cat_name=:cat_name "
                    . " group by features.name"
                    . "";
            $stmt2 = $con->getCon()->prepare($sql2);
            $stmt2->execute(array(":cat_name" => $cat));
            echo '<div class="parts margin_free feat_arrangement smart_parts">';
            echo '<div class="parts full_center_two_h no_paddin_shade_no_Border heit_free">';
            echo '<div class=" small_margin skined_font">' . $cat . '</div>';
            echo '</div>';
            while ($row2 = $stmt2->fetch()) {
                echo '<span  class="small_margin no_paddin_shade_no_Border  heit_free" style="margin: 10px">  <input class="fear_checkbxes" id="' . $row2['name'] . '" style="margin: 2px;" value="' . $row2['features_id'] . '" type="checkbox"  name="features[]"  />' . $row2['name'] . '</span>';
            }
            echo '</div>';
            $c+=1;
        }
        ?></div><?php
    }

    function get_utilities_checkbox() {
        $res = '';
        $con = new my_connection();
        $sql = "select utilities.utilities_id, utilities.name  from utilities ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $c = 0;
        ?><div class="parts no_paddin_shade_no_Border" id="utilities_box"><?php
        while ($row2 = $stmt->fetch()) {
            echo '<span  class="small_margin no_paddin_shade_no_Border  heit_free" style="margin: 10px">  <input type="checkbox" class="util_checkbxes" id="' . $row2['name'] . '" style="margin: 2px;" value="' . $row2['utilities_id'] . '"   name="utilities[]"  />' . $row2['name'] . '</span>';
        }
        ?></div><?php
    }

    function get_feature_by_property_type($id) {
        $res = '';
        $con = new my_connection();
        $sql = " select   feautures.features_id, features.name  from features join property_type on property_type.property_type_id=features.property_type where property_type.property_type_id=:property_type_id";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $id));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts  full_center_two_h margin_free heit_free no_paddin_shade_no_Border res_item">' . $row['features_id'] . '</div>';
        }
    }

    function get_provinceId_by_Name($id) {
        $res = '';
        $con = new my_connection();
        $sql = "select    province.province_id from province where name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $id));
        while ($row = $stmt->fetch()) {
            echo $row['province_id'];
        }
    }

    function get_districts_by_province($province_id) {
        $res = '';
        $con = new my_connection();
        $sql = "select      district.name  from district  join province on province.province_id=district.province where province.name= :province_id";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":province_id" => $province_id));
        while ($row = $stmt->fetch()) {
            ?>  <?php
            echo '<div class="parts full_center_two_h heit_free res_item_districts no_paddin_shade_no_Border margin_free">' . $row['name'] . '</div>';
        }
    }

    function get_sectors_by_district($districtid) {
        $res = ' ';
        $con = new my_connection();
        $sql = "select    sector.name from district join sector on sector.district=district.district_id where district.name=:districtid";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":districtid" => $districtid));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free res_item_sectors no_paddin_shade_no_Border margin_free">' . $row['name'] . '</div>';
        }
    }

    function get_cells_by_sector($name) {
        $res = ' ';
        $con = new my_connection();
        $sql = "select      cell.name from cell join sector on sector.sector_id=cell.sector where  sector.name =:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free res_item_cells no_paddin_shade_no_Border margin_free">' . $row['name'] . '</div>';
        }
    }

    function get_cellsName_by_id($name) {
        $res = ' ';
        $con = new my_connection();
        $sql = "select      cell.cell_id from cell where cell.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free res_item_cells no_paddin_shade_no_Border margin_free"><span id="cell_id_box" class="off">' . $row['cell_id'] . '</span></div>';
        }
    }

    function get_DistrctId_by_name($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select    district.district_id   from district where  district.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo $row['district_id'];
        }
    }

    function get_featureId_by_name($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select    feautures.feature_id   from features where  features.name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo $row['feature_id'];
        }
    }

    function get_SectorId_by_name($name) {
        $res = '';
        $con = new my_connection();
        $sql = "select   sector.sector_id   from sector where name=:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo $row['sector_id'];
        }
    }

    function get_listing() {
        require_once('../web_db/connection.php');
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select listing.listing_id,  listing.listing_date,  listing.account,  listing.listing_type,  listing.property,  listing.title,  listing.purpose,  listing.property_category,  listing.location
                    from listing
                    join account on listing.account = account.account_id
                    join listing_type on listing.listing_type = listing_type.listing_type_id
                    join property on listing.property = property.property_id
                    join property_category on listing.property_category = property_category.property_category_id
                    join location on listing.location = location.location_id
";
        ?>
        <table class="new_data_table">
            <thead><tr><td> listing_id </td><td> listing_date </td><td> account </td><td> listing_type </td><td> property </td><td> title </td><td> purpose </td><td> property_category </td><td> location </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>
                    <td>        <?php echo $row['listing_id']; ?> </td>
                    <td>        <?php echo $row['listing_date']; ?> </td>
                    <td>        <?php echo $row['account']; ?> </td>
                    <td>        <?php echo $row['listing_type']; ?> </td>
                    <td>        <?php echo $row['property']; ?> </td>
                    <td>        <?php echo $row['title']; ?> </td>
                    <td>        <?php echo $row['purpose']; ?> </td>
                    <td>        <?php echo $row['property_category']; ?> </td>
                    <td>        <?php echo $row['location']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_basic_info_name_by_property_type($name) {
        $con = new my_connection();
        $sql = "select basic_info.basic_info_id,   basic_info.name  from basic_info
                 join property_type on basic_info.property_type = property_type.property_type_id
                where   property_type.name = :name  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<input  id="' . $row['name'] . '" style="margin-left: 10px;" value="' . $row['basic_info_id'] . '" type="checkbox"  name="basic_info[]"  />' . $row['name'];
        }
    }

    function get_location_area_name_like($area) {
        $db = new my_connection();
        $stmt = $db->getCon()->prepare("SELECT distinct area FROM location WHERE area LIKE ?");
        $stmt->bindValue(1, "%$area%", PDO::PARAM_STR);
        $stmt->execute();
        while ($row = $stmt->fetch()) {
            echo '<div class="parts hover_theme1 location_data_item" style="padding: 6px;">' . $row['area'] . '</div>';
        }
    }

    function get_lastlisting($user) {
        try {
            $db = new my_connection();
            $con = $db->getCon();
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select   max(listing.listing_id) as listing_id from listing  where listing.account=:account  ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array(":account" => $user));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['listing_id'];
            return $userid;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    function get_feature_cat_combo() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select features_cat.features_cat_id,  features_cat.cat_name from features_cat ";
        ?>
        <select class="parts  combo_feature_cat x_width_one_h"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['features_cat_id'] . ">" . $row['cat_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    //the new location format
    function get_districts_by_prov_new_format($province_id) {
        $res = '';
        $con = new my_connection();
        $sql = "select   district.district_id,   district.name  from district  join province on province.province_id=district.province where province.province_id= :province_id";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":province_id" => $province_id));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts link_cursor loc_district_res"><span class="off">' . $row['district_id'] . '</span>' . $row['name'] . '</div>';
        }
    }

    function get_sectors_by_distr_new_format($districtid) {
        $res = ' ';
        $con = new my_connection();
        $sql = "select   sector.sector_id, sector.name from district join sector on sector.district=district.district_id where district.district_id=:districtid";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":districtid" => $districtid));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts loc_sector_res link_cursor"><span class="off">' . $row['sector_id'] . '</span>' . $row['name'] . '<span></div>';
        }
    }

    function get_provinces_boxes() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select   province.province_id,province.name from province";
        ?>
        <?php
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts link_cursor loc_prov_res "><span style="display:none;">' . $row['province_id'] . '</span>' . $row['name'] . '</div>';
        }
        ?>

        <?php
    }

    function get_districts_boxes() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select district.district_id,  district.name from district";
        ?>
        <?php
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts link_cursor loc_district_res "><span style="display:none;">' . $row['district_id'] . '</span>' . $row['name'] . '</div>';
        }
        ?>

        <?php
    }

    function get_sectors_boxes() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select sector.sector_id,  sector.name from sector";
        ?>
        <?php
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts link_cursor loc_sector_res "><span style="display:none;">' . $row['sector_id'] . '</span>' . $row['name'] . '</div>';
        }
        ?>

        <?php
    }

    function get_cells_boxes() {
        require_once '../Admin/dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select cell.cell_id,  cell.name from cell";
        ?>
        <?php
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts link_cursor loc_cell_res "><span style="display:none;">' . $row['cell_id'] . '</span>' . $row['name'] . '</div>';
        }
        ?>

        <?php
    }

    function get_cells_by_sect_new_format($name) {
        $res = ' ';
        $con = new my_connection();
        $sql = "select   cell.cell_id,   cell.name from cell join sector on sector.sector_id=cell.sector where  sector.sector_id =:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts loc_cell_res link_cursor"><span class="off">' . $row['cell_id'] . '</span>' . $row['name'] . '</div>';
        }
    }

    function features_last_listing($user) {
        $database = new my_connection();
        $db = $database->getCon();
        $last_listing = $this->get_lastlisting($user);
        $sql = "select listing_features.features,  features.name from listing_features
                        join features on listing_features.features = features.features_id where listing_features.listing=:listing";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":listing" => $last_listing));
        $results = array();
        while ($row = $stmt->fetch()) {
            $results[] = trim($row['features']);
        }
        echo json_encode($results);
//        $_SESSION['sess_array'] = $results;
    }

    function utililites_last_price() {
        $database = new my_connection();
        $db = $database->getCon();
        $last_price_id = $this->get_lastprice();
        $sql = "select utilities.utilities_id from utilities
                join price_utilities  on price_utilities.utilities_id = utilities.utilities_id
                join price on price_utilities.price_id = price.price_id
                where price.price_id=:price_id";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":price_id" => $last_price_id));
        $results = array();
        while ($row = $stmt->fetch()) {
            $results[] = trim($row['utilities_id']);
        }
        echo json_encode($results);
    }

    function get_price_utililites_by_listing($listing) {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select utilities.utilities_id from utilities
                join price_utilities  on price_utilities.utilities_id = utilities.utilities_id
                join price on price_utilities.price_id = price.price_id
                where price.listing=:listing";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $results = array();
        while ($row = $stmt->fetch()) {
            $results[] = trim($row['utilities_id']);
        }
        echo json_encode($results);
    }

//End of new location format
//Wen app reports

    function get_rpt_listing_by_id($list_id) {
        $con = new my_connection();
        $sql = "select  distinct  price.price_id, listing.listing_id, price.amount,  price.currency,
price.property,  price.Minimum_advance,  price.deposit_required,
price.commission,  price.utilities_extra,  price.listing,
listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
basic_apartment.bedrooms,  basic_apartment.bathrooms,
basic_land.administrative_location,  basic_land.plot_number, basic_land.plot_size,  basic_land.available_from

from listing
left join price on price.listing = listing.listing_id
left  join image on image.listing = listing.listing_id
left join location on listing.location = location.location_id
left  join cell on location.cell = cell.cell_id
left  join sector on cell.sector = sector.sector_id
left  join district on sector.district = district.district_id
left  join province on district.province = province.province_id
left join basic_apartment on basic_apartment.listing = listing.listing_id
left join basic_land on basic_land.listing = listing.listing_id
join account on listing.account = account.account_id
join listing_type on listing.listing_type = listing_type.listing_type_id
join property on listing.property = property.property_id
left join property_category on listing.property_category = property_category.property_category_id

where listing.listing_id=:list_id  ";

        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":list_id" => $list_id));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder ">';
            echo '<img class="parts no_shade_noBorder" src="../web_images/property/' . $row['path'] . '" height="200" width="280"/>';
            echo '<div class="parts seventy_right  no_paddin_shade_no_Border  ">';
            echo '<div class="parts xx_titles no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';

            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }

            echo'<div class="parts link_cursor rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
            echo'<div class="parts link_cursor rprt_delete_listing_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>Delete</div>';

            echo '</div>';
            echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
            echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';
            echo '</div>';
        }
    }

    function get_detailed_rpt_listing($listingid) {
        ?><div class="parts full_center_two_h" id="rpt_mp"></div><?php
        $con = new my_connection();


        $sql = "select  distinct  price.price_id,listing.listing_id ,listing.description, price.amount,  price.currency,
                    price.property,  price.Minimum_advance,  price.deposit_required,
                    price.commission,  price.utilities_extra,  price.listing,
                    listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                    listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                    image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                    basic_apartment.bedrooms,  basic_apartment.bathrooms,
                    basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from,
                    features.name as feat
                    from listing
                    left  join price on price.listing = listing.listing_id
                    left  join image on image.listing = listing.listing_id
                    left  join location on listing.location = location.location_id
                    left  join cell on location.cell = cell.cell_id
                    left  join sector on cell.sector = sector.sector_id
                    left  join district on sector.district = district.district_id
                    left  join province on district.province = province.province_id
                    left  join basic_apartment on basic_apartment.listing = listing.listing_id
                    left  join basic_land on basic_land.listing = listing.listing_id
                    join  account on listing.account = account.account_id
                    join  listing_type on listing.listing_type = listing_type.listing_type_id
                    join  property on listing.property = property.property_id
                    left  join  property_category on listing.property_category = property_category.property_category_id
                    left   join listing_features on listing_features.features = listing.listing_id
                    left   join features on listing_features.features = features.features_id
                    where listing.listing_id=:listingid  group by listing_id  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listingid" => $listingid));
        ?>
        <?php
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder xx_titles margin_free  ">' . $row['title'] . ' </div> ';
            echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x" >   LISTING ID: LST- ' . $row['listing_id'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border  full_center_two_h heit_free"  > Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
            echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" >   ' . $row['description'] . ' </div>';
            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Administrative location:  ' . $row['administrative_location'] . '     </div>';
            }
            if ($row['feat'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;">Other Features:  ' . $row['feat'] . '     </div>';
            }

            echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
            echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';
            echo '</div>';
        }

        //the last and long
        $sql1 = "select location.lat,  location.longtd from location join listing on listing.location = location.location_id 
                            where listing.listing_id=:listingid";
        $stmt1 = $con->getCon()->prepare($sql1);
        $stmt1->execute(array(":listingid" => $listingid));

        $lat = '';
        $long = '';
        while ($row1 = $stmt1->fetch()) {
            $lat = $row1['lat'];
            $long = $row1['longtd'];
        }


        //images
        $sql2 = "select path from image where listing=:listingid";
        $stmt2 = $con->getCon()->prepare($sql2);
        $stmt2->execute(array(":listingid" => $listingid));
        while ($row2 = $stmt2->fetch()) {
            echo '<img class="parts no_shade_noBorder" src="../web_images/property/' . $row2['path'] . '"/>';
        }
        ?>

        <script>
            function initMap() {
                try {
                    var lt =<?php echo $lat; ?>;
                    var lon = <?php echo $long; ?>;
                    var myLatLng = {lat: lt, lng: lon};
                    var map = new google.maps.Map(document.getElementById('rpt_mp'), {
                        zoom: 17,
                        center: myLatLng
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map,
                        title: 'Disired location'
                    });

                } catch (err) {
                    alert(err.message);
                }
            }
        </script>
        <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
        </script>
        <?php
    }

    function get_rpt_only_map($listingid) {
        $con = new my_connection();
        $sql = "select location.lat,  location.longtd from location join listing on listing.location = location.location_id 
                            where listing.listing_id=:listingid ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listingid" => $listingid));
        ?>
        <?php
        while ($row = $stmt->fetch()) {
            $res = $row['lat'];
        }
        return $res;
    }

    function get_listing_by_year($list_date) {
        $con = new my_connection();
        $sql = "select  distinct  price.price_id,listing.listing_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                from listing
                join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                join cell on location.cell = cell.cell_id
                join sector on cell.sector = sector.sector_id
                join district on sector.district = district.district_id
                join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                join property on listing.property = property.property_id
                join property_category on listing.property_category = property_category.property_category_id
                where year(listing.listing_date)=:list_date group by listing.listing_id";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":list_date" => $list_date));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free  margin_free">';
            echo '<img alt="No image" class="parts no_shade_noBorder" src="../web_images/property/' . $row['path'] . '" height="200" width="280"/>';
            echo '<div class="parts seventy_right  no_paddin_shade_no_Border  ">';
            echo '<div class="parts xx_titles no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }
            //            if ($row['feat'] != '') {
            //                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;">Other Features:  ' . $row['feat'] . '     </div>';
            //            }
            echo'<div class="parts link_cursor rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
            echo '</div></div>';
        }
    }

    function get_listing_by_today() {
        $con = new my_connection();
        $sql = "select  distinct listing.listing_id, price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                ,listing.active from listing
                left  join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                left join property on listing.property = property.property_id
                left join property_category on listing.property_category = property_category.property_category_id
                where listing.listing_date=:list_date  group by listing.listing_id    ";

        $stmt = $con->getCon()->prepare($sql);
        $list_date = date("Y-m-d");
        $stmt->execute(array(":list_date" => $list_date));

        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder by_date_container wiz_body">';
            if ($row['path'] != '') {
                echo '<img   class="parts no_shade_noBorder" src="../web_images/property/' . $row['path'] . '" height="200" width="280" style="border: 1px solid #000;"/>';
            } else {
                echo '<img alt="no image" class="parts no_shade_noBorder" src="../web_images/property/' . $row['path'] . '" height="200" width="280" style="border: 1px solid #000;"/> ';
            }
            echo '<div class="parts sixty_percent  no_shade_noBorder  ">';
            echo '<div class="parts sixty_percent smart_font2 no_shade_noBorder " >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }

            echo'<div id="rprt_more_details_btn"  class="parts link_cursor rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
            echo'<div class="parts link_cursor rprt_delete_listing_btn"  id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>Delete</div>';
            echo'<div class="parts link_cursor rprt_update_listing_btn"  id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>Update</div>';
            echo'<div class="parts link_cursor rprt_enable_listing_btn"  id="rprt_enable_btn" data-enable_lstid="' . $row['listing_id'] . '" > ';
            echo $this->listing_status($row['listing_id']) . ' </div>';
            echo '</div>'
            . '</div>';
        }
    }

    function listing_status($list_id) {
        $db = new my_connection();
        $con = $db->getCon();
        $sql = "select listing.active from listing where listing.listing_id= :listing_id ";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['active'];
        return ($userid == 'yes') ? 'Disable' : 'Enable';
    }

    function get_listing_date_prop_type($list_date, $prop) {
        $con = new my_connection();
        $sql = "select  distinct  price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from
                from listing
                join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                join cell on location.cell = cell.cell_id
                join sector on cell.sector = sector.sector_id
                join district on sector.district = district.district_id
                join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                join property on listing.property = property.property_id
                join property_category on listing.property_category = property_category.property_category_id
               
                where date(listing.listing_date)=:list_date and property_category.name=:prop   group by listing.listing_id   ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":list_date" => $list_date, ":prop" => $prop));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder ">';
            echo '<img class="parts no_shade_noBorder" src="../web_images/property/' . $row['path'] . '" height="200" width="280"/>';
            echo '<div class="parts seventy_right  no_paddin_shade_no_Border  ">';
            echo '<div class="parts xx_titles no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';

            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }
            echo'<div class="parts link_cursor" style="clear: left;" id="rprt_more_details_btn">More details</div>';
            echo '</div>';
            echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
            echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';
            echo '</div>';
        }
    }

    function get_total_listing_by_today() {
        $con = new my_connection();
        $sql = "select  distinct  count(distinct listing.listing_id) as tot
from listing
left join price on price.listing = listing.listing_id
left join location on listing.location = location.location_id
left  join image on image.listing = listing.listing_id
join account on listing.account = account.account_id
join listing_type on listing.listing_type = listing_type.listing_type_id
left join property_category on listing.property_category = property_category.property_category_id
where date(listing.listing_date)=:list_date";
        $stmt = $con->getCon()->prepare($sql);
        $list_date = date("Y-m-d");
        $stmt->execute(array(":list_date" => $list_date));
        $c = 0;
        while ($row = $stmt->fetch()) {
            $c = $row['tot'];
        }
        return $c;
    }

    function get_listing_to_update() {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select    price.price_id,  price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location
                from listing
                join price on price.listing = listing.listing_id
                join location on listing.location = location.location_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                join property on listing.property = property.property_id
                join property_category on listing.property_category = property_category.property_category_id
                group by listing.listing_id order by listing_id desc limit 1";
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts two_fifty_left heit_free">';
            echo '<div class="parts"> Title:  ' . $row['title'] . ' </div>';
            echo '<div class="parts"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts">Price id:   ' . $row['price_id'] . '    </div>';
            echo '<div class="parts"> Amount:  ' . $row['amount'] . '     </div>';
            echo '<div class="parts"> Currency:  ' . $row['currency'] . '     </div>';
            echo '<div class="parts"> property:  ' . $row['property'] . '     </div>';
            echo '<div class="parts"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts"> Utilities:  ' . $row['utilities_extra'] . '</div>';

            echo '<div class="parts"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts"> Property  ' . $row['property'] . '</div>';

            echo '<div class="parts"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts"> Property category  ' . $row['property_category'] . '</div>';
            echo '<div class="parts"> Location:  ' . $row['location'] . '  </div>';
            echo '</div>';
        }
    }

    function get_rpt_listing_by_date($list_date, $date2) {
        $con = new my_connection();
        $sql = "select  distinct  price.price_id, listing.listing_id, price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number, basic_land.plot_size,  basic_land.available_from
                from listing
                left join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left  join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                join property on listing.property = property.property_id
                left join property_category on listing.property_category = property_category.property_category_id
                where listing.listing_date>=:list_date and listing.listing_date<=:list_date2  group by listing.listing_id    ";

        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":list_date" => $list_date, ":list_date2" => $date2));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder by_date_container">';
            echo '<img class="parts no_shade_noBorder my_image" src="../web_images/property/' . $row['path'] . '" height="200" width="280"/>';
            echo '<div class="parts sixty_percent  no_paddin_shade_no_Border  ">';
            echo '<div class="parts sixty_percent smart_font2 no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';

            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }

            echo'<div class="parts link_cursor rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
            echo'<div class="parts link_cursor rprt_delete_listing_btn" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>Delete</div>';
            echo'<div class="parts link_cursor rprt_update_listing_btn" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>Update</div>';

            echo '</div>';
            echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
            echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';
            echo '</div>';
        }
    }

    function get_all_listing() {
        $con = new my_connection();
        $sql = "select  distinct  price.price_id, listing.listing_id, price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number, basic_land.plot_size,  basic_land.available_from
                from listing
                left join price on price.listing = listing.listing_id
                left  join image on image.listing = listing.listing_id
                left join location on listing.location = location.location_id
                left  join cell on location.cell = cell.cell_id
                left  join sector on cell.sector = sector.sector_id
                left  join district on sector.district = district.district_id
                left  join province on district.province = province.province_id
                left join basic_apartment on basic_apartment.listing = listing.listing_id
                left join basic_land on basic_land.listing = listing.listing_id
                join account on listing.account = account.account_id
                join listing_type on listing.listing_type = listing_type.listing_type_id
                join property on listing.property = property.property_id
                join property_category on listing.property_category = property_category.property_category_id

                group by listing.listing_id    ";

        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free no_shade_noBorder by_date_container">';
            echo '<img class="parts no_shade_noBorder my_image" src="../web_images/property/' . $row['path'] . '" height="200" width="280"/>';
            echo '<div class="parts sixty_percent  no_paddin_shade_no_Border  ">';
            echo '<div class="parts sixty_percent smart_font2 no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
            echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';

            if ($row['bedrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
            }if ($row['bathrooms'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
            }
            if ($row['plot_size'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
            }
            if ($row['available_from'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
            }
            if ($row['administrative_location'] != '') {
                echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Administrative_location:  ' . $row['administrative_location'] . '     </div>';
            }

            echo'<div class="parts link_cursor rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
            echo'<div class="parts link_cursor rprt_delete_listing_btn" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>Delete</div>';

            echo '</div>';
            echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
            echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
            echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
            echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
            echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
            echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
            echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
            echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
            echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
            echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';
            echo '</div>';
        }
    }

    //last fields from listing

    function get_last_listing_date() {
        $con = new my_connection();
        $sql = "select listing.listing_date from listing order by listing_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing_date'];
        return $userid;
    }

    function get_last_listing_type() {
        $con = new my_connection();
        $sql = "select listing.listing_type from listing  order by listing_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing_type'];
        return $userid;
    }

    function get_last_listing_prop_category() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = " select property_category.property_category_id, property_category.name from property_category  join listing on listing.property_category = property_category.property_category_id  where listing.listing_id=:last_cat";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":last_cat" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return '<div class="parts res_item pro_cat_data_item"><span class="off">' . $row['property_category_id'] . '</span>' . $row['name'] . '</div>';
    }

    function get_last_listing_prop_cat_noDiv() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = " select property_category.property_category_id, property_category.name from property_category  join listing on listing.property_category = property_category.property_category_id  where listing.listing_id=:last_cat";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":last_cat" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['property_category_id'];
    }

    function get_last_listing_location() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select   cell.name from location join listing on listing.location = location.location_id join cell on location.cell = cell.cell_id  where listing.listing_id=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_last_listing_desc() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select   listing.description from listing order by listing.listing_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['description'];
        return strip_tags($userid);
    }

    function get_lastprice() {

        $db = new my_connection();
        $sql = "select   price.price_id from price order by price.price_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['price_id'];
        return $userid;
    }

    function get_last_listing_prop_type_by_listing_id() {//this method the last listing id is inside of it
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select    property_type.property_type_id  from property_type
                join property_category on property_category.property_type = property_type.property_type_id
                join listing on listing.property_category = property_category.property_category_id
                where  listing.listing_id = :listing_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property_type_id'];
        return $userid;
    }

    function get_last_listing_prop_type_by_list_id($list_id) {//this method the last listing id is not inside of it
        $db = new my_connection();
        $con = $db->getCon();
        $sql = "select    property_type.property_type_id  from property_type
                join property_category on property_category.property_type = property_type.property_type_id
                join listing on listing.property_category = property_category.property_category_id
                where  listing.listing_id = :listing_id ";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property_type_id'];
        return $userid;
    }

    function get_last_list_feat() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select listing_features_id  from listing_features    where   listing_features.listing = :listing_id  
                    order by listing_features_id  desc limit 1  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing_features_id'];
        return $userid;
    }

//basic last fields
    function get_last_listing_basic_aparts() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select    property_type.name  from property_type
                join property_category on property_category.property_type = property_type.property_type_id
                join listing on listing.property_category = property_category.property_category_id
                where  listing.listing_id = :listing_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_last_listing_basic_house() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select    property_type.name  from property_type
join property_category on property_category.property_type = property_type.property_type_id
join listing on listing.property_category = property_category.property_category_id
where  listing.listing_id = :listing_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_last_listing_basic_land() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select    property_type.name  from property_type
join property_category on property_category.property_type = property_type.property_type_id
join listing on listing.property_category = property_category.property_category_id
where  listing.listing_id = :listing_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_last_listing_basic_dev() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select    property_type.name  from property_type
join property_category on property_category.property_type = property_type.property_type_id
join listing on listing.property_category = property_category.property_category_id
where  listing.listing_id = :listing_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_last_listing_id_basic_aparts() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $con = new my_connection();
        $sql = "select    listing from basic_apartment   where  listing = :listing_id order by basic_apartment_id desc limit 1";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing'];
        if ($list_id == $userid) {
            return 1;
        } else {
            return 0;
        }
    }

    function get_last_listing_id_basic_house() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];


        $sql = "select   listing from basic_house where  listing = :listing_id order by basic_house_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing'];
        if ($list_id == $userid) {
            return 1;
        } else {
            return 0;
        }
    }

    function get_last_listing_id_basic_land() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];


        $sql = "select    listing from basic_land     where  listing = :listing_id order by basic_land_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing'];
        if (trim($list_id) == trim($userid)) {
            return 1;
        } else {
            return 0;
        }
    }

    function get_last_listing_id_basic_dev() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];

        $sql = "select    property_type.name  from property_type
join property_category on property_category.property_type = property_type.property_type_id
join listing on listing.property_category = property_category.property_category_id
where  listing.listing_id = :listing_id ";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_last_listing_basic_commercial() {
        $db = new my_connection();
        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $list_id = $row2['listing_id'];
        $sql = "select   basic_commercial.basic_commercial_id from basic_commercial where listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_commercial_id'];
        return $userid;
    }

    function list_comment($min) {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from comment where comment.commentdeleted='no'  ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> comment </td>
                    <td> commentdeleted </td><td> message </td><td> account </td><td> date </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['comment_id']; ?>
                    </td>
                    <td class="commentdeleted_id_cols comment " title="comment" >
                        <?php echo $this->_e($row['commentdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>


                    <td>
                        <a href="#" class="comment_delete_link" style="color: #000080;" value="
                           <?php echo $row['comment_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="comment_update_link" style="color: #000080;" value="
                           <?php echo $row['comment_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function get_chosen_comment_commentdeleted($id) {

            $db = new my_connection();
            $sql = "select   comment.commentdeleted from comment where comment_id=:comment_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['commentdeleted'];
            echo $field;
        }

        function get_chosen_comment_message($id) {

            $db = new my_connection();
            $sql = "select   comment.message from comment where comment_id=:comment_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['message'];
            echo $field;
        }

        function get_chosen_comment_account($id) {

            $db = new my_connection();
            $sql = "select   comment.account from comment where comment_id=:comment_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_comment_date($id) {

            $db = new my_connection();
            $sql = "select   comment.date from comment where comment_id=:comment_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function All_comment() {
            $c = 0;
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select  comment_id   from comment";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_comment() {
            $con = new my_connection();
            $sql = "select comment.comment_id from comment
                    order by comment.comment_id asc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['comment_id'];
            return $first_rec;
        }

        function get_last_comment() {
            $con = new my_connection();
            $sql = "select comment.comment_id from comment
                    order by comment.comment_id desc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['comment_id'];
            return $first_rec;
        }

        function list_comment_replies($min) {
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select * from comment_replies where comment_replies.comment_repliesdeleted='no'  ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> comment_replies </td>
                    <td> comment_repliesdeleted </td><td> message </td><td> date </td><td> account </td><td> comment </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['comment_replies_id']; ?>
                    </td>
                    <td class="comment_repliesdeleted_id_cols comment_replies " title="comment_replies" >
                        <?php echo $this->_e($row['comment_repliesdeleted']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['message']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['comment']); ?>
                    </td>


                    <td>
                        <a href="#" class="comment_replies_delete_link" style="color: #000080;" value="
                           <?php echo $row['comment_replies_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="comment_replies_update_link" style="color: #000080;" value="
                           <?php echo $row['comment_replies_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_comment_replies_comment_repliesdeleted($id) {

            $db = new my_connection();
            $sql = "select   comment_replies.comment_repliesdeleted from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['comment_repliesdeleted'];
            echo $field;
        }

        function get_chosen_comment_replies_message($id) {

            $db = new my_connection();
            $sql = "select   comment_replies.message from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['message'];
            echo $field;
        }

        function get_chosen_comment_replies_date($id) {

            $db = new my_connection();
            $sql = "select   comment_replies.date from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_comment_replies_account($id) {

            $db = new my_connection();
            $sql = "select   comment_replies.account from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_comment_replies_comment($id) {

            $db = new my_connection();
            $sql = "select   comment_replies.comment from comment_replies where comment_replies_id=:comment_replies_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':comment_replies_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['comment'];
            echo $field;
        }

        function All_comment_replies() {
            $c = 0;
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select  comment_replies_id   from comment_replies";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_comment_replies() {
            $con = new my_connection();
            $sql = "select comment_replies.comment_replies_id from comment_replies
                    order by comment_replies.comment_replies_id asc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['comment_replies_id'];
            return $first_rec;
        }

        function get_last_comment_replies() {
            $con = new my_connection();
            $sql = "select comment_replies.comment_replies_id from comment_replies
                    order by comment_replies.comment_replies_id desc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['comment_replies_id'];
            return $first_rec;
        }

//     <editor-fold defaultstate="collapsed" desc="------------------all the listing basics ------------------------ ">
        // <editor-fold defaultstate="collapsed" desc="----------Apartment------------------------">

        function get_last_bedroom_apartment() {
            $db = new my_connection();
            $sql = "select   basic_apartment.bedrooms  from basic_apartment order by basic_apartment.basic_apartment_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['bedrooms'];
            return $userid;
        }

        function get_last_bathrooms_apartment() {
            $db = new my_connection();
            $sql = "select   basic_apartment.bathrooms from basic_apartment order by basic_apartment.basic_apartment_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['bathrooms'];
            return $userid;
        }

        function get_last_floor_number_apartment() {
            $db = new my_connection();
            $sql = "select   basic_apartment.floor_number  from basic_apartment order by basic_apartment.basic_apartment_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['floor_number'];
            return $userid;
        }

        function get_last_total_floor_nbr_apartment() {

            $db = new my_connection();
            $sql = "select   basic_apartment.total_number_floors  from basic_apartment order by basic_apartment.basic_apartment_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['total_number_floors'];
            return $userid;
        }

        function get_last_furnished_apartment() {

            $db = new my_connection();
            $sql = "select   basic_apartment.furnished  from basic_apartment  order by basic_apartment.basic_apartment_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['furnished'];
            return $userid;
        }

        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="-----------House----------------------">
        function get_last_furnished_house() {

            $db = new my_connection();
            $sql = "select   basic_house.furnished from basic_house  order by basic_house.basic_house_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['furnished'];
            return $userid;
        }

        function get_last_available_house() {
            $db = new my_connection();
            $sql = "select   basic_house.available_from  from basic_house  order by basic_house.basic_house_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['available_from'];
            return $userid;
        }

        function get_last_bedroom_house() {
            $con = new my_connection();
            $sql = "select    bedroom  from basic_house  order by basic_house_id desc limit 1  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['bedroom'];
            return $userid;
        }

        function get_last_bathroom_house() {
            $con = new my_connection();
            $sql = "select    bathroom  from basic_house order by basic_house_id desc limit 1   ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['bathroom'];
            return $userid;
        }

        function get_last_compound_size_house() {
            $con = new my_connection();
            $sql = "select    compound_size  from basic_house order by basic_house_id desc limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['compound_size'];
            return $userid;
        }

        function get_last_living_floors_house() {
            $con = new my_connection();
            $sql = "select    living_floors  from basic_house order by basic_house_id desc limit 1 ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['living_floors'];
            return $userid;
        }

        function get_last_total_number_floors_house() {
            $con = new my_connection();
            $sql = "select    total_number_floors  from basic_house order by  basic_house_id desc limit  1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['total_number_floors'];
            return $userid;
        }

        // </editor-fold>
        //
    // <editor-fold defaultstate="collapsed" desc="-----------commercial---------------">

        function get_last_basic_commercial_bedroom() {
            $con = new my_connection();
            $sql = "select    bedroom  from basic_commercial order by basic_commercial_id desc limit 1 ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['bedroom'];
            return $userid;
        }

        function get_last_basic_commercial_bathroom() {
            $con = new my_connection();
            $sql = "select    bathroom  from basic_commercial order by basic_commercial_id desc limit 1                  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['bathroom'];
            return $userid;
        }

        function get_last_basic_commercial_compound_size() {
            $con = new my_connection();
            $sql = "select    compound_size  from basic_commercial order by basic_commercial_id desc limit 1                  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['compound_size'];
            return $userid;
        }

        function get_last_basic_commercial_living_flors() {
            $con = new my_connection();
            $sql = "select    living_floors  from basic_commercial order by basic_commercial_id desc limit 1                  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['living_floors'];
            return $userid;
        }

        function get_last_basic_commercial_totalnumber_flors() {
            $con = new my_connection();
            $sql = "select    total_number_floors  from basic_commercial order by basic_commercial_id desc limit 1                  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['total_number_floors'];
            return $userid;
        }

        function get_last_basic_commercial_furnished() {
            $con = new my_connection();
            $sql = "select    furnished  from basic_commercial order by basic_commercial_id desc limit 1                  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['furnished'];
            return $userid;
        }

        // // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="-------------Land--------------------">
        function get_last_admin_loc_land() {

            $db = new my_connection();
            $sql = "select  basic_land.administrative_location from  basic_land  order by basic_land.basic_land_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['administrative_location'];
            return $userid;
        }

        function get_last_plotno_land() {

            $db = new my_connection();
            $sql = "select   basic_land.plot_number from basic_land  order by basic_land.basic_land_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['plot_number'];
            return $userid;
        }

        function get_last_plotsize_land() {

            $db = new my_connection();
            $sql = "select   basic_land.plot_size from basic_land  order by basic_land.basic_land_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['plot_size'];
            return $userid;
        }

        function get_last_lotuse_land() {

            $db = new my_connection();
            $sql = "select   basic_land.lot_use from basic_land  order by basic_land.basic_land_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['lot_use'];
            return $userid;
        }

        function get_last_available_land() {

            $db = new my_connection();
            $sql = "select   basic_land.available_from from basic_land  order by basic_land.basic_land_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['available_from'];
            return $userid;
        }

        // </editor-fold>
        // 
        // 
        // 
        // </editor-fold>
// <editor-fold defaultstate="collapsed" desc="-----------all last price ------------------ ">
        function get_last_price_amount($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.amount from price where listing=:listing order by price.price_id desc limit 1 ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['amount'];
            return $amount;
        }

        function get_last_price_amount_per_day() {
            $con = new my_connection();
            $sql = "select    amount_per_day  from price order by price_id desc limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['amount_per_day'];
            return $userid;
        }

        function get_last_price_currency($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.currency from price where listing=:listing order by price.price_id desc limit 1 ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['currency'];
            return $amount;
        }

        function get_last_price_condition($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.condition from price order by price.price_id desc limit 1 where listing=:listing";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['condition'];
            return $amount;
        }

        function get_last_price_prperty() {
            $last_listing = $this->get_lastlisting();
            $db = new my_connection();
            $sql = "select   price.property from price order by price.price_id desc limit 1 where listing=:listing";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['property'];
            return $amount;
        }

        function get_last_price_min_advance($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.Minimum_advance from price  where listing=:listing order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['Minimum_advance'];
            return $amount;
        }

        function get_last_price_deposit_req() {
            $last_listing = $this->get_lastlisting();
            $db = new my_connection();
            $sql = "select   price.deposit_required from price  where listing=:listing  order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['deposit_required'];
            return $amount;
        }

        function get_last_price_commission($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.commission from price where listing=:listing order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['commission'];
            return $amount;
        }

        function get_last_price_utilities() {
            $last_listing = $this->get_lastlisting();
            $db = new my_connection();
            $sql = "select   price.utilities_extra from price where listing=:listing order by price.price_id desc limit 1 ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['utilities_extra'];
            return $amount;
        }

        function get_last_price_price_day($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.amount_per_day from price  where listing=:listing order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['amount_per_day'];
            return $amount;
        }

        function get_last_price_perSquare_meter($user) {
            $last_listing = $this->get_lastlisting($user);
            $db = new my_connection();
            $sql = "select   price.price_square_meter_per_day from price  where listing=:listing order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array("listing" => $last_listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['price_square_meter_per_day'];
            return $amount;
        }

        function get_last_price_cur_month() {
            $db = new my_connection();
            $sql = "select   price.currency_month from price order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['currency_month'];
            return $amount;
        }

        function get_last_price_cur_month_by_listing($listing) {
            $db = new my_connection();
            $sql = "select   price.currency_month from price where listing=:listing";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array(":listing" => $listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['currency_month'];
            return $amount;
        }

        function get_last_price_curr_day_bylisting($listing) {
            $db = new my_connection();
            $sql = "select   price.currency from price where listing=:listing";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array(":listing" => $listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['currency'];
            return $amount;
        }

        function get_last_price_curr_day() {
            $db = new my_connection();
            $sql = "select   price.currency from price   order by price.price_id desc limit 1";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['currency'];
            return $amount;
        }

        function get_last_price_utilz() {
            $db = new my_connection();
            $sql = "select price_id from price_utilities    where price_id=(select price_id from price order by price_id desc limit 1)";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $amount = $row['price_id'];
            return $amount;
        }

        // </editor-fold>
// <editor-fold defaultstate="collapsed" desc="-----------location-------------">
        function get_sector_by_cell($cell) {//this is the name
            $con = new my_connection();
            $sql = "select    sector.name  from sector
                    join cell on cell.sector = sector.sector_id
                    join district on sector.district = district.district_id
                    join province on district.province = province.province_id
                    where cell.cell_id=:cell_id  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['name'];
            return $userid;
        }

        function get_sectorId_by_cell($cell) {//this is the id
            $con = new my_connection();
            $sql = "select    sector.sector_id  from sector
                    join cell on cell.sector = sector.sector_id
                    join district on sector.district = district.district_id
                    join province on district.province = province.province_id
                    where cell.cell_id=:cell_id  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['sector_id'];
            return $userid;
        }

        function get_district_by_cell($cell) {
            $con = new my_connection();
            $sql = "select    district.name  from district
    join sector on sector.district = district.district_id
    join cell on cell.sector = sector.sector_id
    where cell.cell_id=:cell_id  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['name'];
            return $userid;
        }

        function get_districtId_by_cell($cell) {//this is the id
            $con = new my_connection();
            $sql = "select    district.district_id  from district
                    join sector on sector.district = district.district_id
                    join cell on cell.sector = sector.sector_id
                    where cell.cell_id=:cell_id  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['district_id'];
            return $userid;
        }

        function get_province_by_cell($cell) {
            $con = new my_connection();
            $sql = "select    province.name  from province
    join district on district.province = province.province_id
    join sector on sector.district = district.district_id
    join cell on cell.sector = sector.sector_id
    where cell.cell_id=:cell_id  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['name'];
            return $userid;
        }

        function get_provinceId_by_cell($cell) {
            $con = new my_connection();
            $sql = "select    province.province_id  from province
                    join district on district.province = province.province_id
                    join sector on sector.district = district.district_id
                    join cell on cell.sector = sector.sector_id
                    where cell.cell_id=:cell_id  ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['province_id'];
            return $userid;
        }

        function get_lastcell($user) {
            $db = new my_connection();
            $listing = $this->get_lastlisting($user);
            $sql = "select   location.cell from location where location_id not 
                in (select location from listing where location=0 and listing=:listing)";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array(":listing" => $listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['cell'];
            return $userid;
        }

        function get_long_by_cell($cell) {
            $con = new my_connection();
            $sql = "select    location.longtd  from location    where cell.cell=:cell_id   order by location_id desc limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['name'];
            return $userid;
        }

        function get_lat_by_cell($cell) {
            $con = new my_connection();
            $sql = "select    cell.lat  from location
    where cell.cell_id=:cell_id   order by location_id desc limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['name'];
            return $userid;
        }

        function get_area_by_last_listing() {
            $con = new my_connection();
            $sql = "select area from location  
                    join listing on listing.location = location.location_id
                    where listing.listing_id =(select listing_id from listing   order by listing_id desc limit 1)";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['area'];
            return $userid;
        }

        function get_address_by_cell($cell) {
            $con = new my_connection();
            $sql = "select address from location  
                        join listing on listing.location = location.location_id
                        where listing.listing_id =(select listing_id from listing   order by listing_id desc limit 1)";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":cell_id" => $cell));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['address'];
            return $userid;
        }

        // </editor-fold>

        function get_currency_rate($from, $to) {
            $con = new my_connection();
            $sql = "select    rate  from currency_conversion currency_conversion  where  currency_conversion.from = '$from' and currency_conversion.to = '$to'   ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['rate'];
            return $userid;
        }

        function get_last_description() {
            $db = new my_connection();
            $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
            $stmt2 = $db->getCon()->prepare($sql2);
            $stmt2->execute();
            $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
            $list_id = $row2['listing_id'];

            $sql = "select description from listing    where  listing.listing_id = :listing_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array(":listing_id" => $list_id));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['description'];
            return $userid;
        }

        function get_price_by_lsting($list_id) {
            $db = new my_connection();
            $sql = "select price_id from price    where  price.listing = :listing_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->execute(array(":listing_id" => $list_id));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['price_id'];
            return $userid;
        }

        function get_prop_cat_combo($prop) {

            //this is the last property type by property type in json
            $res = '';
            $con = new my_connection();
            $sql = "select property_category.property_category_id,   property_category.name from property_category "
                    . " join property_type on property_type.property_type_id=property_category.property_type"
                    . " where property_type.name=:prop";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":prop" => $prop));
            $data = array();
            while ($row = $stmt->fetch()) {
                $data[] = array(
                    'id' => $row['property_category_id'],
                    'name' => $row['name']
                );
            }
            return json_encode($data);
        }

        function list_address_names() {
            try {
                $database = new my_connection();
                $db = $database->getCon();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "select distinct( area) from location   ";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                ?>
            <table class="dataList_table off" id="myTable">
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr class="loc_sear_rows"> 
                        <td>
                            <?php echo $row['area']; ?>
                        </td>
                    </tr>
                    <?php
                    $pages+=1;
                }
                ?></table>
            <?php
        } catch (Exception $exc) {
            echo $exc->getMessage();
        }
    }

    function get_property_type_name_by_lsiting($listing) {
        $con = new my_connection();
        $sql = " select property_type.name  from property_type
                        join property_category on property_category.property_type = property_type.property_type_id 
                        join listing on listing.property_category = property_category.property_category_id 
                        where  listing.listing_id=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_property_type_name_by_prop_name($name) {
        $con = new my_connection();
        $sql = " select property_type.name  from property_type
                     where  property_type.property_type_id=:property_type";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":property_type" => $name));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_lastlocation() {
        $db = new my_connection();
        $sql = "select   location.location_id from location order by location.location_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['location_id'];
        return $userid;
    }

    function list_sector($min) {
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select * from sector limit 25";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> sector </td>
                    <td> name </td><td> district </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['sector_id']; ?>
                    </td>
                    <td class="name_id_cols sector " title="sector" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['district']); ?>
                    </td>


                    <td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="sector_update_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function All_sector() {
            $c = 0;
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select  sector_id   from sector";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_sector() {
            $con = new my_connection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function get_last_sector() {
            $con = new my_connection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function list_cell($min) {
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select cell.cell_id,  cell.name,  cell.sector,  sector.sector_id,  sector.name as sector_name from cell  join sector 
                                on sector.sector_id=cell.sector ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cell </td>
                    <td> name </td><td> sector </td>
                    <td> sector name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="location" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['sector']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['sector_name']); ?>
                    </td>


                    <td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

        function get_chosen_cell_name($id) {

            $db = new my_connection();
            $sql = "select   cell.name from cell where cell_id=:cell_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_cell_sector($id) {

            $db = new my_connection();
            $sql = "select   cell.sector from cell where cell_id=:cell_id ";
            $stmt = $db->getCon()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['sector'];
            echo $field;
        }

        function All_cell() {
            $c = 0;
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select  cell_id   from cell";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cell() {
            $con = new my_connection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function get_last_cell() {
            $con = new my_connection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function get_cell_by_listing($listing) {
            $con = new my_connection();
            $sql = "select name from cell
                        join location on location.cell = cell.cell_id 
                        join listing on listing.location = location.location_id 
                        where listing.listing_id=:listing";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":listing" => $listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['name'];
            return $first_rec;
        }

        function get_images_by_listing($listing) {
            ?><script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script><?php
            $con = new my_connection();
            $sql = " select image.image_id, image.path from image join listing on image.listing = listing.listing_id  where  image.listing = :listing    ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":listing" => $listing));
            ?>  
            <?php
            while ($row = $stmt->fetch()) {
                echo '<div class="parts no_paddin_shade_no_Border imageedit_box" style="width: 315px;">'
                . '<div class="parts">'
                . ' <img src="../web_images/property/' . $row['path'] . '" width="250" height="230"/>'
                . '</div>'
                . '<div class="parts full_center_two_h heit_free control_bar no_paddin_shade_no_Border  reverse_border" style="width: 280px;">  '
                . '<input type="checkbox" style="float: left" class="image_checkbx"  value="' . $row['image_id'] . '"  />'
                . '  <div data-image_id="' . $row['image_id'] . '" data-imageid="' . $row['path'] . '" class="trash_icon link_cursor"></div> </div>'
                . '</div>';
            }
        }

        function get_if_feat_byListing($listing) {
            $con = new my_connection();
            $sql = "SELECT features FROM realestate.listing_features where listing=:listing limit 1;";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":listing" => $listing));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $listng = $row['features'];
            return (!empty($listng)) ? true : false;
        }

        function get_agency_phone($name) {
            $con = new my_connection();
            $type = $this->get_msgtypeid_by_name('call');
            $date = date('y-m-d');
            $account = 0;
            $message = 'The message is to request for a house';
            $new_stm = $con->getCon()->prepare("insert into message values(:message_id, :account,  :date,  :type,  :message)");
            $new_stm->execute(array(':message_id' => 0, ':account' => $account, ':date' => $date, ':type' => $type, ':message' => $message));
//after saving the mesasg




            $sql = "select profile.office_phone from profile 
			join account on account.profile = profile.profile_id 
                join agent on agent.account = account.account_id  
                  join agency on agent.agency = agency.agency_id 
                  where agency_name =:name                group by agency.agency_id";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":name" => $name));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $agency = $row['office_phone'];
            echo $agency;
        }

        function get_msgtypeid_by_name($name) {
            $con = new my_connection();
            $sql = "select    msg_type_id  from msg_type   where  msg_type.name = :name ";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->execute(array(":name" => $name));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['msg_type_id'];
            return $userid;
        }

        function _e($string) {
            echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        }

    }

    class location_new {

        // <editor-fold defaultstate="collapsed" desc="------- changes on location -----------">

        function Load() {
            //load provinces only
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select province.province_id,  province.name from province ";
            ?>
        <select class="parts x_width_one_h" id="sp_combo_prov"><option>-- Province --</option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function specl_district_by_prov($prov) {
        $res = '';
        $con = new my_connection();
        $sql = "select  district.district_id,district.name from district  join province on district.province = province.province_id  where province.province_id=:districtid";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":districtid" => $prov));
        $data = array();
        while ($row = $stmt->fetch()) {
            $data[] = array(
                'id' => $row['district_id'],
                'name' => $row['name']
            );
        }
        return json_encode($data);
    }

    function specl_sectors_by_district($distr) {
        $res = '';
        $con = new my_connection();
        $sql = "select   sector.sector_id,   sector.name  from sector   join district on sector.district = district.district_id where district.district_id =:name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $distr));
        $data = array();
        while ($row = $stmt->fetch()) {
            $data[] = array(
                'id' => $row['sector_id'],
                'name' => $row['name']
            );
        }
        return json_encode($data);
    }

    function specl_cells_by_sectors($sectr) {
        $res = '';
        $con = new my_connection();
        $sql = "select cell.cell_id, cell.name from cell join sector on cell.sector = sector.sector_id   where  sector.sector_id = :name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":name" => $sectr));
        $data = array();
        while ($row = $stmt->fetch()) {
            $data[] = array(
                'id' => $row['cell_id'],
                'name' => $row['name']
            );
        }
        return json_encode($data);
    }

// </editor-fold>
}
