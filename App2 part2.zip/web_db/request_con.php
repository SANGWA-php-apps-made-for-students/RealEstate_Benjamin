<?php

class request_con {

    function req_con() {
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}
