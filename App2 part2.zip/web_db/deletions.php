<?php

require_once '../Admin/dbConnection.php';
$con = new my_connection();

class deletions {

    function deleteFrom_account($account_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from account where account_id ='$account_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_account_category($account_category_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from account_category where account_category_id ='$account_category_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_profile($profile_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from profile where profile_id ='$profile_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_property($property_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from property where property_id ='$property_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_property_category($property_category_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from property_category where property_category_id ='$property_category_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_property_subcategory($property_subcategory_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from property_subcategory where property_subcategory_id ='$property_subcategory_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_features($features_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from features where features_id ='$features_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_listing($listing_id) {
        $db = new my_connection();
        $con = $db->getCon();
        $stmt = $con->prepare(" delete from listing where listing_id=:listing_id");
        $stmt->bindValue(':listing_id', $listing_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Listing removed succefully';
    }

    function deleteFrom_listing_type($listing_type_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from listing_type where listing_type_id ='$listing_type_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_image($listing_id) {
        $db = new my_connection();
        $con = $db->getCon();


        $sql2 = "select  path from image where listing=:listing_id";
        $stmt2 = $con->prepare($sql2);
        $stmt2->execute(array(":listing_id" => $listing_id));
        while ($row2 = $stmt2->fetch()) {
            unlink('../web_images/property/' . $row2['path']);
        }



        $stmt = $con->prepare(" DELETE FROM image where listing=:listing_id");
        $stmt->bindValue(':listing_id', $listing_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_image_table($image_id) {
        $db = new my_connection();
        $con = $db->getCon();
        $stmt = $con->prepare(" DELETE FROM image where image_id=:imageid");
        $stmt->bindValue(':imageid', $image_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Image deleted succefully';
    }

    function deleteFrom_images($listing_id) {//here deletes all images but leaves the listing
        $db = new my_connection();
        $con = $db->getCon();
        $sql2 = "select  path from image where listing=:listing_id";
        $stmt2 = $con->prepare($sql2);
        $stmt2->execute(array(":listing_id" => $listing_id));
        while ($row2 = $stmt2->fetch()) {
            unlink('../web_images/property/' . $row2['path']);
        }
    }

    function deleteFrom_location($location_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from location where location_id ='$location_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_price($price_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from price where price_id ='$price_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_property_visitor($property_visitor_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from property_visitor where property_visitor_id ='$property_visitor_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_info($basic_info_id) {
        $con = new my_connection();
        $con->getCon();
        $query = "delete from basic_info where basic_info_id ='$basic_info_id'";
        mysql_query($query)or die(mysql_error());
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_apartment($basic_apartment_id) {
        $db = new my_connection();
        $db->getCon();
        $smt = $db->prepare(" DELETE FROM basic_apartment where basic_apartment_id =:basic_apartment_id");
        $smt->bindValue(':basic_apartment_id', $basic_apartment_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_commercial($basic_commercial_id) {
        $db = new my_connection();
        $db->getCon();
        $smt = $db->prepare(" DELETE FROM basic_commercial where basic_commercial_id =:basic_commercial_id");
        $smt->bindValue(':basic_commercial_id', $basic_commercial_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_house($basic_house_id) {
        $db = new my_connection();
        $db->getCon();
        $smt = $db->prepare(" DELETE FROM basic_house where basic_house_id =:basic_house_id");
        $smt->bindValue(':basic_house_id', $basic_house_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_land($basic_land_id) {
        $db = new my_connection();
        $db->getCon();
        $smt = $db->prepare(" DELETE FROM basic_land where basic_land_id =:basic_land_id");
        $smt->bindValue(':basic_land_id', $basic_land_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_basic_develop($basic_develop_id) {
        $db = new my_connection();
        $db->getCon();
        $smt = $db->prepare(" DELETE FROM basic_develop where basic_develop_id =:basic_develop_id");
        $smt->bindValue(':basic_develop_id', $basic_develop_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_property_request($property_request_id) {
        $db = new my_connection();
        $db->getCon();
        $smt = $db->prepare(" DELETE FROM property_request where property_request_id =:property_request_id");
        $smt->bindValue(':property_request_id', $property_request_id, PDO::PARAM_STR);
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function delete_all_property_request() {
        $db = new my_connection();
        $con = $db->getCon();
        $stmt = $con->prepare(" DELETE FROM property_request");
        $stmt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_listing_features($listing) {
        try {
            $db = new my_connection();
            $smt = $db->getCon()->prepare("DELETE FROM listing_features where listing_features.listing =:listing");
            $smt->bindValue(':listing', $listing, PDO::PARAM_STR);
            $smt->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function deleteFrom_price_utilities($price_id) {
        try {
            $dbase = new my_connection();
            $db = $dbase->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $smt = $db->prepare(" DELETE FROM price_utilities where price_id =:priceid");
            $smt->bindValue(':priceid', $price_id, PDO::PARAM_STR);
            $smt->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="----the deltions occur wher the user is changing the property type---------">
    // 

    function deleteFrom_bas_aprt_by_listing($listing) {
        $db = new my_connection();
        $stmt = $db->getCon()->prepare(" DELETE FROM basic_apartment where listing =:listing");
        $stmt->bindValue(':listing', $listing, PDO::PARAM_STR);
        $stmt->execute();
    }

    function deleteFrom_bas_comm_by_listing($listing) {
        $db = new my_connection();
        $stmt = $db->getCon()->prepare(" DELETE FROM basic_commercial where listing =:listing");
        $stmt->bindValue(':listing', $listing, PDO::PARAM_STR);
        $stmt->execute();
    }

    function deleteFrom_bas_house_by_listing($listing) {
        $db = new my_connection();
        $stmt = $db->getCon()->prepare(" DELETE FROM basic_house where listing =:listing");
        $stmt->bindValue(':listing', $listing, PDO::PARAM_STR);
        $stmt->execute();
//        echo 'Record removed succefully';
    }

    function deleteFrom_bas_develop_by_listing($listing) {
        $db = new my_connection();
        $stmt = $db->getCon()->prepare(" DELETE FROM basic_develop where listing =:listing");
        $stmt->bindValue(':listing', $listing, PDO::PARAM_STR);
        $stmt->execute();
//        echo 'Record removed succefully';
    }

    function deleteFrom_bas_land_by_listing($listing) {
        $db = new my_connection();
        $stmt = $db->getCon()->prepare(" DELETE FROM basic_land where listing =:listing");
        $stmt->bindValue(':listing', $listing, PDO::PARAM_STR);
        $stmt->execute();
//        echo 'Record removed succefully';
    }

// </editor-fold>
}
