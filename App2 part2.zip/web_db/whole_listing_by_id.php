<?php

//this class will retrive the record by listing

require_once '../Admin/dbConnection.php';
$con = new my_connection();

class chosen_record {

    function get_chosen_listing_account($listingid) {
        $db = new my_connection();
        $sql = "select  listing.account   from listing where listing.listing_id =:listingid ";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array("listingid" => $listingid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account'];
        return $userid;
    }

    function get_chosen_listing_date() {
        $con = new my_connection();
        $sql = "select listing.listing_date from listing where listing.listing_id =:listingid ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing_date'];
        return $userid;
    }

    function get_chosen_listing_type($listingid) {
        $con = new my_connection();
        $sql = "select listing.listing_type from listing where listing.listing_id =:listingid ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array("listingid" => $listingid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['listing_type'];
        return $userid;
    }

    function get_chosen_listing_prop_type_by_listing_id($list_id) {//this method the chosen listing id is inside of it
        $con = new my_connection();
        $sql = "select    property_type.property_type_id  from property_type
            join property_category on property_category.property_type = property_type.property_type_id
            join listing on listing.property_category = property_category.property_category_id
            where  listing.listing_id = :listing_id ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['property_type_id'];
        return $userid;
    }

    function get_chosen_listing_prop_cat_noDiv($list_id) {
        $con = new my_connection();
        $sql = " select property_category.property_category_id, property_category.name from property_category  join listing on listing.property_category = property_category.property_category_id  where listing.listing_id=:chosen_cat";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":chosen_cat" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['property_category_id'];
    }

    function get_chosen_property_cat_name_by_property_cat_id($id) {
        $con = new my_connection();
        $sql = "select  property_category_id,  name  from property_category   where  property_category.property_category_id = :prop_cat ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":prop_cat" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_chosen_listing_title($listingid) {

        $db = new my_connection();
        $sql = "select   listing.title         from listing where listing.listing_id =:listingid";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listingid" => $listingid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['title'];
        return $userid;
    }

    function get_chosen_listing_location($list_id) {
        $con = new my_connection();
        $sql = "select   cell.name from location join listing on listing.location = location.location_id join cell on location.cell = cell.cell_id  where listing.listing_id=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_chosen_listing_purpose($listing) {
        $db = new my_connection();
        $sql = "select       listing.purpose    from listing where listing.listing_id=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['purpose'];
        return $userid;
    }

    function get_chosen_description($list_id) {
        $db = new my_connection();
        $sql = "select description from listing    where  listing.listing_id = :listing_id ";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $list_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['description'];
        return $userid;
    }

    function get_chosen_price_cur_month($listing_id) {
        $db = new my_connection();
        $sql = "select   price.currency_month from price where  listing.listing_id = :listing_id";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $listing_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $amount = $row['currency_month'];
        return $amount;
    }

    function get_chosen_price_curr_day($listing_id) {
        $db = new my_connection();
        $sql = "select   price.currency_day from price   where  listing.listing_id = :listing_id";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing_id" => $listing_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $amount = $row['currency_day'];
        return $amount;
    }

    // <editor-fold defaultstate="collapsed" desc="----All basic info by listing -----">

    function get_chosen_apartment_id($listing_id) {
        $db = new my_connection();
        $sql = "select   basic_apartment.basic_apartment_id  from basic_apartment where basic_apartment.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_apartment_id'];
        return $userid;
    }

    function get_chosen_bedroom_apartment($listing_id) {
        $db = new my_connection();
        $sql = "select   basic_apartment.bedrooms  from basic_apartment where basic_apartment.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['bedrooms'];
        return $userid;
    }

    function get_chosen_bathrooms_apartment($listing) {
        $db = new my_connection();
        $sql = "select   basic_apartment.bathrooms from basic_apartment where basic_apartment.listing_id=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['bathrooms'];
        return $userid;
    }

    function get_chosen_floor_number_apartment($listing) {
        $db = new my_connection();
        $sql = "select   basic_apartment.floor_number  from basic_apartment where basic_apartment.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['floor_number'];
        return $userid;
    }

    function get_chosen_total_floor_nbr_apartment($listing) {
        $db = new my_connection();
        $sql = "select   basic_apartment.total_number_floors  from basic_apartment where basic_apartment.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['total_number_floors'];
        return $userid;
    }

    function get_chosen_furnished_apartment($listing) {
        $db = new my_connection();
        $sql = "select   basic_apartment.furnished  from basic_apartment where basic_apartment.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['furnished'];
        return $userid;
    }

    function get_chosen_house_id($listing) {
        $db = new my_connection();
        $sql = "select   basic_house.basic_house_id from basic_house  where basic_house.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_house_id'];
        return $userid;
    }

    function get_chosen_furnished_house($listing) {
        $db = new my_connection();
        $sql = "select   basic_house.furnished from basic_house  where basic_house.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['furnished'];
        return $userid;
    }

    function get_chosen_available_house($listing) {
        $db = new my_connection();
        $sql = "select   basic_house.available_from  from basic_house  where basic_house.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['available_from'];
        return $userid;
    }

    function get_chosen_bedroom_house($listing) {
        $con = new my_connection();
        $sql = "select    bedroom  from basic_house  where basic_house.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['bedroom'];
        return $userid;
    }

    function get_chosen_bathroom_house($listing) {
        $con = new my_connection();
        $sql = "select    bathroom  from basic_house where basic_house.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['bathroom'];
        return $userid;
    }

    function get_chosen_compound_size_house($listing) {
        $con = new my_connection();
        $sql = "select    compound_size  from basic_house where basic_house.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['compound_size'];
        return $userid;
    }

    function get_chosen_living_floors_house($listing) {
        $con = new my_connection();
        $sql = "select    living_floors  from basic_house where basic_house.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['living_floors'];
        return $userid;
    }

    function get_chosen_basic_commercial__id($listing) {
        $con = new my_connection();
        $sql = "select    basic_commercial_id  from basic_commercial where basic_commercial.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_commercial_id'];
        return $userid;
    }

    function get_chosen_basic_commercial_bedroom($listing) {
        $con = new my_connection();
        $sql = "select    bedroom  from basic_commercial where basic_commercial.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['bedroom'];
        return $userid;
    }

    function get_chosen_basic_commercial_bathroom($listing) {
        $con = new my_connection();
        $sql = "select    bathroom  from basic_commercial where basic_commercial.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['bathroom'];
        return $userid;
    }

    function get_chosen_basic_commercial_compound_size($listing) {
        $con = new my_connection();
        $sql = "select    compound_size  from basic_commercial where basic_commercial.listing=:listing";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['compound_size'];
        return $userid;
    }

    function get_chosen_basic_commercial_living_flors($listing) {
        $con = new my_connection();
        $sql = "select    living_floors  from basic_commercial where basic_commercial.listing=:listing ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['living_floors'];
        return $userid;
    }

    function get_chosen_basic_commercial_totalnumber_flors($listing) {
        $con = new my_connection();
        $sql = "select    total_number_floors  from basic_commercial where basic_commercial.listing=:listing  ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['total_number_floors'];
        return $userid;
    }

    function get_chosen_basic_commercial_furnished($listing) {
        $con = new my_connection();
        $sql = "select    furnished  from basic_commercial where basic_commercial.listing=:listing ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['furnished'];
        return $userid;
    }

    function get_chosen_land_id($listing) {
        $db = new my_connection();
        $sql = "select  basic_land.basic_land_id from  basic_land  where bsic_land.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_land_id'];
        return $userid;
    }

    function get_chosen_admin_loc_land($listing) {

        $db = new my_connection();
        $sql = "select  basic_land.administrative_location from  basic_land  where bsic_land.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['administrative_location'];
        return $userid;
    }

    function get_chosen_plotno_land($listing) {

        $db = new my_connection();
        $sql = "select   basic_land.plot_number from basic_land where bsic_land.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_number'];
        return $userid;
    }

    function get_chosen_plotsize_land($listing) {

        $db = new my_connection();
        $sql = "select   basic_land.plot_size from basic_land  where bsic_land.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_size'];
        return $userid;
    }

    function get_chosen_lotuse_land($listing) {

        $db = new my_connection();
        $sql = "select   basic_land.lot_use from basic_land where bsic_land.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['lot_use'];
        return $userid;
    }

    function get_chosen_available_land($listing) {
        $db = new my_connection();
        $sql = "select   basic_land.available_from from basic_land  where bsic_land.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['available_from'];
        return $userid;
    }

    function get_chosen_dev_id($listing) {
        $db = new my_connection();
        $sql = "select   basic_develop_id from basic_develop  where basic_develop.listing=:listing";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute(array(":listing" => $listing));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['basic_develop_id'];
        return $userid;
    }

// </editor-fold>
}
