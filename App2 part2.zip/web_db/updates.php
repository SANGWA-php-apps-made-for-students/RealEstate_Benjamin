<?php

require_once '../Admin/dbConnection.php';

class updates {

    function update_account($username, $password, $account_category, $online, $deleted, $date_created) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update account  set username= '$username', password= '$password', account_category= '$account_category', online= '$online', deleted= '$deleted', date_created= '$date_created'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_account_category($name) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update account_category  set name= '$name'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_profile($name, $last_name, $email, $home_phone, $office_phone, $mobile_phone, $address, $city, $country, $image) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update profile  set name= '$name', last_name= '$last_name', email= '$email', home_phone= '$home_phone', office_phone= '$office_phone', mobile_phone= '$mobile_phone', address= '$address', city= '$city', country= '$country', image= '$image'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_property($title, $basic_info, $property_category) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update property  set title= '$title', basic_info= '$basic_info', property_category= '$property_category'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_property_category($name) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update property_category  set name= '$name'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_property_subcategory($property_subcategory) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update property_subcategory  set property_subcategory= '$property_subcategory'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_features($name, $property) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update features  set name= '$name', property= '$property'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_listing($listing_type, $title, $desc, $purpose, $property_category, $listing_id) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE listing set   listing_type= ?,  title= ?,description=?, purpose= ?, property_category= ? WHERE listing_id=?");
            $stmt->execute(array($listing_type, $title, $desc, $purpose, $property_category, $listing_id));
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function update_listing_type($name) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update listing_type  set name= '$name'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_image($path, $property, $deleted, $appear) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update image  set path= '$path', property= '$property', deleted= '$deleted', appear= '$appear'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_location($appear, $property, $cell, $lat, $long, $area, $address, $location_id) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE location set appear= ?, property= ?, cell= ?, lat= ?, longtd= ?, area= ?, address= ? WHERE location_id=?");
            $stmt->execute(array($appear, $property, $cell, $lat, $long, $area, $address, $location_id));
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    function update_location_by_listing($appear, $property, $cell, $lat, $long, $area, $address, $listing) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $sql1 = "select location_id from location 
                                    join listing on listing.location=location.location_id
                                    where listing.listing_id=:listing";
            $stmt1 = $db->prepare($sql1);
            $stmt1->execute(array(":listing" => $listing));
            $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
            $location = $row1['location_id'];




            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE location set appear= ?, property= ?, cell= ?, lat= ?, longtd= ?, area= ?, address= ? WHERE location_id=?");
            $stmt->execute(array($appear, $property, $cell, $lat, $long, $area, $address, $location));
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    function update_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $curr_month, $curr_day, $price) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE price set amount= ?, currency= ?, cond= ?, property= ?, Minimum_advance= ?, deposit_required= ?, commission= ?, utilities_extra= ?, listing= ?, amount_per_day= ?, price_square_meter_per_day= ?, minimum_advance_per_day= ?, deposit_required_per_day= ?, commission_per_day= ?, utilities_extra_per_day= ?, currency_month= ?, currency_day= ?    WHERE price_id=?");
            $stmt->execute(array($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required,
                $commission, $utilities_extra, $listing, $amount_per_day, $condition_per_day, $minimum_advance_per_day,
                $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $curr_month, $curr_day, $price));
        } catch (PDOException $e) {
            echo '1errors occured:  ' . $e->getMessage();
        } catch (Exception $ne) {
            echo '2errrs occured: ' . $ne->getMessage();
        }
    }

    function update_property_visitor($property) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update property_visitor  set property= '$property'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_basic_info($name, $property) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update basic_info  set name= '$name', property= '$property'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished, $aprt_id) {
        $database = new my_connection();
        $db = $database->getCon();
        $stmt = $db->prepare("UPDATE basic_apartment set basic_apartmentdeleted= ?, listing= ?, bedrooms= ?, bathrooms= ?, floor_number= ?, total_number_floors= ?, furnished= ? WHERE basic_apartment_id=?");
        $stmt->execute(array($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished, $aprt_id));
    }

    function update_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished, $comm_id) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE basic_commercial set basic_commercialdeleted= ?, listing= ?, bedroom= ?, bathroom= ?, compound_size= ?, living_floors= ?, total_number_floors= ?, furnished= ? WHERE basic_commercial_id=?");
            $stmt->execute(array($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished, $comm_id));
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function update_basic_house($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $basic_house_id) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE basic_house set basic_housedeleted= ?, listing= ?, furnished= ?, available_from= ?, bedroom= ?, bathroom= ?, compound_size= ?, living_floors= ?, total_number_floors= ? WHERE basic_house_id=?");
            $stmt->execute(array($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $basic_house_id));
        } catch (PDOException $e) {
            echo $e;
        }
    }

    function update_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from) {
        $database = new my_connection();
        $db = $database->getCon();
        $stmt = $db->prepare("UPDATE basic_land set basic_landdeleted= ?, listing= ?, administrative_location= ?, plot_number= ?, plot_size= ?, lot_use= ?, available_from= ? WHERE basic_land_id=?");
        $stmt->execute(array($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from));
    }

    function update_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished, $basic_develop_id) {
        $database = new my_connection();
        $db = $database->getCon();
        $stmt = $db->prepare("UPDATE basic_develop set basic_developdeleted= ?, listing= ?, bedrooms= ?, bathrooms= ?, compound_size= ?, living_floors= ?, total_number_floors= ?, furnished=? WHERE basic_develop_id=?");
        $stmt->execute(array($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished, $basic_develop_id));
    }

    //more on updates
    function get_user_online($userid) {
        $db = new PDO('mysql:host=localhost;dbname=realestate;charset=utf8mb4', 'sangwa', 'A.manigu125');
        $stmt = $db->prepare("UPDATE account SET is_online=? WHERE account_id=?");
        $online = 'yes';
        $stmt->execute(array($online, $userid));
        $affected_rows = $stmt->rowCount();
    }

    function update_listing_location() {
        $db = new my_connection();
        $sql = "select   location.location_id from location order by location.location_id desc limit 1";
        $stmt = $db->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $last_loc = $row['location_id'];


        $sql2 = "select   listing.listing_id from listing order by listing.listing_id desc limit 1";
        $stmt2 = $db->getCon()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $last_listing = $row2['listing_id'];

        $db2 = $db->getCon();
        $stmt3 = $db2->prepare("update listing set location= ? where listing_id= ? ");

        $stmt3->execute(array($last_loc, $last_listing));
    }

    function update_listing_enable($status, $listing) {
        $database = new my_connection();
        $db = $database->getCon();
        $stmt = $db->prepare("UPDATE listing SET active=? WHERE listing_id=?");
        $stmt->execute(array($status, $listing));
    }

    function update_list_location_by_listing($listing) {
        $database = new my_connection();
        $db = $database->getCon();
        $sql1 = "select location_id from location 
                                    join listing on listing.location=location.location_id
                                    where listing.listing_id=:listing";
        $stmt1 = $db->prepare($sql1);
        $stmt1->execute(array(":listing" => $listing));
        $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
        $location = $row1['location_id'];

        $db2 = $database->getCon();
        $stmt3 = $db2->prepare("update listing set location= ? where listing_id= ? ");

        $stmt3->execute(array($location, $listing));
    }

    function update_property_request($request_id) {
        $database = new my_connection();
        $db = $database->getCon();
        $stmt = $db->prepare("UPDATE property_request set   received= 'yes'  WHERE property_request_id=?");
        $stmt->execute(array($request_id));
    }

    function update_cell($name, $sector, $cell_id) {
        $database = new my_connection();
        $db = $database->getCon();
        $stmt = $db->prepare("UPDATE cell set name= ?, sector= ? WHERE cell_id=?");
        $stmt->execute(array($name, $sector, $cell_id));
    }

}
