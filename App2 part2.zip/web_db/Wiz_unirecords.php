<?php

class Page_load2 {

    function process() {
        try {
            if (!empty($this->lack_price()) || $this->lack_price() != 0) {
                return 'price';
            } else if (!empty($this->lack_location()) || $this->lack_location() != 0) {
                return 'location';
            } else if (!empty($this->lack_image()) || $this->lack_image() != 0) {
                return 'image';
            } else {
                return 'complete';
            }
        } catch (PDOException $e) {
            echo $e->getCode();
        }
    }

    function lack_price() {

        require_once './dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql2 = " select   min(listing_id) as listing from listing  where listing.listing_id not in (select listing from price where listing <>'null')";
        $stmt2 = $db->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $price = $row2['listing'];
        return trim($price);
    }

    function lack_location() {
        require_once './dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql3 = " select count(location) as tot from listing where  location = 0";
        $stmt3 = $db->prepare($sql3);
        $stmt3->execute();
        $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
        $loc = $row3['tot'];
        return trim($loc);
    }

    function lack_image() {
        require_once './dbConnection.php';
        $database = new my_connection();
        $db = $database->getCon();
        $sql = "select   min(listing_id) as listingid  from listing  where listing.listing_id not in (select listing from image)";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $image = $row['listingid'];
        return trim($image);
    }

    function get_html() {
        if ($this->process() != 'complete') {
            if (empty($_SESSION['listing_date'])) {// this means that the user is currently saving the ilisting,
                require_once './Fresh_data.php';
                require_once './html_fields.php';
                $obj = new html();
                $obj->html_Fresh();
                ?><script>//alert('wiz not complete - fresh <?php echo $this->process(); ?>');</script><?php
            } else {
                require_once './html_fields.php';
                $obj = new html();
                $obj->Existing();
                ?><script>//alert('not complete - existing .. <?php echo $this->process(); ?>');</script><?php
            }
        } else {
            require_once './html_fields.php';
            $obj = new html();
            $obj->empty_html();
            ?><script>//alert('Complete .. ');</script><?php
        }
    }

    function get_changes() {
        echo $change = (!empty($_SESSION['changes'])) ? $_SESSION['changes'] : "no changes";
    }

}
