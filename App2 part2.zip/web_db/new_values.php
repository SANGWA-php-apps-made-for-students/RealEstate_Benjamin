<?php

require_once '../Admin/dbConnection.php';

class new_values {

    function new_account($username, $password, $account_category, $online, $deleted, $date_created, $profile) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category,  :online,  :deleted,  :date_created,  :profile)");
        $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category, ':online' => $online, ':deleted' => $deleted, ':date_created' => $date_created, ':profile' => $profile));
    }

    function new_account_category($name) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
        $stm->execute(array(':account_category_id' => 0, ':name' => $name));
    }

    function new_profile($name, $last_name, $email, $office_phone, $mobile_phone, $address, $city, $country, $image) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :name,  :last_name,  :email,   :office_phone,  :mobile_phone,  :address,  :city,  :country,  :image)");
            $stm->execute(array(':profile_id' => 0, ':name' => $name, ':last_name' => $last_name, ':email' => $email, ':office_phone' => $office_phone, ':mobile_phone' => $mobile_phone, ':address' => $address, ':city' => $city, ':country' => $country, ':image' => $image));
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    function new_property($name) {
        //
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into property values(:property_id, :name)");
        $stm->execute(array(':property_id' => 0, ':name' => $name));
    }

    function new_property_category($name, $property_type) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_category values(:property_category_id, :name,  :property_type)");
        $stm->execute(array(':property_category_id' => 0, ':name' => $name, ':property_type' => $property_type
        ));
    }

    function new_property_subcategory($property_subcategory) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_subcategory values(:property_subcategory_id, :property_subcategory)");
        $stm->execute(array(':property_subcategory_id' => 0, ':property_subcategory' => $property_subcategory
        ));
    }

    function new_features($name, $property_type) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into features values(:features_id, :name,  :property_type)");
        $stm->execute(array(':features_id' => 0, ':name' => $name, ':property_type' => $property_type
        ));
    }

    function new_listing($listing_date, $account, $listing_type, $property, $title, $description, $purpose, $property_category, $location, $active) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into listing values(:listing_id, :listing_date,  :account,  :listing_type,  :property,  :title,:description,  :purpose,  :property_category,  :location,  :active)");
            $stm->execute(array(':listing_id' => 0, ':listing_date' => $listing_date, ':account' => $account, ':listing_type' => $listing_type, ':property' => $property, ':title' => $title, ':description' => $description, ':purpose' => $purpose, ':property_category' => $property_category, ':location' => $location, ':active' => $active));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_listing_type($name) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into listing_type values(:listing_type_id, :name)");
        $stm->execute(array(':listing_type_id' => 0, ':name' => $name
        ));
    }

    function new_image($path, $listing, $deleted, $appear) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into image values(:image_id, :path,  :listing,  :deleted,  :appear)");
        $stm->execute(array(':image_id' => 0, ':path' => $path, ':listing' => $listing, ':deleted' => $deleted, ':appear' => $appear
        ));
    }

    function new_location($appear, $property, $cell, $lat, $long, $area, $address) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into location values(:location_id, :appear,  :property,  :cell,  :lat,  :long,  :area,  :address)");
            $stm->execute(array(':location_id' => 0, ':appear' => $appear, ':property' => $property, ':cell' => $cell, ':lat' => $lat, ':long' => $long, ':area' => $area, ':address' => $address
            ));
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    function new_price($amount, $currency, $condition, $property, $Minimum_advance, $deposit_required, $commission, $utilities_extra, $listing, $amount_per_day, $price_square_meter_per_day, $minimum_advance_per_day, $deposit_required_per_day, $commission_per_day, $utilities_extra_per_day, $curr_month, $curr_day) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into price values(:price_id, :amount,  :currency,  :cond,  :property,  :Minimum_advance,  :deposit_required,  :commission,  :utilities_extra,  :listing,  :amount_per_day,  :price_square_meter_per_day,  :minimum_advance_per_day,  :deposit_required_per_day,  :commission_per_day,  :utilities_extra_per_day, :currency_month,:currency_day)");
            $stm->execute(array(':price_id' => 0, ':amount' => $amount, ':currency' => $currency, ':cond' => $condition, ':property' => $property, ':Minimum_advance' => $Minimum_advance, ':deposit_required' => $deposit_required, ':commission' => $commission, ':utilities_extra' => $utilities_extra, ':listing' => $listing, ':amount_per_day' => $amount_per_day, ':price_square_meter_per_day' => $price_square_meter_per_day, ':minimum_advance_per_day' => $minimum_advance_per_day, ':deposit_required_per_day' => $deposit_required_per_day, ':commission_per_day' => $commission_per_day, ':utilities_extra_per_day' => $utilities_extra_per_day, ':currency_month' => $curr_month, ':currency_day' => $curr_day));
        } catch (PDOException $e) {
            echo $e->getMessage();
        } catch (Exception $ne) {
            echo $ne;
        }
    }

    function new_property_visitor($property) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_visitor values(:property_visitor_id, :property)");
        $stm->execute(array(':property_visitor_id' => 0, ':property' => $property
        ));
    }

    function new_basic_info($name, $property_type) {

        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into basic_info values(:basic_info_id, :name,  :property_type)");
        $stm->execute(array(':basic_info_id' => 0, ':name' => $name, ':property_type' => $property_type));
    }

    function new_agent($agency_desc, $logo, $agency_name, $website, $profile) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into agent values(:agent_id, :agency_desc,  :logo,  :agency_name,  :website,  :profile)");
        $stm->execute(array(':agent_id' => 0, ':agency_desc' => $agency_desc, ':logo' => $logo, ':agency_name' => $agency_name, ':website' => $website, ':profile' => $profile
        ));
    }

    function new_property_type($name, $property) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into property_type values(:property_type_id, :name,  :property)");
        $stm->execute(array(':property_type_id' => 0, ':name' => $name, ':property' => $property
        ));
    }

    function new_province($name) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into province values(:province_id, :name)");
        $stm->execute(array(':province_id' => 0, ':name' => $name
        ));
    }

    function new_sector($name, $disrict) {

        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into sector values(:sector_id, :name,  :disrict)");
        $stm->execute(array(':sector_id' => 0, ':name' => $name, ':disrict' => $disrict
        ));
    }

    function new_cell($name, $sector) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into cell values(:cell_id, :name,  :sector)");
        $stm->execute(array(':cell_id' => 0, ':name' => $name, ':sector' => $sector
        ));
    }

    function new_district($name, $province) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into district values(:district_id, :name,  :province)");
        $stm->execute(array(':district_id' => 0, ':name' => $name, ':province' => $province));
    }

    function new_features_listing($listing, $features) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into features_listing values(:features_listing_id, :listing, :features )");
        $stm->execute(array(':features_listing_id' => 0, ':listing' => $listing, ':features' => $features));
    }

    function new_listing_basic_info($listing, $basic_info, $value) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into listing_basic_info values(:listing_basic_info_id, :listing,  :basic_info,  :value)");
        $stm->execute(array(':listing_basic_info_id' => 0, ':listing' => $listing, ':basic_info' => $basic_info, ':value' => $value
        ));
    }

    function new_listing_features($listing, $features) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into listing_features values(:listing_features_id, :listing,  :features)");
        $stm->execute(array(':listing_features_id' => 0, ':listing' => $listing, ':features' => $features));
    }

    function new_basic_apartment($basic_apartmentdeleted, $listing, $bedrooms, $bathrooms, $floor_number, $total_number_floors, $furnished) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into basic_apartment values(:basic_apartment_id, :basic_apartmentdeleted,  :listing,  :bedrooms,  :bathrooms,  :floor_number,  :total_number_floors,  :furnished)");
        $stm->execute(array(':basic_apartment_id' => 0, ':basic_apartmentdeleted' => $basic_apartmentdeleted, ':listing' => $listing, ':bedrooms' => $bedrooms, ':bathrooms' => $bathrooms, ':floor_number' => $floor_number, ':total_number_floors' => $total_number_floors, ':furnished' => $furnished
        ));
    }

    function new_basic_commercial($basic_commercialdeleted, $listing, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors, $furnished) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into basic_commercial values(:basic_commercial_id, :basic_commercialdeleted,  :listing,  :bedroom,  :bathroom,  :compound_size,  :living_floors,  :total_number_floors, :furnished)");
        $stm->execute(array(':basic_commercial_id' => 0, ':basic_commercialdeleted' => $basic_commercialdeleted, ':listing' => $listing, ':bedroom' => $bedroom, ':bathroom' => $bathroom, ':compound_size' => $compound_size, ':living_floors' => $living_floors, ':total_number_floors' => $total_number_floors, 'furnished' => $furnished));
    }

    function new_basic_house($basic_housedeleted, $listing, $furnished, $available_from, $bedroom, $bathroom, $compound_size, $living_floors, $total_number_floors) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into basic_house values(:basic_house_id, :basic_housedeleted,  :listing,  :furnished,   :available_from, :bedroom, :bathroom, :compound_size, :living_floors,:total_number_floors)");
            $stm->execute(array(':basic_house_id' => 0, ':basic_housedeleted' => $basic_housedeleted, ':listing' => $listing, ':furnished' => $furnished, ':available_from' => $available_from, ':bedroom' => $bedroom, ':bathroom' => $bathroom, ':compound_size' => $compound_size, ':living_floors' => $living_floors, ':total_number_floors' => $total_number_floors));
        } catch (PDOException $e) {
            echo $e;
        }
    }

    function new_basic_land($basic_landdeleted, $listing, $administrative_location, $plot_number, $plot_size, $lot_use, $available_from) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into basic_land values(:basic_land_id, :basic_landdeleted,  :listing,  :administrative_location,  :plot_number,  :plot_size,  :lot_use,  :available_from)");
            $stm->execute(array(':basic_land_id' => 0, ':basic_landdeleted' => $basic_landdeleted, ':listing' => $listing, ':administrative_location' => $administrative_location, ':plot_number' => $plot_number, ':plot_size' => $plot_size, ':lot_use' => $lot_use, ':available_from' => $available_from));
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    function new_basic_develop($basic_developdeleted, $listing, $bedrooms, $bathrooms, $compound_size, $living_floors, $total_number_floors, $furnished) {
        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into basic_develop values(:basic_develop_id, :basic_developdeleted,  :listing,  :bedrooms,  :bathrooms,  :compound_size,  :living_floors,  :total_number_floors, :furnished)");
        $stm->execute(array(':basic_develop_id' => 0, ':basic_developdeleted' => $basic_developdeleted, ':listing' => $listing, ':bedrooms' => $bedrooms, ':bathrooms' => $bathrooms, ':compound_size' => $compound_size, ':living_floors' => $living_floors, ':total_number_floors' => $total_number_floors, ':furnished' => $furnished));
    }

    function new_features_cat($features_catdeleted, $cat_name) {

        $database = new my_connection();
        $db = $database->getCon();

        $stm = $db->prepare("insert into features_cat values(:features_cat_id, :features_catdeleted,  :cat_name)");
        $stm->execute(array(':features_cat_id' => 0, ':features_catdeleted' => $features_catdeleted, ':cat_name' => $cat_name
        ));
    }

    function new_currency_conversion($currency_conversiondeleted, $from, $to, $rate) {

        $database = new my_connection();
        $db = $database->getCon();
        $stm = $db->prepare("insert into currency_conversion values(:currency_conversion_id, :currency_conversiondeleted,  :from,  :to,  :rate)");
        $stm->execute(array(':currency_conversion_id' => 0, ':currency_conversiondeleted' => $currency_conversiondeleted, ':from' => $from, ':to' => $to, ':rate' => $rate
        ));
    }

    function new_property_request($property_requestdeleted, $names, $telephone, $email, $listing, $received, $account) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $request_date = date("Y-m-d");
            $stm = $db->prepare("insert into property_request values(:property_request_id, :property_requestdeleted, :request_date,  :names,  :telephone,  :email,  :listing,  :received,  :account)");
            $stm->execute(array(':property_request_id' => 0, ':property_requestdeleted' => $property_requestdeleted, ':request_date' => $request_date, ':names' => $names, ':telephone' => $telephone, ':email' => $email, ':listing' => $listing, ':received' => $received, ':account' => $account));
//            echo $stm->errorCode();
        } catch (PDOException $r) {
            echo $r->getMessage();
        }
    }

    function new_price_utilities($price, $utilities) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into price_utilities values(:price_utilities_id,   :price_id,  :utilities_id)");
            $stm->execute(array(':price_utilities_id' => 0, ':price_id' => $price, ':utilities_id' => $utilities));
        } catch (PDOException $e) {
            echo 'util problem .. ' . $e->getMessage();
        }
    }

    function new_comment($commentdeleted, $message, $account, $date, $listing) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into comment values(:comment_id, :commentdeleted,  :message,  :account,  :date,  :listing)");
            $stm->execute(array(':comment_id' => 0, ':commentdeleted' => $commentdeleted, ':message' => $message, ':account' => $account, ':date' => $date, ':listing' => $listing
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_comment_replies($comment_repliesdeleted, $message, $date, $account, $comment) {
        try {

            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into comment_replies values(:comment_replies_id, :comment_repliesdeleted,  :message,  :date,  :account,  :comment)");
            $stm->execute(array(':comment_replies_id' => 0, ':comment_repliesdeleted' => $comment_repliesdeleted, ':message' => $message, ':date' => $date, ':account' => $account, ':comment' => $comment));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_agency($website, $office_address, $agency_desc, $logo, $agency_name, $account) {
        try {

            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into agency values(:agency_id, :website,  :office_address,  :agency_desc,  :logo,  :agency_name,  :account)");
            $stm->execute(array(':agency_id' => 0, ':website' => $website, ':office_address' => $office_address, ':agency_desc' => $agency_desc, ':logo' => $logo, ':agency_name' => $agency_name, ':account' => $account
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_message($account, $date, $type, $message) {
        try {
            $database = new my_connection();
            $db = $database->getCon();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into message values(:message_id, :account,  :date,  :type,  :message)");
            $stm->execute(array(':message_id' => 0, ':account' => $account, ':date' => $date, ':type' => $type, ':message' => $message));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_msg_type($name) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into msg_type values(:msg_type_id, :name)");
            $stm->execute(array(':msg_type_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

}
