<?php
session_start();
?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Result</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            a{
                color: #fff;
                text-decoration: none;
                font-size: 16px;
            }
        </style>
    </head>
    <body>
        <form action="home_page_search_res.php" method="post">
            <div style="border-bottom: 3px solid #fff; " class=" parts  full_center_two_h margin_free  heit_free skin  no_shade_noBorder scroll_h_free bg_title" id="home_hovables_box">
                <div class="parts box logo no_paddin_shade_no_Border margin_free">
                </div>
                <div class="parts no_paddin_shade_no_Border">
                    <div class="parts no_paddin_shade_no_Border left_off_xx  " style="padding-bottom: 5px;">
                        <a href="index.php">Home</a>
                    </div>
                    <div class="parts no_paddin_shade_no_Border left_off_x allow_drop" id="drop1">
                        <a href="#" class="">About us</a>
                        <div class="parts  full_center_two_h  x_width_3h   hovable_item" id="hov1"  >
                            <div class="parts no_shade_noBorder"><a href="#" id="wht_we_do_link">   What we do</a>  </div>
                            <div class="parts no_shade_noBorder"><a href="#" id="wht_we_are_link">What we are</a>  </div>
                        </div>
                    </div>
                    <div class="parts no_paddin_shade_no_Border  left_off_x allow_drop" id="drop2">
                        <a href="#">Contact us</a>
                        <div class="parts  full_center_two_h  x_width_3h   hovable_item " id="hov2"  >
                            <div class="parts no_shade_noBorder"> <a href="#" id="admin_link"> Administrator</a>  </div>
                            <div class="parts no_shade_noBorder"><a href="#" id="agent_link"> Agents </a> </div>
                        </div>
                    </div>
                </div>
                <div class="two_fifty_right heit_free">
                    <a href="login.php">Login</a>
                </div>
            </div>
            <div class="parts ninenty_centered no_paddin_shade_no_Border">
                <div class="parts eighty_centered no_paddin_shade_no_Border">
                    <div class="parts xx_titles eighty_centered no_paddin_shade_no_Border">
                        Search result:
                    </div>
                </div>
                <?php
                include './header_menu.php';
                if (isset($_POST['maximum_price'])) {
                    $region = $_POST['region'];
                    if (!empty($region)) {
                        //search the listing with region
                        $hmp_prop_type_combo = trim($_POST['hmp_prop_type_combo']);
                        $maximum_price = trim($_POST['maximum_price']);
                        get_listing_by_maxPrice_location_type($maximum_price, $region, $hmp_prop_type_combo);
                    } else {
                        //search the listing withour region
                        $hmp_prop_type_combo = $_POST['hmp_prop_type_combo'];
                        $maximum_price = $_POST['maximum_price'];
                        get_listing_by_maxPrice_type($maximum_price, $hmp_prop_type_combo);
                    }
                } else {
                    header("location: index.php");
                }
                ?>
            </div>
        </form>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
<?php

function get_listing_by_maxPrice_location_type($max_price, $location, $type) {
    require_once('web_db/connection.php');
    $con = new my_connection();
    $sql = "select listing.listing_id,property_category.name,price.amount, listing_type.name, image.deleted,image.appear,   image.listing,  listing.listing_date,  listing.title,  listing.purpose,  listing.account,  listing.listing_type,  image.path
        from listing
        join image on image.listing=listing.listing_id
        left join price on price.listing = listing.listing_id
                            left join location on listing.location = location.location_id
                      left  join cell on location.cell = cell.cell_id
                      left  join sector on cell.sector = sector.sector_id
                      left  join district on sector.district = district.district_id
                      left  join province on district.province = province.province_id
                      left  join basic_apartment on basic_apartment.listing = listing.listing_id
                      left  join basic_land on basic_land.listing = listing.listing_id
                        join account on listing.account = account.account_id
                        join listing_type on listing.listing_type = listing_type.listing_type_id
                        join property on listing.property = property.property_id
                        join property_category on listing.property_category = property_category.property_category_id
                      where   property_category.property_category_id=:prop_cate and price.amount<=:amount and area=:location group by listing.listing_id";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":prop_cate" => $type, ":amount" => $max_price, ":location" => $location));
    ?>
    <?php
    while ($row = $stmt->fetch()) {
        echo'<div class="parts two_fifty_left heit_free no_shade_noBorder  " >
        <div   style="background-color:#fff; border: 1px solid #511a7e; margin-left: 6px;" class= parts margin_free  full_center_two_h heit_free">' . '';
        echo "<img class=\"parts no_paddin_shade_no_Border\" src=web_images/property/" . $row['path'] . " width=\"220\"; height=\"200\"/>";
        echo '<div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border link_cursor" style="font-family: Arial;">' . $row['title'] . '</div>';
        echo '<div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border">' . $row['listing_date'] . '</div>';
        echo '<div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border">' . $row['appear'] . '</div>';
        echo'<div class="parts link_cursor hmp_rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
        echo '   </div>
        </div>';
    }
}

function get_listing_by_maxPrice_type($max_price, $type) {
    require_once('web_db/connection.php');
    $con = new my_connection();
    $sql = "select listing.listing_id,property_category.name,price.amount, listing_type.name, image.deleted,image.appear,   image.listing,  listing.listing_date,  listing.title,  listing.purpose,  listing.account,  listing.listing_type,  image.path
        from listing
        join image on image.listing=listing.listing_id
        left join price on price.listing = listing.listing_id
                            left join location on listing.location = location.location_id
                      left  join cell on location.cell = cell.cell_id
                      left  join sector on cell.sector = sector.sector_id
                      left  join district on sector.district = district.district_id
                      left  join province on district.province = province.province_id
                      left  join basic_apartment on basic_apartment.listing = listing.listing_id
                      left  join basic_land on basic_land.listing = listing.listing_id
                        join account on listing.account = account.account_id
                        join listing_type on listing.listing_type = listing_type.listing_type_id
                        join property on listing.property = property.property_id
                        join property_category on listing.property_category = property_category.property_category_id
                      where   property_category.property_category_id=:prop_cate and price.amount<=:amount  group by listing.listing_id";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":prop_cate" => $type, ":amount" => $max_price));
    ?>
    <?php
    while ($row = $stmt->fetch()) {
        echo'<div class="parts two_fifty_left heit_free no_shade_noBorder  " >
        <div   style="background-color:#fff; border: 1px solid #511a7e; margin-left: 6px;" class= parts margin_free  full_center_two_h heit_free">' . '';
        echo "<img class=\"parts no_paddin_shade_no_Border\" src=web_images/property/" . $row['path'] . " width=\"220\"; height=\"200\"/>";
        echo '<div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border link_cursor" style="font-family: Arial;">' . $row['title'] . '</div>';
        echo '<div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border">' . $row['listing_date'] . '</div>';
        echo '<div class="parts margin_free full_center_two_h heit_free no_paddin_shade_no_Border">' . $row['appear'] . '</div>';
        echo'<div class="parts link_cursor hmp_rprt_more_details_btn" style="clear: left;" id="rprt_more_details_btn"><span class="off">' . $row['listing_id'] . '</span>More details</div>';
        echo '   </div>
        </div>';
    }
}

function get_rpt_listing_by_id($list_id) {
    require_once 'Admin/dbConnection.php';
    $con = new my_connection();
    $con = new my_connection();
    $sql = "select  distinct  price.price_id,listing.listing_id ,listing.description, price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from,
                features.name as feat
                from listing
                    left join price on price.listing = listing.listing_id
                    left  join image on image.listing = listing.listing_id
                    left join location on listing.location = location.location_id
                    left  join cell on location.cell = cell.cell_id
                    left  join sector on cell.sector = sector.sector_id
                    left  join district on sector.district = district.district_id
                    left  join province on district.province = province.province_id
                    left join basic_apartment on basic_apartment.listing = listing.listing_id
                    left join basic_land on basic_land.listing = listing.listing_id
                        join account on listing.account = account.account_id
                        join listing_type on listing.listing_type = listing_type.listing_type_id
                        join property on listing.property = property.property_id
                        join property_category on listing.property_category = property_category.property_category_id
                    left   join listing_features on listing_features.features = listing.listing_id
                      left   join features on listing_features.features = features.features_id
                      where listing.listing_id=:listingid  group by path, title  ";

    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listingid" => $list_id));
    while ($row = $stmt->fetch()) {
        echo '<div class="parts full_center_two_h heit_free no_shade_noBorder ">';
        echo '<div class="parts xx_titles no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';

        echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" >   LISTING ID: LST- ' . $row['listing_id'] . ' </div>';
        echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" >   ' . $row['description'] . ' </div>';
        echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
        echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
        echo '<div class="parts no_paddin_shade_no_Border  full_center_two_h heit_free"  > Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
        if ($row['bedrooms'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
        }if ($row['bathrooms'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
        }
        if ($row['plot_size'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
        }
        if ($row['available_from'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
        }
        if ($row['administrative_location'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Administrative location:  ' . $row['administrative_location'] . '     </div>';
        }
        if ($row['feat'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;">Other Features:  ' . $row['feat'] . '     </div>';
        }
        echo '<div class="parts no_paddin_shade_no_Border  full_center_two_h heit_free contact_phone"  >'
        . ''
        . '<div class="parts contact_phone_btn link_cursor"> Contact  </div>'
        . '    </div>';
        echo '<img class="parts no_shade_noBorder" src="web_images/property/' . $row['path'] . '" style=""/>';
        echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
        echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
        echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
        echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
        echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
        echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
        echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
        echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
        echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
        echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';

        echo '</div>';
    }
}
