$(document).ready(function (){
    get_districts_by_province();
    
});
function get_districts_by_province() {
    $('.combo_province2').change(function () {
        var district_by_prov = $('.combo_province2 option:selected').text();
        var province = $('.combo_province2 option:selected').text();
        $.post('../Admin/handler.php', {district_by_prov: district_by_prov}, function (data) {
            $('#districts_res').show().html(data);
        });
//        $.post('../Admin/handler.php', {province: province}, function (data) {
//            var dd = $('#d').html(data);
//            $('#txt_province_id').val($('#d').text());
//        });
    });
}