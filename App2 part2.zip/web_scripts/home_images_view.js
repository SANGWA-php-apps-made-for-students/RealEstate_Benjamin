$(document).ready(function () {
    try {
        view_slide_pic();
    } catch (err) {
        alert(err.message);
    }
});
function view_slide_pic() {
    $('.slide_pics').click(function () {
        try {
            $('.slide_pics').toggleClass('hmp_slide_full');
        } catch (err) {
            alert(err.message);
        }
    });
}