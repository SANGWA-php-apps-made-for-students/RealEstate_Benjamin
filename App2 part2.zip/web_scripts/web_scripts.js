var slideCounter = 0;

$(document).ready(function () {
    slideShow();
    show_pic_by_random();
});
function slideShow() {
    setTimeout(function () {
        slideCounter += 1;
        if (slideCounter == 6) {
            $('.slide_pics').fadeOut(100);
            $('#pic1').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c1').css('background-color', "#2cbc5b");
        } else if (slideCounter == 11) {
            $('.slide_pics').fadeOut(100);
            $('#pic2').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c2').css('background-color', "#2cbc5b");
        } else if (slideCounter == 17) {
            $('.slide_pics').fadeOut(100);
            $('#pic3').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c3').css('background-color', "#2cbc5b");
        } else if (slideCounter == 24) {
            $('.slide_pics').fadeOut(100);
            $('#pic4').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c4').css('background-color', "#2cbc5b");
        } else if (slideCounter == 31) {
            $('.slide_pics').fadeOut(100);
            $('#pic5').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c5').css('background-color', "#2cbc5b");
        } else if (slideCounter == 38) {
            $('.slide_pics').fadeOut(100);
            $('#pic6').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c7').css('background-color', "#2cbc5b");
        } else if (slideCounter == 46) {
            $('.slide_pics').fadeOut(100);
            $('#pic7').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c7').css('background-color', "#2cbc5b");
        } else if (slideCounter == 53) {
            $('.slide_pics').fadeOut(100);
            $('#pic8').fadeIn(450);
            $('.p_c').css('background-color', "transparent");
            $('#p_c8').css('background-color', "#2cbc5b");
            slideCounter = 0;
        }
        slideShow();
    }, 1000);
}
function show_pic_by_random() {
    $('#p_c1').click(function () {
        slideCounter = 6;
        $('.slide_pics').fadeOut(450);
        $('#pic1').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c1').css('background-color', "#2cbc5b");
    });
    $('#p_c2').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic1').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c2').css('background-color', "#2cbc5b");
    });
    $('#p_c3').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic3').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c3').css('background-color', "#2cbc5b");
    });
    $('#p_c4').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic4').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c4').css('background-color', "#2cbc5b");
    });
    $('#p_c5').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic5').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c5').css('background-color', "#2cbc5b");
    });
    $('#p_c6').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic6').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c6').css('background-color', "#2cbc5b");
    });
    $('#p_c7').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic7').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c7').css('background-color', "#2cbc5b");
    });
    $('#p_c8').click(function () {
        $('.slide_pics').fadeOut(450);
        $('#pic8').fadeIn(450);
        $('.p_c').css('background-color', "transparent");
        $('#p_c8').css('background-color', "#2cbc5b");
    });
}