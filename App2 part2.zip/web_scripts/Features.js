$(document).ready(function () {
    try {
        get_off_step_one();
       
    } catch (err) {
        alert(err.message);
    }
});
function get_off_step_one() {
    var y = '';
    $('#send_features').click(function () {
       var selecteditems = [];
        $("#features_box").find("input:checked").each(function (i, ob) {
            selecteditems.push($(ob).val());
        });
        for (var i = 0; i < selecteditems.length; i++) {
            var feature_item = selecteditems[i];
            $.post('../Admin/handler.php', {feature_item: feature_item}, function (data) {
                //       $('#my_cat_res').show().html(data);
               
              alert(data);
            });
        }
       return false;
    });

}