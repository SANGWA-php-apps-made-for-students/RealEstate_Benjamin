var lat, lng, hover_count = 0;
var marker;
var comment_reply = true;
$(document).ready(function () {
    try {
        get_all_uploaded_image();
        get_home_selected_menu();
        select_butn_color_changer('#listing_typeid', '.list_typebtn');
        icon_setter('.listing_type_data_res'); // fund on list type
        step_clicked();
        getAndSend_id_by_name_from_combo();
        get_property_id_combo();
        get_property_type_id_combo();

        res_item_selected();
        map_loc_link();
        get_map_loc();
        get_provinces_combo();
        get_districts_combo();
        get_sectors_combo();
//      get_listing_type_combo();
        get_cells_by_sector();
        get_selected_cell();
        get_districts_by_province();
        get_sectors_by_district();
        get_new_data_hide_show();
        get_condition_price_combo();
        get_utilities_combo();
        validate_numbers_textfields();
        hover_theme1();
        get_listing_type_data_res_selected();

        get_area_clicked();
        get_more_images();
//      get_homepage_hovables();
        home_menu_links();
        get_location_listing();
        get_feature_checked();
        //updates
        update_listing_image();
        get_rpt_listing_by_date();
        update_listing_price();
        hide_rpt_details();
        //get_property_type_id_combo_to_update();
        get_request_accepted();
        prop_cat_clicked();
        feat_chosen();
        utils_chosen();
        comment_del_udpate();
        comment_replies_del_udpate();

        tab_switch();
        cell_del_udpate();
        get_image_deleted();
        addmoreimages_link();
        dlog_btn_No_Yes();
        select_all_images();
        menu();
        enable_report();
    } catch (err) {
        alert(err.message);
    }
});
function get_home_selected_menu() {
    $('#for_sale').click(function () {
        $('#menu_selection').val('for_sale');
    });
    $('#for_rent').click(function () {
        $('#menu_selection').val('for_rent');
    });
    $('#furnished').click(function () {
        $('#menu_selection').val('furnished');
    });
    $('.home_menu').click(function () {
        $('.home_menu').css('background-color', '#5fd4f6');
        $(this).css('background-color', '#2c7489').css('color', '#fff');
    });
}
function select_butn_color_changer(hidn_field, btn) {// this specifies the button selected by color and puts the id in the hidden field
    $(btn).click(function () {
        var id = $(this).children('span:first').html();
        $(btn).removeClass('ok_ticked');
        $(this).addClass('ok_ticked');
        $(hidn_field).val(id);
    });
}
function icon_setter(btn) {
    $(btn).removeClass('ok_ticked');
    $(this).addClass('ok_ticked');
}
function step_clicked() {
    $('.stepItem').click(function () {


    });
    var step = $('#current_step').val();
    if (step == 1) {
        $('.stepItem').css('border-color', '#fff');
        $('#listing_step1').css('border-color', '#009039').css('border-width', '3px');
    } else if (step == 2) {
        $('.stepItem').css('border-color', '#fff');
        $('#listing_step2').css('border-color', '#009039').css('border-width', '3px');
    } else if (step == 3) {
        $('.stepItem').css('border-color', '#fff');
        $('#listing_step3').css('border-color', '#009039').css('border-width', '3px');
    } else if (step == 4) {
        $('.stepItem').css('border-color', '#fff');
        $('#listing_step4').css('border-color', '#009039').css('border-width', '3px');
    }
}
function getAndSend_id_by_name_from_combo() {
    try {
        $('.combo_user_cat').change(function () {
            sent = $('.combo_user_cat option:selected').text();
            $.post('../Admin/handler.php', {sent: sent}, function (data) {
                $('#d').html(data);
                $('#acc_typeid').val($('#d').text());
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_property_id_combo() {
    try {
        $('.combo_property').change(function () {
            alert('property scriptAddon on  line 116 and method get_property_id_combo');
            var prop = $('.combo_property option:selected').text();
            $.post('../Admin/handler.php', {prop: prop}, function (data) {
                $('#txt_propertyid').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_property_type_id_combo() {
    try {
        $('.combo_property_type').unbind('change').change(function () {
            var prop_type = $('.combo_property_type option:selected').text().trim();
            $('#features_box').html('Loading ...');
            $('#my_cat_res').show().html('Loading ...');

            var house_or_land = prop_type;
            house_or_land = (prop_type !== 'Land') ? '8' : '9';
            $('#house_or_land').val(house_or_land);

            if (prop_type == 'Apartment') {
                $('.aparts_rows').slideDown(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideUp(200);
                $('.basic_dev_rows').slideUp(200);
                $('.development_rows').slideUp(200);
                $('#feature_label').show();
            } else if (prop_type == 'House') {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideDown(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideUp(200);
                $('.basic_dev_rows').slideUp(200);
                $('.development_rows').slideUp(200);
                $('#feature_label').show();
            } else if (prop_type == 'Land') {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideDown(200);
                $('.commercial_rows').slideUp(200);
                $('.basic_dev_rows').slideUp(200);
                $('.development_rows').slideUp(200);
                $('#feature_label').show();
            } else if (prop_type == 'Commercial') {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideDown(200);
                $('.basic_dev_rows').slideUp(200);
                $('.development_rows').slideUp(200);
                $('#feature_label').show();
            } else if (prop_type == 'Development') {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideUp(200);
                $('.development_rows').slideUp(200);
            }
            var prop_type_cat = $('.gen_cat option:selected').text().trim(); //here we  are looking for the property category
            $('#prop_name').val(prop_type_cat);
            var prop_type_cat_id = $('.gen_cat option:selected').val();
            $('#txt_property_type_id').val(prop_type_cat_id);
            $('#combo_tofill').empty();
            $('#combo_tofill').append('<option></option>');
            var c;
            $.post('../Admin/handler.php', {prop_type_cat: prop_type_cat}, function (data) {
                $('#my_cat_res').show().html(data);
                $('#property_subCat_label').show();


//                $('#combo_tofill').append('<option> -- Select the option -- </option>');
                var final = $.parseJSON(data);
                $.each(final, function (i, option) {
                    $('#combo_tofill').append($('<option/>').attr("value", option.id).text(option.name));
                });
            }).complete(function () {
                var features_by_prop_type = $('.combo_property_type option:selected').val().trim();
                $.post('../Admin/handler.php', {features_by_prop_type: features_by_prop_type}, function (data) {
                    $('#features_box').html(data);
                });
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function prop_cat_clicked() {

    //this was replace by the drop change
    $("#combo_tofill").unbind('change').change(function () {
        var prop_cat = $('#combo_tofill option:selected').val().trim();
        $('#txt_property_cat_id').val(prop_cat);
    });
    $('.res_item').unbind('click').click(function () {
    });
}
function get_property_type_id_combo_to_update() {
    try {
        $('.combo_property_type_toUpdate').unbind('change').change(function () {
            alert('change on line 219');
            var prop_type = $('.combo_property_type_toUpdate option:selected').text().trim();
            if (prop_type == 'Apartment') {
                $('.aparts_rows').slideDown(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
            } else if (prop_type == 'House') {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideDown(200);
                $('.land_rows').slideUp(200);
            } else if (prop_type == 'Land') {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideDown(200);
            } else {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
            }
            var prop_type_cat = $('.combo_property_type_toUpdate option:selected').text(); //here we mean that we are looking for the property category
            $.post('../Admin/handler.php', {prop_type_cat: prop_type_cat}, function (data) {
                $('#my_cat_res').show().html(data);
                $('#property_subCat_label').show();
            });
        });
    } catch (err) {
        alert(err.message);
    }

}

function get_provinces_combo() {
    try {
        $('.combo_province').unbind('change').change(function () {
            var province = $('.combo_province option:selected').text().trim();
            $.post('../Admin/handler.php', {province: province}, function (data) {
                var dd = $('#d').html(data);
                $('#txt_province_id').val($('#d').text());
                $('#districts_res').html(data);
            });
        });

    } catch (err) {
        alert(err.message);
    }
}
function get_districts_by_province() {
    $('.combo_province2').change(function () {
        var district_by_prov = $('.combo_province2 option:selected').text();
        var province = $('.combo_province2 option:selected').text();
        $.post('../Admin/handler.php', {district_by_prov: district_by_prov}, function (data) {
            $('#districts_res').show().html(data);
        });
        $.post('../Admin/handler.php', {province: province}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_province_id').val($('#d').text());
        });
    });
}
function get_districts_combo() {//this is found on location form
    $('.combo_district').unbind('change').change(function () {
        var district = $('.combo_district option:selected').text().trim();
        $.post('../Admin/handler.php', {district: district}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_district_id').val($('#d').text());
        });
    });
    //combo_district
}
function get_sectors_combo() {
    $('.combo_sectors').change(function () {
        var sector = $('.combo_sectors option:selected').text();
        $.post('../Admin/handler.php', {sector: sector}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_sector_id').val($('#d').text());
        });
    });
    //combo_district
}

function res_item_selected() {

}// this is for any res_item
function get_cells_by_sector() {
    $('.res_item_sectors').unbind('click').click(function () {
        var cell_by_sector = $(this).html();
        $.post('../Admin/handler.php', {cell_by_sector: cell_by_sector}, function (data) {
            //$('#districts_res').show().html(data);
            $('#res_cell_box').html(data);
        });
        $('.res_item_sectors').css('background', 'none').css('color', '#000080');
        $(this).css('background', '#000080').css('color', '#fff');
    });

    $('#btn_send_listing_loc').click(function () {

        var cell = ('#txt_cell_id').val();
        if (cell == !'') {
            return true;
        } else {
            alert('You have to choose location and specify the cell');
            return false;
        }
    });

}
function get_selected_cell() {
    $('.res_item_cells').click(function () {
        var cell_id = $(this).html();
        $.post('../Admin/handler.php', {cell_id: cell_id}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_cell_id').val($('#d').text());
        });
        $('.res_item_cells').css('background', 'none').css('color', '#000080');
        $(this).css('background', '#000080').css('color', '#fff');
    });
}
function map_loc_link() {
    $('#map_loc_link').click(function () {
//get full
        $('#map_box').show();
        $('#map').show();
        $('#label').show();
        $('#marker_loc').show();
        //show dialog
        //,user-scalable=no'
        get_map_loc();
    });
    $('#map_box').click(function () {

        $(this).hide();
        $('#map_box').hide();
        $('#map').hide();
        $('#label').hide();
        $('#marker_loc').hide();
    });
    $('#marker_loc').click(function () {
        try {
            $('#txt_loc_lat').val(lat);
            $('#txt_loc_lng').val(lng);
            $(this).hide();
            $('#map_box').hide();
            $('#map').hide();
            $('#label').hide();
            $('#marker_loc').hide();
            $('#chosen_lat_long').html($('#txt_loc_lat').val() + ' -  ' + $('#txt_loc_lng').val());
        } catch (err) {
            alert(err.message);
        }


    });
}
function get_map_loc() {
    navigator.geolocation.getCurrentPosition(function (position) {
        $("#result").html("Found your location <br />Lat : " + position.coords.latitude + " </br>Lang :" + position.coords.longitude);
        var myLatLng = {lat: position.coords.latitude, lng: position.coords.longitude};
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,
            center: myLatLng
        });
        marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: 'Me',
            draggable: true
        });
        google.maps.event.addListener(marker, 'drag', function (evt) {
            lat = marker.getPosition().lat();
            lng = marker.getPosition().lng();
            $('#label').html(lat + ' -- ' + lng);
        });
        lat = position.coords.latitude;
        var long = position.coords.longitude;
        $.ajax({url: 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + long + '&sensor=true',
            success: function (data) {
                $('.text_loc').val(data.results[0].formatted_address);
                //alert(data.results[0].formatted_address);
                /*or you could iterate the components for only the city and state*/
            }
        });
    });
//    $('#marker_loc').click(function () {
//        lat = marker.getPosition().lat();
//        lng = marker.getPosition().lng();
//        alert('the marker at:' + lng + ' ' + lat);
//    });
}
function get_districts_by_province() {
    $('.combo_province2').change(function () {
        var district_by_prov = $('.combo_province2 option:selected').text().trim();
        var province = $('.combo_province2 option:selected').text();
        $.post('../Admin/handler.php', {district_by_prov: district_by_prov}, function (data) {
            $('#districts_res').show().html(data);
            alert(data);
        });
        //$.post('../Admin/handler.php', {province: province}, function (data) {
        //    var dd = $('#d').html(data);
        //    $('#txt_province_id').val($('#d').text());
        //});
    });
}
function get_sectors_by_district() {
    $('.res_item_districts').unbind('click').click(function () {
        var sectors_by_district = $(this).html();
        $.post('../Admin/handler.php', {sectors_by_district: sectors_by_district}, function (data) {
//      $('#districts_res').show().html(data);
            $('#res_sector_box').html(data);
        });
        try {
            $('.res_item_districts').css('background', 'none').css('color', '#000080');
            $(this).css('background', '#000080').css('color', '#fff');
            //get the id of the clicked item
            var district = $(this).html();
            // $.post('../Admin/handler.php', {district: district}, function (data) {
            //     var dd = $('#d').html(data);
            //     $('#txt_district_id').val($('#d').text());
            // });
        } catch (err) {
            alert(err.message);
        }
    });
}
function get_new_data_hide_show() {
    $('.new_data_hider').html('Add data');
    $('.new_data_hider').unbind('click').click(function () {
        $('.new_data_box').slideToggle();
    });
}
function get_condition_price_combo() {
    $('#price_condition').change(function () {
        var condition = $('#price_condition option:selected').text();
        if (condition == 'Other') {
            $('#price_cond_textfield').show(300);
            $('#txt_condition_id').val('');
        } else {
            $('#price_cond_textfield').hide(300);
            $('#txt_condition_id').val(condition);
        }
    });
}
function get_utilities_combo() {
    $('#utilities_combo').change(function () {
        var condition = $('#utilities_combo option:selected').text();
        if (condition == 'Other') {
            $('#txt_utilities').show(300);
            $('#txt_utilities').val('');
        } else {
            $('#txt_utilities').hide(300);
            $('#txt_utilities').val(condition);
        }
    });
}
function get_txt_new_listing_area_typed() {
    $('#txt_new_listing_area').unbind('keyup').keyup(function () {
        var search_area_typed = $(this).val();
        $.post('../Admin/handler.php', {search_area_typed: search_area_typed}, function (data) {
            if (search_area_typed != '') {
                $('#new_listing_area_res_box').show(200).html(data);
            } else {
                $('#new_listing_area_res_box').show(200).html('');
            }
        });
    });
}
function get_area_clicked() {
    $('.location_data_item').click(function () {

        $('#txt_new_listing_area').val($(this).html());
        $('#new_listing_area_res_box').html('').slideUp(300);

    });
}
function get_listing_type_data_res_selected() {
    $('.listing_type_data_res').click(function () {
        $('.listing_type_data_res').css('background-color', 'transparent').css('color', '#000080');
        $(this).css('background-color', '#000080').css('color', '#fff');
        var id = $(this).children('span:first').html();
        $('#listing_type_chosen').html($(this).html());
        $('#listing_type').val(id);
    });
}
function get_more_images() {
    $('#add_more').click(function () {
        var id = 0;
        var current_count = $('input[type="file"]').length;
        var next_count = current_count + 1;
        var last_listing = '200';
        $.post('../Admin/handler.php', {last_listing: last_listing}, function (data) {
            id = data;
        }).complete(function () {
            id += 1;
            $('#new_img').prepend('<p> <input type="file" name="files_up[]"  /> </p>');
        });
    });
}
function get_all_uploaded_image() {
    if (window.File && window.FileList && window.FileReader) {
        $("#files").unbind('change').on("change", function (e) {
            var files = e.target.files,
                    filesLength = files.length;
            for (var i = 0; i < filesLength; i++) {
                var f = files[i];
                var fileReader = new FileReader();
                fileReader.onload = (function (e) {
                    var file = e.target;
                    $("<span class=\"pip\">" +
                            "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
                            "<br/><span class=\"remove\">Remove image</span>" +
                            "</span>").insertBefore("#files");
                    $(".remove").click(function () {
                        $(this).parent(".pip").remove();
                    });
                    // Old code here
                    /*$("<img></img>", {
                     class: "imageThumb",
                     src: e.target.result,
                     title: file.name + " | Click to remove"
                     }).insertAfter("#files").click(function(){$(this).remove();});*/
                });
                fileReader.readAsDataURL(f);
            }
        });
    } else {
        alert("Your browser doesn't support to File API");
    }
}
function get_homepage_hovables() {
    $('#home_hovables_box  #drop1').mouseover(function () {
        $('#home_hovables_box #hov1').slideDown(200);
    });
    $('#home_hovables_box  #drop1').mouseleave(function () {
        $('#home_hovables_box #hov1').slideUp(200);
    });
    $('#home_hovables_box  #drop2').mouseover(function () {
        $('#home_hovables_box #hov2').slideDown(200);
    });
    $('#home_hovables_box  #drop2').mouseleave(function () {
        $('#home_hovables_box #hov2').slideUp(200);
    });
    $('#home_hovables_box  #drop3').mouseover(function () {
        $('#home_hovables_box #hov3').slideDown(200);
    });
    $('#home_hovables_box  #drop3').mouseleave(function () {
        $('#home_hovables_box #hov3').slideUp(200);
    });
}
function home_menu_links() {
    $('#wht_we_do_link').click(function () {
        $('#full_dialog').fadeIn(200);
        $('#close_btn').fadeIn(300);
        $("#about_us_box").fadeIn(300);
    });
    $('#close_btn').click(function () {
        $('#full_dialog').fadeOut(200);
        $('#about_us_box').hide(300);
        $("#what_wedo_box").hide(300);
        $('.what_weare_box').fadeOut(300);
        $('#admin_box').fadeOut(300);
        $('#agent_box').fadeOut(200);
        $(this).hide(300);
    });
    $('#wht_we_are_link').click(function () {
        $('#full_dialog').fadeIn(200);
        $('#close_btn').fadeIn(300);
        $('#what_weare_box').fadeIn(300);
    });
    $('#admin_link').click(function () {
        $('#full_dialog').fadeIn(200);
        $('#close_btn').fadeIn(300);
        $('#admin_box').fadeIn(200);
    });
    $('#agent_link').click(function () {
        $('#full_dialog').fadeIn(200);
        $('#close_btn').fadeIn(300);
        $('#agent_box').fadeIn(200);
    });
}
function get_location_listing() {
    $('#loc_province').click(function () {
        $('#loc_all_prov').slideDown(300);
        $('#loc_all_distr').slideUp(300);
        $('#loc_all_sectors').slideUp(300);
        $('#loc_all_cells').slideUp(300);
        $('#chosen_district').html('');
        $('#chosen_sector').html('');
        $('#chosen_cell').html('');
    });

    $('#sp_combo_prov').unbind('change').change(function () {
        var district_by_prov = $('#sp_combo_prov option:selected').val().trim();
        $('#sp_combo_distr').empty();
        $('#sp_combo_distr').append('<option> -- District -- </option>');
        $.post('../Admin/handler.php', {district_by_prov: district_by_prov}, function (data) {
            var final = $.parseJSON(data);
            $.each(final, function (i, option) {
                $('#sp_combo_distr').append($('<option/>').attr("value", option.id).text(option.name));
            });
        });

    });
    $('#sp_combo_distr').unbind('change').change(function () {
        var sectors_by_district = $('#sp_combo_distr option:selected').val().trim();
        $('#sp_combo_sectr').empty();
        $('#sp_combo_sectr').append('<option> -- Sector -- </option>');
        $.post('../Admin/handler.php', {sectors_by_district: sectors_by_district}, function (data) {
            var final = $.parseJSON(data);

            $.each(final, function (i, option) {
                $('#sp_combo_sectr').append($('<option/>').attr("value", option.id).text(option.name));
            });
        });
    });
    $('#sp_combo_sectr').unbind('change').change(function () {
        var cell_by_sector = $('#sp_combo_sectr option:selected').val().trim();
        $('#sp_combo_cell').empty();
        $('#sp_combo_cell').append('<option> -- Cell -- </option>');
        $.post('../Admin/handler.php', {cell_by_sector: cell_by_sector}, function (data) {
            var final = $.parseJSON(data);

            $.each(final, function (i, option) {
                $('#sp_combo_cell').append($('<option/>').attr("value", option.id).text(option.name));
            });
        });
    });
    $('#sp_combo_cell').unbind('change').change(function () {
        var new_district_by_prov = $('#sp_combo_cell option:selected').val().trim();

        $('#txt_cell_id').val(new_district_by_prov);

    });

}
function get_feature_checked() {
    $('.small_margin').click(function () {
//            $(this).children('.fear_checkbxes').prop('checked', true);

    });
}

function get_request_accepted() {
    $('.request_link').unbind('click').click(function () {
        var req = $(this).attr('value');
        var req_id = $(this).closest('td').siblings('.request_col').html().trim();
        var req_accepted = req_id;
        $.post('../Admin/handler.php', {req_accepted: req_accepted}, function (data) {

        }).complete(function () {
            $('#rpt_details_dialog').fadeIn(200);
            $('#rpt_det_contents').fadeIn(200);
            $('#rpt_det_contents').html('Loading ...');
            var det_report = req;
            $.post('../Admin/handler.php', {det_report: det_report}, function (data) {
                $('#rpt_det_contents').html(data);

            });
        });
    });
}
function feat_chosen() {
    $('.fear_checkbxes').on('change', function () {
        if ($(this).is(':checked')) {
            var feat = $('#feat_chosen').val().trim();
            if (feat == '') {
                $('#feat_chosen').val('feact chosen');
            }
        } else if (!$(this).is(':checked')) {
            var selected = [];
            var n = 0;
            $('#features_box input:checked').each(function () {
                selected.push($(this).attr('name'));
                n += 1;
            });
            if (n < 1) {
                $('#feat_chosen').val('');
                $('#last_feat').val('');
            }
        }
    });

}

//<editor-fold defaultstate="collapsed" desc="----Price--------------">
function utils_chosen() {
    $('.util_checkbxes').on('change', function () {
        if ($(this).is(':checked')) {
            $('#txt_utilities').val('available');
        } else if (!$(this).is(':checked')) {
            var selected = [];
            var n = 0;
            $('#utilities_box input:checked').each(function () {
                selected.push($(this).attr('name'));
                n += 1;
            });
            if (n < 1) {
                $('#txt_utilities').val('');
                $('#util_exist').val('');
            }
        }
    });
}

//</editor-fold>

function comment_del_udpate() {
    $('.comment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.comment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcomment.. 
    $('.comment_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.comment').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from comment_replies ...
function comment_replies_del_udpate() {
    $('.comment_replies_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.comment_replies').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcomment_replies.. 
    $('.comment_replies_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.comment_replies').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}

//update listings

function currency_updates() {
    $('#txt_month_currency').unbind('change').change(function () {
        var curncy = $('#txt_month_currency option:selected').val().trim();
        var amount = $('#txt_amount').val();
        if ($('#txt_amount_per_day').val() == '') {
            $("#amount_day_select").val(curncy);
        }
        if ($('#txt_price_square_meter_per_day').val() == '') {
            $('#perSqaure_select').val(curncy);
        }
        $('#curncy_box').html('converting ...');
        if (amount != '') {
            // get rate in db
            $('#curncy_box_month').html('Converting  ...');
            $.post('../Admin/new_currency.php', {curncy: curncy, amount: amount}, function (data) {
                $('#curncy_box_month').html(data);
            }).error(function () {
                $('#curncy_box_month').html('converting (local) ...');
            });
        }
    });

    $('#amount_day_select').unbind('change').change(function () {
        var curncy = $('#amount_day_select option:selected').val().trim();
        var amount = $('#txt_amount_per_day').val();
        if (amount >= 1) {
            $('#equiv_day').html('converting ...');
            $.post('../Admin/new_currency.php', {curncy: curncy, amount: amount}, function (data) {
                $('#equiv_day').html(data);
            });
        }

    });
    $('#perSqaure_select').unbind('change').change(function () {
        var curncy = $('#perSqaure_select option:selected').val().trim();
        var amount = $('#txt_price_square_meter_per_day').val();
        if (amount >= 1) {
            $('#curncy_box_square').html('converting ...');
            $.post('../Admin/new_currency.php', {curncy: curncy, amount: amount}, function (data) {
                $('#curncy_box_square').html(data);
            });
        }
    });
    //per month textbox
    //
    //this is to calcua=late while typing the amount in the textboxes. the chack 
//must be done when other fields are done the amount.
//

    $('#txt_amount').unbind('keyup').keyup(function () {
        var curncy = $('#txt_month_currency option:selected').val().trim();
        var amount = $('#txt_amount').val();
        if (amount != '') {

            $('#curncy_box_month').html('converting ...');
            $.post('../Admin/new_currency.php', {curncy: curncy, amount: amount}, function (data) {
                $('#curncy_box_month').html(data);
            }).error(function () {
                $('#curncy_box_month').html('converting (local) ...');
            });
        }
    });
    $('#txt_amount_per_day').unbind('keyup').keyup(function () {
        var curncy = $('#amount_day_select option:selected').val().trim();
        var amount = $('#txt_amount_per_day').val();
        if (amount >= 1) {
            $('#equiv_day').html('converting ...');

            $.post('../Admin/new_currency.php', {curncy: curncy, amount: amount}, function (data) {
                $('#equiv_day').html(data);
            });
        }
    });
    $('#txt_price_square_meter_per_day').unbind('keyup').keyup(function () {
        var curncy = $('#perSqaure_select option:selected').val().trim();
        var amount = $('#txt_price_square_meter_per_day').val();
        if (amount >= 1) {
            $('#curncy_box_square').html('converting ...');
            $.post('../Admin/new_currency.php', {curncy: curncy, amount: amount}, function (data) {
                $('#curncy_box_square').html(data);
            });
        }
    });
}

function update_listing_image() {
    $('.id_listing_to_update').click(function () {
        var id = $(this).attr('value');
        $('#txt_listing_id').val(id);
        $(this).closest('tr').css('background-color', '#000086').css('color', '#fff');
        $('#images_dialog').fadeIn(200);
        $("#title_prop").fadeIn(300);
        $("#child_dialog").fadeIn(300);
        var prop_title = $(this).closest('td').siblings('.listing_title_col').text().trim();
        $('#title_prop').html(prop_title);
        return false;
    });
    $('#images_dialog').click(function () {
        $(this).fadeOut(300);
        $('#title_prop').fadeOut(330);
        $("#child_dialog").fadeOut(300);
        $('#child_prices').fadeOut(200);
    });
}
function hide_rpt_details() {
    $('#rpt_details_dialog').click(function () {
        $('#rpt_details_dialog').fadeOut(200);
    });
}
function update_listing_price() {
//when we click the link
    $('.id_listing_to_update_price').click(function () {
        $('#child_prices').fadeIn(200);
        $('#images_dialog').fadeIn(200);
        var listing_id = $(this).attr('value');
        $('#txt_listing_id').val(listing_id);
        var prop_title = $(this).closest('td').siblings('.listing_title_col').text().trim();
        $('#listing_title').html('Property Title: ' + prop_title);
    });
    $('#deposity').on('change', function () {
        if ($(this).is(':checked')) {
            $('#txt_deposit_toggle').val('deposit evailable');
        }
    });
}
//this si the homepage report

//Defaults
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
//here its fine!.
        } else {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });
    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function get_image_deleted() {//here are also deleting many images at the same time
    $('.trash_icon').unbind('click').click(function () {
        var delete_image = $(this).data('imageid');// the image path
        var image_id = $(this).data('image_id');// the image id
        $(this).closest('.imageedit_box').slideUp();
        $.post('../Admin/handler.php', {image_id: image_id, delete_image: delete_image}, function (data) {
            
        });
    });

}
//<editor-fold defaultstate="collapsed" desc="------new_location ------">
function tab_switch() {
    $('.selected_tab').css('background-color', '#ddd5be').css('box-shadow', '0px 0px 10px #000').css('margin-right', '10px;');
    $('#tab1').unbind('click').click(function () {
        $('.tab_content').hide();
        $('#tab1_content').show();
    });
    $('#tab2').unbind('click').click(function () {
        $('.tab_content').hide();
        $('#tab2_content').show();

    });
    $('.tab_buttons').click(function () {
        $('.tab_buttons').css('background-color', '#fff').css('box-shadow', 'none');
        $(this).css('background-color', '#ddd5be').css('box-shadow', '0px 0px 10px #000').css('margin-right', '10px;');
    });
}
function cell_del_udpate() {
    $('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('new_redirect.php');
        });
    });//delete fromcell.. 
    $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();
        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from district ...


//</editor-fold>
function menu() {
    $('.dash_main_menu_link').unbind('click').click(function () {
        $('.sub_menu').slideToggle();
        return false;
    });
    $('#dshM_menu_lnk_user').click(function () {
        $('#dshM_menu_lnk_user').show();
        $('#users_sm').show();
        $('#feat_sm').hide();
        $('#prpty_sm').hide();
        $('#users_sm').hide();
    });
    $('#dshM_menu_lnk_feat').click(function () {
        $('#dshM_menu_lnk_feat').show();
        $('#users_sm').hide();
        $('#feat_sm').show();
        $('#prpty_sm').hide();
        $('#users_sm').hide();
    });
    $('#dshM_menu_lnk_Properties').click(function () {
        $('#dshM_menu_lnk_Properties').show();
        $('#users_sm').hide();
        $('#feat_sm').hide();
        $('#prpty_sm').show();
        $('#users_sm').hide();
    });

    $('#dshM_menu_lnk_currencies').click(function () {
        $('#dshM_menu_lnk_currencies').show();
        $('#users_sm').hide();
        $('#feat_sm').hide();
        $('#prpty_sm').hide();
        $('#users_sm').hide();
    });

}
//<editor-fold defaultstate="collapsed" desc="----images ------">
function addmoreimages_link() {
//    $('#tab1').unbind('click').click(function () {
//       $('#tab2_content').slideToggle();
//       
//    });
}
function select_all_images() {

    $('#select_all_images').unbind('click').click(function () {
        $('.image_checkbx').prop('checked', true);
        return false;
    });
    $('#deleteAll_images').unbind('click').click(function () {
        var delete_All_image_bySession = "<?php echo $_SESSION['complete_updating']; ?>";
//        $('.imageedit_box').addClass('selected_images');
//        $('.warn_dialogs').fadeIn(300);
        $('.imageedit_box').slideUp();
        var call_dialog = 'Do you really want to delete all images?';
        var my_data = '';
        postDisplayData('Do you really want to clear all images??', '#more_dialogs');
//        
//        
//        $.post('../Admin/handler.php', {delete_All_image_bySession: delete_All_image_bySession}, function (data) {
//            alert(data);
//        });
    });
}
function postData(msg) {
    $.post('../Admin/handler.php', {msg: msg}, function (data) {

    });
}
function postDisplayData(call_dialog, div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}
function dlog_btn_No_Yes() {
    $(document).on('click', '#dlog_btnNo', function () {
        $('#dlog_btnNo').unbind('click');
        $('.msg_dialog').slideUp(300);
        $('.new_absfull').fadeOut();
    });
    $(document).on('click', '#dlog_btnYes', function () {
        $('#dlog_btnYes').off('click', '#dlog_btnYes');
        alert('Now accepted');
    });
}
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="-------reports delete, update, enable and details -------------">
function get_rpt_listing_by_date() {
    try {
        $('#listing_btn').unbind('click').click(function () {
            $('#rprt_res_today_report').slideUp(300);
            var search_combo_item = $('#search_option_combo option:selected').text().trim();
            if (search_combo_item == 'By a date') {
                $('#rprt_res_box').html('Loading ...');
                var listing_date = $('#txt_date_pick').val();
                var end_date = $('.end_date').val();
                $.post('../Admin/handler.php', {listing_date: listing_date, end_date: end_date}, function (data) {
                    $('#rprt_res_box').html('Listings done on ' + listing_date + ': <br/>' + data);
                });
            } else if (search_combo_item == 'By a year') {
                $('#rprt_res_box').html('Loading ...');
                var listing_date_year = $('#txt_year_pick').val();
                $.post('../Admin/handler.php', {listing_date_year: listing_date_year}, function (data) {
                    $('#rprt_res_box').html('Listings done in ' + listing_date_year + ' :<br/>' + data);
                });
            } else if (search_combo_item == 'By a listing type & date') {
                $('#rprt_res_box').html('Loading ...');
                var listing_date_prop_type_date = $('#txt_date_pick').val();
                var listing_date_prop_type = $('#txt_prop_type_combo option:selected').text();
                $.post('../Admin/handler.php', {listing_date_prop_type: listing_date_prop_type, listing_date_prop_type_date: listing_date_prop_type_date}, function (data) {
                    $('#rprt_res_box').html('Listings done on ' + listing_date_prop_type_date + ', ' + listing_date_prop_type + ' :<br/>' + data);
                });
            }
            $('#rprt_res_box').addClass('more_shades');
        });
        $('#listing_btn_all').unbind('click').click(function () {
            var cont_rpt_all = 'c';
            $('#rprt_res_today_report').hide();
            $('#rprt_res_box').html('Loading ...');
            $.post('../Admin/handler.php', {cont_rpt_all: cont_rpt_all}, function (data) {
                $('#rprt_res_box').html('Listings done from the beginning :<br/>' + data);
            }).complete(function () {

            });
        });
    } catch (err) {
        alert(err.message);
    }
    $('#search_option_combo').unbind('change').change(function () {
        var search_combo_item = $('#search_option_combo option:selected').text().trim();
        if (search_combo_item == 'By a date') {
            $('#txt_date_pick').slideDown();
            $('.end_date').slideDown();
            $('#txt_year_pick').slideUp();
            $('#txt_prop_type_combo').hide(100);
        } else if (search_combo_item == 'By a year') {
            $('#txt_date_pick').slideUp();
            $('.end_date').slideUp();
            $('#txt_year_pick').slideDown();
            $('#txt_prop_type_combo').hide(100);
        } else if (search_combo_item == 'By a listing type & date') {
            $('#txt_date_pick').slideDown();
            $('.end_date').slideUp();
            $('#txt_year_pick').slideUp();
            $('#txt_prop_type_combo').show(200);
        }
    });
    $('.rprt_more_details_btn').on('click',function () {
        var det_report = $(this).children('span:first').html();
        $('#rpt_det_contents, #rpt_details_dialog').fadeIn(200);
        $('#rpt_det_contents').html('Loading ...');
        $.post('../Admin/handler.php', {det_report: det_report}, function (data) {
            $('#rpt_det_contents').html(data);
        });
    });
    $('#rpt_details_dialog').on('click',function () {
        $('#rpt_det_contents').fadeOut(200);
    });
    $('.rprt_delete_listing_btn').on('click',function () {
        var lising_delete = $(this).children('span:first').html();
        $(this).closest('.by_date_container').slideUp(300);
        $.post('../Admin/handler.php', {lising_delete: lising_delete}, function (data) {
            alert(data);
        }).complete(function () {
            $(this).closest('.by_date_container').slideUp(300);
        });
    });
    $('.rprt_update_listing_btn').on('click',function () {
        var lst_comple_update = $(this).children('span:first').html();
        $.post('../Admin/handler.php', {lst_comple_update: lst_comple_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });
}
function enable_report() {
    $('.rprt_enable_listing_btn').unbind('click').click(function () {
        var enable_listing = $(this).data('enable_lstid');
        var status = $(this).html().trim();
        var btn = $(this);
        
        if (status == 'Enable') {
            $.post('handler.php', {status: status, enable_listing: enable_listing}, function (data) {
                
            }).complete(function () {
                $(btn).html('Disable');
            });
        } else if (status == 'Disable') {
            $.post('handler.php', {status: status, enable_listing: enable_listing}, function (data) {
               
            }).complete(function () {
                $(btn).html('Enable');
            });
        }
    });
    
    
    $('#view_home_page').unbind('click').click(function () {
        $('#homePage_holder').load('../home/index.php');
    });
 
}
//</editor-fold>
//
 
