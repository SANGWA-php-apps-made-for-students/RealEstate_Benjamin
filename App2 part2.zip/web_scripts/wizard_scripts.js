
var refresh_stop = false;
var timer_val;
var working_listing_id;
refresh_count = 0;
$(document).ready(function () {
    try {
        wizard_step_click();
        get_uncomplete_steps();
        cat_item_clicked();
        util_chosen();
//        feat_chosen();
    } catch (err) {
        alert(err.message);
    }
});
function wizard_step_click() {
    // var account='<?php  echo $_SESSION['account'] ?>';
    $('#wiz_1').unbind('click').click(function () {
        var the_step = $('#txt_process').val().trim();
        var changes = $('#changes').val();

        if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
            wiz_step1();
            $('#Editing_mode').val('update');
            // $('#property_desc_title').slideUp(500).slideDown(700).html('UDPATING LISTING');
            var prop_type = $('#update_property_type_id').val().trim();
            var prop_cat = $('#update_property_category_name').val();
            
//            $('#property_subCat_label').show();
//            $('#my_cat_res').show().html('<div class="parts res_item pro_cat_data_item"><span class="off">' + prop_type + '</span>' + prop_cat + '</div>');
//            $('#my_cat_res').show();
//            $('.list_type_combo').val($('#update_listing_type').val());
//            $('.combo_property_type').val($('#update_property_type_id').val());
//            $('#txt_title').val($('#update_title').val());
//            var desc = $('#update_description').val();
//            $('#txt_desc').val(desc);
            if (prop_type == 8) {//this is the basic partment of the house
                $('.aparts_rows').slideDown(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideUp();
                $('.development_rows').slideUp(200);
                Last_apart_details();
                display_relative_features(prop_type);
            } else if (prop_type == 9) {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideDown();
                $('.development_rows').slideUp(200);
                Last_comm_details();
                display_relative_features(prop_type);
            } else if (prop_type == 10) {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideDown(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideUp();
                $('.development_rows').slideUp(200);
                Last_house_details();
                display_relative_features(prop_type);
            } else if (prop_type == 11) {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideDown(200);
                $('.commercial_rows').slideUp();
                $('.development_rows').slideUp(200);
                Last_land_details();
                display_relative_features(prop_type);
            } else if (prop_type == 12) {
                $('.aparts_rows').slideUp(200);
                $('.house_rows').slideUp(200);
                $('.land_rows').slideUp(200);
                $('.commercial_rows').slideUp();
                $('.development_rows').slideDown();
                Last_dev_details();
            }
        }
    });
    $('#wiz_2').unbind('click').click(function () {
        var the_step = $('#txt_process').val().trim();
        var changes = $('#changes').val();
        if (the_step == 'price' || the_step == 'location' || the_step == 'image') {
            wiz_step2();
            toggle_rent_sale_price();
        }
        if (the_step == 'location' || the_step == 'image') {
            $('#Editing_mode').val('update');
            $('#Editing_mode_price').val('update');
            $('#txt_amount').val($('#update_price_amount').val());
            $('#txt_month_currency').val($('#update_price_currency').val());
            $('#txt_minimum_advance').val($('#update_price_Minimum_advance').val());
            $('#deposity').val($('#update_price_deposit_required').val());
            $('#txt_commission').val($('#update_price_commission').val());
            $('#price_condition').val($('#update_price_condition').val());
            $('#utilities_combo').val($('#update_price_utilities_extra').val());
            $('#price_condition').val($('#update_price_condition_per_day').val());
            $('#txt_amount_per_day').val($('#update_price_amount_per_day').val());
            $('#txt_condition_per_day').val($('#update_price_condition_per_day').val());
            $('#txt_minimum_advance_per_day').val($('#update_price_minimum_advance_per_day').val());
            $('#txt_deposit_required_per_day').val($('#update_price_deposit_required_per_day').val());
            $('#txt_commission_per_day').val($('#update_price_commission_per_day').val());
//            $('#txt_utilities_extra_per_day').val($('#update_price_utilities_extra_per_day').val());
            var utilities_chk = 'c';
            $.post('../Admin/handler.php', {utilities_chk: utilities_chk}, function (data) {
                $('#d').html(data);
                var c = $('#d').text().trim();
                var parsed = $.parseJSON(c);
                var arr = [];
                for (var x in parsed) {
                    arr.push(parsed[x]);
                }
                for (var i = 0; i < arr.length; i++) {
                    console.log(arr[i]);
                    var chk = arr[i].trim();
                    //                $(":checkbox[value=" + chk + "]").prop("checked", "true");
                    $("#utilities_box").find("input[type=checkbox][value=" + chk + "]").prop("checked", true);
                }
            }).complete(function () {
                $("#utilities_box").css('background', '$00ddcc');
            });
            toggle_rent_sale_price();
        }
    });
    $('#wiz_3').unbind('click').click(function () {
        var the_step = $('#txt_process').val().trim();
        var changes = $('#changes').val();
        $('.aparts_rows').slideUp(200);
        $('.house_rows').slideUp(200);
        $('.land_rows').slideUp(200);
        $('.commercial_rows').slideUp();
        $('.development_rows').slideUp(200);
        if (the_step == 'location' || the_step == 'image') {
            wiz_step3();
            $('#Editing_mode').val('update');
        }
        if (the_step == 'image') {
            var cell, sector, district, province, long, lat, area;
            var address, cell_name;
            cell = $('#updateLoc_txt_cell_id').val();
            cell_name = $('#updateLoc_txt_cell_name').val();
            sector = $('#updateLoc_txt_sector_id').val();
            district = $('#updateLoc_txt_district_id').val();
            province = $('#updateLoc_txt_province_id').val();

            long = $('#updateLoc_txt_loc_long').val();
            lat = $('#updateLoc_txt_loc_lat').val();
            area = $('#updateLoc_txt_area').val();
            address = $('#updateLoc_txt_address').val();

            $('#txt_cell_id').val(cell);
            $('#txt_loc_lat').val(lat);
            $('#txt_new_listing_area').val(area);
            $('#txt_loc_lng').val(long);
            $('#txt_addressf').val(address);

            $('#chosen_province').html(province);
            $('#chosen_district').html(district);
            $('#chosen_sector').html(sector);
            $('#chosen_cell').html(cell_name);// this is the cell name for user
            $('#txt_cell_id').html(cell_name);//this is the cell id for db

            $('#loc_all_prov').slideUp(300);
            $('#loc_all_distr').slideUp(300);
            $('#loc_all_sectors').slideUp(300);
            $('#loc_all_cells').slideUp(300);
        }
    });
    $('#wiz_4').unbind('click').click(function () {
        var the_step = $('#txt_process').val().trim();
        var changes = $('#changes').val();
        if (the_step == 'image') {
            wiz_step4();
        }
        $('#Editing_mode').val('update');
    });
}
function cat_item_clicked() {
    $('#pro_cat_data_item').click(function () {
        alert('click');
        $(this).css('background', '#000080').css('color', '#fff');
    });


}

function display_relative_features(prop_type) {
    var features_by_prop_type = prop_type;
    var features_last_listing = 'c';
    var changes = $('#data_found').val().trim();
    var c = $('#d').text().trim();
    var parsed = $.parseJSON(c);
//      $("#" + data[i]).attr("checked", "checked");
    var arr = [];
    for (var x in parsed) {
        arr.push(parsed[x]);
    }
    for (var i = 0; i < arr.length; i++) {
        console.log(arr[i]);
        var chk = arr[i].trim();
        //$(":checkbox[value=" + chk + "]").prop("checked", "true");
        $("#features_box").find("input[type=checkbox][value=" + chk + "]").prop("checked", true);
    }

}
function Last_apart_details() {
    var bed, bath, floon, nfloo, furnished;
    bed = $('#update_basic_aprt_bedrooms').val();
    bath = $('#update_basic_aprt_bathrooms').val();
    floon = $('#update_basic_aprt_flor_no').val();
    nfloo = $('#update_basic_aprt_tot_no').val();
    furnished = $('#update_basic_aprt_furnished').val();

    $('#txt_apart_bedrooms').val(bed).css('backround-color', '#0044cc');
    $('#txt_apart_bathrooms').val(bath);
    $('#txt_apart_floorNo').val(floon);
    $('#txt_total_number_floors').val(nfloo);
    $('#apart_furnished').val(furnished);

}
function Last_comm_details(res) {
    $('#txt_comm_bedroom').val($('#basic_comm_bedrooms').val());
    $('#txt_comm_bathroom').val($('#update_basic_comm_bathrooms').val());
    $('#txt_comm_total_number_floors').val($('#update_basic_comm_total_noFlor').val());
    $('#txt_comm_compound_size').val($('#update_basic_comm_compound_size').val());
    $('#txt_comm_living_floors').val($('#update_basic_comm_living_flor').val());
    $('#txt_comm_furnished').val($('#update_last_basic_comm_furnished').val());

}
function Last_house_details(res) {
    $('#txt_house_furnished').val($('#update_basic_house_furnished').val());
    $('#txt_house_available_from').val($('#update_basic_available_from').val());
    $('#txt_house_bedroom').val($('#update_basic_house_bedrooms').val());
    $('#txt_house_bathroom').val($('#update_basic_house_bathrooms').val());
    $('#txt_house_total_number_floors').val($('#update_basic_total_number_floors').val());

    $('#txt_house_compound_size').val($('#update_basic_house_compound_size').val());
    $('#txt_house_living_floors').val($('#update_basic_house_living_floor').val());
}
function Last_land_details(res) {
    $('#d').html(res);
    $('#txt_administrative_loc').val($('#update_basic_administrative_location').val());
    $('#txt_plot_number').val($('#update_basic_land_plot_no').val());
    $('#txt_plot_size').val($('#update_basic_land_plot_size').val());
    $('#txt_lot_use').val($('#update_basic_lot_use').val());
    $('#txt_plot_available_from').val($('#update_basic_land_available_from').val());


}
function Last_dev_details() {
    $('#txt_dev_bedroom').val($('#update_basic_dev_bedrooms').val());
    $('#txt_dev_bathroom').val($('#update_basic_dev_bathrooms').val());
    $('#txt_dev_total_number_floors').val($('#update_basic_dev_total_N_Floo').val());
    $('#txt_dev_compound_size').val($('#update_basic_dev_compound_size').val());
    $('#txt_dev_living_floors').val($('#update_basic_dev_living_flor').val());
    $('#dev_dev_furnished').val($('#update_basic_dev_furnished').val());
}

function changeable_link_property() {
    $('#changeable_link_property').click(function () {
        $('.combo_property_type_toUpdate').slideDown(200);
        return false;
    });
}
function wiz_step1() {
//    $('#wiz_step1').show();
//     $('#wiz_step1').show("slide", {direction: "right"}, 800);
    $("#wiz_step1").show("drop", {direction: "down"}, 600);
    $('#wiz_step2').hide();
    $('#wiz_step3').hide();
    $('#wiz_step4').hide();
    $('.wizard_steps').css('background-color', 'transparent');
    $('.wizard_steps').css('border-color', '#fff');
    $('#wiz_1').css('border-color', '#000086');
    $('#wiz_1').css('background-color', '#fff');

}
function wiz_step2() {
    $('#wiz_step1').hide();
    $("#wiz_step2").show("drop", {direction: "down"}, 600);
    $('#wiz_step3').hide();
    $('#wiz_step4').hide();
    $('.wizard_steps').css('background-color', 'transparent');
    $('.wizard_steps').css('border-color', '#fff');
    $('#wiz_2').css('border-color', '#000086');
    $('#wiz_2').css('background-color', '#fff');
    toggle_rent_sale_price();
}
function wiz_step3() {
    $('#wiz_step1').hide();
    $('#wiz_step2').hide();
    $("#wiz_step3").show("drop", {direction: "down"}, 600);
    $('#wiz_step4').hide();
    $('.wizard_steps').css('background-color', 'transparent');
    $('.wizard_steps').css('border-color', '#fff');
    $('#wiz_3').css('border-color', '#000086').css('background-color', '#fff');
}
function wiz_step4() {
    $('#wiz_step1').hide();
    $('#wiz_step2').hide();
    $('#wiz_step3').hide();
    $("#wiz_step4").show("drop", {direction: "down"}, 600);
    $('.wizard_steps').css('background-color', 'transparent');
    $('.wizard_steps').css('border-color', '#fff');
    $('#wiz_4').css('border-color', '#000086');
    $('#wiz_4').css('background-color', '#fff');
}

function toggle_rent_sale_price() {
    //this displays the fields of square meter, on price wizard step
    var listing_type = '';
    var prop_type = $('#update_listing_type').val().trim();
    var propertt_type_new = $('#listing_type').val().trim();
    var listing_type = (prop_type != '') ? prop_type : propertt_type_new;
    if (listing_type == 1) {
        $('#hide_amount_day').show();
        $('#equivalent_price_day').show();
        $('#currency_amount').show();
    } else {
        $("#hide_amount_day").hide();
        $('#equivalent_price_day').hide();
        $('#currency_amount').hide();
    }

}
function show_basic_details_aparts() {
    $('.aparts_rows').slideDown(200);
    $('.house_rows').slideUp(200);
    $('.land_rows').slideUp(200);
}
function show_basic_details_house() {
    $('.aparts_rows').slideUp(200);
    $('.house_rows').slideDown(200);
    $('.land_rows').slideUp(200);
}
function show_basic_details_land() {
    $('.aparts_rows').slideUp(200);
    $('.house_rows').slideUp(200);
    $('.land_rows').slideDown(200);
}

function feat_chosen() {
    $('.fear_checkbxes').on('change', function () {
        if ($(this).is(':checked')) {
            alert('the ffeat');
        }
    });
}


