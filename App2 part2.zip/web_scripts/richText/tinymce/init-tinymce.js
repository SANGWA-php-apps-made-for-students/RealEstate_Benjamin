tinymce.init({
    selector:"textarea.tinymce",
    menubar:false,
    statusbar: false,
    toolbar:false,
    height: 100,
    branding:false
});
