<?php
session_start();

if (isset($_POST['send_comment'])) {
    $commentdeleted = 'no';
    $message = $_POST['txt_message'];
    $account = $_SESSION['userid'];
    $date = date('y-m-d');
    $listing = $_POST['listing'];
    new_comment($commentdeleted, $message, $account, $date, $listing);
}
?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Detailed information</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            a{
                color: #fff;
                text-decoration: none;
                font-size: 16px;
            }
            #phone_contact{
                position: absolute;
                top: 0px;

            }
            .contact_phone{/*this is the holder*/
                color: #008000;
                padding: 8px;

            }
            .contact_phone_btn{
                background-color: #c8ff00;

            }
            #phone_dialog{
                width: auto;
                background-color:  #dab3ff;
                margin-left: 30%;
                height: auto;
            }
            table{
                background-color: #dab3ff;
            }

        </style>
    </head>
    <body>
        <form action="home_report.php" method="post" id="data_form">
            <div class="parts abs_full home_abs_full" id="full_bg_dialog">
            </div>
            <div class="parts iconed no_paddin_shade_no_Border link_cursor" id="close_btn">

            </div>
            <div class="parts abs_child home_abs_full" id="phone_dialog">
                <table>
                    <tr>
                        <td>Your phone number</td>
                        <td><input type="text" id="txt_contact_phone" class="textbox" name="txt_contact_phone" /></td>
                    </tr>
                    <tr>
                        <td>Your full name</td>
                        <td> <input type="text" id="txt_contact_names" class="textbox" name="txt_contact_names" /></td>
                    </tr>
                    <tr>
                        <td>Your Email</td>
                        <td> <input type="email" id="txt_contact_email" class="textbox" name="txt_email_names" /></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <input type="button" class="confirm_buttons" id="close_request_btn" value="Close" name="send_request" />
                            <input type="button" class="confirm_buttons" id="send_request_btn" value="Send" name="send_request" /></td>
                    </tr>
                </table>
            </div>
            <div class="parts eighty_centered " style="background-color: #fff; position: relative;  " id="get_id">
                <input type="hidden" id="txt_listing_id" name="listing" value="<?php echo $_POST['my_id']; ?>"/>
                <div style="margin-top: 60px;">
                    <?php
                    if (isset($_POST['my_id']) && !isset($_SESSION['go_res'])) {
                        $id = $_POST['my_id'];
                        get_rpt_listing_by_id($id);
                    }
                    ?>
                </div>

            </div>
            <div class="parts eighty_centered">
                <?php
//                require_once './web_db/multi_values.php';
                $first = get_first_comment();
//                list_comment($first);
                ?>
                <table class="new_data_table">
                    <tr><td>message :</td><td> <textarea name="txt_message" required class="textbox"  ></textarea>  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_comment" value="Save"/>  </td></tr>
                </table>
            </div>
        </form>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('.hmp_rprt_more_details_btn').click(function () {
                    var id = $(this).children('span:first').html();
                                //Create a Form
                                var $form = $("<form/>").attr("id", "data_form")
                                                        .attr("action", "home_report.php")
                                                        .attr("method", "post");
                                $("body").append($form);
 
                                //Append the values to be send
                                AddParameter($form, "my_id", id);
                                AddParameter($form, "technology", $("#ddlTechnolgy").val());
                                                         //Send the Form
                                $form[0].submit();
                   
                        function AddParameter(form, name, value) {
                                var $input = $("<input />").attr("type", "hidden")
                                                                .attr("name", name)
                                                                .attr("value", value);
                                form.append($input);
                        }

                });
                //contact button
                $('.contact_phone_btn').click(function () {
                    $('#full_bg_dialog').fadeIn(100);
                    $('#phone_dialog').fadeIn(100);
                });
                //sending request btn
                $('#send_request_btn').click(function () {
                    var send_request = 'c';
                    var listing_id = $('#txt_listing_id').val();
                    var names = $('#txt_contact_names').val();
                    var phone = $('#txt_contact_phone').val();
                    var txt_contact_email = $('#txt_contact_email').val();
                    // alert('listing id:'+listing_id+'  names '+names+'  '+phone);
                    $.post('Admin/handler.php', {send_request: send_request, txt_contact_email: txt_contact_email, listing_id: listing_id, names: names, phone: phone}, function (data) {

                    }).complete(function () {
                        alert('Request sent');
                        window.location.replace('http://localhost/Restate/index.php');
                    });

                });
                //when admin selects a request by clicking it
                $('.request_link').click(function () {
                    try {
                        var id = $(this).attr('value');
                        var accept_request = id;
                        $.post('../Admin/handler.php', {accept_request: accept_request}, function (data) {
                        }).complete(function () {
                            alert('Request received');
//           window.location.replace('http://localhost/Restate/Admin/new_report_request.php');
                        });
                    } catch (err) {
                        alert(err);
                    }
                });
                //if we want to delete all the requests
                $('.clear_request_btn').click(function () {
                    var clear_all_request = 'yes';
                    $.post('../Admin/handler.php', {clear_all_request: clear_all_request}, function (data) {
                        alert(data);
                    }).complete(function () {
//                alert('Request cleared');
//           window.location.replace('http://localhost/Restate/Admin/new_report_request.php');
                    });
                });
                $('#close_request_btn').click(function () {
                    $('.home_abs_full').fadeOut(100);
                });
            });
        </script>
    </body>
</html>
<?php

function get_rpt_listing_by_id($list_id) {
    require_once 'Admin/dbConnection.php';
    $con = new my_connection();

    $sql = "select  distinct  price.price_id,listing.listing_id ,listing.description, price.amount,  price.currency,
                price.property,  price.Minimum_advance,  price.deposit_required,
                price.commission,  price.utilities_extra,  price.listing,
                listing.listing_date,  listing.account,  listing.listing_type,  listing.property,
                listing.title,  listing.purpose,  listing.property_category,  listing.location,price.currency,
                image.path,cell.name as cell,province.name as province,district.name as district, sector.name as sector,
                basic_apartment.bedrooms,  basic_apartment.bathrooms,
                basic_land.administrative_location,  basic_land.plot_number,  basic_land.plot_size,  basic_land.available_from,
                features.name as feat
                from listing
                    left join price on price.listing = listing.listing_id
                    left  join image on image.listing = listing.listing_id
                    left join location on listing.location = location.location_id
                    left  join cell on location.cell = cell.cell_id
                    left  join sector on cell.sector = sector.sector_id
                    left  join district on sector.district = district.district_id
                    left  join province on district.province = province.province_id
                    left join basic_apartment on basic_apartment.listing = listing.listing_id
                    left join basic_land on basic_land.listing = listing.listing_id
                        join account on listing.account = account.account_id
                        join listing_type on listing.listing_type = listing_type.listing_type_id
                        join property on listing.property = property.property_id
                        join property_category on listing.property_category = property_category.property_category_id
                    left   join listing_features on listing_features.features = listing.listing_id
                      left   join features on listing_features.features = features.features_id
                      where listing.listing_id=:listingid  group by path, title  ";

    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute(array(":listingid" => $list_id));
    while ($row = $stmt->fetch()) {
        echo '<div class="parts full_center_two_h heit_free no_shade_noBorder ">';
        echo '<div class="parts xx_titles no_paddin_shade_no_Border" >   ' . $row['title'] . ' </div>';

        echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" >   LISTING ID: LST- ' . $row['listing_id'] . ' </div>';
        echo '<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" >   ' . $row['description'] . ' </div>';
        echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Location:  ' . $row['province'] . ',' . $row['district'] . ',' . $row['sector'] . ',' . $row['cell'] . '  </div>';
        echo '<div class="parts off"> Listing:  ' . $row['listing'] . '</div>';
        echo '<div class="parts no_paddin_shade_no_Border  full_center_two_h heit_free"  > Amount:  ' . $row['currency'] . '  ' . $row['amount'] . '     </div>';
        if ($row['bedrooms'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bedrooms:  ' . $row['bedrooms'] . '     </div>';
        }if ($row['bathrooms'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Bathrooms:  ' . $row['bathrooms'] . '     </div>';
        }
        if ($row['plot_size'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Plot size:  ' . $row['plot_size'] . '     </div>';
        }
        if ($row['available_from'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border" style="clear: left;"> Available from:  ' . $row['available_from'] . '     </div>';
        }
        if ($row['administrative_location'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;"> Administrative location:  ' . $row['administrative_location'] . '     </div>';
        }
        if ($row['feat'] != '') {
            echo '<div class="parts no_paddin_shade_no_Border full_center_two_h heit_free" style="clear: left;">Other Features:  ' . $row['feat'] . '     </div>';
        }
        echo '<div class="parts no_paddin_shade_no_Border  full_center_two_h heit_free contact_phone"  >'
        . ''
        . '<div class="parts contact_phone_btn link_cursor"> Contact  </div>'
        . '    </div>';
        echo '<img class="parts no_shade_noBorder" src="web_images/property/' . $row['path'] . '" style=""/>';
        echo '<div class="parts off"> Minimum price: ' . $row['Minimum_advance'] . ' </div>';
        echo '<div class="parts off"> deposit required:  ' . $row['deposit_required'] . ' </div>';
        echo '<div class="parts off"> Commission:  ' . $row['commission'] . '</div>';
        echo '<div class="parts off"> Utilities:  ' . $row['utilities_extra'] . '</div>';
        echo '<div class="parts off"> listing date: ' . $row['listing_date'] . '</div>';
        echo '<div class="parts off"> Account:  ' . $row['account'] . '</div>';
        echo '<div class="parts off"> Listing type:  ' . $row['listing_type'] . '</div>';
        echo '<div class="parts off"> Property  ' . $row['property'] . '</div>';
        echo '<div class="parts off"> Purpose:  ' . $row['purpose'] . '  </div>';
        echo '<div class="parts off"> Property category  ' . $row['property_category'] . '</div>';

        echo '</div>';
    }
}

function list_comment($min) {
    $database = new my_connection();
    $db = $database->getCon();
    $sql = "select * from comment where comment.commentdeleted='no'  ";
    $stmt = $db->prepare($sql);
    $stmt->execute(array(":min" => $min));
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> comment </td>
                <td> commentdeleted </td><td> message </td><td> account </td><td> date </td>
                <td>Delete</td><td>Update</td></tr></thead>
        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?><tr> 

                <td>
                    <?php echo $row['comment_id']; ?>
                </td>
                <td class="commentdeleted_id_cols comment " title="comment" >
                    <?php echo _e($row['commentdeleted']); ?>
                </td>
                <td>
                    <?php echo _e($row['message']); ?>
                </td>
                <td>
                    <?php echo _e($row['account']); ?>
                </td>
                <td>
                    <?php echo _e($row['date']); ?>
                </td>

                <td>
                    <a href="#" class="comment_delete_link" style="color: #000080;" value="
                       <?php echo $row['comment_id']; ?>">Delete</a>
                </td>
                <td>
                    <a href="#" class="comment_update_link" style="color: #000080;" value="
                       <?php echo $row['comment_id']; ?>">Update</a>
                </td></tr>
            <?php
            $pages+=1;
        }
        ?></table>
    <?php
}

function get_first_comment() {
    $con = new my_connection();
    $sql = "select comment.comment_id from comment
                    order by comment.comment_id asc
                    limit 1";
    $stmt = $con->getCon()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $first_rec = $row['comment_id'];
    return $first_rec;
}

function new_comment($commentdeleted, $message, $account, $date, $listing) {
    try {
        require_once('web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into comment values(:comment_id, :commentdeleted,  :message,  :account,  :date, :listing)");
        $stm->execute(array(':comment_id' => 0, ':commentdeleted' => $commentdeleted, ':message' => $message, ':account' => $account, ':date' => $date, ':listing' => $listing));
    } catch (PDOException $e) {
        echo 'Error .. ' . $e;
    }
}

function new_comment_replies($comment_repliesdeleted, $message, $date, $account, $comment) {
    try {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into comment_replies values(:comment_replies_id, :comment_repliesdeleted,  :message,  :date,  :account,  :comment)");
        $stm->execute(array(':comment_replies_id' => 0, ':comment_repliesdeleted' => $comment_repliesdeleted, ':message' => $message, ':date' => $date, ':account' => $account, ':comment' => $comment
        ));
    } catch (PDOException $e) {
        echo 'Error .. ' . $e;
    }
}
